package common;

import java.sql.*;
public class JDBCConnection {

	public String getPasscode(String userName,String sqlQuery) throws ClassNotFoundException, SQLException {

		String passcode=null;

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection Con = DriverManager.getConnection("jdbc:oracle:thin:@10.68.47.122:1521/MPSAUAT_HA","PORTAL_ADM", "d3fPWgb_mpw");		
			//System.out.println("connection Successful");
			if (Con != null) {
				System.out.println("Connection Established");
			} else {
				System.out.println("Failed to make connection!");
			}

			Statement stmt = Con.createStatement();

			ResultSet rs=  stmt.executeQuery(sqlQuery+"'"+userName+"';");
			while(rs.next()){
				passcode= rs.getString("PASSCODE");
				System.out.println("The Passcode is "+passcode);

			}
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}

		return passcode;
	}
	
	public String getEncryptedUserName(String userName,String sqlQuery) throws ClassNotFoundException, SQLException {

		String encryptedUserName=null;

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection Con = DriverManager.getConnection("jdbc:oracle:thin:@10.68.47.122:1521/MPSAUAT_HA","PORTAL_ADM", "d3fPWgb_mpw");		
			//System.out.println("connection Successful");
			if (Con != null) {
				System.out.println("Connection Established");
			} else {
				System.out.println("Failed to make connection!");
			}

			Statement stmt = Con.createStatement();
			ResultSet rs=  stmt.executeQuery(sqlQuery+"'"+userName+"';");
			while(rs.next()){
				encryptedUserName= rs.getString("HASH_VALUE");
				System.out.println("The Passcode is "+encryptedUserName);

			}
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}

		return encryptedUserName;
	}

	public String getLoginAttemptCount(String userName) throws ClassNotFoundException, SQLException {

		String attemptCount=null;

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection Con = DriverManager.getConnection("jdbc:oracle:thin:@10.68.47.122:1521/MPSAUAT_HA","PORTAL_ADM", "d3fPWgb_mpw");		
			//System.out.println("connection Successful");
			if (Con != null) {
				System.out.println("Connection Established");
			} else {
				System.out.println("Failed to make connection!");
			}

			Statement stmt = Con.createStatement();

			ResultSet rs=  stmt.executeQuery("SELECT INVALID_LOGIN_COUNT FROM USR u where u.alliance_code='EMS' and u.username="+"'"+userName+"';");
			while(rs.next()){
				attemptCount= rs.getString("INVALID_LOGIN_COUNT");
				System.out.println("The Passcode is "+attemptCount);

			}
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}

		return attemptCount;
	}
	
	public void resetPasswordExpirationDate(String userName, String sqlQuery) throws ClassNotFoundException, SQLException {

		//String attemptCount=null;

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection Con = DriverManager.getConnection("jdbc:oracle:thin:@10.68.47.122:1521/MPSAUAT_HA","PORTAL_ADM", "d3fPWgb_mpw");		
			//System.out.println("connection Successful");
			if (Con != null) {
				System.out.println("Connection Established");
			} else {
				System.out.println("Failed to make connection!");
			}

			Statement stmt = Con.createStatement();
			String query=sqlQuery+"'"+userName+"';";
			System.out.println("The sql query is:"+sqlQuery);
			ResultSet rs=  stmt.executeQuery(query);
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}

	}
	
	public void lockAccount(String userName, String sqlQuery) throws ClassNotFoundException, SQLException {

		//String attemptCount=null;

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection Con = DriverManager.getConnection("jdbc:oracle:thin:@10.68.47.122:1521/MPSAUAT_HA","PORTAL_ADM", "d3fPWgb_mpw");		
			//System.out.println("connection Successful");
			if (Con != null) {
				System.out.println("Connection Established");
			} else {
				System.out.println("Failed to make connection!");
			}

			Statement stmt = Con.createStatement();
			String query=sqlQuery+"'"+userName+"';";
			System.out.println("The sql query is:"+sqlQuery);
			ResultSet rs=  stmt.executeQuery(query);
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}

	}
	
	public static String GetTheDbqueryValue(String sqlQuery) throws ClassNotFoundException, SQLException {
		String passcode=null;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection Con = DriverManager.getConnection("jdbc:oracle:thin:@10.68.47.122:1521/MPSAUAT_HA","PORTAL_ADM", "d3fPWgb_mpw");		
		//System.out.println("connection Successful");
		if (Con != null) {
            System.out.println("Connection Established");
        } else {
            System.out.println("Failed to make connection!");
        }
		
		Statement stmt = Con.createStatement();
		
		 ResultSet rs=  stmt.executeQuery(sqlQuery);
		//ResultSet rs= stmt.executeQuery("select username,passcode from usr u where u.username='TestAutomationBO';");
		 while(rs.next()){
		 passcode=    rs.getString("passcode");
		 System.out.println("Passcode is : "+passcode);
		   
		  }
		}
		  catch (Exception e) 
		{
		         System.out.println(e.getMessage());
		  }
		return passcode;
	}



}
