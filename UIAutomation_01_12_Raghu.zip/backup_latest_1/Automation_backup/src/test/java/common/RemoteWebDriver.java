package common;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import net.serenitybdd.core.SerenitySystemProperties;
import net.thucydides.core.ThucydidesSystemProperty;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;
import net.thucydides.core.webdriver.DriverSource;
import util.Config;

public class RemoteWebDriver implements DriverSource {
	static String driverName="";
	static String provider="";

	AppiumDriver driver=null;

	@Override
	@SuppressWarnings("rawtypes")
	public WebDriver newDriver() {
		// TODO Auto-generated method stub     
		WebDriver driver = null;
		// Properties prop=new Properties();

		// String timeoutMilli = ConfigDetails.prop.getProperty("webdriver.implicitWaitTimeoutMilli", "0");
		String iePageLoadTimeout = ""; //Config.get("setup","webdriver.ie.pageLoadTimeout", "60");
		try {

			EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();

			DesiredCapabilities capabilities =new DesiredCapabilities();
			System.out.println("Platform name is:"+variables.getProperty("saucelabs.target.platform"));    	
			capabilities.setCapability("platformName",variables.getProperty("saucelabs.target.platform"));

			System.out.println("Appium Version is:"+variables.getProperty("appium.version"));
			capabilities.setCapability("appiumVersion",variables.getProperty("appium.version"));
			
			System.out.println("Device name is:"+variables.getProperty("appium.deviceName"));
			capabilities.setCapability("deviceName",variables.getProperty("appium.deviceName"));
			
			System.out.println("Platform Version is:"+variables.getProperty("appium.platformVersion"));
			capabilities.setCapability("platformVersion",variables.getProperty("appium.platformVersion"));
			
			System.out.println("Browser Name is:"+variables.getProperty("appium.browserName"));
			capabilities.setCapability("browserName",variables.getProperty("appium.browserName"));

			//System.setProperty("webdriver.chrome.driver","D:\\New folder\\Automation\\libs\\chromedriver.exe");
			// capabilities.setCapability("app", "sauce-storage:GuineaPigApp-debug.apk");
			//capabilities.setCapability("name","SauceLabsTest");
			//	        capabilities.setCapability("useProxy","true");
			//	        capabilities.setCapability("proxyHost","proxy.cognizant.com");
			//	        capabilities.setCapability("proxyPort","6050");
			//	        capabilities.setCapability("proxyUserDomain","cts");
			//	        capabilities.setCapability("proxyUser","509146");
			//  capabilities.setCapability("deviceOrientation", "portrait");
			//  capabilities.setCapability("appiumVersion", "1.5.1");

			System.out.println("SauceLabs URL is:"+variables.getProperty("saucelabs.url"));
			driver = new AndroidDriver(new URL(variables.getProperty("saucelabs.url")), capabilities);


			//	        } catch (IOException ex) {
			//	            ex.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return driver;
	}

	@Override
	public boolean takesScreenshots() {
		// TODO Auto-generated method stub
		return true;
	}

}
