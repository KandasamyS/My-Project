/*package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.java.Before;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(monochrome=true,
features="src/test/resources/features",
glue="stepdefinitions",
strict=true,
tags="@ui,@uiapi,@funct")
public class UITestRunner {*/

	/*@Before
	public void setup()
	{
		System.out.println("Setting up env");
		System.out.println( "Vrtify");
		@CucumberOptions(tags="@test")
	}*/
//}
