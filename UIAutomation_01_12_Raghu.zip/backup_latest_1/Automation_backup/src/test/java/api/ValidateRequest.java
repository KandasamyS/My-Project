//package api;
//
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.File;
//import java.sql.CallableStatement;
//import java.sql.Connection;
//import java.sql.ResultSet;
//import java.util.Iterator;
//
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
//import javax.xml.xpath.XPath;
//import javax.xml.xpath.XPathConstants;
//import javax.xml.xpath.XPathFactory;
//
//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
//import org.w3c.dom.Node;
//import org.w3c.dom.NodeList;
//import org.xml.sax.InputSource;
//import org.json.simple.JSONObject;
//import org.json.simple.JSONArray;
////import org.json.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;
////import org.json.JSONArray;
//import org.junit.Assert;
//
//import com.jayway.restassured.response.Response;
//
//import net.thucydides.core.annotations.Step;
//import stepdefinitions.Apidefinitions;
//
//
//
//public class ValidateRequest {
//
///*	@Step	
//	public String statuscode(String statuscode, Response responsebody){
//		String strStatusResponse;
//		String strStatusCode;
//		int stat = responsebody.andReturn().statusCode();
//		strStatusCode=Integer.toString(stat);
//		org.junit.Assert.assertEquals(Integer.parseInt(statuscode),stat);
//		responsebody.andReturn().peek();
//		strStatusResponse=""+"|"+responsebody.asString();
//		return strStatusResponse;
//	}
//	
//	@Step
//	public void resultvalidation(String arg1, String arg2, Response responsebody){
//		String nodeValue = responsebody.andReturn().body().jsonPath().get(arg1).toString();
//		if(nodeValue.contains("[" + arg2 + "]")){
//			org.junit.Assert.assertTrue(true);
//		}else{
//			//org.junit.Assert.assertThat("Expected is:" + arg2 + "Actual is:" + nodeValue, "T","T");			
//			org.junit.Assert.assertTrue(false);
//		}
//	}
//	
//	@Step
//	public static void writexml(String strFileName,String output) 
//    {
//          try
//          {
//               String strPath= "D:\\Results\\Response\\"+strFileName+".json";
//               
//               System.out.println("File to write: "+strPath);
//               File file = new File(strPath); // If you want to write as file to local.
//               FileWriter fileWriter = new FileWriter(file);
//               fileWriter.write(output);
//               fileWriter.close();
//               
//          }
//          catch(Exception e)
//          {
//               // Exit();
//          }
//    }
//public static String xmlverify(String strFilename,String strNode,String strResponse)  
//    {
//          try
//          {
//              
//
//               //Creates a new File instance 
//               File fXmlFile = new File(strFilename);
//
//               //Obtain a new instance of a DocumentBuilderFactory.
//               DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
//
//               //Creates a new instance of a DocumentBuilder using the currently configured parameters.
//               DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
//               Document doc = dBuilder.parse(fXmlFile);
//               String[] strArray= strResponse.split("\\,");
//               String OutputResponse=null;
//
//               doc.getDocumentElement().normalize();
//
//               System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
//
//               //Returns a NodeList of all the Elements in document order with a given tag name and are contained in the document.
//               NodeList nList = doc.getElementsByTagName(strNode);
//
//               System.out.println("----------------------------");
//
//               //verify the nodes parameter value.
//               String strData;
//               //Execute a loop through NodeList
//               for (int temp = 0; temp < nList.getLength(); temp++) 
//               {
//                    // get the base node name which is in first position.
//                    Node nNode = nList.item(temp);
//
//                    System.out.println("Current Element :" + nNode.getNodeName());
//
//                    if (nNode.getNodeType() == Node.ELEMENT_NODE) 
//                    {
//                          //parse a Node into Element(represents an element in an HTML or XML document)
//                          Element eElement = (Element) nNode;
//
//                          //Execute a loop through the array of nodes which we wish to refer or read.
//                          for(int i=0;i<strArray.length;i++)
//                          {
//                               //Returns a NodeList of all descendant Elements with a given tag name, in document order.
//                               NodeList nodeName = eElement.getElementsByTagName(strArray[i]);
//                               
//                               //Execute a loop through the NodeList of all elements with a given tag name
//                               for (int j = 0; j < nodeName.getLength(); j++) 
//                               {
//                                    //Get text content of particular given tag name.
//                                    strData= nodeName.item(j).getTextContent();
//                                    if(OutputResponse==null)
//                                    {
//                                          OutputResponse=strData;
//                                    }
//                                    else
//                                    {
//                                         OutputResponse=OutputResponse+";"+strData;
//
//                                    }
//                               }
//                          }
//                        return OutputResponse;
//                    }
//               }
//
//          }catch(Exception e)
//          {
//          lib.WriteReportStep("2", "Reading Data from XML Response", "Exception Occured" ,e.getLocalizedMessage(), "Failed");
//          Exit();
//          }
//          return null;         
//    }  
////String strStatus,String strError,String strResponse
//public static String JsonRead(String strFile,String[] strValidate) throws FileNotFoundException, IOException, ParseException
//{
//	String Reponse = null;
//	String output=null;
//	String strData;
//	 JSONParser parser = new JSONParser();
//	 Object objJson = parser.parse(new FileReader("D:\\Results\\Response\\"+strFile+".json"));
//	 JSONObject jtrsonObject = (JSONObject) objJson; 
//	 System.out.println(jtrsonObject.toJSONString());
//     String strStatus=(String) jtrsonObject.get(strValidate[0]);
//     if(strStatus!=null && strStatus.equalsIgnoreCase("success"))
//     {
//    	 System.out.println("Api response status is success");
//    	 JSONObject strParentID= (JSONObject) jtrsonObject.get("response");
//         
//         String[] ArrayRep=strValidate[2].split("\\:");
//         int nodeLen=ArrayRep.length;
//         for(int i=0;i<nodeLen;i++)
//         {
//        	 strData= (String) strParentID.get(ArrayRep[i]);
//        	 if(output==null)
//             {
//        		 output=strData;
//             }
//             else
//             {
//            	 output=output+":"+strData;
//
//             }
//         }
//         Reponse=strStatus+"|"+(String)jtrsonObject.get(strValidate[1])+"|"+output;
//     }
//     else if(strStatus!=null && strStatus.equalsIgnoreCase("errors"))
//     {
//    	 String strArray;
//    	 String[] strVal;
//    	 String errData;
//    	 String errOutput = null;
//    	 JSONArray ArrJson = (JSONArray) jtrsonObject.get("errors");
//    	 @SuppressWarnings("rawtypes")
//    	 Iterator iterator = ArrJson.iterator();
//    	 while (iterator.hasNext()) 
//    	 {
//    		 strArray=iterator.next().toString();
//    		 strArray=strArray.replaceAll("[{}\"]","");
//    		 System.out.println("Error Reponse"+strArray);
//    		 strVal=strArray.split("\\,");
//    		 for( int m=0;m<strVal.length;m++)
//    		 {
//    			 System.out.println("value: "+strVal[m]);
//    			 //System.out.println(strCode[0].replace("\"", ""));
//    			  String[] strCode=strVal[m].split("\\:");
//    			 
//    			 if(strCode[0].equalsIgnoreCase("code")||strCode[0].equalsIgnoreCase("message") )
//    			 {
//    				 errData= strCode[1];
//    	        	 if(errOutput==null)
//    	             {
//    	        		 errOutput=errData;
//    	             }
//    	             else
//    	             {
//    	            	 errOutput=errOutput+":"+errData;
//
//    	             }
//    			 }
//    		 }
//    		
//    	 }
//    	 Reponse=(String) jtrsonObject.get(strValidate[0])+"|"+errOutput;
//     }
//     else if(strStatus==null)
//     {
//    	 String strcode= (String) jtrsonObject.get("code");
//    	 String strmessage= (String) jtrsonObject.get("message");
//    	 boolean straccess= (boolean) jtrsonObject.get("access-denied");
//    	 String strcause= (String) jtrsonObject.get("cause");
//    	 Reponse=strcode+"|"+strmessage+"|"+straccess+"|"+strcause;
//     }
//     else
//     {
//    	 System.out.println("Exception thrown");
//     }
//     return Reponse;
//	
//}
//
//public static String JsonFetch() throws FileNotFoundException, IOException, ParseException
//{
//	String Reponse = null;
//	String output=null;
//	String strData;
//
//		JSONParser parser = new JSONParser();
//		JSONArray ArrJson = (JSONArray) parser.parse(new FileReader("D:\\request for application api.json"));
//		 for (Object o : ArrJson)
//		  {
//		    JSONObject person = (JSONObject) o;
//
//		    String name = (String) person.get("status");
//		    System.out.println(name);
//
//	  //  String city = (String) person.get("errors");
//	 //out.println(city);
////
////		    String job = (String) person.get("job");
////		    System.out.println(job);
//
//		    JSONArray cars = (JSONArray) person.get("errors");
//
//		    for (Object c : cars)
//		    {
//		      System.out.println(c+"");
//		    }
//		  }
//	  
//	
//		return null;
//	
//}
//public static String readFile(String filename) {
//    String result = "";
//    try {
//        BufferedReader br = new BufferedReader(new FileReader(filename));
//        StringBuilder sb = new StringBuilder();
//        String line = br.readLine();
//        while (line != null) {
//            sb.append(line);
//            line = br.readLine();
//        }
//        result = sb.toString();
//    } catch(Exception e) {
//        e.printStackTrace();
//    }
//    return result;
//}*/
//
//
//@Step("Verify Response")
//public void verifyresponse(String status, String ErrorCode, String Message, String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws ParseException{
//	String strStatus = Apidefinitions.responsebody.body().jsonPath().getJsonObject("status");
//	System.out.println("***&&&&"+strStatus);
//	if((strStatus!=null && strStatus.equalsIgnoreCase("success"))){
//	Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getJsonObject("status"), status);
//	System.out.println("*****" +status);
//	}
//    else if(strStatus!=null && strStatus.equalsIgnoreCase("error"))
//     {
//		 Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getJsonObject("status"), status);
//		 Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getString("errors.code[0]"), ErrorCode);
//		 Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getJsonObject("errors.message[0]"), Message);
//     }
//    else if(strStatus==null)
//    {
//		 Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getJsonObject("code"), ErrorCode);
//		 Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getJsonObject("message"), Message);
//		 Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getJsonObject("access-denied"), Authaccessdenied);
//		 Assert.assertEquals(Apidefinitions.responsebody.body().jsonPath().getJsonObject("cause"), AuthErrCause);
//    }
//	 
//}
//
//
//
//}
