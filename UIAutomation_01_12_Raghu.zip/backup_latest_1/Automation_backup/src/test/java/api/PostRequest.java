//package api;
//
//
//import org.apache.commons.collections.map.LinkedMap;
//import org.apache.xmlbeans.impl.xb.xsdschema.Public;
//import org.eclipse.jetty.websocket.api.Session;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;
//import org.openqa.selenium.remote.server.DriverSessions;
//import org.openqa.selenium.remote.server.handler.GetAllSessions;
//import org.openqa.selenium.remote.server.handler.GetCurrentUrl;
//import org.junit.Test;
//import org.junit.Assert;
//
//import com.jayway.restassured.matcher.ResponseAwareMatcher;
//import com.jayway.restassured.response.Response;
//import com.jayway.restassured.response.ResponseBody;
//import com.jayway.restassured.response.ValidatableResponse;
//import com.jayway.restassured.specification.RequestSpecification;
//import com.thoughtworks.selenium.webdriven.commands.GetCookieByName;
//
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.LinkedHashMap;
//import java.util.Map;
//
//import javax.servlet.http.HttpSession;
//import javax.swing.plaf.synth.SynthSpinnerUI;
//
//import cucumber.api.java.en.Given;
//import net.thucydides.core.annotations.Step;
//import stepdefinitions.Apidefinitions;
//import stepdefinitions.ServiceURI;
//import net.serenitybdd.*;
//import net.serenitybdd.core.Serenity;
//import net.serenitybdd.rest.SerenityRest;
//
//
//
//public class PostRequest extends SerenityRest{
//
//
//@Step
//public void postGETRequest(String appurl){
//	/*String uriVal = uri.toString().replace("{countryCode}", LoadRequest.countryCode); //getURI(uri); // replace countrycide
//	System.out.println("===>"+uriVal);*/
//	post(appurl);
//	
//}
//
//@SuppressWarnings("unchecked")
//@Step
//public void postGETRequest_getsalessummary(String appurl, String currency){
//		
//	Apidefinitions.responsebody = 
//			given()
//			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
//			.headers(LoadRequest.jsonAsMap).param("currency",currency).get(appurl).andReturn();
//}
//
//@SuppressWarnings("unchecked")
//@Step
//public void postGETRequest_getProfileList(String appurl, String userType){
//		
//	Apidefinitions.responsebody = 
//			given()
//			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
//			.headers(LoadRequest.jsonAsMap).param("userType",userType).get(appurl).andReturn();
//}
//
//@SuppressWarnings("unchecked")
//@Step
//public void postGETRequest_getUserDetails(String appurl){
//		
//	Apidefinitions.responsebody = 
//			given()
//			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
//			.headers(LoadRequest.jsonAsMap).get(appurl).andReturn();
//}
//
//@SuppressWarnings("unchecked")
//@Step
//public void postGETRequest_getUserList(String appurl, String pageNumber, String accountStatus, String profile, String firstName, String lastName, String userName){
//		
//	Apidefinitions.responsebody = 
//			given()
//			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
//			.headers(LoadRequest.jsonAsMap)
//			.param("pageNumber",pageNumber)
//			.param("accountStatus",accountStatus)
//			.param("profile",profile)
//			.param("firstName",firstName)
//			.param("lastName",lastName)
//			.param("userName",userName)
//			.get(appurl).andReturn();
//}
//
//public String getURI(String uri){
//	String getreqUri = null;
//	/*if(uri.equals("getStateURI"))
//	{
//	getreqUri=ServiceURI.getStateURI.toString().replace("{countryCode}", LoadRequest.countryCode);
//	
//	}*/
//	return getreqUri;
//		
//}
//
//public static void post(String appurl){
//	 Apidefinitions.responsebody = given().headers(LoadRequest.jsonAsMap1).get(appurl).andReturn();		
//	// .proxy("proxy.cognizant.com", 6050)
///*	 //body = haspmap: object mapper
//	 Apidefinitions.responsebody = given().headers(LoadRequest.jsonAsMap).body(body)\\string body.*/
//}
//
//
///*public Map authenticateuser(String appurl, String userName, String password, String allianceCode){
//	//countryCode=countryCd;
//	LinkedHashMap<String,String> Authenticateuser = new LinkedHashMap<>();
//	Authenticateuser.put("userName",userName);
//	Authenticateuser.put("password",password);
//	Authenticateuser.put("allianceCode",allianceCode);
//	return Authenticateuser;
//	System.out.println();
//	}
//*/
///*public Map postND(String uri, Map Authenticateuser){
//	 Apidefinitions.responsebody = given()
//			 .param("userName",userName)
//			 .param("password",Authenticateuser)
//			 .param("AllianceCode",Authenticateuser)
//	 		 .post(uri);
//	 		 String strtoken = Apidefinitions.responsebody.cookie(getDefaultSessionId());
//	  
//			
//	 		System.out.println("sessiontoken"+strtoken);
//	 		System.out.println(getDefaultSessionId().toString());
//	 	
//	return Authenticateuser;
//	
//
//}*/
//
//@Step
//public Response postND(String appurl, String userName, String password, String allianceCode){
//	 Apidefinitions.responsebody = given()
//			 .param("userName",userName)
//			 .param("password",password)
//			 .param("AllianceCode",allianceCode)
//			 .when()
//			 .post(appurl);
//	 		 return then()
//	 		 .extract()
//	 		 .response();
//			 
//}
//
//@SuppressWarnings("unchecked")
//@Step
//public Response postrequest_logout(String appurl){
//	 Apidefinitions.responsebody = given()
//			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
//			.headers(LoadRequest.jsonAsMap)
//			.when()
//		    .post(appurl);
//	 		return then()
//	 		.extract()
//	 		.response();
//}
//
//@SuppressWarnings("unchecked")
//@Step
//public Response postrequest_invalidateSession(String appurl,String allianceCode){
//	 Apidefinitions.responsebody = given()
//			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
//			.headers(LoadRequest.jsonAsMap)
//			.param("allianceCode",allianceCode)
//			.when()
//		    .post(appurl);
//	 		return then()
//	 		.extract()
//	 		.response();
//	 		
//}
//	
//	
//
//
///*public HttpSession postND(String uri, Map Authenticateuser){
//	 Apidefinitions.responsebody = given()
//			 .param("userName","DemoAccount1")
//			 .param("password","Password@1")
//			 .param("AllianceCode","EMS")
//			 .when()
//			 .post(uri);//LoadRequest.jsonAsMap
//	 		
//	Apidefinitions.strSess= (HttpSession) given()
//			 .param("userName","DemoAccount1")
//			 .param("password","Password@1")
//			 .param("AllianceCode","EMS")
//			 .when()
//			 .post(uri);
//	
//	return (HttpSession) Apidefinitions.strSess;
//	
//}*/
//
//
//
///*private ResponseAwareMatcher<Response> equalTo(String status) {
//	// TODO Auto-generated method stub
//	return null;
//}
//
//@Step
//public void postPOSTRequest(String uri, Map Authenticateuser){
//	
//	 //Map postreq = (Map) postND(uri,Authenticateuser);
//	postND(uri,Authenticateuser);
//	
//
//	
//	 
//}
//
//public JSONObject postJson(String strJsonpath) throws FileNotFoundException, IOException, ParseException
//{
//    JSONParser parser = new JSONParser();
//    Object obj = parser.parse(new FileReader(strJsonpath));
//    JSONObject jsonObject = (JSONObject) obj;
//	return jsonObject;
//		 
//}*/
//
//
//
//
//}
