/*package ui.Signon;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import common.JDBCConnection;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;

public class AccountActivationPage extends PageObject {

	WebDriver driver =null;

	String Result=null;

	JDBCConnection jdbcConnection;

	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	CommunicationSummaryPage communicationSummaryPage;
	AccountActivationPageObjects accountActivationPageObjects;

	@Step
	public String launchInitiationLink()
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		String url=communicationSummaryPage.initiationLink;
		System.out.println("The URL to be launched is:"+url);
		driver.get(url);
		while(!accountActivationPageObjects.letsGo.isCurrentlyVisible())
		{
			waitFor(accountActivationPageObjects.letsGo);
		}
		if(accountActivationPageObjects.letsGo.isCurrentlyVisible())
		{
			Result="Passed";
			waitFor(accountActivationPageObjects.letsGo);
			executor.executeScript("arguments[0].click()",accountActivationPageObjects.letsGo);
		}

		else
		{
			Result="Failed";
		}

		return Result;
	}

	public String enterPasscode(String userName,String mobileNumber) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		if(accountActivationPageObjects.mobileNumber.getText().equals(mobileNumber))
		{
			//			waitFor(accountActivationPageObjects.resendPasscode);
			//			executor.executeScript("arguments[0].click()",accountActivationPageObjects.resendPasscode);

			//String passcode=jdbcConnection.getPasscode(userName);
			String passcode=JOptionPane.showInputDialog("Enter the passcode:");
			System.out.println("The received Passcode is:"+passcode);

			waitFor(accountActivationPageObjects.verificationCodeTextBox).click();
			waitFor(accountActivationPageObjects.verificationCodeTextBox).sendKeys(passcode);
			waitFor(accountActivationPageObjects.proceed);
			executor.executeScript("arguments[0].click()",accountActivationPageObjects.proceed);

			if(!accountActivationPageObjects.passcodeErrorMessage.isCurrentlyVisible())
			{
				Result="Passed";
			}
			else
			{
				Result=accountActivationPageObjects.passcodeErrorMessage.getText();
			}
		}
		else
		{
			Result="Phone numbers do not match";
		}

		return Result;
	}

	public String setPasswordAndPortalLanguage(String password, String portalLanguage)
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		String language=null;
		System.out.println("The password to be set is:"+password);

		executor.executeScript("arguments[0].click()",accountActivationPageObjects.password);
		waitFor(accountActivationPageObjects.password).sendKeys(password);
		executor.executeScript("arguments[0].click()",accountActivationPageObjects.confirmPassword);
		waitFor(accountActivationPageObjects.confirmPassword).sendKeys(password);

		switch(portalLanguage)
		{
		case "Dutch"   : language="Nederlands";break;
		case "French"  : language="Fran�ais";break;
		case "German"  : language="Deutsch";break;
		case "English" : language="English";break;
		}

		executor.executeScript("arguments[0].click()",accountActivationPageObjects.languageDropDown);

		List<WebElement> languageList=driver.findElements(accountActivationPageObjects.languageList);

		while(languageList.size()==0)
		{
			languageList=driver.findElements(accountActivationPageObjects.languageList);
		}

		for(WebElement element:languageList)
		{
			if(element.getText().equals(portalLanguage))
			{
				executor.executeScript("arguments[0].click()",element);
			}
		}

		waitFor(accountActivationPageObjects.acceptTermsAndConditions);
		executor.executeScript("arguments[0].click()",accountActivationPageObjects.acceptTermsAndConditions);

		System.out.println("The chosen language is:"+language);
		if(accountActivationPageObjects.languageDropDown.getText().equalsIgnoreCase(language))
		{
			waitFor(accountActivationPageObjects.continueButton);
			executor.executeScript("arguments[0].click()",accountActivationPageObjects.continueButton);
			if(!accountActivationPageObjects.passwordErrorMessage.isCurrentlyVisible())
			{
				Result="Passed";
			}
			else
			{
				Result=accountActivationPageObjects.passwordErrorMessage.getText();
			}
		}
		else
		{
			Result="Language not changed";
		}

		return Result;
	}

	public String validateAccountStatus()
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		if(accountActivationPageObjects.navigateToLoginPage.isCurrentlyVisible())
		{
			Result="Passed";
			executor.executeScript("arguments[0].click()",accountActivationPageObjects.navigateToLoginPage);
		}
		else
		{
			Result="Failed";
		}
		return Result;
	}

	public String resendPasscodeForPasswordReset(String userName,String passwordResetLink,String sqlQuery) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		WebDriverWait wait=new WebDriverWait(driver,20);

		String encryptedUserName=jdbcConnection.getEncryptedUserName(userName,sqlQuery);
		String url=passwordResetLink+encryptedUserName;
		System.out.println("the password Reset link is:"+url);
		driver.get(url);

		while(!accountActivationPageObjects.passwordReset_verificationText.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(accountActivationPageObjects.passwordReset_verificationText));
		}

		executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_resendPasscode);

		//String passcode=jdbcConnection.getPasscode(userName);
		String passcode=JOptionPane.showInputDialog("Enter the passcode:");
		System.out.println("The passcode is:"+passcode);

		accountActivationPageObjects.passwordReset_passcodeTextBox.sendKeys(passcode);

		executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_done);

		if(!accountActivationPageObjects.passwordReset_passcodeErrorMessage.isCurrentlyVisible())
		{
			if(accountActivationPageObjects.passwordReset_newPasswordText.isCurrentlyVisible())
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result=accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText();
		}

		return Result;
	}

	public String validatePasswordResetLinkStatus(String userName, String newPassword, String confirmPassword, String passwordResetLink, String sqlQuery) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		String encryptedUserName=jdbcConnection.getEncryptedUserName(userName,sqlQuery);
		String url=passwordResetLink+encryptedUserName;
		System.out.println("the password Reset link is:"+url);
		driver.get(url);

		//String passcode=jdbcConnection.getPasscode(userName);
		String passcode=JOptionPane.showInputDialog("Enter the passcode:");
		System.out.println("The passcode is:"+passcode);

		accountActivationPageObjects.passwordReset_passcodeTextBox.sendKeys(passcode);

		executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_done);

		if(!accountActivationPageObjects.passwordReset_passcodeErrorMessage.isCurrentlyVisible())
		{
			if(accountActivationPageObjects.passwordReset_newPasswordText.isCurrentlyVisible())
			{
				waitFor(accountActivationPageObjects.passwordReset_newPassword).sendKeys(newPassword);
				waitFor(accountActivationPageObjects.passwordReset_confirmPassword).sendKeys(confirmPassword);
				executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_changePasswordButton);
				if(accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText().contains("Your password has been successfully changed. You are ready to log in."))
				{
					driver.get(url);
					if(accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText().contains("MPBE00057") || accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText().contains("Username already active"))
					{
						Result="Passed";
					}
					else
					{
						Result="Failed";
					}
				}
				else
				{
					Result="Password not changed";
				}

			}
		}
		else
		{
			Result=accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText();
		}

		return Result;
	}
	
	public String resetPasswordFromPasswordResetLink(String userName,String passwordResetLink,String sqlQuery,String newPassword,String confirmPassword) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		WebDriverWait wait=new WebDriverWait(driver,20);

		//String encryptedUserName=jdbcConnection.getEncryptedUserName(userName);
		//String url=passwordResetLink+encryptedUserName;
		
		String url="https://uat1.merchantportal.firstdata.eu/emsMerchantUI/#/reset2?userName=2432612431302472544e37792f33743173796a763234525a787130662e50713149655971524e556773627466763371772e313042456e416c5a77624f";
		System.out.println("the password Reset link is:"+url);
		driver.get(url);

		while(!accountActivationPageObjects.passwordReset_verificationText.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(accountActivationPageObjects.passwordReset_verificationText));
		}

		//executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_resendPasscode);

		//String passcode=jdbcConnection.getPasscode(userName);
		String passcode=JOptionPane.showInputDialog("Enter the passcode:");
		System.out.println("The passcode is:"+passcode);

		accountActivationPageObjects.passwordReset_passcodeTextBox.sendKeys(passcode);

		executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_done);


		if(!accountActivationPageObjects.passwordReset_passcodeErrorMessage.isCurrentlyVisible())
		{
			waitFor(accountActivationPageObjects.passwordReset_newPasswordText);
			if(accountActivationPageObjects.passwordReset_newPasswordText.isCurrentlyVisible())
			{
				accountActivationPageObjects.passwordReset_newPassword.sendKeys(newPassword);
				accountActivationPageObjects.passwordReset_confirmPassword.sendKeys(confirmPassword);
				executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_changePasswordButton);
				
				if(accountActivationPageObjects.passwordReset_resetPasswordSuccessMessage.getText().contains("Your password has been successfully changed. You are ready to log in."))
				{
					Result="Passed";
				}
				else
				{
					Result=accountActivationPageObjects.passwordReset_resetPasswordErrorMessage.getText();
				}
			}
			else
			{
				Result="Could not navigate to the Reset Password Page";
			}
			
		}
		else
		{
			Result=accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText();
		}

		return Result;
	}
	

}
*/