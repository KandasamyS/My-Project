package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.SignonObjects;

public class MerchantAdminPage extends PageObject {

	WebDriver driver =null;

	MerchantAdminPageObjects merchantadminpageobjects;
	ExportEmailPageObjects exportEmailPageObjects;
	ParametersPageObjects parametersPageObjects;
	public String device;

	@Step
	public void clickDocumentsLink()
	{
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.documents_link())).click();
	}
	public void clickUsersListLink()
	{
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.userslist_link())).click();
	}
	
	public void clickUsersListAdminUserLink()
	{
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.userslist_adminuser_link())).click();
	}

	public void clickTermsAndConditionsLink() throws InterruptedException
	{
		for(int i=0;i<50;i++){};
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.termsandconditions_link()));
		//new Actions(driver).click(merchantadminpageobjects.termsandconditions_link()).build().perform();
		merchantadminpageobjects.termsandconditions_link().click();
	}
	
	public void clickSmsTemplatesLink() throws InterruptedException
	{
		for(int i=0;i<50;i++){};
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.smstemplates_link()));
		//new Actions(driver).click(merchantadminpageobjects.termsandconditions_link()).build().perform();
		merchantadminpageobjects.smstemplates_link().click();
	}
	
	public void clickEmailTemplatesLink() throws InterruptedException
	{
		for(int i=0;i<50;i++){};
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.emailtemplates_link()));
		//new Actions(driver).click(merchantadminpageobjects.termsandconditions_link()).build().perform();
		merchantadminpageobjects.emailtemplates_link().click();
	}
	
	public void clickCommunicationSummaryLink() throws InterruptedException
	{
		for(int i=0;i<50;i++){};
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.communicationSummary_link()));
		//new Actions(driver).click(merchantadminpageobjects.termsandconditions_link()).build().perform();
		merchantadminpageobjects.communicationSummary_link().click();
	}
	public void clickExportEmailLink() throws InterruptedException
	{
		for(int i=0;i<50;i++){};
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.exportEmail_link()));
		//new Actions(driver).click(merchantadminpageobjects.termsandconditions_link()).build().perform();
		merchantadminpageobjects.exportEmail_link().click();
		waitFor(exportEmailPageObjects.allianceName).sendKeys("EMS");
	}
	
	public void clickParametersLink() throws InterruptedException
	{
		for(int i=0;i<50;i++){};
		driver= this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait=new WebDriverWait(driver,90);
		wait.until(ExpectedConditions.elementToBeClickable(merchantadminpageobjects.parameters_link()));
		merchantadminpageobjects.parameters_link().click();
		for(int i=0;i<50;i++){};
		//executor.executeScript("arguments[0].click();",parametersPageObjects.activeParameters());
	//	waitFor(parametersPageObjects.activeParameters());
		System.out.println(parametersPageObjects.activeParameters.isCurrentlyVisible());
		for(int i=0;i<=25;i++){
			wait.until(ExpectedConditions.elementToBeClickable(parametersPageObjects.activeParameters()));
		}
		System.out.println(parametersPageObjects.activeParameters.isCurrentlyVisible());
		new Actions(driver).moveToElement(parametersPageObjects.activeParameters()).click().build().perform();
		System.out.println("Clicked on active paramters");
	}

	
}
