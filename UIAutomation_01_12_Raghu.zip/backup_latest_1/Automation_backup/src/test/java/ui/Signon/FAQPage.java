package ui.Signon;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Reports.TestResult;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.DocumentsPageObjects;
import ui.pageobjects.Signon.FAQPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.SignonObjects;

public class FAQPage extends PageObject{

	WebDriver driver =null;
	TestResult lib=new TestResult();
	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	FundingPageObjects fundingpageobjects;
	DocumentsPageObjects documentspageobjects;
	FAQPageObjects faqpageobjects;
	public String device;
	
	
	public ArrayList<String> faqCategories=new ArrayList<String>();
	public ArrayList<String> faqCategoriesQuestions=new ArrayList<String>();

	
	@Step
	public void moveToFAQ(){
		driver = this.getDriver();
		Actions actions=new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		//waitFor(dasboardpageObjects.close_cookie).click();

		if(device.equalsIgnoreCase("mobile")){
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}


			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.more_options_dashboard());

			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.faqLink_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.faqLink_dashboard());
		}
		else if(device.equalsIgnoreCase("tablet"))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.more_options_dashboard());

			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.faqLink_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.faqLink_dashboard());
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.more_options_dashboard());

			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.faqLink_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.faqLink_dashboard());
		}
	}

	@Step
	public void getFAQCategoriesandSubCategories(){
		driver = this.getDriver();
		Actions actions=new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		moveToFAQ();
	
		for(int i=0;i<=25;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
		}
		for(WebElement element:faqpageobjects.faqCategories)
		{
			faqCategories.add(element.getText());
			waitFor(element);
			executor.executeScript("arguments[0].click()",element);
			for (WebElement element1:faqpageobjects.faqCategoriesQuestions())
			{
				faqCategoriesQuestions.add(element1.getText());
			}
	
		}
	}
}
