/*package ui.Signon;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.UsersListPageObjects;

public class CommunicationSummaryPage extends PageObject {
	
	WebDriver driver =null;
	String Result=null;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	UsersListPageObjects usersListPageObjects;
	MerchantAdminPageObjects merchantAdminPageObjects;
	public static String initiationLink;
	public static WebElement passwordResetLink;
	
	@Step
	
	public void searchEmail(String userName)
	{
		driver=this.getDriver();
		while(!communicationSummaryPageObjects.emailSearchBox.isPresent())
		{
			waitFor(communicationSummaryPageObjects.emailSearchBox);
		}
		
		communicationSummaryPageObjects.emailSearchBox.click();
		communicationSummaryPageObjects.emailSearchBox.sendKeys(userName);
		waitFor(communicationSummaryPageObjects.emailSearchButton).click();
		
		while(!communicationSummaryPageObjects.emailSearchResult_latest.getText().equals(userName))
		{
			waitFor(communicationSummaryPageObjects.emailSearchResult_latest);
		}
		
		waitFor(communicationSummaryPageObjects.emailSearchResult_latest).click();
		
	}
	
	public String verifyPasswordResetLink(String userName, String emailAddress)
	{
		driver=this.getDriver();
		
		searchEmail(userName);
		
		passwordResetLink=communicationSummaryPageObjects.passwordResetLink;
		
		if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(emailAddress)
				&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
				 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("RESET PASSWORD"))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
		
		return Result;
		
	}
	
	public String acessInitiationLink(String userName, String emailAddress)
	{
		driver=this.getDriver();
		
		searchEmail(userName);
		
		initiationLink=communicationSummaryPageObjects.manualEmailNotification_resendLink.getText();
		System.out.println("the initiation link is:"+initiationLink);
		
		if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(emailAddress)
				&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
				 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("REGISTRATION"))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
		
		return Result;
		
	}
	
	public String resendInitiationLink(String userName, String emailAddress, String targetEmailAddress)
	{
		driver=this.getDriver();
		
		searchEmail(userName);
		
		if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(emailAddress)
				&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
				 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("CHANGE EMAIL"))
		{
		waitFor(communicationSummaryPageObjects.resendEmail).click();
		}
		
		waitFor(usersListPageObjects.feedbackpanelinfo).click();
		
		waitFor(merchantAdminPageObjects.communicationSummary_link);
		
		searchEmail(userName);
		
		if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(targetEmailAddress)
				&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
				 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("CHANGE EMAIL"))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
		
		return Result;
		
	}
	

}
*/