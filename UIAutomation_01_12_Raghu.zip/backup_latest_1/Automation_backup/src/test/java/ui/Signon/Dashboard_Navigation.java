package ui.Signon;

import java.awt.AWTException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.xalan.templates.ElemApplyImport;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.gl.E;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.pages.WebElementState;
import net.thucydides.core.annotations.Step;
import stepdefinitions.UIDefinitions;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.ChangePasswordPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;
import ui.pageobjects.Signon.UsersListPageObjects;
public class Dashboard_Navigation extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	AdminPage_object adminPageobjects;
	UserManagementPageObjects usermanagePageobjects;
	SettingsPageObjects settingspageobjects;
	ExportEmailPageObjects exportemailadminPageobjects;
	CommunicationSummaryPageObjects comsummaryadminPageobjects;
	EmailTemplatePageObjects emailtemplatePageobjects;
	SMSTemplatePageObjects smstemplatePageobjects;
	PreAuthorizationsPageObjects preauthobjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	UserManagementPageObjects usermanagementpageobjects;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	AccountActivationPageObjects accountActivationPageObjects;
	ChangePasswordPageObjects changePasswordPageObjects; 
	MerchantAdminPageObjects merchantAdminPageObjects;
	UsersListPageObjects usersListPageObjects; 
	ParametersPageObjects parametersPageObjects;
	//UIDefinitions uiDefinitions;
	public String device;

	public ArrayList<String> tourguideSections=new ArrayList<String>();

	public Double combinedSalesAmount=0.0;
	public Double combinedSalesCustomers=0.0;
	public String approvalDetails;
	ArrayList<String> dashboardInformation=new ArrayList<String>();


	@Step
	public String Verify_dashboard_panel_Navigation(String Pre_authorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Messages_Text, String Documents_Text, String Help_Text) {
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 30);
		dasboardpageObjects.preauthorization_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
		if(dasboardpageObjects.preauthorization_text().getText().equals(Pre_authorizations_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link()));
		//new Actions(driver).moveToElement(dasboardpageObjects.Authorizations_Link).perform();  
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click()", dasboardpageObjects.Authorizations_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_text()));
		if(dasboardpageObjects.Authorizations_text().getText().equals(Authorizations_Text))
		{

			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.transaction_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_text()));
		if(dasboardpageObjects.transaction_text().getText().equals(Transactions_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.funding_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
		if(dasboardpageObjects.funding_text().getText().equals(Funding_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.messages_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
		if(dasboardpageObjects.messages_text().getText().equals(Messages_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.documents_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
		if(dasboardpageObjects.documents_text().getText().equals(Documents_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		/*wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.more_option());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_option()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.help_option());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_text()));
	if(dasboardpageObjects.help_text().getText().equals(Help_Text))
	{
		Status = true;
	}
	else{
		Status=false;

	}*/
		if (Status==true)
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
		return Result;
	}
	@Step
	public String Navigate_Preauth_Widget_to_detailed_preauth_view(String Preauth_text) throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.pre_authorization_widget()));
		if(dasboardpageObjects.pre_authorization_widget().getText().equals(Preauth_text))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Navigate_Pre_auth_view()));
			dasboardpageObjects.Navigate_Pre_auth_view().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
			if(dasboardpageObjects.preauthorization_text().getText().equals(Preauth_text))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		return Result;

	}
	@Step
	public String Navigate_Funding_Widget_to_detailed_funding_view(String funding_text) throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.view_details_funding()));
		dasboardpageObjects.view_details_funding().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
		if(dasboardpageObjects.funding_text().getText().equals(funding_text))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;

	}
	@Step
	public String Navigate_sales_to_transaction() throws InterruptedException{
		driver = this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver,50);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Sales_dashboard_link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.Sales_dashboard_link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Couldnot_find_result_text()));
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		if(dasboardpageObjects.Couldnot_find_result_text.isDisplayed())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.date_dropdown()));
			dasboardpageObjects.date_dropdown().click();
			dasboardpageObjects.Last_7_days_link().click();
			dasboardpageObjects.Apply_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.posting_date()));
			Result="Passed";	
		}
		else {
			Result="Failed";
		}
		return Result;	
	}
	@Step
	public String Change_currency_code(String Currency_code) throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.currency_drop_down));
		dasboardpageObjects.currency_drop_down.click();
		if(Currency_code.equals("EUR"))
		{
			dasboardpageObjects.EUR_currency().click();
			if((dasboardpageObjects.payment_currency_Text_Validation()).getText().contains("�"))
			{
				Result="Passed : "+ dasboardpageObjects.payment_currency_Text_Validation().getText();
			}
		}
		else if(Currency_code.equals("USD"))
		{
			dasboardpageObjects.USD_currency().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.payment_currency_Text_Validation()));
			if((dasboardpageObjects.payment_currency_Text_Validation()).getText().contains("$"))
			{
				Result="Passed : "+ dasboardpageObjects.payment_currency_Text_Validation().getText();
			}
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}
	@Step
	public String Change_Language_code(String Language_change,String Pre_authorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text) throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 60);
		JavascriptExecutor executor = (JavascriptExecutor)driver;

		/*for(int i=0;i<=50;i++)
	{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));}

	executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
		 */
		dasboardpageObjects.more_option().click();
		for(int i=0;i<=50;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));}
		dasboardpageObjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
		executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
		if(Language_change.equals("Dutch") || Language_change.equals("Nederlands") || Language_change.equals("N�erlandais") || Language_change.equals("Niederl�ndisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());	
		}
		else if(Language_change.equals("English") || Language_change.equals("Engels") || Language_change.equals("Englisch") || Language_change.equals("Anglais"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
		}
		else if(Language_change.equals("French") || Language_change.equals("Frans") || Language_change.equals("Fran�ais") || Language_change.equals("Franz�sisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
		}
		else if(Language_change.equals("German") || Language_change.equals("Duits") || Language_change.equals("Allemand") || Language_change.equals("Deutsch")  )
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
		}
		executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
		if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
		{
			if(dasboardpageObjects.pre_authorization_widget.getText().contains(Pre_authorizations_Text) && 
					dasboardpageObjects.sales_dashboard_text.getText().contains(Transactions_Text) && 
					dasboardpageObjects.payment_dashboard_text.getText().contains(Authorizations_Text) &&
					dasboardpageObjects.funding_Dashboard_Text.getText().contains(Funding_Text))
			{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.payment_dashboard_text()));
				Result="Passed "+": "+ Language_change +"_"+ dasboardpageObjects.payment_dashboard_text().getText()+" "+
						dasboardpageObjects.sales_dashboard_text.getText()+" "+ dasboardpageObjects.payment_dashboard_text +" "+
						dasboardpageObjects.funding_Dashboard_Text;
			}
		}
		else
		{
			Result="Failed "+"The langauge has not been changed ";
		}
		return Result;
	}
	@Step
	public String Navigate_to_message_view_from_notification()  throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 20);
		if(dasboardpageObjects.Message_Title_Notification.isCurrentlyVisible())	
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Message_Title_Notification()));
			String message_title=dasboardpageObjects.Message_Title_Notification().getText();
			String Message_subTitle=dasboardpageObjects.Message_subtitle_notification().getText();
			dasboardpageObjects.Read_more_message_notofication().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
			if(messagespageobjects.Message_Title().getText().equals(message_title) && messagespageobjects.message_subTitle().getText().equals(Message_subTitle))
			{
				Result="Passed" +" "+message_title;
			}
			else{
				Result= "Failed";

			}
		}
		else
		{
			Result="Failed";
		}
		return Result;

	}
	@Step
	public String Confirm_unread_alert_after_login()  throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 20);
		//wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.unread_alerts()));
		if(dasboardpageObjects.unread_alerts.isCurrentlyVisible())
		{

			String alert_title=dasboardpageObjects.unread_alerts_title().getText();
			dasboardpageObjects.unread_alerts().click();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			Result="Passed "+alert_title;

		}
		else
		{
			Result="Failed";
		}

		return Result;	
	}
	@Step
	public String Close_message_notification()  throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 20);
		//wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_notofication_cross_symbol()));
		if(dasboardpageObjects.message_notofication_cross_symbol.isCurrentlyVisible())
		{
			dasboardpageObjects.message_notofication_cross_symbol().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			if(!dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
			{
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}
	@Step
	public String Navigate_unread_message_detail_view()  throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 20);

		if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
			Result="Passed";
		}
		else if(!dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
		return Result;
	}
	@Step
	public String Validate_Disclaimer_widget()  throws InterruptedException{
		driver = this.getDriver();	
		String Result1=null,Result2=null,Result3=null,Result4=null;
		WebDriverWait wait = new WebDriverWait(driver, 20);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_payment_icon()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_payment_icon());
		if(dasboardpageObjects.Payment_Disclaimer_text.isCurrentlyVisible())
		{
			Result1="Passed "+dasboardpageObjects.Payment_Disclaimer_text().getText();
		}
		else
		{
			Result1="Failed "+"No Disclaimer is available";
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_sales_icon()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_sales_icon());
		if(dasboardpageObjects.sales_Disclaimer_text.isCurrentlyVisible())
		{
			Result2="Passed "+dasboardpageObjects.sales_Disclaimer_text().getText();
		}
		else
		{
			Result2="Failed "+"No Disclaimer is available";
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_preauth_icon()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_preauth_icon());
		if(dasboardpageObjects.preauth_Disclaimer_text.isCurrentlyVisible())
		{
			Result3="Passed "+dasboardpageObjects.preauth_Disclaimer_text().getText();
		}
		else
		{
			Result3="Failed "+"No Disclaimer is available";
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_transafer_icon()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_transafer_icon());
		if(dasboardpageObjects.transafer_Disclaimer_text.isCurrentlyVisible())
		{
			Result4="Passed "+dasboardpageObjects.transafer_Disclaimer_text().getText();
		}
		else
		{
			Result4="Failed "+"No Disclaimer is available";
		}
		Result=Result1+Result2+Result3+Result4;
		return Result;
	}


	public String validatePreAuthorizationsDetails()
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		
		if(device.equalsIgnoreCase("mobile"))
		{
			if(!dasboardpageObjects.swipeButton_mobile.isEmpty())
			{
				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.preAuthorizationsGraph.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}
				
			}
			
			if(dasboardpageObjects.preAuthorizationsGraph.isCurrentlyVisible())
			{
				if(dasboardpageObjects.noExpiringPreAuthorizations.size() > 0)
				{
					Result=dasboardpageObjects.noExpiringPreAuthorizations.get(0).getText();
				}
				else
				{
					Result="PreAuthorization details are displayed";
				}
			}
			else
			{
				Result="No PreAuthorization details displayed";
			}
		}
		
		else if(device.equalsIgnoreCase("tablet"))
		{
		if(dasboardpageObjects.preAuthorizationsGraph.isCurrentlyVisible())
		{
			if(dasboardpageObjects.noExpiringPreAuthorizations.size() > 0)
			{
				Result=dasboardpageObjects.noExpiringPreAuthorizations.get(0).getText();
			}
			else
			{
				Result="PreAuthorization details are displayed";
			}
		}
		else
		{
			Result="No PreAuthorization details displayed";
		}
		}
		else
		{
			if(dasboardpageObjects.preAuthorizationsGraph.isCurrentlyVisible())
			{
				if(dasboardpageObjects.noExpiringPreAuthorizations.size() > 0)
				{
					Result=dasboardpageObjects.noExpiringPreAuthorizations.get(0).getText();
				}
				else
				{
					Result="PreAuthorization details are displayed";
				}
			}
			else
			{
				Result="No PreAuthorization details displayed";
			}
		}

		return Result;
	}
	@Step
	public String user_should_be_able_to_view_revenue_for_each_payment_type()  throws InterruptedException{
		driver = this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
		//View Transaction for the Day
		if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			if(dasboardpageObjects.Payment_Type_Value.isCurrentlyVisible())
			{
				Result="Passed"+"::"+"Transaction for Period -> "+dasboardpageObjects.Date.getText()+";"+dasboardpageObjects.Payment_Type_Value.getText();
			}				
		}
		//View Transaction for the Week
		else
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
			dasboardpageObjects.Week.click();
			wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			//View Transaction for the current Week
			if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
				if(dasboardpageObjects.Payment_Type_Value.isCurrentlyVisible())
				{
					Result="Passed"+"::"+"Transaction for Period -> "+dasboardpageObjects.Date.getText()+";"+dasboardpageObjects.Payment_Type_Value.getText();
				}
			}
			//View Transaction for the Previous Week
			else
			{
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
				wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
				//View Transaction for Previous Week if enabled
				if(dasboardpageObjects.Previous_Week.isEnabled())
				{
					wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
					wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
					dasboardpageObjects.Previous_Week.click();
					wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
					wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
					if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
						wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
						if(dasboardpageObjects.Payment_Type_Value.isCurrentlyVisible())
						{
							Result="Passed"+"::"+"Transaction for Period -> "+dasboardpageObjects.Date.getText()+";"+dasboardpageObjects.Payment_Type_Value.getText();
						}
					}
					//No Transaction until Previous Week
					else
					{
						Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
					}
				}
				//Display result of current Week
				else
				{
					Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
				}
			}
		}
		return Result;
	}

	@Step
	public String user_should_be_able_to_view_payment_details()  throws InterruptedException{
		driver = this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
		//View Transaction for the Day
		if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			dasboardpageObjects.view_details_link.click();
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.View_Details_resultpg_Search_button()));
			if(!dasboardpageObjects.View_Details_NoResult_text.isCurrentlyVisible()||dasboardpageObjects.View_Details_Result_Expand.isCurrentlyVisible())
			{
				Result="Passed"+"::"+"Transactions combined in summary view is displayed";
			}
			else
			{
				Result="Failed"+"::"+dasboardpageObjects.View_Details_Date.getText()+"=>"+dasboardpageObjects.View_Details_NoResult_text.getText();
			}

		}
		//View Transaction for the Week
		else
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
			dasboardpageObjects.Week.click();
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			//View Transaction for the current Week
			if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
				dasboardpageObjects.view_details_link.click();
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.View_Details_resultpg_Search_button()));
				if(!dasboardpageObjects.View_Details_NoResult_text.isCurrentlyVisible())
				{
					Result="Passed"+"::"+"Transactions combined in summary view is displayed";
				}
				else
				{
					Result="Failed"+"::"+dasboardpageObjects.View_Details_Date.getText()+"=>"+dasboardpageObjects.View_Details_NoResult_text.getText();
				}
			}
			//View Transaction for the Previous Week
			else
			{
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
				//View Transaction for Previous Week if enabled
				if(dasboardpageObjects.Previous_Week.isEnabled())
				{
					wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
					dasboardpageObjects.Previous_Week.click();
					wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
					if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
						dasboardpageObjects.view_details_link.click();
						wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.View_Details_resultpg_Search_button()));
						if(!dasboardpageObjects.View_Details_NoResult_text.isCurrentlyVisible())
						{
							Result="Passed"+"::"+"Transactions combined in summary view is displayed";
						}
						else
						{
							Result="Failed"+"::"+dasboardpageObjects.View_Details_Date.getText()+"=>"+dasboardpageObjects.View_Details_NoResult_text.getText();
						}
					}
					//No Transaction until Previous Week
					else
					{
						Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
					}
				}
				//Display result of current Week
				else
				{
					Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
				}
			}

		}
		return Result;
	}

	@Step
	public String user_should_be_able_to_view_Approval_widget_for_the_day()  throws InterruptedException{
		driver = this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
		//View Transaction for the Day
		if(dasboardpageObjects.Dashboard_Successful.isCurrentlyVisible())
		{
			Result="Passed"+"::"+dasboardpageObjects.Dashboard_Successful.getText()+" -> "+dasboardpageObjects.Dashboard_Successful_percent.getText()+" ; "+dasboardpageObjects.Dashboard_Declined.getText()+" -> "+dasboardpageObjects.Dashboard_Declined_percent.getText();		
		}
		else
		{
			Result="Failed"+"::"+dasboardpageObjects.No_Transactions.getText();		
		}
		return Result;
	}
	public void clickJS(WebElementFacade pageObject){
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click()", pageObject);
	}

	@Step
	public String Dashboard_cookie_information_link() throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		if(dasboardpageObjects.Portal_cookie_message.getText().equals("By using our website, you agree to EMS� use of cookies."))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.portal_cookie_details()));
			dasboardpageObjects.portal_cookie_details().click();
			for(int i=0;i<50;i++){};
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.cookie_page()));
			if(dasboardpageObjects.cookie_page().getText().equals("Privacy & Cookie Policy"))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
			driver.close();
			driver.switchTo().window(tabs2.get(0));
		}
		else
		{
			Result="Failed";
		}

		return Result;	
	}
	public String Unread_message_count() throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
		if(dasboardpageObjects.message_indicator_count().getText()!=null)
		{
			Result="Passed"+":"+dasboardpageObjects.message_indicator_count().getText();
		}


		else
		{
			Result="Failed"+":"+dasboardpageObjects.message_indicator_count().getText()+":"+"No unread message are there for now";
		}
		return Result;
	}

	public String Unread_Document_count() throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
		if(dasboardpageObjects.document_indicator_count().getText()!=null)
		{
			Result="Passed"+":"+dasboardpageObjects.document_indicator_count().getText();
		}


		else
		{
			Result="Failed"+":"+dasboardpageObjects.document_indicator_count().getText()+":"+"No unread message are there for now";
		}
		return Result;
	}

	public String getDashboardUrl() throws InterruptedException{
		driver=this.getDriver();
		return driver.getCurrentUrl();
	}



	/*------------------------Raghu----------------------------------*/


	public String getAmountFromFundingWidget() throws InterruptedException
	{
		driver=this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, 50);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String todayAmount="";
		if(device.equals("mobile"))
		{
			if(!dasboardpageObjects.swipeButton_mobile.isEmpty())
			{
				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					waitFor(element);
					if(fundingpageobjects.amountDepositedToday_Funding.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}
			}
			waitFor(fundingpageobjects.amountDepositedToday_Funding());
			todayAmount=fundingpageobjects.amountDepositedToday_Funding().getText();
			System.out.println(todayAmount);
		}

		else if(device.equals("tablet"))
		{

			waitFor(fundingpageobjects.amountDepositedToday_Funding());
			fundingpageobjects.amountDepositedToday_Funding().getText();
			System.out.println(todayAmount);
		}

		else
		{

			waitFor(fundingpageobjects.amountDepositedToday_Funding());
			fundingpageobjects.amountDepositedToday_Funding().getText();
			System.out.println(todayAmount);
		}

		return todayAmount;
	}

	public void clickMessagesLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 100);
		//waitFor(dasboardpageObjects.close_cookie).click();
		if(device.equals("mobile"))
		{
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}

			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messagesLink_dashboard()));
			dasboardpageObjects.messagesLink_dashboard().click();
			
			while(!messagespageobjects.inbox.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.inbox));
			}
			
			if(messagespageobjects.inbox.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", messagespageobjects.inbox);
			}
		}

		else if(device.equals("tablet"))
		{

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messagesLink_dashboard()));
			dasboardpageObjects.messagesLink_dashboard().click();
		}

		else
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messagesLink_dashboard()));
			dasboardpageObjects.messagesLink_dashboard().click();
		}
	}

	public void clickDocumentsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		//waitFor(dasboardpageObjects.close_cookie).click();

		if(device.equals("mobile"))
		{
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documentsLink_dashboard()));
			dasboardpageObjects.documentsLink_dashboard().click();
		}
		else if(device.equals("tablet"))
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documentsLink_dashboard()));
			dasboardpageObjects.documentsLink_dashboard().click();
		}
		else
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documentsLink_dashboard()));
			dasboardpageObjects.documentsLink_dashboard().click();
		}
	}
	public void clickPreAuthorizationsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 100);
		//waitFor(dasboardpageObjects.close_cookie).click();
		if(device.equals("mobile"))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}
			//waitFor(dasboardpageObjects.close_cookie).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_Link));
			dasboardpageObjects.preauthorization_Link.click();
		}
		else if(device.equals("tablet"))
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_Link));
			dasboardpageObjects.preauthorization_Link.click();
		}
		else
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_Link));
			dasboardpageObjects.preauthorization_Link.click();
		}
	}
	public void clickAuthorizationsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		//waitFor(dasboardpageObjects.close_cookie).click();
		if(device.equals("mobile"))
		{
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}
			//waitFor(dasboardpageObjects.close_cookie).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link));
			dasboardpageObjects.Authorizations_Link.click();
		}
		else if(device.equals("tablet"))
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link));
			dasboardpageObjects.Authorizations_Link.click();
		}
		else
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link));
			dasboardpageObjects.Authorizations_Link.click();
		}

	}
	public void clickTransactionsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		//waitFor(dasboardpageObjects.close_cookie).click();
		if(device.equals("mobile"))
		{
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}
			//waitFor(dasboardpageObjects.close_cookie).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link));
			dasboardpageObjects.transaction_Link.click();
		}
		else if(device.equals("tablet"))
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link));
			dasboardpageObjects.transaction_Link.click();
		}
		else
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link));
			dasboardpageObjects.transaction_Link.click();
		}
	}
	public void clickFundingLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		//waitFor(dasboardpageObjects.close_cookie).click();
		if(device.equals("mobile"))
		{
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}

			//waitFor(dasboardpageObjects.close_cookie).click();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link));
			dasboardpageObjects.funding_Link.click();
		}
		else if(device.equals("tablet"))
		{

			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link));
			dasboardpageObjects.funding_Link.click();
		}
		else
		{
			//WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link));
			dasboardpageObjects.funding_Link.click();
		}
	}

	public String checkAccountExpiryNotification() throws InterruptedException, AWTException{
		driver = this.getDriver();
		String Result;
		if(dasboardpageObjects.accountExpiryNotification.isCurrentlyVisible() && dasboardpageObjects.accountExpiryNotification.getText().contains("Your account will expire"))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;

	}

	public String checkIfLoginSessionIsActive(String url,String timeout) throws InterruptedException, AWTException{
		driver = this.getDriver();
		String Result;
		Date d1=new Date();
		System.out.println(d1);
		Date d2=new Date();
		System.out.println(d2);
		long d3=(d2.getTime()-d1.getTime());

		while(d3!=(Long.parseLong(timeout)*60000)+4000)
		{
			d2=new Date();
			System.out.println();
			d3=(d2.getTime()-d1.getTime());
			System.out.println(d3);
		}

		JavascriptExecutor executor = (JavascriptExecutor)driver;
		//waitFor(dasboardpageObjects.close_cookie).click();

		if(device.equals("mobile"))
		{

			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}

			waitFor(dasboardpageObjects.messagesLink_dashboard).click();
			if(driver.getCurrentUrl().equals(url))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else if(device.equals("tablet"))
		{
			waitFor(dasboardpageObjects.messagesLink_dashboard).click();
			if(driver.getCurrentUrl().equals(url))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			waitFor(dasboardpageObjects.messagesLink_dashboard).click();
			if(driver.getCurrentUrl().equals(url))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}

		return Result;

	}

	public String checkifImpersonatedUserNameisVisible(String impersonationUserName, String userName, String password)
	{
		driver=this.getDriver();
		waitFor(dasboardpageObjects.impersonationUserName).click();
		waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
		waitFor(dasboardpageObjects.impersonationLogin).click();

		if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
		{

			System.out.println(dasboardpageObjects.impersonatedUserNameText.getText());

			waitFor(dasboardpageObjects.endImpersonationSession).click();
			waitFor(dasboardpageObjects.impersonationLogout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(userName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(password);
			waitFor(signonObjects.Submit()).click();

			System.out.println("The username is:"+dasboardpageObjects.impersonationUserName.getAttribute("value"));
			if(!dasboardpageObjects.impersonationUserName.getAttribute("value").equals(impersonationUserName))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result=dasboardpageObjects.impersonationErrorMessage.getText();
		}

		return Result;
	}

	public String validateImpersonatedUserData(String impersonationUserName,String callCenterUserName, String callCenterPassword)
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		String paymentAmount,paymentCustomer,salesAmount,salesCustomer;

		if(device.equalsIgnoreCase("mobile"))
		{
			if(!dasboardpageObjects.swipeButton_mobile.isEmpty())
			{
				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todayPaymentAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}
			}

			paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();

			if(!dasboardpageObjects.swipeButton_mobile.isEmpty())
			{
				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todaySalesAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}
			}

			salesAmount=dasboardpageObjects.todaySalesAmount.getText();
			salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

			waitFor(dasboardpageObjects.logout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
			waitFor(signonObjects.Submit()).click();



			waitFor(dasboardpageObjects.impersonationUserName).click();
			waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
			waitFor(dasboardpageObjects.impersonationLogin).click();


			if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
			{

				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todayPaymentAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}

				String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
				String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();

				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todaySalesAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}

				String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
				String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();



				if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
						&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer))
				{

					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result=dasboardpageObjects.impersonationErrorMessage.getText();
			}
		}
		else if(device.equalsIgnoreCase("tablet"))
		{
			paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			salesAmount=dasboardpageObjects.todaySalesAmount.getText();
			salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

			waitFor(dasboardpageObjects.logout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
			waitFor(signonObjects.Submit()).click();

			waitFor(dasboardpageObjects.impersonationUserName).click();
			waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
			waitFor(dasboardpageObjects.impersonationLogin).click();


			if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
			{

				String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
				String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
				String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
				String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

				if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
						&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer))
				{

					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result=dasboardpageObjects.impersonationErrorMessage.getText();
			}
		}
		else
		{
			paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			salesAmount=dasboardpageObjects.todaySalesAmount.getText();
			salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

			waitFor(dasboardpageObjects.logout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
			waitFor(signonObjects.Submit()).click();

			waitFor(dasboardpageObjects.impersonationUserName).click();
			waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
			waitFor(dasboardpageObjects.impersonationLogin).click();


			if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
			{

				String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
				String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
				String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
				String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

				if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
						&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer))
				{

					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result=dasboardpageObjects.impersonationErrorMessage.getText();
			}
		}

		return Result;
	}

	public String checkImpersonatedUserFunctionsareAvailable(String impersonationUserName,String callCenterUserName, String callCenterPassword)
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		String paymentAmount,paymentCustomer,salesAmount,salesCustomer;

		if(device.equalsIgnoreCase("mobile"))
		{
			if(!dasboardpageObjects.swipeButton_mobile.isEmpty())
			{
				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todayPaymentAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}
			}

			paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();

			if(!dasboardpageObjects.swipeButton_mobile.isEmpty())
			{
				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todaySalesAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}
			}

			salesAmount=dasboardpageObjects.todaySalesAmount.getText();
			salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

			waitFor(dasboardpageObjects.logout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
			waitFor(signonObjects.Submit()).click();



			waitFor(dasboardpageObjects.impersonationUserName).click();
			waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
			waitFor(dasboardpageObjects.impersonationLogin).click();


			if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
			{

				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todayPaymentAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}

				String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
				String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();

				for(WebElement element:dasboardpageObjects.swipeButton_mobile)
				{
					if(dasboardpageObjects.todaySalesAmount.isCurrentlyVisible())
					{
						break;
					}
					else
					{
						executor.executeScript("arguments[0].click()", element);
					}
				}

				String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
				String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();



				if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
						&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer))
				{

					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result=dasboardpageObjects.impersonationErrorMessage.getText();
			}
		}

		else if(device.equalsIgnoreCase("tablet"))
		{
			paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			salesAmount=dasboardpageObjects.todaySalesAmount.getText();
			salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();


			waitFor(dasboardpageObjects.logout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
			waitFor(signonObjects.Submit()).click();

			waitFor(dasboardpageObjects.impersonationUserName).click();
			waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
			waitFor(dasboardpageObjects.impersonationLogin).click();


			if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
			{

				String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
				String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
				String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
				String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

				waitFor(dasboardpageObjects.preauthorization_Link);
				waitFor(dasboardpageObjects.Authorizations_Link);
				waitFor(dasboardpageObjects.transaction_Link);
				waitFor(dasboardpageObjects.funding_Link);

				if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
						&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer)
						&& dasboardpageObjects.preauthorization_Link.isCurrentlyVisible() && dasboardpageObjects.Authorizations_Link.isCurrentlyVisible()
						&& dasboardpageObjects.transaction_Link.isCurrentlyVisible() && dasboardpageObjects.funding_Link.isCurrentlyVisible())
				{

					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result=dasboardpageObjects.impersonationErrorMessage.getText();
			}
		}
		else
		{
			paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			salesAmount=dasboardpageObjects.todaySalesAmount.getText();
			salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();


			waitFor(dasboardpageObjects.logout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
			waitFor(signonObjects.Submit()).click();

			waitFor(dasboardpageObjects.impersonationUserName).click();
			waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
			waitFor(dasboardpageObjects.impersonationLogin).click();


			if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
			{

				String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
				String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
				String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
				String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

				waitFor(dasboardpageObjects.preauthorization_Link);
				waitFor(dasboardpageObjects.Authorizations_Link);
				waitFor(dasboardpageObjects.transaction_Link);
				waitFor(dasboardpageObjects.funding_Link);

				if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
						&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer)
						&& dasboardpageObjects.preauthorization_Link.isCurrentlyVisible() && dasboardpageObjects.Authorizations_Link.isCurrentlyVisible()
						&& dasboardpageObjects.transaction_Link.isCurrentlyVisible() && dasboardpageObjects.funding_Link.isCurrentlyVisible())
				{

					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result=dasboardpageObjects.impersonationErrorMessage.getText();
			}
		}

		return Result;
	}


	public String validateTourGuide(String userName, String password)
	{

		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",signonObjects.Accept_TermsAndCondition);
		}

		waitFor(dasboardpageObjects.startTheTour);
		executor.executeScript("arguments[0].click()",dasboardpageObjects.startTheTour);
		waitFor(dasboardpageObjects.tourGuide_Next);
		while(dasboardpageObjects.tourGuide_Next.isCurrentlyVisible())
		{

			waitFor(dasboardpageObjects.tourGuide_Sections);
			String sections=dasboardpageObjects.tourGuide_Sections.getText();
			System.out.println("Tour guide section currently being covered:"+sections);
			tourguideSections.add(sections);
			new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.tourGuide_Next));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.tourGuide_Next);

		}

		while(!dasboardpageObjects.tourGuide_Sections.isCurrentlyVisible())
		{
			waitFor(dasboardpageObjects.tourGuide_Sections);
		}
		String sections=dasboardpageObjects.tourGuide_Sections.getText();
		System.out.println("Tour guide section currently being covered:"+sections);
		tourguideSections.add(sections);

		waitFor(dasboardpageObjects.endTheTour).click();

		waitFor(dasboardpageObjects.logout).click();

		waitFor(signonObjects.UserName()).click();
		waitFor(signonObjects.UserName()).sendKeys(userName);
		waitFor(signonObjects.Password()).click();
		waitFor(signonObjects.Password()).sendKeys(password);
		waitFor(signonObjects.Submit()).click();

		if(!dasboardpageObjects.startTheTour.isCurrentlyVisible())
		{

			Result="Passed";
			System.out.println("\n Total Number of sections covered:"+tourguideSections.size());
		}



		return Result;
	}

	public void getSalesDetails() throws ParseException
	{
		//NumberFormat format = NumberFormat.getCurrencyInstance();
		driver=this.getDriver();

		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.dashboardPage_PreviousButton));
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click()",dasboardpageObjects.dashboardPage_PreviousButton);

		String salesAmount= dasboardpageObjects.todaySalesAmount.getText().substring(2).replaceAll(",","");
		String salesCustomers=dasboardpageObjects.todaySalesCustomers.getText();
		Double sales = Double.parseDouble(salesAmount);
		Double customers = Double.parseDouble(salesCustomers);
		System.out.println("SalesAmount:"+sales.toString());
		System.out.println("Customers:"+customers.toString());

		while(dasboardpageObjects.dashboardPage_PreviousButton.isPresent())
		{
			waitFor(dasboardpageObjects.todaySalesAmount);
			waitFor(dasboardpageObjects.todaySalesCustomers);
			salesAmount= dasboardpageObjects.todaySalesAmount.getText().substring(2).replaceAll(",","");
			salesCustomers=dasboardpageObjects.todaySalesCustomers.getText();
			sales = Double.parseDouble(salesAmount);
			customers = Double.parseDouble(salesCustomers);
			System.out.println("SalesAmount:"+sales.toString());
			System.out.println("Customers:"+customers.toString());

			combinedSalesAmount=combinedSalesAmount+sales;
			combinedSalesCustomers=combinedSalesCustomers+customers;

			new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.dashboardPage_PreviousButton));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.dashboardPage_PreviousButton);
		}

		System.out.println("\n the combined sales amount is:"+combinedSalesAmount);
		System.out.println("\n the total number of sales customers is:"+combinedSalesCustomers);

	}

	public String getApprovalRatioInformation()
	{
		driver=this.getDriver();
		StringBuilder sb=new StringBuilder();
		if(!dasboardpageObjects.noTransactionsProcessed.isCurrentlyVisible())
		{
			String approvedPayment=dasboardpageObjects.paymentSuccess.getText();
			String declinedPayment=dasboardpageObjects.paymentDecline.getText();
			String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();

			for(int i=0;i<dasboardpageObjects.paymentType.size() && i<dasboardpageObjects.paymentValue.size();i++)
			{
				sb.append("PaymentType:").append(dasboardpageObjects.paymentType.get(i).getText()).append("-").append("PaymentValue:").append(dasboardpageObjects.paymentValue.get(i).getText());
			}

			String paymentDetails=sb.toString();

			approvalDetails="PaymentAmount:"+paymentAmount+"Number of Customers:"+paymentCustomer+"Approved Payment:"+approvedPayment+"Declined Payment:"+declinedPayment+"Payment Details:"+paymentDetails;
			Result="Passed";	
		}
		else
		{
			Result=dasboardpageObjects.noTransactionsProcessed.getText();
		}

		return Result;
	}

	public ArrayList<String> getDashboardDetails()
	{
		driver=this.getDriver();
		String paymentDetails,paymentDetails1;
		StringBuilder sb=new StringBuilder();
		StringBuilder sb1=new StringBuilder();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		String currentDate=dasboardpageObjects.currentDate.getText();
		String todayFundingAmount=fundingpageobjects.amountDepositedToday_Funding.getText();
		if(!dasboardpageObjects.noTransactionsProcessed.isCurrentlyVisible())
		{
			String approvedPayment=dasboardpageObjects.paymentSuccess.getText();
			String declinedPayment=dasboardpageObjects.paymentDecline.getText();
			String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			for(int i=0;i<dasboardpageObjects.paymentType.size() && i<dasboardpageObjects.paymentValue.size();i++)
			{
				sb.append("PaymentType:").append(dasboardpageObjects.paymentType.get(i).getText()).append("-").append("PaymentValue:").append(dasboardpageObjects.paymentValue.get(i).getText());

			}

			paymentDetails=sb.toString();
			approvalDetails="Current Date:"+currentDate+"PaymentAmount:"+paymentAmount+"Number of Customers:"+paymentCustomer+"Approved Payment:"+approvedPayment+"Declined Payment:"+declinedPayment+"Payment Details:"+paymentDetails;
			dashboardInformation.add(approvalDetails+"Amount deposited today:"+todayFundingAmount);	

		}
		else
		{
			approvalDetails="Current Date:"+currentDate+"Payment Details:"+dasboardpageObjects.noTransactionsProcessed.getText();
			dashboardInformation.add(approvalDetails+"Amount deposited today:"+todayFundingAmount);	
		}

		while(dasboardpageObjects.dashboardPage_PreviousButton.isPresent())
		{
			currentDate=dasboardpageObjects.currentDate.getText();
			waitFor(dasboardpageObjects.todaySalesAmount);
			waitFor(dasboardpageObjects.todaySalesCustomers);
			String salesAmount= dasboardpageObjects.todaySalesAmount.getText();
			String salesCustomers=dasboardpageObjects.todaySalesCustomers.getText();
			if(!dasboardpageObjects.noTransactionsProcessed.isCurrentlyVisible())
			{
				String approvedPayment=dasboardpageObjects.paymentSuccess.getText();
				String declinedPayment=dasboardpageObjects.paymentDecline.getText();
				String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
				String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
				for(int i=0;i<dasboardpageObjects.paymentType.size() && i<dasboardpageObjects.paymentValue.size();i++)
				{
					sb1.append("PaymentType:").append(dasboardpageObjects.paymentType.get(i).getText()).append("-").append("PaymentValue:").append(dasboardpageObjects.paymentValue.get(i).getText());
				}

				paymentDetails1=sb1.toString();
				approvalDetails="Current Date:"+currentDate+"Sales Amount:"+salesAmount+"Sales Customers:"+salesCustomers+"PaymentAmount:"+paymentAmount+"Number of Customers:"+paymentCustomer+"Approved Payment:"+approvedPayment+"Declined Payment:"+declinedPayment+"Payment Details:"+paymentDetails1;
				dashboardInformation.add(approvalDetails);	
			}
			else
			{
				approvalDetails="Current Date:"+currentDate+"Payment Details:"+"Sales Amount:"+salesAmount+"Sales Customers:"+salesCustomers+"Payment Details:"+dasboardpageObjects.noTransactionsProcessed.getText();
				dashboardInformation.add(approvalDetails);	
			}

			new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.dashboardPage_PreviousButton));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.dashboardPage_PreviousButton);
		}
		return dashboardInformation;

	}

	public void moveToSettingsWindow()
	{
		driver=this.getDriver();

		Actions actions=new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		//waitFor(dasboardpageObjects.close_cookie).click();

		if(device.equalsIgnoreCase("mobile")){
			if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}


			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.more_options_dashboard());

			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settingsLink_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.settingsLink_dashboard());
		}
		else if(device.equalsIgnoreCase("tablet"))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.more_options_dashboard());

			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settingsLink_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.settingsLink_dashboard());
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.more_options_dashboard());

			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settingsLink_dashboard()));	
			executor.executeScript("arguments[0].click()", dasboardpageObjects.settingsLink_dashboard());
		}
	}

	public String enableEmailNotifications(){

		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		boolean enableEmailNotifications;
		Actions actions=new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 30);

		moveToSettingsWindow();


		WebElement emailNotificationsCheckbox=driver.findElement(settingspageobjects.enableEmailNotifications_checkbox);

		for(int i=0;i<15;i++)
		{
			emailNotificationsCheckbox=driver.findElement(settingspageobjects.enableEmailNotifications_checkbox);
		}

		executor.executeScript("arguments[0].scrollIntoView();",emailNotificationsCheckbox);
		System.out.println(emailNotificationsCheckbox.getAttribute("class"));
		if(emailNotificationsCheckbox.getAttribute("class").contains("ng-not-empty"))
		{
			String id=emailNotificationsCheckbox.getAttribute("id");
			System.out.println("The button is already clicked. Id is:"+id);
			Result="Button already clicked";
			//	executor.executeScript("document.getElementById('"+id+"').click()");
			//	executor.executeScript("document.getElementById('"+id+"').click()");
		}
		else
		{
			String id=emailNotificationsCheckbox.getAttribute("id");
			System.out.println("The button is yet to be clicked. Id is:"+id);
			executor.executeScript("document.getElementById('"+id+"').click()");

			if(emailNotificationsCheckbox.getAttribute("class").contains("ng-not-empty"))
			{
				Result="Passed";
				wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.saveNotifications_button()));
				//settingspageobjects.saveNotifications_button().click();
				executor.executeScript("arguments[0].click()",settingspageobjects.saveNotifications_button);
				executor.executeScript("arguments[0].click()",settingspageobjects.continueToDashboard);
			}	
			else
			{
				Result="Failed";
			}
		}

		System.out.println(Result);
		return Result;

	}


	@Step
	public String Change_Language_code(String Language_change) throws InterruptedException{

		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		Actions actions=new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 50);

		moveToSettingsWindow();

		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
		//actions.moveToElement(settingspageobjects.Language_dropDown()).click().build().perform();
		executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
		if(Language_change.equals("Dutch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());   
		}
		else if(Language_change.equals("English") || Language_change.equals("Engels"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
		}
		else if(Language_change.equals("French"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
		}
		else if(Language_change.equals("German"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
		}
		executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());

		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		//actions.moveToElement(dasboardpageObjects.Continue_dashboard_button()).click().build().perform();
		executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
		if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
		{
			Result="Passed "+": "+Language_change+"_"+dasboardpageObjects.payment_dashboard_text().getText();
		}
		else
		{
			Result="Failed";
		}
		return Result;
	}

	public String verifyEmailAndMobileNumber(String eMail, String mobileNumber) throws InterruptedException{

		driver=this.getDriver();	
		moveToSettingsWindow();

		if(settingspageobjects.emailAddress.getText().equals(eMail) && settingspageobjects.mobileNumber.getText().equals(mobileNumber))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}


}
