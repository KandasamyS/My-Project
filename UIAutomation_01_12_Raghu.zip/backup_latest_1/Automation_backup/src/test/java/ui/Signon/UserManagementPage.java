/*package ui.Signon;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;



public class UserManagementPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	SettingsPageObjects settingspageobjects;
	UserManagementPageObjects usermanagementpageobjects;

//	@Step
//	public String assignBOProfileToAdditionalUser(){
//
////		driver=this.getDriver();
////		boolean enableEmailNotifications;	
////		Actions actions=new Actions(driver);
////		
////		WebDriverWait wait = new WebDriverWait(driver, 30);
////		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
////		actions.moveToElement(dasboardpageObjects.more_options_dashboard()).build().perform();
////
////		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.userManagementLink_dashboard()));	
////		actions.moveToElement(dasboardpageObjects.userManagementLink_dashboard()).click().build().perform();
////		
////		wait.until(ExpectedConditions.elementToBeClickable(usermanagementpageobjects.userProfile_DropDown()));
////		Select userprofile=new Select(usermanagementpageobjects.userProfile_DropDown());
////		userprofile.selectByVisibleText("Business Assistant");
////		
////
////		return enableEmailNotifications;
//
//	}
}*/