package ui.Signon;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.ChangePasswordPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;
import ui.pageobjects.Signon.UsersListPageObjects;

public class Dashboard_Customization extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	AdminPage_object adminPageobjects;
	UserManagementPageObjects usermanagePageobjects;
	SettingsPageObjects settingspageobjects;
	ExportEmailPageObjects exportemailadminPageobjects;
	CommunicationSummaryPageObjects comsummaryadminPageobjects;
	EmailTemplatePageObjects emailtemplatePageobjects;
	SMSTemplatePageObjects smstemplatePageobjects;
	PreAuthorizationsPageObjects preauthobjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	UserManagementPageObjects usermanagementpageobjects;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	AccountActivationPageObjects accountActivationPageObjects;
	ChangePasswordPageObjects changePasswordPageObjects; 
	MerchantAdminPageObjects merchantAdminPageObjects;
	UsersListPageObjects usersListPageObjects; 
	ParametersPageObjects parametersPageObjects;
	public String device;
	
@Step
public String Display_static_manage_content_in_preferred_language(String Language_Change,String Welcome_Text, String Authorizations_Text,String Pre_authorizations_Text,String Transactions_Text,String Funding_Text) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
	if(dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
	{
		System.out.println(dasboardpageObjects.payment_dashboard_text().getText().contains(Authorizations_Text));
		System.out.println(		dasboardpageObjects.sales_dashboard_text().getText().contains(Transactions_Text));
				System.out.println(		dasboardpageObjects.pre_authorization_widget().getText().contains(Pre_authorizations_Text) );
						System.out.println(		dasboardpageObjects.funding_Dashboard_Text().getText().contains(Funding_Text));
		
		if(dasboardpageObjects.payment_dashboard_text().getText().contains(Authorizations_Text) && 
				dasboardpageObjects.sales_dashboard_text().getText().contains(Transactions_Text) &&
				dasboardpageObjects.pre_authorization_widget().getText().contains(Pre_authorizations_Text) &&
				dasboardpageObjects.funding_Dashboard_Text().getText().contains(Funding_Text))
		{
			Result="Passed "+"Prefered Language is : "+Language_Change+
			"Currency for the payment type : "+dasboardpageObjects.payment_currency_Text_Validation.getText()+System.lineSeparator()
			+"No.of customer for the payment widget : "+dasboardpageObjects.payment_customer_text().getText()+System.lineSeparator()+
			"Currency for the sale type : "+dasboardpageObjects.sale_currency_text().getText()+"No. of customer for the sale widget : "+
			dasboardpageObjects.sales_customer_text().getText()+System.lineSeparator();
		}
		else
		{
			Result="Failed "+"Dashboard Language is not prefered language for the merchant please change the language";
		}
	}
	else
	{
		Result="Failed "+"Dashboard Language is not prefered language for the merchant please change the language";
	}
	return Result;

}

@Step
public String portal_appears_in_my_preferred_locale(String Welcome_Text) throws InterruptedException, ParseException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
	
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy,HH:mm");
		String dateTime=dasboardpageObjects.last_login_date_time().getText();
		if(dateTime.contains("-") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" " + dasboardpageObjects.login_date.getText()+" "  + dateTime;
		}
		else if(dateTime.contains("/") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" " + dasboardpageObjects.login_date.getText() +" " + dateTime;
		}
		else if(dateTime.contains(".") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" "+ dasboardpageObjects.login_date.getText()+" " + dateTime;
		}
		else
		{
			Result="Failed";
		}

	return Result;	
}

@Step
public String Manage_the_message_in_portal_specific_Language(String Language_Change,String Message_title) throws InterruptedException, ParseException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
	dasboardpageObjects.messages_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
	if(messagespageobjects.searchbox_message.isCurrentlyVisible())
	{
		messagespageobjects.searchbox_message().sendKeys(Message_title);
		messagespageobjects.search_Button().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
		System.out.println(messagespageobjects.Message_Title().equals(Message_title));
		System.out.println(messagespageobjects.Message_Title().getText().contains(Message_title));
		if(messagespageobjects.Message_Title().getText().equals(Message_title))
		{
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
			Result="Passed "+Message_title;
		}
		else
		{
			Result="Passed "+messagespageobjects.no_message_found().getText();
		}
	}
	else
	{
		Result="Passed "+messagespageobjects.no_message_found().getText();
	}
	return Result;
	
}
}