package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import common.JDBCConnection;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.SignonObjects;
public class Signon extends PageObject{

	String Result=null;
	String loginStatus=null;
	WebDriver driver =null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	
	public String device;

	JDBCConnection jdbcConnection;

	@Step
	public void loadbrowser(){

		System.out.println("Loading Browser");
		System.out.println("Launched CHrome Browser");
		driver = this.getDriver();	
	}

	@Step
	public void navigate(String url) throws Exception{

		driver.get(url);
		for(int i=0;i<50;i++){};
	}
	@Step
	public void RememberMe() throws InterruptedException{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.RememberMe()));
		if(signonObjects.RememberMe().isDisplayed()){
			signonObjects.RememberMe().click();
		}

	}
	@Step
	public String userInput(String fieldName, String fieldValue) throws InterruptedException{
		System.out.println(fieldName);
		WebDriverWait wait = new WebDriverWait(driver, 50);
		if (fieldName.equals("UserName")){
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
			signonObjects.UserName().sendKeys(fieldValue);
			Result="Passed";
		}

		else if(fieldName.equals("Password"))
		{
			signonObjects.Password().sendKeys(fieldValue);
			Result="Passed";
		}
		else if(fieldName.equals("Alliance"))
		{
			signonObjects.alliance().sendKeys(fieldValue);
			Result="Passed";
		}
		return Result;
	}

	@Step
	public String Submitlogin(String welcome_text) throws InterruptedException{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		signonObjects.Submit().click();
		
		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",signonObjects.Accept_TermsAndCondition);
		}
		
		while(dasboardpageObjects.confirmButton.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",dasboardpageObjects.confirmButton);
		}
		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.login_date()));
		//waitFor(dasboardpageObjects.close_cookie).click();
		String login=dasboardpageObjects.login_date().getText();
		//String status=dasboardpageObjects.Welcome_message().getText();
		//System.out.println(welcome_text+" "+status+" "+login);
		if(dasboardpageObjects.currentDate.isCurrentlyVisible())
		{
			Result="Passed";
		}
		else {
			Result="Failed";

		}
		return Result;
	}
	@Step
	public String login_admin_console() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		signonObjects.login_admin().click();
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Welcome_text_admin()));
		if(signonObjects.Welcome_text_admin().getText().contains("User"))
		{
			Result="Passed";
		}
		else {
			Result="Failed";

		}

		return Result;
	}

	@Step
	public String Accept_terms_and_conditions() throws InterruptedException{
		driver = this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			signonObjects.Accept_TermsAndCondition().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
			Result="Passed "+"Successfully accepted the terms and conditions ";
		}
		else
		{
			Result="Failed "+" There is no terms and conditions available come back later ";
		}
		return Result;

	}
	public String checkIfAccessIsDenied() throws InterruptedException, AWTException{
		driver = this.getDriver();
		Robot robot=new Robot();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			robot.keyPress(KeyEvent.VK_ESCAPE);
			for(int i=0;i<50;i++){};
		}

		if(!(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible()) && signonObjects.UserName.isCurrentlyVisible())
		{
			loginStatus="Passed ";
		}
		else
		{
			loginStatus="Failed ";
		}
		return loginStatus;

	}

	public String View_terms_and_conditions() throws InterruptedException{
		driver = this.getDriver();
		JavascriptExecutor executor=((JavascriptExecutor)driver);

		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			//signonObjects.Accept_TermsAndCondition().click();
			//executor.executeAsyncScript("arguments[0].style.border='3px solid red'",signonObjects.Accept_TermsAndCondition);
			//wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
			Result="Passed "+"Successfully viewed the terms and conditions ";
		}
		else
		{
			Result="Failed "+" There are no terms and conditions available";
		}
		return Result;

	}

	public String download_terms_and_condition(String downloaded_Path) throws InterruptedException{
		driver = this.getDriver(); 
		WebDriverWait wait = new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
		if(signonObjects.download_TermsConditions.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
			signonObjects.download_TermsConditions().click();
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
			String fileName = getLatestFile.getName();
			long length = getLatestFile.length();
			if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
			{
				Result="Passed "+fileName;
			}
			else
			{
				Result="Failed "+"We did not find the document in the folder";
			}
		}
		return Result;       
	}
	public boolean isFileDownloaded(String downloadPath, String fileName) {
		boolean flag = false;
		File dir = new File(downloadPath);
		File[] dir_contents = dir.listFiles();

		for (int i = 0; i < dir_contents.length; i++) {
			if (dir_contents[i].getName().contains(fileName))
				return flag=true;
		}

		return flag;
	}
	private File getLatestFilefromDir(String dirPath){
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;
	}

	public String checkIfAccountHasExpired() throws InterruptedException, AWTException{
		driver = this.getDriver();
		String Result;
		if(signonObjects.accountExpiredErrorMessage.isCurrentlyVisible() && signonObjects.accountExpiredErrorMessage.getText().contains("This account is expired. Please contact Customer Service"))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}



		return Result;

	}

	public String sendPasswordResetLink(String userName)
	{
		driver=this.getDriver();

		while(!signonObjects.forgotPasswordLink.isPresent())
		{
			waitFor(signonObjects.forgotPasswordLink);
		}
		waitFor(signonObjects.forgotPasswordLink).click();
		while(!signonObjects.forgotPasswordUsername.isPresent())
		{
			waitFor(signonObjects.forgotPasswordUsername);
		}
		waitFor(signonObjects.forgotPasswordUsername).sendKeys(userName);
		waitFor(signonObjects.resetPasswordSlider);
		Dimension sliderSize = signonObjects.resetPasswordSlider.getSize();
		int sliderWidth=sliderSize.getWidth();
		System.out.println(sliderWidth);
		int xCoord = signonObjects.resetPasswordSliderBar.getLocation().getX();
		System.out.println(xCoord);
		new Actions(driver).moveToElement(signonObjects.resetPasswordSliderBar).click().dragAndDropBy(signonObjects.resetPasswordSlider,xCoord,xCoord + sliderWidth).build().perform();

		if(signonObjects.resetPasswordSliderStatus.isCurrentlyVisible() && signonObjects.resetPasswordSliderStatus.getText().contains("human"))
		{
			waitFor(signonObjects.sendPasswordResetLink).click();
			if(signonObjects.loginErrorMessage.getText().contains("We have sent you an email regarding the changes, please check your email inbox."))
			{
				Result="Passed";
			}
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}

	public String lockAccount(String userName,String password) throws InterruptedException
	{
		driver=this.getDriver();
		
		for(int i=0;i<10;i++)
		{
		waitFor(signonObjects.UserName);
		waitFor(signonObjects.Password);
		waitFor(signonObjects.Submit);
		}
		
		for(int i=0;i<3;i++)
		{
			waitFor(signonObjects.UserName).clear();
			waitFor(signonObjects.UserName).sendKeys(userName);
			waitFor(signonObjects.Password).clear();
			waitFor(signonObjects.Password).sendKeys(password);
			waitFor(signonObjects.Submit).click();
			
			System.out.println("tried logging in for:"+i+"th time");
		}

		if(signonObjects.loginErrorMessage.getText().contains("Your account is temporarily locked due to 3 unsuccessful login attempts. Please wait for 30 minutes and try again."))
		{
			Result=signonObjects.loginErrorMessage.getText();
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}

	public String validateLoginAttemptCount(String userName,String password) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		
		for(int i=0;i<10;i++)
		{
		waitFor(signonObjects.UserName);
		waitFor(signonObjects.Password);
		waitFor(signonObjects.Submit);
		}

		if(signonObjects.loginErrorMessage.isCurrentlyVisible() && signonObjects.loginErrorMessage.getText().contains("Your account is temporarily locked due to 3 unsuccessful login attempts. Please wait for 30 minutes and try again."))
		{
			waitFor(signonObjects.UserName).clear();
			waitFor(signonObjects.UserName).sendKeys(userName);
			waitFor(signonObjects.Password).clear();
			waitFor(signonObjects.Password).sendKeys(password);
			waitFor(signonObjects.Submit).click();
			System.out.println("tried logging in for the 4th time");
		}

		String attemptCount=jdbcConnection.getLoginAttemptCount(userName);
		System.out.println("The attempt count is:"+attemptCount);

		if(attemptCount=="3")
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}
	public String checkIfLoginAttemptCountIsCleared(String userName, String password) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();

		String attemptCount=jdbcConnection.getLoginAttemptCount(userName);
		System.out.println("The attempt count is:"+attemptCount);

		if(attemptCount=="0")
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}
	
	public String lockAccountPermanently(String userName,String password)
	{
		driver=this.getDriver();
		for(int i=0;i<10;i++)
		{
		waitFor(signonObjects.UserName);
		waitFor(signonObjects.Password);
		waitFor(signonObjects.Submit);
		}
		for(int i=0;i<3;i++)
		{
	
			waitFor(signonObjects.UserName).clear();
			waitFor(signonObjects.UserName).sendKeys(userName);
			waitFor(signonObjects.Password).clear();
			waitFor(signonObjects.Password).sendKeys(password);
			waitFor(signonObjects.Submit).click();
			
			System.out.println("tried logging in for:"+i+"th time");
		}

		if(signonObjects.loginErrorMessage.isCurrentlyVisible() && signonObjects.loginErrorMessage.getText().contains("You have made 6 unsuccessful attempts to login. This account is now locked, please contact the Call Centre."))
		{
			Result=signonObjects.loginErrorMessage.getText();
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}
	
	public String warnUserAboutLoginAttempt(String userName,String password)
	{
		driver=this.getDriver();
		for(int i=0;i<10;i++)
		{
		waitFor(signonObjects.UserName);
		waitFor(signonObjects.Password);
		waitFor(signonObjects.Submit);
		}
		for(int i=0;i<2;i++)
		{
	
			waitFor(signonObjects.UserName).sendKeys(userName);
			waitFor(signonObjects.Password).sendKeys(password);
			waitFor(signonObjects.Submit).click();
			
			System.out.println("tried logging in for:"+i+"th time");
		}

		if(signonObjects.loginErrorMessage.isCurrentlyVisible() && signonObjects.loginErrorMessage.getText().contains("You have made 5 unsuccessful attempts to login. This is your last attempt otherwise your account will be locked."))
		{
			Result=signonObjects.loginErrorMessage.getText();
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}

	
	
}









