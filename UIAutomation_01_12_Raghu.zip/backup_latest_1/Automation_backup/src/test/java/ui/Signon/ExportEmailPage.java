/*package ui.Signon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SignonObjects;

public class ExportEmailPage extends PageObject {
	

	String Result=null;
	String loginStatus=null;
	WebDriver driver =null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	SMSTemplatePageObjects smstemplatepageobjects;
	EmailTemplatePageObjects emailtemplatepageobjects;
	ExportEmailPageObjects exportemailpageobjects;

	@Step
	public String[][] getListOfUsers(){

		driver = this.getDriver();
		int count=0;
		String[][] usersList;
		
		ArrayList<String> userName=new ArrayList<String>();
		ArrayList<String> userProfile=new ArrayList<String>();
		ArrayList<String> accountStatus=new ArrayList<String>();
		
		boolean flag=true;
		while(flag==true)
		{
		
			System.out.println("Size of the disabled link is: "+exportemailpageobjects.nextButtondisabled().size());
			
				if(exportemailpageobjects.nextButtondisabled().size()>0)
				{
					flag=false;
				}
				
				for(int i=0;i<exportemailpageobjects.userName.size();i++)
				{
					if(exportemailpageobjects.userProfile.get(i).getText().equals("BusinessOwner") || exportemailpageobjects.userProfile.get(i).getText().equals("BusinessAssistant"))
					{
						userName.add(exportemailpageobjects.userName.get(i).getText());
						userProfile.add(exportemailpageobjects.userProfile.get(i).getText());
						accountStatus.add(exportemailpageobjects.accountStatus.get(i).getText());
						count++;
						
					}
				}
				
				if(count==2)
				{
					flag=false;
				}
				
				
				if(flag=true)
				{
					waitFor(exportemailpageobjects.nextButton()).click();
				}
				
			}
		
		usersList=new String[userName.size()+1][userName.size()+1];
		usersList[0][0]="User Name";usersList[0][1]="User Profile";usersList[0][2]="Account Status";
		
		for(int i=1;i<userName.size();i++)
		{
			usersList[i][0]=userName.get(i-1);
			usersList[i][1]=userProfile.get(i-1);
			usersList[i][2]=accountStatus.get(i-1);
		}
		
		for(int i=0; i<usersList.length;i++)
		{
			for(int j=0; i<usersList[0].length;i++)
			{
				System.out.println(usersList[i][j]);
			}
			System.out.println("\n");
		}
		
	
		return usersList;	
	}
		

}
*/