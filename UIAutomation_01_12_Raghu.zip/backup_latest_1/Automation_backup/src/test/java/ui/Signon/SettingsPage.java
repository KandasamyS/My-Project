/*package ui.Signon;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;



public class SettingsPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	SettingsPageObjects settingspageobjects;


	@Step

	public void moveToSettingsWindow()
	{
		driver=this.getDriver();

		Actions actions=new Actions(driver);

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_options_dashboard()));	
		actions.moveToElement(dasboardpageObjects.more_options_dashboard()).build().perform();

		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settingsLink_dashboard()));	
		actions.moveToElement(dasboardpageObjects.settingsLink_dashboard()).click().build().perform();

	}
	public String enableEmailNotifications(){

		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		boolean enableEmailNotifications;
		Actions actions=new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 30);

		moveToSettingsWindow();


		WebElement emailNotificationsCheckbox=driver.findElement(settingspageobjects.enableEmailNotifications_checkbox);

		for(int i=0;i<15;i++)
		{
			emailNotificationsCheckbox=driver.findElement(settingspageobjects.enableEmailNotifications_checkbox);
		}

		executor.executeScript("arguments[0].scrollIntoView();",emailNotificationsCheckbox);
		System.out.println(emailNotificationsCheckbox.getAttribute("class"));
		if(emailNotificationsCheckbox.getAttribute("class").contains("ng-not-empty"))
		{
			String id=emailNotificationsCheckbox.getAttribute("id");
			System.out.println("The button is already clicked. Id is:"+id);
			Result="Button already clicked";
			//	executor.executeScript("document.getElementById('"+id+"').click()");
			//	executor.executeScript("document.getElementById('"+id+"').click()");
		}
		else
		{
			String id=emailNotificationsCheckbox.getAttribute("id");
			System.out.println("The button is yet to be clicked. Id is:"+id);
			executor.executeScript("document.getElementById('"+id+"').click()");
			
			if(emailNotificationsCheckbox.getAttribute("class").contains("ng-not-empty"))
			{
				Result="Passed";
				wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.saveNotifications_button()));
				settingspageobjects.saveNotifications_button().click();
				executor.executeScript("arguments[0].click()",settingspageobjects.continueToDashboard);
			}	
			else
			{
				Result="Failed";
			}
		}

		System.out.println(Result);
		return Result;

	}


	@Step
	public String Change_Language_code(String Language_change) throws InterruptedException{

		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		Actions actions=new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 50);

		moveToSettingsWindow();

		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
		//actions.moveToElement(settingspageobjects.Language_dropDown()).click().build().perform();
		executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
		if(Language_change.equals("Dutch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());   
		}
		else if(Language_change.equals("English") || Language_change.equals("Engels"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
		}
		else if(Language_change.equals("French"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
		}
		else if(Language_change.equals("German"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
		}
		executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());

		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		//actions.moveToElement(dasboardpageObjects.Continue_dashboard_button()).click().build().perform();
		executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
		if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
		{
			Result="Passed "+": "+Language_change+"_"+dasboardpageObjects.payment_dashboard_text().getText();
		}
		else
		{
			Result="Failed";
		}
		return Result;
	}

	public String verifyEmailAndMobileNumber(String eMail, String mobileNumber) throws InterruptedException{

		driver=this.getDriver();	
		moveToSettingsWindow();

		if(settingspageobjects.emailAddress.getText().equals(eMail) && settingspageobjects.mobileNumber.getText().equals(mobileNumber))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}



}*/