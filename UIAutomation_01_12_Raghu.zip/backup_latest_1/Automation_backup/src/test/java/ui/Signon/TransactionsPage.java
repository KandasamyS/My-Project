/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.sun.jna.platform.win32.OaIdl.EXCEPINFO;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.TransactionsPageObjects;



public class TransactionsPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	TransactionsPageObjects transactionsPageObjects;
	PreAuthorizationsPageObjects preAuthorizationsPageObjects;

	public ArrayList<Date> transactionDateAndTime=new ArrayList<Date>();
	public ArrayList<String> transactioncolumns=new ArrayList<String>();
	public ArrayList<String> fundingFees=new ArrayList<String>();
	public ArrayList<String> emsFees=new ArrayList<String>();
	public ArrayList<String> transactionCreditData=new ArrayList<String>();
	public ArrayList<String> transactionDebitData=new ArrayList<String>();


	@Step
	public String validateTransactionsSortOrder(String fromDate, String toDate) throws IOException, ParseException, InterruptedException{



		driver=this.getDriver();

		for(int i=0;i<30;i++)
		{
			waitFor(ExpectedConditions.elementToBeClickable(transactionsPageObjects.searchFieldText));
		}

		System.out.println("\n Inside Transactions");

		waitFor(transactionsPageObjects.date_dropdown).click();
		waitFor(transactionsPageObjects.FromDate).click();
		waitFor(transactionsPageObjects.FromDate).clear();
		waitFor(transactionsPageObjects.FromDate).sendKeys(fromDate);
		waitFor(transactionsPageObjects.ToDate).click();
		waitFor(transactionsPageObjects.ToDate).clear();
		waitFor(transactionsPageObjects.ToDate).sendKeys(toDate);
		waitFor(transactionsPageObjects.applyDate).click();

		for(int i=0;i<30;i++)
		{
			waitFor(ExpectedConditions.elementToBeClickable(transactionsPageObjects.searchFieldText));
		}


		if(!transactionsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{

			SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");// HH:mm");

			List<WebElement> transactionDate=driver.findElements(transactionsPageObjects.transactionsDate);
			List<WebElement> transactionTime=driver.findElements(transactionsPageObjects.transactionsTime);

			for(int i=0;i<transactionDate.size()&& i<transactionTime.size();i++)
			{
				String dateAndTime= transactionDate.get(i).getText();//+" "+transactionTime.get(i).getText();
				System.out.println("Date And Time value is:"+dateAndTime);
				transactionDateAndTime.add(sdf.parse(dateAndTime));
			}

			System.out.println("The Date and Time are:"+transactionDateAndTime);

			ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
			duplicateDateAndTime=(ArrayList<Date>) transactionDateAndTime.clone();
			Collections.sort(duplicateDateAndTime);
			Collections.reverse(duplicateDateAndTime);

			System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);

			if(transactionDateAndTime.equals(duplicateDateAndTime))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="No Records found";
		}


		return Result;

	}


	public String validateTransactionColumns(String columnName) throws InterruptedException
	{
		driver=this.getDriver();
		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		boolean defaultColumnAvailability=false;

		if(!transactionsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			StringBuilder sb=new StringBuilder();
			//			wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.showMoreColumns));
			//			executor.executeScript("arguments[0].click()",transactionsPageObjects.showMoreColumns);
			//			wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.restoreDefault));
			//			executor.executeScript("arguments[0].click()",transactionsPageObjects.restoreDefault);
			//			wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.apply));
			//			executor.executeScript("arguments[0].click()",transactionsPageObjects.apply);

			List<WebElement> transactionColumns=driver.findElements(transactionsPageObjects.transactionColumns);
			for(int i=0;i<30;i++)
			{
				transactionColumns=driver.findElements(transactionsPageObjects.transactionColumns);
			}
			System.out.println("NUMBER OF COLUMNS IS:"+transactionColumns.size());
			for(int i=1;i<transactionColumns.size();i++)
			{

				if(transactionColumns.get(i).getText().isEmpty())
				{
					transactioncolumns.add("ECommerce/POS transaction");
				}
				else
				{
					transactioncolumns.add(transactionColumns.get(i).getText());
				}

			}


			System.out.println("the default transaction columns are:"+transactioncolumns);
			System.out.println("The name of the column to be clicked is:"+columnName);

			for(int j=0;j<transactioncolumns.size();j++)
			{
				System.out.println(transactioncolumns.get(j));
				if(transactioncolumns.get(j).contains(columnName))
				{
					defaultColumnAvailability=true;
				}
			}

			System.out.println("is column available:"+defaultColumnAvailability);
			if(defaultColumnAvailability==false)
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.showMoreColumns));
				executor.executeScript("arguments[0].scrollIntoView();",transactionsPageObjects.showMoreColumns);
				executor.executeScript("arguments[0].click()",transactionsPageObjects.showMoreColumns);
				for(WebElement additionalColumns:transactionsPageObjects.additionalTransactionColumns)
				{
					System.out.println("the name of the column is:"+additionalColumns.getText());
					if(additionalColumns.getText().equalsIgnoreCase(columnName))
					{
						wait.until(ExpectedConditions.visibilityOf(additionalColumns));
						executor.executeScript("arguments[0].click()",additionalColumns);
					}
				}

				wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.apply));
				executor.executeScript("arguments[0].scrollIntoView();",transactionsPageObjects.apply);
				executor.executeScript("arguments[0].click()",transactionsPageObjects.apply);

				transactionColumns=driver.findElements(transactionsPageObjects.transactionColumns);
				for(int i=0;i<30;i++)
				{
					transactionColumns=driver.findElements(transactionsPageObjects.transactionColumns);
				}
				System.out.println("Size of the columns after adding a new column is:"+transactionColumns.size());

				for(int i=0;i<transactionColumns.size();i++)
				{
					System.out.println(transactionColumns.get(i).getText());
					if(transactionColumns.get(i).getText().contains(columnName))
					{
						System.out.println("Inside the loop");
						Result="Passed";
					}
				}

			}
			else
			{
				Result="Column already available in default view";
			}
		}
		else
		{
			Result="No Records Present";
		}
		return Result;
	}

	public String viewInterchangeCharges() throws InterruptedException
	{
		driver=this.getDriver();
		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;


		if(!transactionsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			StringBuilder sb=new StringBuilder();

			//	System.out.println(transactionsPageObjects.transactionsDate.size());
			//waitFor(transactionsPageObjects.transactionsDate.get(0));'
			for(int i=0;i<200;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.date_dropdown));
			}
			//wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(transactionsPageObjects.transactionsDate));
			List<WebElement> transactionDate=driver.findElements(transactionsPageObjects.transactionsDate);
			System.out.println(transactionDate.size());
			for(int i=0;i<100;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.date_dropdown));
			}
			for(int i=0;i<transactionDate.size();i++)
			{executor.executeScript("arguments[0].click()",transactionDate.get(i));
			List<WebElement> transactionDetails_Funding=driver.findElements(transactionsPageObjects.transactionDetails_Funding);
			List<WebElement> transactionDetails_EMSFees=driver.findElements(transactionsPageObjects.transactionDetails_EMSFees);

			System.out.println("Number of funding fees is:"+transactionDetails_Funding.size());
			System.out.println("Number of EMS fees is:"+transactionDetails_EMSFees.size());

			for(int i1=0;i1<transactionDetails_Funding.size() && i1< transactionDetails_EMSFees.size();i1++)
			{
				System.out.println("The CSS value is:"+transactionDetails_Funding.get(i1).getCssValue("color"));
				fundingFees.add(transactionDetails_Funding.get(i1).getText());
				emsFees.add(transactionDetails_EMSFees.get(i1).getText());
			}

			emsFees.add(transactionsPageObjects.transactionDetails_GrossCharge.getText());

			System.out.println("the funding fees are:"+fundingFees);
			System.out.println("the ems fees are:"+emsFees);
			Result="Passed";

			}
		}
		else
		{
			Result="No Records Present";
		}
		return Result;
	}

	public String validateTransactionCreditAndDebitTransactionData(String transactionID)
	{
		driver=this.getDriver();

		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		preAuthorizationsPageObjects.searchFieldText.sendKeys(transactionID);
		executor.executeScript("arguments[0].click()",transactionsPageObjects.search_transactionId);
		wait.until(ExpectedConditions.elementToBeClickable(preAuthorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.search_button);

		for(int i=0;i<50;i++){}
		if(!transactionsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			List<WebElement> transactionDate=driver.findElements(transactionsPageObjects.transactionsDate);
			for(int i=0;i<transactionDate.size();i++)
			{
				executor.executeScript("arguments[0].click()",transactionDate.get(i));
				List<WebElement> fundingName=driver.findElements(transactionsPageObjects.transactionDetails_FundingName);
				List<WebElement> fundingValue=driver.findElements(transactionsPageObjects.transactionDetails_FundingValue);
				List<WebElement> emsFeeName=driver.findElements(transactionsPageObjects.transactionDetails_EMSFeeName);
				List<WebElement> emsFeeValue=driver.findElements(transactionsPageObjects.transactionDetails_EMSFeeValue);

				for(int j=0;j<fundingName.size() && j<fundingValue.size();j++)
				{
					if(fundingValue.get(j).getText().startsWith("-") && fundingValue.get(j).getCssValue("color").equals("rgba(240, 4, 4, 1)"))
					{
						System.out.println("Color is:"+fundingValue.get(j).getCssValue("color"));
						String combined=fundingName.get(j).getText()+":"+fundingValue.get(j).getText();
						transactionDebitData.add(combined);
					}
					else
					{
						System.out.println("Color is:"+fundingValue.get(j).getCssValue("color"));
						String combined=fundingName.get(j).getText()+":"+fundingValue.get(j).getText();
						transactionCreditData.add(combined);
					}
				}

				for(int k=0;k<emsFeeName.size() && k<emsFeeValue.size();k++)
				{
					if(emsFeeValue.get(k).getText().startsWith("-") && emsFeeValue.get(k).getCssValue("color").equals("rgba(240, 4, 4, 1)"))
					{
						System.out.println("Color is:"+emsFeeValue.get(k).getCssValue("color"));
						String combined=emsFeeValue.get(k).getText()+":"+emsFeeValue.get(k).getText();
						transactionDebitData.add(combined);
					}
					else
					{
						System.out.println("Color is:"+emsFeeValue.get(k).getCssValue("color"));
						String combined=emsFeeName.get(k).getText()+":"+emsFeeValue.get(k).getText();
						transactionCreditData.add(combined);
					}
				}

			}


			Result="Passed";
		}
		else
		{
		
		Result="No Records Present";
		}

		
		return Result;
	}
}















































*/