/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;



import net.serenitybdd.core.pages.PageObject;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UsersListPageObjects;

public class UsersListPage extends PageObject {

	WebDriver driver =null;
	public String clickedAccountStatus;
	MerchantAdminPageObjects merchantadminpageobjects;
	UsersListPageObjects userslistspageobjects;
	SignonObjects signOnObjects;
	public String Result=null;

	public String expiryDay,expiryMonth,expiryYear;


	public String getTermsAndConditionsId(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException, AWTException
	{
		driver=this.getDriver();

		filterUser(firstname, lastname, username, email, accountstatus);

		String termsandconditionsid=new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.termsandconditionsid())).getText();

		System.out.println("Terms and conditons ID is :"+termsandconditionsid);

		return termsandconditionsid;

	}

	public void filterUser(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException
	{
		driver=this.getDriver();




		waitFor((userslistspageobjects.useradvancedsearch_button())).click();
		System.out.println("Clicked on Advanced search");

		waitFor((userslistspageobjects.filterfirstname()));
		userslistspageobjects.filterfirstname().click();
		userslistspageobjects.filterfirstname().sendKeys(firstname);
		System.out.println("Clicked on first name. Chosen Value is:"+userslistspageobjects.filterfirstname().getAttribute("value"));

		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterlastname())).click();
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterlastname())).sendKeys(lastname);
		System.out.println("Clicked on last name. Chosen Value is:"+userslistspageobjects.filterlastname().getAttribute("value"));

		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterusername())).click();
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterusername())).sendKeys(username);
		System.out.println("Clicked on user name. Chosen Value is:"+userslistspageobjects.filterusername().getAttribute("value"));

		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filteruseremail())).click();
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filteruseremail())).sendKeys(email);
		System.out.println("Clicked on useremail. Chosen Value is:"+userslistspageobjects.filteruseremail().getAttribute("value"));

		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterstatusdropdown())).click();
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterstatusdropdown())).sendKeys(accountstatus);
		System.out.println("Clicked on status. Chosen Value is:"+userslistspageobjects.filterstatusdropdown.getAttribute("value"));

		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.applyfilter())).click();
		System.out.println("Clicked on apply filter");


		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.usersearch_firstresult())).click();
		System.out.println("Clicked on the first result");
	}

	public void blockUser(String firstname, String lastname, String username, String email, String accountstatus, String targetaccountstatus, String blockreason) throws AWTException, InterruptedException
	{
		driver=this.getDriver();
		filterUser(firstname,lastname,username,email,accountstatus);
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.useraccountstatus()));
		Select selectstatus=new Select(userslistspageobjects.useraccountstatus());
		selectstatus.selectByVisibleText(targetaccountstatus);
		System.out.println("Chosen Status is:"+userslistspageobjects.useraccountstatus().getAttribute("value"));

		waitFor(userslistspageobjects.blockreason());
		Select selectblockreason=new Select(userslistspageobjects.blockreason());
		selectblockreason.selectByVisibleText(blockreason);
		System.out.println("Chosen Reason is:"+userslistspageobjects.blockreason().getAttribute("value"));
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.saveButton())).click();
		System.out.println("Clicked on Save");
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.feedbackpanelinfo())).click();
		waitFor((userslistspageobjects.useradvancedsearch_button())).click();
		waitFor((userslistspageobjects.advancedsearchreset_button())).click();

	}

	public String getBlockReason(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException
	{
		driver=this.getDriver();
		filterUser(firstname,lastname,username,email,accountstatus);
		Select selectblockreason=new Select(userslistspageobjects.blockreason());
		System.out.println("Status is:"+userslistspageobjects.useraccountstatus().getAttribute("value"));
		clickedAccountStatus=userslistspageobjects.useraccountstatus().getAttribute("value");
		System.out.println("Reason for blocking is:"+selectblockreason.getFirstSelectedOption().getText());
		return selectblockreason.getFirstSelectedOption().getText();
	}

	public String unBlockUser(String firstname, String lastname, String username, String email, String accountstatus, String targetaccountstatus) throws InterruptedException
	{
		driver=this.getDriver();
		filterUser(firstname,lastname,username,email,accountstatus);
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.useraccountstatus()));
		Select selectstatus=new Select(userslistspageobjects.useraccountstatus());
		selectstatus.selectByVisibleText(targetaccountstatus);
		System.out.println("Chosen Status is:"+userslistspageobjects.useraccountstatus().getAttribute("value"));
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.saveButton())).click();
		System.out.println("Clicked on Save");
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.feedbackpanelinfo())).click();
		waitFor((userslistspageobjects.useradvancedsearch_button())).click();
		waitFor((userslistspageobjects.advancedsearchreset_button())).click();
		filterUser(firstname,lastname,username,email,targetaccountstatus);
		System.out.println("Chosen Status after saving is:"+userslistspageobjects.useraccountstatus().getAttribute("value"));
		return userslistspageobjects.useraccountstatus().getAttribute("value");


	}

	public void setAccountExpiryDate(String firstname, String lastname, String username, String email, String accountstatus, String day, String month, String year) throws AWTException, InterruptedException
	{
		driver=this.getDriver();
		filterUser(firstname,lastname,username,email,accountstatus);
		if(new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.markForExpiry())).isSelected())
		{
			new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.markForExpiry())).click();
		}
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.markForExpiry())).click();
		waitFor(userslistspageobjects.accountexpiryday());
		new Select(userslistspageobjects.accountexpiryday()).selectByVisibleText(day);
		waitFor(userslistspageobjects.accountexpirymonth());
		new Select(userslistspageobjects.accountexpirymonth()).selectByVisibleText(month);
		waitFor(userslistspageobjects.accountexpiryyear());
		new Select(userslistspageobjects.accountexpiryyear()).selectByVisibleText(year);
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.saveButton())).click();
		System.out.println("Clicked on Save");
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.feedbackpanelinfo())).click();
		waitFor((userslistspageobjects.useradvancedsearch_button())).click();
		waitFor((userslistspageobjects.advancedsearchreset_button())).click();

	}

	public void getAccountExpiryDate(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException
	{
		driver=this.getDriver();
		filterUser(firstname,lastname,username,email,accountstatus);
		expiryDay=new Select(userslistspageobjects.accountexpiryday()).getFirstSelectedOption().getText();
		expiryMonth=new Select(userslistspageobjects.accountexpirymonth()).getFirstSelectedOption().getText();
		expiryYear=new Select(userslistspageobjects.accountexpiryyear()).getFirstSelectedOption().getText();
	}

	public String checkIfPortalAccessIsBlocked(String firstname, String lastname, String username, String email, String accountstatus, String url, String password) throws InterruptedException
	{
		driver=this.getDriver();
		filterUser(firstname,lastname,username,email,accountstatus);
		System.out.println("Account Status is:"+userslistspageobjects.useraccountstatus().getAttribute("value"));
		String status=userslistspageobjects.useraccountstatus().getAttribute("value");
		if(status.equalsIgnoreCase("BLOCKED"))
		{
			driver.get(url);
			waitFor(signOnObjects.UserName()).sendKeys(username);
			waitFor(signOnObjects.Password()).sendKeys(password);
			waitFor(signOnObjects.Submit()).click();

			if(signOnObjects.loginErrorMessage.isCurrentlyVisible() && signOnObjects.loginErrorMessage().getText().contains("Your access to the portal is not permitted currently. Please contact the Call Centre."))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}

		else
		{
			Result="Account is not blocked. Account status is:"+status;
		}


		return Result;	
	}

	public String changeEmail(String username, String firstname, String lastname, String email, String accountstatus,String targetemail) throws InterruptedException
	{
		driver=this.getDriver();
		filterUser(firstname,lastname,username,email,accountstatus);
		waitFor(userslistspageobjects.userEmailAddress);
		userslistspageobjects.userEmailAddress.clear();
		userslistspageobjects.userEmailAddress.sendKeys(targetemail);
		waitFor(userslistspageobjects.saveButton()).click();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.feedbackpanelinfo())).click();
		waitFor((userslistspageobjects.useradvancedsearch_button())).click();
		waitFor((userslistspageobjects.advancedsearchreset_button())).click();
		filterUser(firstname,lastname,username,targetemail,accountstatus);
		System.out.println("Email after saving is:"+userslistspageobjects.userEmailAddress.getAttribute("value"));
		return userslistspageobjects.useraccountstatus().getAttribute("value");
	}

	public String getAccountStatus(String username, String firstname, String lastname, String email)
	{
		driver=this.getDriver();

		waitFor((userslistspageobjects.useradvancedsearch_button())).click();


		waitFor((userslistspageobjects.filterfirstname()));
		userslistspageobjects.filterfirstname().click();
		userslistspageobjects.filterfirstname().sendKeys(firstname);
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterlastname())).click();
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterlastname())).sendKeys(lastname);
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterusername())).click();
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filterusername())).sendKeys(username);
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filteruseremail())).click();
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.filteruseremail())).sendKeys(email);
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.applyfilter())).click();
		System.out.println("Clicked on apply filter");
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(userslistspageobjects.usersearch_firstresult())).click();
		System.out.println("Clicked on the first result");
		
		String accountStatus=new Select(userslistspageobjects.useraccountstatus()).getFirstSelectedOption().getText();
		
		if(accountStatus.isEmpty())
		{
			Result="Failed";
		}
		
		else
		{
			Result=accountStatus;
		}
		
		return Result;
	}

}
*/