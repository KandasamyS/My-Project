/*package ui.Signon;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import common.JDBCConnection;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.ChangePasswordPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.SignonObjects;

public class ChangePasswordPage extends PageObject {


	WebDriver driver =null;

	String Result=null;

	JDBCConnection jdbcConnection;

	DashboardPage_Objects dashboardPageObjects;
	SignonObjects signOnObjects;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	CommunicationSummaryPage communicationSummaryPage;
	AccountActivationPageObjects accountActivationPageObjects;
	ChangePasswordPageObjects changePasswordPageObjects; 

	@Step
	public String changePassword(String userName,String newPassword)
	{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		waitFor(changePasswordPageObjects.newPassword).sendKeys(newPassword);
		waitFor(changePasswordPageObjects.repeatPassword).sendKeys(newPassword);
		executor.executeScript("arguments[0].click()",changePasswordPageObjects.changePassword);
		if(changePasswordPageObjects.continueToDashboard.isCurrentlyVisible())
		{
//			executor.executeScript("arguments[0].click()",changePasswordPageObjects.continueToDashboard);
//		}
//		
//		executor.executeScript("arguments[0].click()",dashboardPageObjects.logout);
//		waitFor(signOnObjects.UserName).sendKeys(userName);
//		waitFor(signOnObjects.Password).sendKeys(newPassword);
//		executor.executeScript("arguments[0].click()",signOnObjects.Submit);
//
//		if(dashboardPageObjects.Welcome_message.isCurrentlyVisible())
//		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}
}
*/