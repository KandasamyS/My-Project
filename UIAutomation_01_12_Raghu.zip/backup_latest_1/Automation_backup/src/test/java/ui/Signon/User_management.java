package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import common.JDBCConnection;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.pages.WebElementFacade;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.ChangePasswordPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;
import ui.pageobjects.Signon.UsersListPageObjects;

public class User_management extends PageObject{

	String Result=null,Error_message=null;
	WebDriver driver =null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	AdminPage_object adminPageobjects;
	UserManagementPageObjects usermanagePageobjects;
	SettingsPageObjects settingspageobjects;
	ExportEmailPageObjects exportemailadminPageobjects;
	CommunicationSummaryPageObjects comsummaryadminPageobjects;
	EmailTemplatePageObjects emailtemplatePageobjects;
	SMSTemplatePageObjects smstemplatePageobjects;
	PreAuthorizationsPageObjects preauthobjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	UserManagementPageObjects usermanagementpageobjects;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	AccountActivationPageObjects accountActivationPageObjects;
	ChangePasswordPageObjects changePasswordPageObjects; 
	MerchantAdminPageObjects merchantAdminPageObjects;
	UsersListPageObjects usersListPageObjects; 
	ParametersPageObjects parametersPageObjects;
	
	public String device;
	
	JDBCConnection jdbcConnection;
	//CommunicationSummaryPage communicationSummaryPage;
	public static String initiationLink;
	public static WebElement passwordResetLink;
	String loginStatus=null;
	public String expiryDay,expiryMonth,expiryYear;
	public String clickedAccountStatus;

	
	
@Step
public void loadbrowser(){
	
	System.out.println("Loading Browser");
	System.out.println("Launched CHrome Browser");
	driver = this.getDriver();	
}
	
@Step
public String navigate(String url) throws Exception{
	driver=this.getDriver();
	driver.get(url);
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
	if(signonObjects.UserName.isCurrentlyVisible())
	{
		Result="Passed "+"WebPage is available for next action";
	}
	else
	{
		Result="Failed "+"WebPage in not loaded.";
	}
	return Result;
}
@Step
public void RememberMe() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.RememberMe()));
	if(signonObjects.RememberMe().isDisplayed()){
		signonObjects.RememberMe().click();
	}
	
}
@Step
public String userInput(String fieldName, String fieldValue) throws InterruptedException{
	System.out.println(fieldName);
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if (fieldName.equals("UserName")){
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
		signonObjects.UserName().sendKeys(fieldValue);
		Result="Passed";
	}
	
	else if(fieldName.equals("Password"))
	{
		signonObjects.Password().sendKeys(fieldValue);
		Result="Passed";
	}
	else if(fieldName.equals("Alliance"))
	{
		signonObjects.alliance().sendKeys(fieldValue);
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
}
@Step
public String Submitlogin_for_alert_testcase() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	signonObjects.Submit().click();
	if(signonObjects.error_message_invalidLogin.isCurrentlyVisible())
	{
		Result="Failed "+signonObjects.error_message_invalidLogin().getText();
	}
	else
	{
		Result="Passed "+"Successfully login to the system";
	}
	
	return Result;
	
}
@Step
public String Submitlogin(String welcome_text) throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 80);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].click()",signonObjects.Submit());
	for(int i=0;i<=100;i++)
	{waitForWithRefresh();
	checkPageIsReady();}
	
	if(signonObjects.error_message_invalidLogin.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.error_message_invalidLogin()));
		Result="Failed "+signonObjects.error_message_invalidLogin().getText();
	}
	else
	{
		for(int i=0;i<=50;i++)
		{waitForWithRefresh();
		checkPageIsReady();}
		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",signonObjects.Accept_TermsAndCondition());
		}
		for(int i=0;i<=50;i++)
		{waitForWithRefresh();
		checkPageIsReady();}
		if(dasboardpageObjects.unread_alerts.isCurrentlyVisible())
		{
			
			executor.executeScript("arguments[0].click()",dasboardpageObjects.unread_alerts());
			for(int i=0;i<=50;i++)
			{waitForWithRefresh();
			checkPageIsReady();}
			checkPageIsReady();}
	
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.login_date()));
		String login=dasboardpageObjects.login_date().getText();
		
			if(dasboardpageObjects.login_date.isCurrentlyVisible())
			{
				Result="Passed "+"Successfully login to the system";
			}
	}
	return Result;
}
@Step
public String login_admin_console() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	signonObjects.login_admin().click();
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Welcome_text_admin()));
	if(signonObjects.Welcome_text_admin().getText().contains("User"))
	{
		Result="Passed";
	}
	else {
		Result="Failed";
				
	}
	
	return Result;
}
@Step
public String last_login_date_time_in_home_page() throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if(dasboardpageObjects.last_login_date_time.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		String [] login_date_time=dasboardpageObjects.last_login_date_time().getText().split(",");
		Result="Passed  "+ "The last_login date is : "+login_date_time[0]+" and "+" The time is : "+login_date_time[1];
		
	}
	else
	{
		Result="Failed"+" No Last login date are available";
	}
	
	
	return Result;
}
@Step
public String create_new_allianz_user(String User_Type,String Alliance_name,String Profile_type,String First_Name,String last_name,String email_id,String UserName_new_alliance,String mobile_number,String Language)throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 100);
	System.out.println("profile type : "+Profile_type);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.create_user()));
	adminPageobjects.create_user().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.user_type()));
	adminPageobjects.user_type().sendKeys(User_Type);
	checkPageIsReady();
	Thread.sleep(3000);
	System.out.println(adminPageobjects.allianceType.isCurrentlyVisible());
	checkPageIsReady();
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.allianceType()));
	checkPageIsReady();
	adminPageobjects.allianceType().sendKeys(Alliance_name);
	checkPageIsReady();
	Thread.sleep(3000);
	for(int i=0;i<=100;i++)	
	{wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.profile_type()));}
	checkPageIsReady();
	System.out.println(adminPageobjects.profile_type.isCurrentlyVisible());
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.profile_type()));
	checkPageIsReady();
	Select select=new Select(adminPageobjects.profile_type());
	select.selectByVisibleText(Profile_type);
	//adminPageobjects.profile_type().sendKeys(Profile_type);
	if(UserName_new_alliance.length()==8 || !(UserName_new_alliance.length()<8) || !(UserName_new_alliance.length()>25))
	{
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.firstName()));
	adminPageobjects.firstName().sendKeys(First_Name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.lastName()));
	adminPageobjects.lastName().sendKeys(last_name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.email_id()));
	adminPageobjects.email_id().sendKeys(email_id);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.mobileNUmber()));
	adminPageobjects.mobileNUmber().sendKeys(mobile_number);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Language_msg_dropdown()));
	adminPageobjects.Language_msg_dropdown().sendKeys(Language);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.UserName_new_alliance()));
	adminPageobjects.UserName_new_alliance().sendKeys(UserName_new_alliance);
	Result="passed  ";
	}
	else
	{
		Result="Failed  ";
	}
		adminPageobjects.save_button().click();
		for(int i=0;i<adminPageobjects.error_message_field.size();i++)
		{
			if(adminPageobjects.error_message_field.get(i).isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.error_message_field.get(i)));
				Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.error_message_field.get(i).getText();
			}
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
		if(adminPageobjects.Created_successfully_text().getText().contains("User has been added successfully"))
		{
			Result="Passed  "+adminPageobjects.Created_successfully_text().getText();
		}
		else
		{
			Result="Failed  "+adminPageobjects.Created_successfully_text().getText();
		}
		}
	return Result;	
}
@Step
public String Create_new_merchant(String User_Type,String Merchant_ID,String Profile_type,String First_Name,String last_name,String UserName_new_alliance,String email_id,String mobile_number,String Language) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 100);
	//JavascriptExecutor executor = (JavascriptExecutor)driver;
//	if(!adminPageobjects.create_user_boardingagent.isCurrentlyVisible())
//	{adminPageobjects.hidden_button.click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.create_user_boardingagent()));
	adminPageobjects.create_user_boardingagent.click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.user_type()));
	adminPageobjects.user_type().sendKeys(User_Type);
	checkPageIsReady();
	adminPageobjects.merchantID.isCurrentlyVisible();
	System.out.println(adminPageobjects.merchantID.isCurrentlyVisible());
	for(int i=0;i<=100;i++)
	{checkPageIsReady();wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.merchantID()));}
    adminPageobjects.merchantID().sendKeys(Merchant_ID);
    for(WebElement element:adminPageobjects.merchantList)

    {
        if(element.getText().contains(Merchant_ID))
        waitFor(element).click();
    }
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.profile_type()));
	adminPageobjects.profile_type().sendKeys(Profile_type);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.firstName()));
	adminPageobjects.firstName().sendKeys(First_Name);
	adminPageobjects.lastName().sendKeys(last_name);
	adminPageobjects.email_id().sendKeys(email_id);
	if(UserName_new_alliance.length()==8 || !(UserName_new_alliance.length()<8) || !(UserName_new_alliance.length()>25))
	{
		adminPageobjects.mobileNUmber().sendKeys(mobile_number);
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Language_msg_dropdown()));
		adminPageobjects.Language_msg_dropdown().sendKeys(Language);
		for(int i=0;i<=100;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.UserName_new_alliance()));}
		adminPageobjects.merchantID.isCurrentlyVisible();
		System.out.println(adminPageobjects.UserName_new_alliance.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.UserName_new_alliance()));
		adminPageobjects.UserName_new_alliance().sendKeys(UserName_new_alliance);	
	}
	else
	{
		Result="Failed  ";
	}
		adminPageobjects.save_button().click();
		for(int i=0;i<adminPageobjects.error_message_field.size();i++)
		{
			if(adminPageobjects.error_message_field.get(i).isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.error_message_field.get(i)));
				Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.error_message_field.get(i).getText();
			}
			/*else if(adminPageobjects.PanelError.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.PanelError()));
				Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.PanelError().getText();
			}*/
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
				if(adminPageobjects.Created_successfully_text().getText().contains("User has been added successfully."))
				{
					wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
					Result="Passed  "+adminPageobjects.Created_successfully_text().getText();
				}
				else
				{
					wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
					Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.PanelError().getText();
				}
			}
		}

return Result;	
}
@Step
public String Validate_profile_information() throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	dasboardpageObjects.more_option().click();
	dasboardpageObjects.settings().click();
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.First_LastName()));
	if(settingspageobjects.First_LastName.isCurrentlyVisible() && dasboardpageObjects.Welcome_message().getText().contains(settingspageobjects.First_LastName().getText()) && 
			settingspageobjects.email_addres.isCurrentlyVisible() && settingspageobjects.mobile_number.isCurrentlyVisible() && settingspageobjects.userName.isCurrentlyEnabled())
	{
		Result="Passed "+" Firstname and last Name of the account: "+settingspageobjects.First_LastName().getText()+" Email address of the account: "+
			settingspageobjects.email_addres().getText()+" Mobile Number of the user: "+settingspageobjects.mobile_number().getText()+" UserName of the user Account "+settingspageobjects.userName().getText();
	}
	else
	{
		Result="Failed "+"No in formation is there..Error in fetching the details";
	}
	return Result;
	
}
@Step
public String Change_Password_of_BO(String New_password, String password) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	dasboardpageObjects.more_option().click();
	dasboardpageObjects.settings().click();
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.changePassword_link()));
	executor.executeScript("arguments[0].click()",settingspageobjects.changePassword_link());
	if(settingspageobjects.oldPassword.isCurrentlyVisible() && settingspageobjects.newPassword.isCurrentlyVisible() && !password.equals(New_password) && New_password.length()==8 
			|| !(New_password.length()<8) && !(New_password.length()>=25))
	{
		settingspageobjects.oldPassword().sendKeys(password);
		settingspageobjects.newPassword().sendKeys(New_password);
		settingspageobjects.confirmPassword().sendKeys(New_password);
	}
	else
	{
		Result="Failed";
	}
	executor.executeScript("arguments[0].click()",settingspageobjects.continue_button());
	if(settingspageobjects.passwordErromessage.isCurrentlyVisible())
	{
		Result="Failed to change the password Got the error like : "+settingspageobjects.passwordErromessage().getText();
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		String SuccessPasswordMessage=settingspageobjects.passwordsetmessage().getText();
		dasboardpageObjects.Continue_dashboard_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		Result="Passed "+ " Successfully Change the password " +SuccessPasswordMessage;
	}
	return Result;	
}
@Step
public String Password_expire_message(String New_password, String password) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.passwordExpireMessage()));
	if(dasboardpageObjects.passwordExpireMessage.isCurrentlyVisible())
	{
		String ExpiredMessage = dasboardpageObjects.passwordExpireMessage().getText();
		dasboardpageObjects.passwordExpirelink().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.oldPassword()));
		if(settingspageobjects.oldPassword.isCurrentlyVisible() && settingspageobjects.newPassword.isCurrentlyVisible() && !password.equals(New_password) && New_password.length()==8 
				|| !(New_password.length()<8) && !(New_password.length()>=25))
		{
			settingspageobjects.oldPassword().sendKeys(password);
			settingspageobjects.newPassword().sendKeys(New_password);
			settingspageobjects.confirmPassword().sendKeys(New_password);
		}
		else
		{
			Result="Failed";
		}
		settingspageobjects.continue_button().click();
		if(settingspageobjects.passwordErromessage.isCurrentlyVisible())
		{
			Result="Failed to change the password Got the error like : "+settingspageobjects.passwordErromessage().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
			String SuccessPasswordMessage=settingspageobjects.passwordsetmessage().getText();
			dasboardpageObjects.Continue_dashboard_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
			Result="Passed "+" Previously got the message like this : "+ ExpiredMessage +" After changing the password :" +SuccessPasswordMessage;
		}
	}
	else
	{
		Result="Passed "+"Pasword has been changed ";
	}
	return Result;
}
@Step
public String Search_User_in_Admin_console(String First_Name, String last_name,String UserName_new_alliance) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.users_list()));
	adminPageobjects.users_list().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Filter_button()));
	adminPageobjects.Filter_button().click();
	waitFor(adminPageobjects.firstname_filter());
	//wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Filter_button()));
	//wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.firstname_filter()));
	adminPageobjects.firstname_filter().sendKeys(First_Name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.lastname_filter()));
	adminPageobjects.lastname_filter().sendKeys(last_name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.username_filter()));
	adminPageobjects.username_filter().sendKeys(UserName_new_alliance);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Applybutton_filter()));
	adminPageobjects.Applybutton_filter().click();
	if(!adminPageobjects.no_records_found.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.selected_message()));
		if(adminPageobjects.username_text().getText().contains(UserName_new_alliance))
		{
			Result="Passed "+"Admin able to see the "+UserName_new_alliance;
		}
		else
		{
			Result="Failed "+"Username is not matched with "+UserName_new_alliance;
		}
	}
	else
	{
		Result="Failed "+adminPageobjects.no_records_found.getText();
	}
	return Result;
}
@Step
public String Export_the_alliance_user_list(String Alliance_name,String downloaded_Path) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	//JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(exportemailadminPageobjects.Export_email_link()));
	exportemailadminPageobjects.Export_email_link().click();
	waitFor(exportemailadminPageobjects.alliance_drop_down());
	if(exportemailadminPageobjects.No_record_found_text.isCurrentlyVisible())
	{
		exportemailadminPageobjects.alliance_drop_down().sendKeys(Alliance_name);
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(exportemailadminPageobjects.First_Record()));
		waitFor(exportemailadminPageobjects.csv_button());
		exportemailadminPageobjects.csv_button().click();
		for(int i=0;i<=80;i++){checkPageIsReady();
	    waitFor(exportemailadminPageobjects.csv_button());}
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    long length = getLatestFile.length();
	    for(int i=0;i<=60;i++)
	    {checkPageIsReady();waitFor(exportemailadminPageobjects.csv_button());}
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && fileName.endsWith(".csv"))
	    	{
	    		Result="Passed "+fileName+"Successfully exported the document";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	
	return Result;
}
@Step
public String Check_communication_summary_for_registraion_link(String UserName_new_alliance) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.Communication_Summary__link()));
	comsummaryadminPageobjects.Communication_Summary__link().click();
	for(int i=0;i<=50;i++)
	{
		wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.search_text_box()));
		checkPageIsReady();
	}
	comsummaryadminPageobjects.search_text_box().sendKeys(UserName_new_alliance);
	comsummaryadminPageobjects.search_button().click();
	for(int i=0;i<=100;i++)
	{
		wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.selected_row()));
		checkPageIsReady();
	}
	executor.executeScript("arguments[0].click()",comsummaryadminPageobjects.selected_row());
	for(int i=0;i<=50;i++)
	{
		wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.Email_Type()));
	}
	if(comsummaryadminPageobjects.Activate_account_link.isCurrentlyVisible())
	{
		Result="Passed "+comsummaryadminPageobjects.Activate_account_link.getText()+comsummaryadminPageobjects.Email_Type();
	}
	else
	{
		Result="Failed ";
	}
	return Result;	
}
@Step
public String Send_Registration_Email_available_in_communication_summary(String UserName_new_alliance) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.Communication_Summary__link()));
	comsummaryadminPageobjects.Communication_Summary__link().click();
	for(int i=0;i<=50;i++)
	{
		wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.search_text_box()));
		checkPageIsReady();
	}
	comsummaryadminPageobjects.search_text_box().sendKeys(UserName_new_alliance);
	comsummaryadminPageobjects.search_button().click();
	for(int i=0;i<=200;i++)
	{
		wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.selected_row()));
		checkPageIsReady();
	}
	if(comsummaryadminPageobjects.selected_row().getText().contains(UserName_new_alliance))
	{
		executor.executeScript("arguments[0].click()",comsummaryadminPageobjects.selected_row());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(comsummaryadminPageobjects.Resend_link()));
		}
		if(comsummaryadminPageobjects.Resend_link.isCurrentlyVisible())
		{
			String Resend_link=comsummaryadminPageobjects.Resend_link.getText();
			driver.get(Resend_link);
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			if(signonObjects.accountActiveStatus.isCurrentlyVisible())
			{
				Result="Passed "+signonObjects.accountActiveStatus().getText();
			}
			else if(signonObjects.Lets_go_link_in_registration.isCurrentlyVisible())
			{
				Result="Passed "+signonObjects.Lets_go_link_in_registration().getText();
			}
			else
			{
				Result="Failed "+"404 not found";
			}
		}
		else
		{
			Result="Failed "+"Link is not present in the console";
		}
	}
	else
	{
			Result="Failed "+adminPageobjects.no_records_found().getText();
	}
	return Result;	
}
@Step
public String logout() throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.logout()));
	if(dasboardpageObjects.logout.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",dasboardpageObjects.logout());
		Result="Passed "+ "Successfully logout from the system. ";
	}
	else
	{
		Result="Failed "+"Failed to logout. ";
	}
	return Result;
}
@Step
public String Change_Password_error_prompt(String password, String New_password, String Retype_New_password) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	dasboardpageObjects.more_option().click();
	dasboardpageObjects.settings().click();
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.changePassword_link()));
	executor.executeScript("arguments[0].click()",settingspageobjects.changePassword_link());
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.oldPassword()));
	if(settingspageobjects.oldPassword.isCurrentlyVisible() && settingspageobjects.newPassword.isCurrentlyVisible() && !password.equals(New_password) && !(New_password.length()>=25))
	{
		settingspageobjects.oldPassword().sendKeys(password);
		settingspageobjects.newPassword().sendKeys(New_password);
		settingspageobjects.confirmPassword().sendKeys(Retype_New_password);
	}
	else
	{
		Result="Failed";
	}
	executor.executeScript("arguments[0].click()",settingspageobjects.continue_button());
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.passwordErromessage()));
	if(settingspageobjects.passwordErromessage.isCurrentlyVisible())
	{
		Result="Passed "+"Failed to change the password Got the error like : "+settingspageobjects.passwordErromessage().getText();
	}
	else
	{
		Result="Failed "+ " No error message Prompt came ";
	}
	return Result;	
}
@Step
public String Define_Modify_email_template(String email_Type, String Language, String Description_email,String email_subject) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.Email_template()));
	emailtemplatePageobjects.Email_template().click();
	wait.until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.search_text_box()));
	emailtemplatePageobjects.search_text_box().sendKeys(email_Type);
	emailtemplatePageobjects.search_button().click();
	for(int i=0;i<=100;i++){checkPageIsReady();}
	/*if(emailtemplatePageobjects.No_data_found.isCurrentlyVisible())
	{
		Result="Failed "+emailtemplatePageobjects.No_data_found().getText();
	}*/
	/*else
	{*/
		
		for(int i=0;i<emailtemplatePageobjects.selected_row_email_type.size() && emailtemplatePageobjects.selected_row_email_type.get(i).getText().contains(email_Type);i++)
		{
				if(emailtemplatePageobjects.selected_row_Language.get(i).getText().contains(Language))
				{
					wait.until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.selected_row_email_type.get(i)));
					emailtemplatePageobjects.selected_row_email_type.get(i).click();
					wait.until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.Description_emeil_template()));
					emailtemplatePageobjects.Description_emeil_template().clear();
					emailtemplatePageobjects.Description_emeil_template().sendKeys(Description_email);
					wait.until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.Subject_email_template()));
					emailtemplatePageobjects.Subject_email_template().clear();
					emailtemplatePageobjects.Subject_email_template().sendKeys(email_subject);
					wait.until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.submit_button()));
					emailtemplatePageobjects.submit_button().click();
					for(int i1=0;i1<=25;i1++){checkPageIsReady();}
					if(emailtemplatePageobjects.Panel_message_success_error().getText().contains("is already exist"))
					{
						Result="Failed "+emailtemplatePageobjects.Panel_message_success_error().getText();
					}
					else
					{
						Result="Passed "+emailtemplatePageobjects.Panel_message_success_error().getText();
					}
				}
			}
		
	
	return Result;
}

@Step
public String Define_Modify_sms_template(String sms_Type, String Language, String Description_sms,String sms_subject) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.SMS_template()));
	smstemplatePageobjects.SMS_template().click();
	wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.search_text_box()));
	smstemplatePageobjects.search_text_box().sendKeys(sms_Type);
	smstemplatePageobjects.search_button().click();
	for(int i=0;i<=100;i++){checkPageIsReady();}
	if(smstemplatePageobjects.No_data_found.isCurrentlyVisible())
	{
		Result="Failed "+smstemplatePageobjects.No_data_found().getText();
	}
	else
	{
		for(int i=0;i<smstemplatePageobjects.selected_row_sms_template.size() && smstemplatePageobjects.selected_row_sms_template.get(i).getText().contains(sms_Type);i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.selected_row_sms_template.get(i)));
			smstemplatePageobjects.selected_row_sms_template.get(i).click();
			String select=new Select(smstemplatePageobjects.language_selection()).getFirstSelectedOption().getText();
			System.out.println(select);
			if(select.equals(Language))
			{
				wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.Description_sms_template()));
				smstemplatePageobjects.Description_sms_template().clear();
				smstemplatePageobjects.Description_sms_template().sendKeys(Description_sms);
				wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.Subject_sms_template()));
				smstemplatePageobjects.Subject_sms_template().clear();
				smstemplatePageobjects.Subject_sms_template().sendKeys(sms_subject);
				wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.submit_button()));
				smstemplatePageobjects.submit_button().click();
				for(int i1=0;i1<=25;i1++){checkPageIsReady();}
				if(smstemplatePageobjects.Panel_message_success_error().getText().contains("is already exist"))
				{
					Result="Failed "+smstemplatePageobjects.Panel_message_success_error().getText();
				}
				else
				{
					Result="Passed "+smstemplatePageobjects.Panel_message_success_error().getText();
				}
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.cancel_button()));
				smstemplatePageobjects.cancel_button().click();
				wait.until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.search_text_box()));
				smstemplatePageobjects.search_text_box().sendKeys(sms_Type);
				smstemplatePageobjects.search_button().click();
				for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			}
		}
	}
	return Result;	
}

@Step
public String Role_based_access_restriction_for_BO_and_BA() throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	int count=0;
	String Result1=null;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_Link()));
	dasboardpageObjects.preauthorization_Link().click();
	for(int i=0;i<=100;i++)
	{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));}
	if(preauthobjects.search_error_message.isCurrentlyVisible())
	{
		Result="Failed "+preauthobjects.search_error_message.getText();
	}
	else
	{
		System.out.println(preauthobjects.plus_icon.size());
		
		List<WebElement> completeBeforeDate=preauthobjects.complete_before_date;
		wait.until(ExpectedConditions.visibilityOfAllElements(completeBeforeDate));
		
		for(int i=0;i<preauthobjects.plus_icon.size();i++)
		{
			System.out.println("size of date is:"+completeBeforeDate.size());
			wait.until(ExpectedConditions.elementToBeClickable(completeBeforeDate.get(i)));
			System.out.println(completeBeforeDate.get(i).getText());
			System.out.println(!completeBeforeDate.get(i).getText().equals("Completed"));
			System.out.println(!completeBeforeDate.get(i).getText().equals("Declined"));
			if(!completeBeforeDate.get(i).getText().equals("Completed") && !completeBeforeDate.get(i).getText().equals("Declined") )
			{
				executor.executeScript("arguments[0].click()", preauthobjects.plus_icon.get(i));
				for(int i1=0;i1<=50;i1++){checkPageIsReady();}
				if(preauthobjects.preAuth_complete_button.isCurrentlyVisible() && preauthobjects.Void_button.isCurrentlyVisible())
				{
					count=count+1;
					Result1="Passed "+count+" This account is related to BO account "+"It will have access to financial activity and preauth completion";
					executor.executeScript("arguments[0].click()", preauthobjects.plus_icon.get(i));
				}
				else
				{
					count=count+1;
					Result1="Passed "+count+" This account is related to BA account "+"It wont have full access to do the preauth completion, void ";
				}
			}
		}
		Result=Result1;
	}
	return Result;
}

@Step
public String Create_sub_account_in_merchant_portal(String First_Name,String last_name,String UserName_new_alliance,String email_id,String mobile_number,String Profile_type) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 100);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	dasboardpageObjects.more_option().click();
	dasboardpageObjects.User_management().click();
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.create_user()));
	executor.executeScript("arguments[0].click()",usermanagePageobjects.create_user());
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.First_Name()));
	usermanagePageobjects.First_Name().sendKeys(First_Name);
	usermanagePageobjects.last_name().sendKeys(last_name);
	usermanagePageobjects.UserName_new_alliance().sendKeys(UserName_new_alliance);
	usermanagePageobjects.email_id().sendKeys(email_id);
	usermanagePageobjects.mobile_number().sendKeys(mobile_number);
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button()));
	executor.executeScript("arguments[0].click()",usermanagePageobjects.Next_button());
	if(usermanagePageobjects.Firstname_error_message.isCurrentlyVisible() || usermanagePageobjects.Lasname_error_message.isCurrentlyVisible() || usermanagePageobjects.username_error_message.isCurrentlyVisible() ||usermanagePageobjects.emailid_error_message.isCurrentlyVisible() ||usermanagePageobjects.mobileNumber_error_message.isCurrentlyVisible())
	{
		if(usermanagePageobjects.Firstname_error_message.isCurrentlyVisible())
		{
			Error_message=usermanagePageobjects.Firstname_error_message().getText();
		}
		else if(usermanagePageobjects.Lasname_error_message.isCurrentlyVisible())
		{
			Error_message=usermanagePageobjects.Lasname_error_message().getText();
		}
		else if(usermanagePageobjects.username_error_message.isCurrentlyVisible())
		{
			Error_message=usermanagePageobjects.username_error_message().getText();
		}
		else if(usermanagePageobjects.emailid_error_message.isCurrentlyVisible())
		{
			Error_message=usermanagePageobjects.emailid_error_message().getText();
		}
		else if(usermanagePageobjects.mobileNumber_error_message.isCurrentlyVisible())
		{
			Error_message=usermanagePageobjects.mobileNumber_error_message().getText();
		}
		Result="Failed "+"Invalid input for one of the field : "+Error_message;
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.profile_dropdown()));
		Actions actions = new Actions(driver);
		actions.moveToElement(usermanagePageobjects.profile_dropdown());
		actions.click();
		actions.sendKeys(Profile_type);
		actions.build().perform();
		//usermanagePageobjects.profile_dropdown().sendKeys(Profile_type);
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.nextbutton_2ndpage()));
		usermanagePageobjects.nextbutton_2ndpage().click();
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.merchantUserSelection()));
		executor.executeScript("arguments[0].click()",usermanagePageobjects.merchantUserSelection());
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.save_button()));
		usermanagePageobjects.save_button().click();
		Result="Passed"+"User : "+UserName_new_alliance+" has been added successfully";
	}
	return Result;
}
@Step
public String Modify_sub_account_in_Admin_portal(String UserName_new_alliance) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 100);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.users_list()));
	adminPageobjects.users_list().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.search_box()));
	adminPageobjects.search_box().sendKeys(UserName_new_alliance);
	adminPageobjects.search_button().click();
	for(int i=0;i<=25;i++)
	{checkPageIsReady();}
	if(!adminPageobjects.no_records_found.isCurrentlyVisible())
	{
		if(adminPageobjects.selected_UserName().getText().contains(UserName_new_alliance))
		{
			wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.selected_UserName()));
			executor.executeScript("arguments[0].click()",adminPageobjects.selected_UserName());
			if(adminPageobjects.error_title_sub_account.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.error_title_sub_account()));
				Result="Passed "+adminPageobjects.error_title_sub_account().getText();
				System.out.println(Result);
			}
			else
			{
				Result="Failed "+"This user : "+UserName_new_alliance+" is not an sub account";
			}
		}
		else
		{
			Result="Failed "+"The user name is not same as what we have searched ";
		}
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.no_records_found()));
		Result="Failed "+adminPageobjects.no_records_found().getText();
	}
	System.out.println("After all block"+Result);
	return Result;	
}

@Step
public String navigate_to_UserLists()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Users_List()));
	if(adminPageobjects.Users_List.isCurrentlyVisible())
	{
		adminPageobjects.Users_List.click();
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
	
}
@Step
public String Search_Userdetails(String User_Name)  throws InterruptedException{
	driver = this.getDriver();	
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Search_Text()));
	adminPageobjects.Search_Text().sendKeys(User_Name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Search_button()));
	adminPageobjects.Search_button().click();
	wait.until(ExpectedConditions.visibilityOf(adminPageobjects.Search_button()));
	waitFor(adminPageobjects.Search_button());
	if (adminPageobjects.No_Result_Found.isPresent())
	{
		Result="Failed"+":"+adminPageobjects.No_Result_Found().getText();
	}
	else 
	{
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Result_Found()));
		waitFor(adminPageobjects.Result_Found());
		Thread.sleep(5000);
		executor.executeScript("arguments[0].click()",adminPageobjects.Result_Found());
		//waitFor(adminPageobjects.Edit_User_header());
		Result="Passed"+":"+"Result Found";
	}	
	 
	return Result;
	
}
@Step
public String Modify_Userdetails(String First_Name, String Last_Name, String Email, String Mobile_Phone, String Phone_Number)  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Edit_User_header()));
	if(adminPageobjects.Edit_User_header.isCurrentlyVisible())
	{
		if (!(First_Name).isEmpty())
		{
			adminPageobjects.First_Name().clear();
			adminPageobjects.First_Name().sendKeys(First_Name);
		}
		if (!(Last_Name).isEmpty())
		{
			adminPageobjects.Last_Name().clear();
			adminPageobjects.Last_Name().sendKeys(Last_Name);
		}
		if (!(Email).isEmpty())
		{
			adminPageobjects.Email().clear();
			adminPageobjects.Email().sendKeys(Email);
		}
		if (!(Mobile_Phone).isEmpty())
		{
			adminPageobjects.Mobile_Phone().clear();
			adminPageobjects.Mobile_Phone().sendKeys(Mobile_Phone);
		}
		if (!(Phone_Number).isEmpty())
		{
			adminPageobjects.Phone_Number().clear();
			adminPageobjects.Phone_Number().sendKeys(Phone_Number);
		}
		waitFor(adminPageobjects.submitButton());
		if (adminPageobjects.submitButton().isEnabled())
		{
		adminPageobjects.submitButton().click();
			if (adminPageobjects.Save_message.isCurrentlyVisible())
			{
			Result="Passed"+":"+adminPageobjects.Save_message().getText();
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="Failed";
		}
	}
	else
	{
		Result="Failed";
	}
	return Result;
	
}

@Step
public String navigate_to_User_Management()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].click()",dasboardpageObjects.Dashboard_link());
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.page_load_text()));
	//wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.More_Option()));
	if(usermanagePageobjects.More_Option.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.More_Option()));
		//executor.executeScript("arguments[0].click()",usermanagePageobjects.More_Option());
		usermanagePageobjects.More_Option().click();
		if(usermanagePageobjects.User_Management_Link.isPresent())
		{
		//wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.User_Management_Link()));
		//wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.User_Management_Link()));
		//usermanagePageobjects.User_Management_Link().click();
		executor.executeScript("arguments[0].click()",usermanagePageobjects.User_Management_Link());
		Result="Passed"+"::"+"Successfuly navigated to User Management";
		}
		else
		{
			Result="Failed"+"::"+"Unable to Navigate to User Management.User Management Link not available";
		}
	}
	else
	{
		Result="Failed"+"::"+"Unable to Navigate to User Management.More option Link not available";;
	}
	return Result;
}
@Step
public String navigate_to_Manage_user_access(String User_Name)  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Page_load_image()));
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
	if (usermanagePageobjects.Search_Textbox.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
		usermanagePageobjects.Search_Textbox().clear();
		usermanagePageobjects.Search_Textbox().sendKeys(User_Name);
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		System.out.println(usermanagePageobjects.Search_Textbox_AutoFill_Username.getText());
		usermanagePageobjects.Search_Textbox_AutoFill_Username().click();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_button()));
		usermanagePageobjects.Search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
		waitFor(usermanagePageobjects.Search_Textbox());
		if (!usermanagePageobjects.No_Result_Found.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Result_Expand()));
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Result_Expand()));
			//usermanagePageobjects.Search_Result_Expand().click();
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Search_Result_Expand());
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Manage_User_Access_button()));
			//usermanagePageobjects.Manage_User_Access_button().click();
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Manage_User_Access_button());
			Result="Passed";
		}
		else
		{
			Result="Failed"+":"+usermanagePageobjects.No_Result_Found.getText();
		}
	}
	else 
	{
		Result="Failed";
	}	
	return Result;
	
}
@Step
public String user_should_be_able_to_provide_reason_for_blocking_sub_account(String reason)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Profile_access()));
	String Profile_access1=null,Profile_access2=null;
	if(usermanagePageobjects.Profile_access.isCurrentlyVisible())
	{
		System.out.println("Before choosing Status:"+usermanagePageobjects.Profile_access.getText());
		Profile_access1=usermanagePageobjects.Profile_access.getText();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Profile_access()));
		waitFor(usermanagePageobjects.Profile_access());
		executor.executeScript("arguments[0].click()",usermanagePageobjects.Profile_access());
		//usermanagePageobjects.Profile_access.click();
		waitFor(usermanagePageobjects.Profile_access_Blocked());
		usermanagePageobjects.Profile_access_Blocked.click();
		System.out.println("After choosing Status:"+usermanagePageobjects.Profile_access.getText());
		Profile_access2=usermanagePageobjects.Profile_access.getText();
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Reason_dropdown()));
		System.out.println("Before choosing Reason:"+usermanagePageobjects.Reason_dropdown.getText());
		waitFor(usermanagePageobjects.Reason_dropdown());
		usermanagePageobjects.Reason_dropdown.click();
		if(reason.contains("User is no longer working for the company"))
		{
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Block_Reason1());	
			System.out.println("After choosing Reason:"+usermanagePageobjects.Reason_dropdown.getText());
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
			usermanagePageobjects.Save_Changes_button().click();
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.success_message()));
			Result="Passed" + "::"+"Profile Access updated for User from "+Profile_access1+" -> "+Profile_access2+" Blocked for reason - "+reason;
			//usermanagePageobjects.Close_button.click();
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Close_button());
		}
		else if(reason.contains("User has another role within the company"))
		{
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Block_Reason2());	
			System.out.println("After choosing:"+usermanagePageobjects.Reason_dropdown.getText());
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
			usermanagePageobjects.Save_Changes_button().click();
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.success_message()));
			System.out.println("Success Message:"+usermanagePageobjects.success_message.getText());
			//Result="Passed" + ":"+ "User Access Successfully Updated; Blocke for reason - "+ reason;
			Result="Passed" + "::"+"Profile Access updated for User from "+Profile_access1+" -> "+Profile_access2+" Blocked for reason - "+reason;
			//usermanagePageobjects.Close_button.click();
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Close_button());
		}
		else if(reason.contains("Other"))
		{
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Block_Reason3());	
			System.out.println("After choosing:"+usermanagePageobjects.Reason_dropdown.getText());
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
			usermanagePageobjects.Save_Changes_button().click();
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.success_message()));
			System.out.println("Success Message:"+usermanagePageobjects.success_message.getText());
			//Result="Passed" + ":"+ "User Access Successfully Updated; Blocked for reason - "+ reason;
			Result="Passed" + "::"+"Profile Access updated for User from "+Profile_access1+" -> "+Profile_access2+" Blocked for reason - "+reason;
			//usermanagePageobjects.Close_button.click();
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Close_button());
		}
		else 
		{
			Result="Failed" + ":"+"Reason provided doesn't match with drop down list";
			//usermanagePageobjects.Close_button.click();
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Close_button());
		}
		
	}
	else
	{
		Result="Failed" + ":"+"Unable to navigate to Manage User access";
	}
	return Result;
}

@Step
public String user_should_not_be_able_to_view_Mark_for_Expiry()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Manage_user_access_text()));
	if(driver.getPageSource().contains("Expir"))
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
}

@Step
public String user_should_not_be_able_to_view_option_to_terminate_all_additional_users()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Textbox()));
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Result_Expand()));
	if (usermanagePageobjects.Search_Result_Expand.isCurrentlyVisible())
	{
		if (usermanagePageobjects.Check_box.isPresent())
		{
			Result="Failed"+"::"+"Checkbox is available in the page and hence user has option to terminate all additional users";
		}
		else
		{
			Result="Passed"+"::"+"Checkbox is not be available in the page and hence user has no option to terminate all additional users";
		}
	}
	else 
	{
		if(usermanagePageobjects.No_Result_Found.isCurrentlyVisible())
		{
		Result="Failed"+"::"+usermanagePageobjects.No_Result_Found.getText();
		}
		if(usermanagePageobjects.Technical_Error.isCurrentlyVisible())
		{
		Result="Failed"+"::"+usermanagePageobjects.Technical_Error.getText();	
		}
		
	}	
	return Result;
	
}

@Step
public String access_should_be_restricted_for_additional_BO_user_to_modify(String original_BO_accounts)  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Page_load_image()));
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Textbox()));
	if (usermanagePageobjects.Search_Textbox.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Page_load_image()));
		usermanagePageobjects.Search_Textbox().clear();
		usermanagePageobjects.Search_Textbox().sendKeys(original_BO_accounts);
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		waitFor(usermanagePageobjects.Search_Textbox_AutoFill_Username());
		usermanagePageobjects.Search_Textbox_AutoFill_Username().click();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_button()));
		usermanagePageobjects.Search_button().click();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Page_load_image()));
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
		waitFor(usermanagePageobjects.Search_Textbox());
		if (usermanagePageobjects.No_Result_Found.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.No_Result_Found()));
			Result="Passed"+"::"+usermanagePageobjects.No_Result_Found.getText();
		}
		else if(usermanagePageobjects.Search_Result_Expand.isDisplayed())
		{
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Page_load_image()));
			Result="Failed"+"::"+"Additional BO User has access to modify Original BO Accounts";
		}
		else if(usermanagePageobjects.Technical_Error.isDisplayed())
		{
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Technical_Error()));
			Result="Failed"+"::"+usermanagePageobjects.Technical_Error.getText();	
		}
		else 
		{
			Result="Failed";
		}
	}
	else 
	{
		Result="Failed"+"::"+"Page Navigation or Load Error";
	}	
	return Result;
}
@Step
public String navigate_to_Edit_user_details(String User_Name)  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Page_load_image()));
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
	if (usermanagePageobjects.Search_Textbox.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
		usermanagePageobjects.Search_Textbox().clear();
		usermanagePageobjects.Search_Textbox().sendKeys(User_Name);
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		System.out.println(usermanagePageobjects.Search_Textbox_AutoFill_Username.getText());
		usermanagePageobjects.Search_Textbox_AutoFill_Username().click();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_button()));
		usermanagePageobjects.Search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
		waitFor(usermanagePageobjects.Search_Textbox());
		if (!usermanagePageobjects.No_Result_Found.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Result_Expand()));
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Result_Expand()));
			usermanagePageobjects.Search_Result_Expand().click();
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Edit_user_details_button()));
			usermanagePageobjects.Edit_user_details_button().click();
			Result="Passed";
		}
		else
		{
			Result="Failed"+":"+usermanagePageobjects.No_Result_Found.getText();
		}
	}
	else 
	{
		Result="Failed";
	}	
	return Result;
	
}
@Step
public String user_should_be_able_to_edit(String Firstname, String Lastname, String Email, String mobileno, String telphoneno, String Profile)  throws InterruptedException{
	driver = this.getDriver();
	String Result1=null, Result2=null, Result3=null, Result4=null, Result5=null;
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Edit_user_Title()));
	if(usermanagePageobjects.Edit_user_Title.isCurrentlyVisible())
	{
		//driver.switchTo().frame(driver.findElement(By.id("frameId")));
		{
		if (!(Firstname).isEmpty())
		{
			usermanagePageobjects.Firstname().clear();
			usermanagePageobjects.Firstname().sendKeys(Firstname);
		}
		if (!(Lastname).isEmpty())
		{
			usermanagePageobjects.Lastname().clear();
			usermanagePageobjects.Lastname().sendKeys(Lastname);
		}
		if (!(Email).isEmpty())
		{
			usermanagePageobjects.Email().clear();
			usermanagePageobjects.Email().sendKeys(Email);
		}
		if (!(mobileno).isEmpty())
		{
			usermanagePageobjects.mobileno().clear();
			usermanagePageobjects.mobileno().sendKeys(mobileno);
		}
		if (!(telphoneno).isEmpty())
		{
			usermanagePageobjects.telphoneno().clear();
			usermanagePageobjects.telphoneno().sendKeys(telphoneno);
		}
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step1()));
		usermanagePageobjects.Next_button_Step1().click();
		}
		
		if(usermanagePageobjects.Firstname_error.isCurrentlyVisible()||usermanagePageobjects.Lastname_error.isCurrentlyVisible()||usermanagePageobjects.Email_error.isCurrentlyVisible()||usermanagePageobjects.mobileno_error.isCurrentlyVisible()||usermanagePageobjects.telphoneno_error.isCurrentlyVisible())
		{
			if (usermanagePageobjects.Firstname_error.isCurrentlyVisible())
			{
				Result1=usermanagePageobjects.Firstname_error.getText();
			}
			if (usermanagePageobjects.Lastname_error.isCurrentlyVisible())
			{
				Result2=usermanagePageobjects.Lastname_error.getText();
			}
			if (usermanagePageobjects.Email_error.isCurrentlyVisible())
			{
				Result3=usermanagePageobjects.Email_error.getText();
			}
			if (usermanagePageobjects.mobileno_error.isCurrentlyVisible())
			{
				Result4=usermanagePageobjects.mobileno_error.getText();
			}
			if (usermanagePageobjects.telphoneno_error.isCurrentlyVisible())
			{
				Result5=usermanagePageobjects.telphoneno_error.getText();
			}
			
			Result="Failed" + "::" +Result1+" ; "+Result2+" ; "+Result3+" ; "+Result4+" ; "+Result5;
		}
		else
		{
			waitFor(usermanagePageobjects.Select_Profile_drop_down());
			usermanagePageobjects.Select_Profile_drop_down.click();
				if(Profile.contains("Business Assistant"))
				{
					executor.executeScript("arguments[0].click()",usermanagePageobjects.Business_Assistant());	
					wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step2()));
					usermanagePageobjects.Next_button_Step2().click();
					wait.until(ExpectedConditions.stalenessOf(usermanagePageobjects.Save_Changes_button()));
					waitFor(usermanagePageobjects.Save_Changes_button());
					wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Save_Changes_button()));
					wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
					usermanagePageobjects.Save_Changes_button().click();
					if(usermanagePageobjects.Save_Error.isPresent())
					{
					Result="Failed" + ":"+ usermanagePageobjects.Save_Error.getText();	
					}
					else
					{
					Result="Passed" + ":"+ "User details edited Successfully";	
					}
				}
				else if(Profile.contains("Business Owner"))
				{
					executor.executeScript("arguments[0].click()",usermanagePageobjects.Business_Owner());	
					wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step2()));
					usermanagePageobjects.Next_button_Step2().click();
					//wait.until(ExpectedConditions.stalenessOf(usermanagePageobjects.Save_Changes_button()));
					waitFor(usermanagePageobjects.Save_Changes_button());
					wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Save_Changes_button()));
					wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
					usermanagePageobjects.Save_Changes_button().click();
					if(usermanagePageobjects.Save_Error.isPresent())
					{
					Result="Failed" + ":"+ usermanagePageobjects.Save_Error.getText();	
					}
					else
					{
					Result="Passed" + ":"+ "User details edited Successfully";	
					}
				}
				else 
				{
					Result="Failed" + ":"+"Profile provided doesn't match with drop down list";
				}
		}
		
	}
	else
	{
		Result="Failed" + ":"+"Unable to navigate to Edit User details";
	}
	return Result;
}
@Step
public String Click_Create_User()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Page_load_image()));
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Create_User()));
	//usermanagePageobjects.Create_User().click();
	executor.executeScript("arguments[0].click()",usermanagePageobjects.Create_User());
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Edit_user_Title()));
	if(usermanagePageobjects.Edit_user_Title.isCurrentlyVisible())
	{
		Result="Passed";
	}
	else 
	{
		Result="Failed";
	}	
	return Result;
}
@Step
public String user_should_be_able_to_provide_BO_Profile_to_additional_users(String Firstname, String Lastname, String User_name, String Email, String mobileno, String telphoneno)  throws InterruptedException{
	driver = this.getDriver();
	String Result1=null, Result2=null, Result3=null, Result4=null, Result5=null, Result6=null;
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Edit_user_Title()));
	if(usermanagePageobjects.Edit_user_Title.isCurrentlyVisible())
	{
		usermanagePageobjects.Firstname().sendKeys(Firstname);
		usermanagePageobjects.Lastname().sendKeys(Lastname);
		usermanagePageobjects.User_name().sendKeys(User_name);
		usermanagePageobjects.Email().sendKeys(Email);
		usermanagePageobjects.mobileno().sendKeys(mobileno);
		if (!(telphoneno).isEmpty())
		{
			usermanagePageobjects.telphoneno().sendKeys(telphoneno);
		}
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step1()));
		usermanagePageobjects.Next_button_Step1().click();
		//Step 1 -> Validation
		if(usermanagePageobjects.Firstname_error.isCurrentlyVisible()||usermanagePageobjects.Lastname_error.isCurrentlyVisible()||usermanagePageobjects.User_name_error.isCurrentlyVisible()||usermanagePageobjects.Email_error.isCurrentlyVisible()||usermanagePageobjects.mobileno_error.isCurrentlyVisible()||usermanagePageobjects.telphoneno_error.isCurrentlyVisible())
		{
			if (usermanagePageobjects.Firstname_error.isCurrentlyVisible())
			{
				Result1=usermanagePageobjects.Firstname_error.getText();
			}
			if (usermanagePageobjects.Lastname_error.isCurrentlyVisible())
			{
				Result2=usermanagePageobjects.Lastname_error.getText();
			}
			if (usermanagePageobjects.User_name_error.isCurrentlyVisible())
			{
				Result3=usermanagePageobjects.User_name_error.getText();
			}
			if (usermanagePageobjects.Email_error.isCurrentlyVisible())
			{
				Result4=usermanagePageobjects.Email_error.getText();
			}
			if (usermanagePageobjects.mobileno_error.isCurrentlyVisible())
			{
				Result5=usermanagePageobjects.mobileno_error.getText();
			}
			if (usermanagePageobjects.telphoneno_error.isCurrentlyVisible())
			{
				Result6=usermanagePageobjects.telphoneno_error.getText();
			}
			
			Result="Failed" + "::" +Result1+" ; "+Result2+" ; "+Result3+" ; "+Result4+" ; "+Result5+" ; "+Result6;
		}
		else
		{
			waitFor(usermanagePageobjects.Select_Profile_drop_down());
			usermanagePageobjects.Select_Profile_drop_down.click();				
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Business_Owner());	
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step2()));
			usermanagePageobjects.Next_button_Step2().click();
			//wait.until(ExpectedConditions.stalenessOf(usermanagePageobjects.Save_Changes_button()));
			waitFor(usermanagePageobjects.Save_Changes_button());
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Save_Changes_button()));
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Merchant_All_Radio_button());
			//usermanagePageobjects.Merchant_All_Radio_button.click();
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Save_Changes_button());
			//usermanagePageobjects.Save_Changes_button().click();
			if(usermanagePageobjects.Save_Error.isPresent())
			{
			Result="Failed" + ":"+ usermanagePageobjects.Save_Error.getText();	
			}
			else
			{
			Result="Passed" + ":"+ "Created additional user and provided BO Profile successfully";	
			}	
		}	
	}
	else
	{
		Result="Failed" + ":"+"Unable to navigate to Create User";
	}
	return Result;
}

@Step
public String user_should_be_able_to_Create_new_user(String Firstname, String Lastname, String User_name, String Email, String mobileno, String telphoneno, String Profile)  throws InterruptedException{
	driver = this.getDriver();
	String Result1=null, Result2=null, Result3=null, Result4=null, Result5=null, Result6=null;
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Edit_user_Title()));
	if(usermanagePageobjects.Edit_user_Title.isCurrentlyVisible())
	{
		usermanagePageobjects.Firstname().sendKeys(Firstname);
		usermanagePageobjects.Lastname().sendKeys(Lastname);
		usermanagePageobjects.User_name().sendKeys(User_name);
		usermanagePageobjects.Email().sendKeys(Email);
		usermanagePageobjects.mobileno().sendKeys(mobileno);
		if (!(telphoneno).isEmpty())
		{
			usermanagePageobjects.telphoneno().sendKeys(telphoneno);
		}
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step1()));
		usermanagePageobjects.Next_button_Step1().click();
		//Step 1 -> Validation
		if(usermanagePageobjects.Firstname_error.isCurrentlyVisible()||usermanagePageobjects.Lastname_error.isCurrentlyVisible()||usermanagePageobjects.User_name_error.isCurrentlyVisible()||usermanagePageobjects.Email_error.isCurrentlyVisible()||usermanagePageobjects.mobileno_error.isCurrentlyVisible()||usermanagePageobjects.telphoneno_error.isCurrentlyVisible())
		{
			if (usermanagePageobjects.Firstname_error.isCurrentlyVisible())
			{
				Result1=usermanagePageobjects.Firstname_error.getText();
			}
			if (usermanagePageobjects.Lastname_error.isCurrentlyVisible())
			{
				Result2=usermanagePageobjects.Lastname_error.getText();
			}
			if (usermanagePageobjects.User_name_error.isCurrentlyVisible())
			{
				Result3=usermanagePageobjects.User_name_error.getText();
			}
			if (usermanagePageobjects.Email_error.isCurrentlyVisible())
			{
				Result4=usermanagePageobjects.Email_error.getText();
			}
			if (usermanagePageobjects.mobileno_error.isCurrentlyVisible())
			{
				Result5=usermanagePageobjects.mobileno_error.getText();
			}
			if (usermanagePageobjects.telphoneno_error.isCurrentlyVisible())
			{
				Result6=usermanagePageobjects.telphoneno_error.getText();
			}
			
			Result="Failed" + "::" +Result1+" ; "+Result2+" ; "+Result3+" ; "+Result4+" ; "+Result5+" ; "+Result6;
			usermanagePageobjects.Close_button.click();
		}
		//Step2 validation
		else
		{
			waitFor(usermanagePageobjects.Select_Profile_drop_down());
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Select_Profile_drop_down());
			//usermanagePageobjects.Select_Profile_drop_down.click();	
			if(Profile.contains("Business Assistant"))
			{
				executor.executeScript("arguments[0].click()",usermanagePageobjects.Business_Assistant());	
				wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step2()));
				usermanagePageobjects.Next_button_Step2().click();
				//wait.until(ExpectedConditions.stalenessOf(usermanagePageobjects.Save_Changes_button()));
				waitFor(usermanagePageobjects.Save_Changes_button());
				wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Save_Changes_button()));
				wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
				executor.executeScript("arguments[0].click()",usermanagePageobjects.Merchant_All_Radio_button());
				executor.executeScript("arguments[0].click()",usermanagePageobjects.Save_Changes_button());
				if(usermanagePageobjects.Save_Error.isPresent())
				{
				Result="Failed" + ":"+ usermanagePageobjects.Save_Error.getText();
				usermanagePageobjects.Close_button.click();
				}
				else
				{
				Result="Passed" + ":"+ "User created Successfully";	
				}
			}
			else if(Profile.contains("Business Owner"))
			{
				executor.executeScript("arguments[0].click()",usermanagePageobjects.Business_Owner());	
				wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Next_button_Step2()));
				usermanagePageobjects.Next_button_Step2().click();
				//wait.until(ExpectedConditions.stalenessOf(usermanagePageobjects.Save_Changes_button()));
				waitFor(usermanagePageobjects.Save_Changes_button());
				wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Save_Changes_button()));
				wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
				executor.executeScript("arguments[0].click()",usermanagePageobjects.Merchant_All_Radio_button());
				executor.executeScript("arguments[0].click()",usermanagePageobjects.Save_Changes_button());
				if(usermanagePageobjects.Save_Error.isPresent())
				{
				Result="Failed" + ":"+ usermanagePageobjects.Save_Error.getText();
				usermanagePageobjects.Close_button.click();
				}
				else
				{
				Result="Passed" + ":"+ "User created Successfully";	
				}
			}
			else 
			{
				Result="Failed" + ":"+"Profile provided doesn't match with drop down list";
				//usermanagePageobjects.Close_button.click();
				executor.executeScript("arguments[0].click()",usermanagePageobjects.Close_button());
			}
			
		}	
	}
	else
	{
		Result="Failed" + ":"+"Unable to navigate to Create User";
	}
	return Result;
}
@Step
public String should_be_able_to_view_User_created_by_the_BO(String AdditionalUser)  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Page_load_image()));
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
	if (usermanagePageobjects.Search_Textbox.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
		usermanagePageobjects.Search_Textbox().clear();
		usermanagePageobjects.Search_Textbox().sendKeys(AdditionalUser);
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox_AutoFill_Username()));
		System.out.println(usermanagePageobjects.Search_Textbox_AutoFill_Username.getText());
		usermanagePageobjects.Search_Textbox_AutoFill_Username().click();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_button()));
		usermanagePageobjects.Search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Textbox()));
		waitFor(usermanagePageobjects.Search_Textbox());
		if (!usermanagePageobjects.No_Result_Found.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Search_Result_Expand()));
			wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Search_Result_Expand()));
			executor.executeScript("arguments[0].click()",usermanagePageobjects.Search_Result_Expand());
			//usermanagePageobjects.Search_Result_Expand().click();
			wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Edit_user_details_button()));
			Result="Passed";
		}
		else
		{
			Result="Failed"+":"+usermanagePageobjects.No_Result_Found.getText();
		}
	}
	else 
	{
		Result="Failed";
	}	
	return Result;	
}

@Step
public String user_should_be_able_to_unblock_sub_account()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Profile_access()));
	String Profile_access=null;
	if(usermanagePageobjects.Profile_access.isCurrentlyVisible())
	{
		System.out.println("Before choosing Status:"+usermanagePageobjects.Profile_access.getText());
		Profile_access=usermanagePageobjects.Profile_access.getText();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Profile_access()));
		waitFor(usermanagePageobjects.Profile_access());
		executor.executeScript("arguments[0].click()",usermanagePageobjects.Profile_access());
		//usermanagePageobjects.Profile_access.click();
		waitFor(usermanagePageobjects.Profile_access_Active());
		//usermanagePageobjects.Profile_access_Active.click();
		executor.executeScript("arguments[0].click()",usermanagePageobjects.Profile_access_Active());
		System.out.println("After choosing Status:"+usermanagePageobjects.Profile_access.getText());
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
		//usermanagePageobjects.Save_Changes_button().click();
		executor.executeScript("arguments[0].click()",usermanagePageobjects.Save_Changes_button());
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.success_message()));
		Result="Passed" + ":"+"Profile Access updated for User from "+Profile_access+" -> "+usermanagePageobjects.Profile_access.getText();
		//Result="Passed" + ":"+"Profile Access '"+usermanagePageobjects.Profile_access.getText()+"' updated for User";	
		executor.executeScript("arguments[0].click()",usermanagePageobjects.Close_button());
		//usermanagePageobjects.Close_button.click();
	}
	else
	{
		Result="Failed" + ":"+"Unable to navigate to Manage User access";
	}
	return Result;
}

@Step
public String user_should_be_able_to_Terminate_sub_account()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Profile_access()));
	String Profile_access=null;
	if(usermanagePageobjects.Profile_access.isCurrentlyVisible())
	{
		System.out.println("Before choosing Status:"+usermanagePageobjects.Profile_access.getText());
		Profile_access=usermanagePageobjects.Profile_access.getText();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.Profile_access()));
		waitFor(usermanagePageobjects.Profile_access());
		executor.executeScript("arguments[0].click()",usermanagePageobjects.Profile_access());
		//usermanagePageobjects.Profile_access.click();
		waitFor(usermanagePageobjects.Profile_access_Terminated());
		usermanagePageobjects.Profile_access_Terminated.click();
		System.out.println("After choosing Status:"+usermanagePageobjects.Profile_access.getText());
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.Save_Changes_button()));
		usermanagePageobjects.Save_Changes_button().click();
		wait.until(ExpectedConditions.visibilityOf(usermanagePageobjects.success_message()));
		Result="Passed" + ":"+"Profile Access updated for User from "+Profile_access+" -> "+usermanagePageobjects.Profile_access.getText();
		//Result="Passed" + ":"+"Profile Access '"+usermanagePageobjects.Profile_access.getText()+"' updated for User";
		executor.executeScript("arguments[0].click()",usermanagePageobjects.Close_button());
		//usermanagePageobjects.Close_button.click();
	}
	else
	{
		Result="Failed" + ":"+"Unable to navigate to Manage User access";
	}
	return Result;
}

@Step
public String user_Navigate_to_Communication_summary()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Communication_summary()));
	if(adminPageobjects.Communication_summary.isCurrentlyVisible())
	{
		adminPageobjects.Communication_summary.click();
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
	
}
@Step
public String user_should_be_able_to_view_communication_history_for_Email_and_SMS()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Search_button()));
	int x=0;
	while (x < adminPageobjects.communication_summary_Table.size())
	{
		WebElement element = adminPageobjects.communication_summary_Table.get(x);
		if(element.isDisplayed())
        {
             waitFor(element).click();
             System.out.println("Page Viewed: "+adminPageobjects.Page_Header.getText()+" for user :"+adminPageobjects.comm_summary_username.getText());
             wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Communication_summary()));
             adminPageobjects.Communication_summary.click();
             wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Communication_summary()));
             Result="Passed";
             x++;
        }
        else
        {
        	Result="Failed";
        }
	}
	return Result;
}
@Step
public String user_should_be_able_to_Resend_previous_communications_via_email()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(adminPageobjects.comm_summary_username.isDisplayed())
    {
		System.out.println("Page Viewed: "+adminPageobjects.Page_Header.getText()+" for user :"+adminPageobjects.comm_summary_username.getText());
        executor.executeScript("arguments[0].click()",adminPageobjects.Send_button());
        wait.until(ExpectedConditions.visibilityOf(adminPageobjects.Mail_Sent_message()));
        if (adminPageobjects.Mail_Sent_message.getText().equalsIgnoreCase("manual email sent"))
        {
         	 Result="Passed"+"::"+adminPageobjects.Mail_Sent_message.getText();
        }
        else
        {
           	Result="Failed"+"::"+adminPageobjects.Mail_Sent_message.getText();
        }
    }
    else
    {
    	Result="Failed";
    }
	
	return Result;
}
@Step
public String Navigates_to_Settings()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
	wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.More_Option()));
	if(usermanagePageobjects.More_Option.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(usermanagePageobjects.More_Option()));
		usermanagePageobjects.More_Option().click();
		//executor.executeScript("arguments[0].click()",UsermgmtObjects.More_Option());
		wait.until(ExpectedConditions.visibilityOf(settingspageobjects.Settings_Link()));
		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Settings_Link()));
		settingspageobjects.Settings_Link().click();
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
}

@Step
public String username_should_be_same_as_email_address()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(settingspageobjects.User_name()));
	if(settingspageobjects.User_name.getText().equals(settingspageobjects.Email_address.getText()))
	{
		Result="Passed"+"::"+"User name is same as Email address; "+"User name is "+settingspageobjects.User_name.getText()+ ";"+"Email address is "+settingspageobjects.Email_address.getText();
	}
	else
	{
		Result="Failed"+"::"+"User name is not same as Email address; "+"User name is "+settingspageobjects.User_name.getText()+ ";"+"Email address is "+settingspageobjects.Email_address.getText();
	}
	return Result;
}
public boolean isFileDownloaded(String downloadPath, String fileName) throws InterruptedException {
	boolean flag = false;
	File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }
	 
    return flag;
}
private File getLatestFilefromDir(String dirPath) throws InterruptedException{
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}
public void checkPageIsReady() throws InterruptedException {

	  JavascriptExecutor js = (JavascriptExecutor)driver;


	  //Initially bellow given if condition will check ready state of page.
	/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
	
	   return; 
	  } 
*/
	  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
	  //You can replace your value with 25 If you wants to Increase or decrease wait time.
	  for (int i=0; i<100; i++){ 
	   //To check page ready state.
	   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   
	    break; 
	   }
	   System.out.println("Page Is loaded.");
	  }
	 }


/*------------------------Raghu----------------------------------*/

@Step
public String launchInitiationLink()
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;
	String url=initiationLink;
	System.out.println("The URL to be launched is:"+url);
	driver.get(url);
	while(!accountActivationPageObjects.letsGo.isCurrentlyVisible())
	{
		waitFor(accountActivationPageObjects.letsGo);
	}
	if(accountActivationPageObjects.letsGo.isCurrentlyVisible())
	{
		Result="Passed";
		waitFor(accountActivationPageObjects.letsGo);
		executor.executeScript("arguments[0].click()",accountActivationPageObjects.letsGo);
	}

	else
	{
		Result="Failed";
	}

	return Result;
}

public String enterPasscode(String userName,String mobileNumber) throws ClassNotFoundException, SQLException
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;

	if(accountActivationPageObjects.mobileNumber.getText().equals(mobileNumber))
	{
		//			waitFor(accountActivationPageObjects.resendPasscode);
		//			executor.executeScript("arguments[0].click()",accountActivationPageObjects.resendPasscode);

		//String passcode=jdbcConnection.getPasscode(userName);
		String passcode=JOptionPane.showInputDialog("Enter the passcode:");
		System.out.println("The received Passcode is:"+passcode);

		waitFor(accountActivationPageObjects.verificationCodeTextBox).click();
		waitFor(accountActivationPageObjects.verificationCodeTextBox).sendKeys(passcode);
		waitFor(accountActivationPageObjects.proceed);
		executor.executeScript("arguments[0].click()",accountActivationPageObjects.proceed);

		if(!accountActivationPageObjects.passcodeErrorMessage.isCurrentlyVisible())
		{
			Result="Passed";
		}
		else
		{
			Result=accountActivationPageObjects.passcodeErrorMessage.getText();
		}
	}
	else
	{
		Result="Phone numbers do not match";
	}

	return Result;
}

public String setPasswordAndPortalLanguage(String password, String portalLanguage)
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;
	String language=null;
	System.out.println("The password to be set is:"+password);

	executor.executeScript("arguments[0].click()",accountActivationPageObjects.password);
	waitFor(accountActivationPageObjects.password).sendKeys(password);
	executor.executeScript("arguments[0].click()",accountActivationPageObjects.confirmPassword);
	waitFor(accountActivationPageObjects.confirmPassword).sendKeys(password);

	switch(portalLanguage)
	{
	case "Dutch"   : language="Nederlands";break;
	case "French"  : language="Fran�ais";break;
	case "German"  : language="Deutsch";break;
	case "English" : language="English";break;
	}

	executor.executeScript("arguments[0].click()",accountActivationPageObjects.languageDropDown);

	List<WebElement> languageList=driver.findElements(accountActivationPageObjects.languageList);

	while(languageList.size()==0)
	{
		languageList=driver.findElements(accountActivationPageObjects.languageList);
	}

	for(WebElement element:languageList)
	{
		if(element.getText().equals(portalLanguage))
		{
			executor.executeScript("arguments[0].click()",element);
		}
	}

	waitFor(accountActivationPageObjects.acceptTermsAndConditions);
	executor.executeScript("arguments[0].click()",accountActivationPageObjects.acceptTermsAndConditions);

	System.out.println("The chosen language is:"+language);
	if(accountActivationPageObjects.languageDropDown.getText().equalsIgnoreCase(language))
	{
		waitFor(accountActivationPageObjects.continueButton);
		executor.executeScript("arguments[0].click()",accountActivationPageObjects.continueButton);
		if(!accountActivationPageObjects.passwordErrorMessage.isCurrentlyVisible())
		{
			Result="Passed";
		}
		else
		{
			Result=accountActivationPageObjects.passwordErrorMessage.getText();
		}
	}
	else
	{
		Result="Language not changed";
	}

	return Result;
}

public String validateAccountStatus()
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;

	if(accountActivationPageObjects.navigateToLoginPage.isCurrentlyVisible())
	{
		Result="Passed";
		executor.executeScript("arguments[0].click()",accountActivationPageObjects.navigateToLoginPage);
	}
	else
	{
		Result="Failed";
	}
	return Result;
}

public String resendPasscodeForPasswordReset(String userName,String passwordResetLink,String sqlQuery) throws ClassNotFoundException, SQLException
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;
	WebDriverWait wait=new WebDriverWait(driver,20);

	String encryptedUserName=jdbcConnection.getEncryptedUserName(userName,sqlQuery);
	String url=passwordResetLink+encryptedUserName;
	System.out.println("the password Reset link is:"+url);
	driver.get(url);

	while(!accountActivationPageObjects.passwordReset_verificationText.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.visibilityOf(accountActivationPageObjects.passwordReset_verificationText));
	}

	executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_resendPasscode);

	//String passcode=jdbcConnection.getPasscode(userName);
	String passcode=JOptionPane.showInputDialog("Enter the passcode:");
	System.out.println("The passcode is:"+passcode);

	accountActivationPageObjects.passwordReset_passcodeTextBox.sendKeys(passcode);

	executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_done);

	if(!accountActivationPageObjects.passwordReset_passcodeErrorMessage.isCurrentlyVisible())
	{
		if(accountActivationPageObjects.passwordReset_newPasswordText.isCurrentlyVisible())
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	else
	{
		Result=accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText();
	}

	return Result;
}

public String validatePasswordResetLinkStatus(String userName, String newPassword, String confirmPassword, String passwordResetLink, String sqlQuery) throws ClassNotFoundException, SQLException
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;

	String encryptedUserName=jdbcConnection.getEncryptedUserName(userName,sqlQuery);
	String url=passwordResetLink+encryptedUserName;
	System.out.println("the password Reset link is:"+url);
	driver.get(url);

	//String passcode=jdbcConnection.getPasscode(userName);
	String passcode=JOptionPane.showInputDialog("Enter the passcode:");
	System.out.println("The passcode is:"+passcode);

	accountActivationPageObjects.passwordReset_passcodeTextBox.sendKeys(passcode);

	executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_done);

	if(!accountActivationPageObjects.passwordReset_passcodeErrorMessage.isCurrentlyVisible())
	{
		if(accountActivationPageObjects.passwordReset_newPasswordText.isCurrentlyVisible())
		{
			waitFor(accountActivationPageObjects.passwordReset_newPassword).sendKeys(newPassword);
			waitFor(accountActivationPageObjects.passwordReset_confirmPassword).sendKeys(confirmPassword);
			executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_changePasswordButton);
			if(accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText().contains("Your password has been successfully changed. You are ready to log in."))
			{
				driver.get(url);
				if(accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText().contains("MPBE00057") || accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText().contains("Username already active"))
				{
					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result="Password not changed";
			}

		}
	}
	else
	{
		Result=accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText();
	}

	return Result;
}

public String resetPasswordFromPasswordResetLink(String userName,String passwordResetLink,String sqlQuery,String newPassword,String confirmPassword) throws ClassNotFoundException, SQLException
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;
	WebDriverWait wait=new WebDriverWait(driver,20);

	//String encryptedUserName=jdbcConnection.getEncryptedUserName(userName);
	//String url=passwordResetLink+encryptedUserName;
	
	String url="https://uat1.merchantportal.firstdata.eu/emsMerchantUI/#/reset2?userName=2432612431302472544e37792f33743173796a763234525a787130662e50713149655971524e556773627466763371772e313042456e416c5a77624f";
	System.out.println("the password Reset link is:"+url);
	driver.get(url);

	while(!accountActivationPageObjects.passwordReset_verificationText.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.visibilityOf(accountActivationPageObjects.passwordReset_verificationText));
	}

	//executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_resendPasscode);

	//String passcode=jdbcConnection.getPasscode(userName);
	String passcode=JOptionPane.showInputDialog("Enter the passcode:");
	System.out.println("The passcode is:"+passcode);

	accountActivationPageObjects.passwordReset_passcodeTextBox.sendKeys(passcode);

	executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_done);


	if(!accountActivationPageObjects.passwordReset_passcodeErrorMessage.isCurrentlyVisible())
	{
		waitFor(accountActivationPageObjects.passwordReset_newPasswordText);
		if(accountActivationPageObjects.passwordReset_newPasswordText.isCurrentlyVisible())
		{
			accountActivationPageObjects.passwordReset_newPassword.sendKeys(newPassword);
			accountActivationPageObjects.passwordReset_confirmPassword.sendKeys(confirmPassword);
			executor.executeScript("arguments[0].click()",accountActivationPageObjects.passwordReset_changePasswordButton);
			
			if(accountActivationPageObjects.passwordReset_resetPasswordSuccessMessage.getText().contains("Your password has been successfully changed. You are ready to log in."))
			{
				Result="Passed";
			}
			else
			{
				Result=accountActivationPageObjects.passwordReset_resetPasswordErrorMessage.getText();
			}
		}
		else
		{
			Result="Could not navigate to the Reset Password Page";
		}
		
	}
	else
	{
		Result=accountActivationPageObjects.passwordReset_passcodeErrorMessage.getText();
	}

	return Result;
}

@Step
public String changePassword(String userName,String newPassword)
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;

	waitFor(changePasswordPageObjects.newPassword).sendKeys(newPassword);
	waitFor(changePasswordPageObjects.repeatPassword).sendKeys(newPassword);
	executor.executeScript("arguments[0].click()",changePasswordPageObjects.changePassword);
	if(changePasswordPageObjects.continueToDashboard.isCurrentlyVisible())
	{
//		executor.executeScript("arguments[0].click()",changePasswordPageObjects.continueToDashboard);
//	}
//	
//	executor.executeScript("arguments[0].click()",dashboardPageObjects.logout);
//	waitFor(signonObjects.UserName).sendKeys(userName);
//	waitFor(signonObjects.Password).sendKeys(newPassword);
//	executor.executeScript("arguments[0].click()",signonObjects.Submit);
//
//	if(dashboardPageObjects.Welcome_message.isCurrentlyVisible())
//	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}

	return Result;
}

@Step

public void searchEmail(String userName)
{
	driver=this.getDriver();
	while(!communicationSummaryPageObjects.emailSearchBox.isPresent())
	{
		waitFor(communicationSummaryPageObjects.emailSearchBox);
	}
	
	communicationSummaryPageObjects.emailSearchBox.click();
	communicationSummaryPageObjects.emailSearchBox.sendKeys(userName);
	waitFor(communicationSummaryPageObjects.emailSearchButton).click();
	
	while(!communicationSummaryPageObjects.emailSearchResult_latest.getText().equals(userName))
	{
		waitFor(communicationSummaryPageObjects.emailSearchResult_latest);
	}
	
	waitFor(communicationSummaryPageObjects.emailSearchResult_latest).click();
	
}

public String verifyPasswordResetLink(String userName, String emailAddress)
{
	driver=this.getDriver();
	
	searchEmail(userName);
	
	passwordResetLink=communicationSummaryPageObjects.passwordResetLink;
	
	if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(emailAddress)
			&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
			 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("RESET PASSWORD"))
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	
	return Result;
	
}

public String acessInitiationLink(String userName, String emailAddress)
{
	driver=this.getDriver();
	
	searchEmail(userName);
	
	initiationLink=communicationSummaryPageObjects.manualEmailNotification_resendLink.getText();
	System.out.println("the initiation link is:"+initiationLink);
	
	if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(emailAddress)
			&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
			 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("REGISTRATION"))
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	
	return Result;
	
}

public String resendInitiationLink(String userName, String emailAddress, String targetEmailAddress)
{
	driver=this.getDriver();
	
	searchEmail(userName);
	
	if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(emailAddress)
			&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
			 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("CHANGE EMAIL"))
	{
	waitFor(communicationSummaryPageObjects.resendEmail).click();
	}
	
	waitFor(usersListPageObjects.feedbackpanelinfo).click();
	
	waitFor(merchantAdminPageObjects.communicationSummary_link);
	
	searchEmail(userName);
	
	if(communicationSummaryPageObjects.emailCommunicationDetails_emailAddress.getText().contains(targetEmailAddress)
			&& communicationSummaryPageObjects.emailCommunicationDetails_userName.getText().equalsIgnoreCase(userName)
			 && communicationSummaryPageObjects.manualEmailNotification_emailType.getText().equalsIgnoreCase("CHANGE EMAIL"))
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	
	return Result;
	
}


@Step
public HashMap<String,String> getEmailTemplate(){

	driver = this.getDriver();	
	String currentPage;
	//HashMap<WebElement,WebElement> combine=new HashMap<WebElement,WebElement>();
	HashMap<String,String> finalEmailTemplate=new HashMap<String,String>();
	boolean flag=true;
	while(flag==true)
	{


			System.out.println("Size of the disabled link is: "+emailtemplatePageobjects.nextButtondisabled().size());
			if(emailtemplatePageobjects.nextButtondisabled().size()>0)
			{
				flag=false;
			}


			currentPage=emailtemplatePageobjects.currentPage().getText();
			System.out.println("Current Page is:"+currentPage);
			List<WebElement> email_id=emailtemplatePageobjects.email_id();
			System.out.println("number of ids is:"+email_id.size());
			List<WebElement> emailTemplate_id=emailtemplatePageobjects.emailTemplate_id();	
			System.out.println("number of template ids is:"+email_id.size());
			for(int i=0;i<10 && i<email_id.size();i++)
			{

				String templateid=email_id.get(i).getText();
				//System.out.println("template id:"+templateid);
				String templatename=emailTemplate_id.get(i).getText();
				//System.out.println("template name:"+templatename);

				new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(email_id.get(i))).click();
				if(driver.getCurrentUrl().contains(templateid) && smstemplatePageobjects.editSmsTemplateValue().getText().equals(templatename))
				{
					finalEmailTemplate.put(templateid,templatename);
					//System.out.println(finalSmsTemplate);
					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.cancelButton())).click();
				}

				while(!emailtemplatePageobjects.currentPage().getText().equals(currentPage))
				{
					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.nextButton())).click();
				}
			}

			//sms_id.clear();
			//smsTemplate_id.clear();
			if(flag==true)
			{
				System.out.println("Next Button status:"+emailtemplatePageobjects.nextButton().isEnabled());
				new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(emailtemplatePageobjects.nextButton())).click();
				System.out.println("Next Button status:"+emailtemplatePageobjects.nextButton().isEnabled());
			}
		}



	System.out.println("Total number of SMS templates is"+finalEmailTemplate.size());
	System.out.println(finalEmailTemplate);
	return finalEmailTemplate;	
}

@Step
public String changeSessionExpiryTime(String expiryTime)
{
	driver= this.getDriver();
	waitFor(parametersPageObjects.sessionExpiryTime).click();
	String originalValue=waitFor(parametersPageObjects.sessionExpiryTime).getAttribute("value");
	waitFor(parametersPageObjects.sessionExpiryTime).clear();
	waitFor(parametersPageObjects.sessionExpiryTime).sendKeys(expiryTime);
	waitFor(parametersPageObjects.saveButton).click();
	if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
	{
		Result=parametersPageObjects.parameterErrorMessage.getText();
	}
	else
	{
		waitFor(parametersPageObjects.activeParameters).click();
		String duration=waitFor(parametersPageObjects.sessionExpiryTime).getAttribute("value");
		if(duration.equals(expiryTime))
		{
			Result="Passed";
			waitFor(parametersPageObjects.sessionExpiryTime).click();
			waitFor(parametersPageObjects.sessionExpiryTime).clear();
			waitFor(parametersPageObjects.sessionExpiryTime).sendKeys(originalValue);
			waitFor(parametersPageObjects.saveButton).click();
		}
		else
		{
			Result="Failed";
		}
		
	}
	
	return Result;
}

public String changePasscodeExpiryTime(String passcodeExpiryTime)
{
	driver= this.getDriver();
	String originalValue=waitFor(parametersPageObjects.sessionExpiryTime).getAttribute("value");
	waitFor(parametersPageObjects.passcodeExpiryTime).click();
	waitFor(parametersPageObjects.passcodeExpiryTime).clear();
	waitFor(parametersPageObjects.passcodeExpiryTime).sendKeys(passcodeExpiryTime);
	waitFor(parametersPageObjects.saveButton).click();
	if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
	{
		Result=parametersPageObjects.parameterErrorMessage.getText();
	}
	else
	{
		waitFor(parametersPageObjects.activeParameters).click();
		String duration=waitFor(parametersPageObjects.passcodeExpiryTime).getAttribute("value");
		if(duration.equals(passcodeExpiryTime))
		{
			Result="Passed";
			waitFor(parametersPageObjects.passcodeExpiryTime).click();
			waitFor(parametersPageObjects.passcodeExpiryTime).clear();
			waitFor(parametersPageObjects.passcodeExpiryTime).sendKeys(originalValue);
			waitFor(parametersPageObjects.saveButton).click();
		}
		else
		{
			Result="Failed";
		}
		
	}
	
	return Result;
}

public String changePasswordExpiryDuration(String passwordExpiryDuration)
{
	driver= this.getDriver();
	String originalValue=waitFor(parametersPageObjects.passwordExpiryDays).getAttribute("value");
	waitFor(parametersPageObjects.passwordExpiryDays).click();
	waitFor(parametersPageObjects.passwordExpiryDays).clear();
	waitFor(parametersPageObjects.passwordExpiryDays).sendKeys(passwordExpiryDuration);
	waitFor(parametersPageObjects.saveButton).click();
	if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
	{
		Result=parametersPageObjects.parameterErrorMessage.getText();
	}
	else
	{
		waitFor(parametersPageObjects.activeParameters).click();
		String duration=waitFor(parametersPageObjects.passwordExpiryDays).getAttribute("value");
		if(duration.equals(passwordExpiryDuration))
		{
			Result="Passed";
			waitFor(parametersPageObjects.passwordExpiryDays).click();
			waitFor(parametersPageObjects.passwordExpiryDays).clear();
			waitFor(parametersPageObjects.passwordExpiryDays).sendKeys(originalValue);
			waitFor(parametersPageObjects.saveButton).click();
		}
		else
		{
			Result="Failed";
		}
		
	}
	
	return Result;
}

public String changePasswordResetLinkExpiryTime(String passwordResetLinkExpiryTime)
{
	driver= this.getDriver();
	String originalValue=waitFor(parametersPageObjects.passwordResetLinkExpiryTime).getAttribute("value");
	waitFor(parametersPageObjects.passwordResetLinkExpiryTime).click();
	waitFor(parametersPageObjects.passwordResetLinkExpiryTime).clear();
	waitFor(parametersPageObjects.passwordResetLinkExpiryTime).sendKeys(passwordResetLinkExpiryTime);
	waitFor(parametersPageObjects.saveButton).click();
	if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
	{
		Result=parametersPageObjects.parameterErrorMessage.getText();
	}
	else
	{
		waitFor(parametersPageObjects.activeParameters).click();
		String duration=waitFor(parametersPageObjects.passwordResetLinkExpiryTime).getAttribute("value");
		if(duration.equals(passwordResetLinkExpiryTime))
		{
			Result="Passed";
//			waitFor(parametersPageObjects.passcodeExpiryTime).click();
//			waitFor(parametersPageObjects.passcodeExpiryTime).clear();
//			waitFor(parametersPageObjects.passcodeExpiryTime).sendKeys(originalValue);
//			waitFor(parametersPageObjects.saveButton).click();
		}
		else
		{
			Result="Failed";
		}
		
	}
	
	return Result;
}

public String checkIfAccessIsDenied() throws InterruptedException, AWTException{
	driver = this.getDriver();
	Robot robot=new Robot();
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
	if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
	{
		robot.keyPress(KeyEvent.VK_ESCAPE);
		for(int i=0;i<50;i++){};
	}

	if(!(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible()) && signonObjects.UserName.isCurrentlyVisible())
	{
		loginStatus="Passed ";
	}
	else
	{
		loginStatus="Failed ";
	}
	return loginStatus;

}


public String checkIfAccountHasExpired() throws InterruptedException, AWTException{
	driver = this.getDriver();
	String Result;
	if(signonObjects.accountExpiredErrorMessage.isCurrentlyVisible() && signonObjects.accountExpiredErrorMessage.getText().contains("This account is expired. Please contact Customer Service"))
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}



	return Result;

}

public String sendPasswordResetLink(String userName)
{
	driver=this.getDriver();

	while(!signonObjects.forgotPasswordLink.isPresent())
	{
		waitFor(signonObjects.forgotPasswordLink);
	}
	waitFor(signonObjects.forgotPasswordLink).click();
	while(!signonObjects.forgotPasswordUsername.isPresent())
	{
		waitFor(signonObjects.forgotPasswordUsername);
	}
	waitFor(signonObjects.forgotPasswordUsername).sendKeys(userName);
	waitFor(signonObjects.resetPasswordSlider);
	Dimension sliderSize = signonObjects.resetPasswordSlider.getSize();
	int sliderWidth=sliderSize.getWidth();
	System.out.println(sliderWidth);
	int xCoord = signonObjects.resetPasswordSliderBar.getLocation().getX();
	System.out.println(xCoord);
	new Actions(driver).moveToElement(signonObjects.resetPasswordSliderBar).click().dragAndDropBy(signonObjects.resetPasswordSlider,xCoord,xCoord + sliderWidth).build().perform();

	if(signonObjects.resetPasswordSliderStatus.isCurrentlyVisible() && signonObjects.resetPasswordSliderStatus.getText().contains("human"))
	{
		waitFor(signonObjects.sendPasswordResetLink).click();
		if(signonObjects.loginErrorMessage.getText().contains("We have sent you an email regarding the changes, please check your email inbox."))
		{
			Result="Passed";
		}
	}
	else
	{
		Result="Failed";
	}

	return Result;
}

public String lockAccount(String userName,String password) throws InterruptedException
{
	driver=this.getDriver();
	
	for(int i=0;i<10;i++)
	{
	waitFor(signonObjects.UserName);
	waitFor(signonObjects.Password);
	waitFor(signonObjects.Submit);
	}
	
	for(int i=0;i<3;i++)
	{
		waitFor(signonObjects.UserName).clear();
		waitFor(signonObjects.UserName).sendKeys(userName);
		waitFor(signonObjects.Password).clear();
		waitFor(signonObjects.Password).sendKeys(password);
		waitFor(signonObjects.Submit).click();
		
		System.out.println("tried logging in for:"+i+"th time");
	}

	if(signonObjects.loginErrorMessage.getText().contains("Your account is temporarily locked due to 3 unsuccessful login attempts. Please wait for 30 minutes and try again."))
	{
		Result=signonObjects.loginErrorMessage.getText();
	}
	else
	{
		Result="Failed";
	}

	return Result;
}

public String validateLoginAttemptCount(String userName,String password) throws ClassNotFoundException, SQLException
{
	driver=this.getDriver();
	
	for(int i=0;i<10;i++)
	{
	waitFor(signonObjects.UserName);
	waitFor(signonObjects.Password);
	waitFor(signonObjects.Submit);
	}

	if(signonObjects.loginErrorMessage.isCurrentlyVisible() && signonObjects.loginErrorMessage.getText().contains("Your account is temporarily locked due to 3 unsuccessful login attempts. Please wait for 30 minutes and try again."))
	{
		waitFor(signonObjects.UserName).clear();
		waitFor(signonObjects.UserName).sendKeys(userName);
		waitFor(signonObjects.Password).clear();
		waitFor(signonObjects.Password).sendKeys(password);
		waitFor(signonObjects.Submit).click();
		System.out.println("tried logging in for the 4th time");
	}

	String attemptCount=jdbcConnection.getLoginAttemptCount(userName);
	System.out.println("The attempt count is:"+attemptCount);

	if(attemptCount=="3")
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}

	return Result;
}
public String checkIfLoginAttemptCountIsCleared(String userName, String password) throws ClassNotFoundException, SQLException
{
	driver=this.getDriver();

	String attemptCount=jdbcConnection.getLoginAttemptCount(userName);
	System.out.println("The attempt count is:"+attemptCount);

	if(attemptCount=="0")
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}

	return Result;
}

public String lockAccountPermanently(String userName,String password)
{
	driver=this.getDriver();
	for(int i=0;i<10;i++)
	{
	waitFor(signonObjects.UserName);
	waitFor(signonObjects.Password);
	waitFor(signonObjects.Submit);
	}
	for(int i=0;i<3;i++)
	{

		waitFor(signonObjects.UserName).clear();
		waitFor(signonObjects.UserName).sendKeys(userName);
		waitFor(signonObjects.Password).clear();
		waitFor(signonObjects.Password).sendKeys(password);
		waitFor(signonObjects.Submit).click();
		
		System.out.println("tried logging in for:"+i+"th time");
	}

	if(signonObjects.loginErrorMessage.isCurrentlyVisible() && signonObjects.loginErrorMessage.getText().contains("You have made 6 unsuccessful attempts to login. This account is now locked, please contact the Call Centre."))
	{
		Result=signonObjects.loginErrorMessage.getText();
	}
	else
	{
		Result="Failed";
	}

	return Result;
}

public String warnUserAboutLoginAttempt(String userName,String password)
{
	driver=this.getDriver();
	for(int i=0;i<10;i++)
	{
	waitFor(signonObjects.UserName);
	waitFor(signonObjects.Password);
	waitFor(signonObjects.Submit);
	}
	for(int i=0;i<2;i++)
	{

		waitFor(signonObjects.UserName).sendKeys(userName);
		waitFor(signonObjects.Password).sendKeys(password);
		waitFor(signonObjects.Submit).click();
		
		System.out.println("tried logging in for:"+i+"th time");
	}

	if(signonObjects.loginErrorMessage.isCurrentlyVisible() && signonObjects.loginErrorMessage.getText().contains("You have made 5 unsuccessful attempts to login. This is your last attempt otherwise your account will be locked."))
	{
		Result=signonObjects.loginErrorMessage.getText();
	}
	else
	{
		Result="Failed";
	}

	return Result;
}

@Step
public HashMap<String,String> getSMSTemplate(){

	driver = this.getDriver();	
	String currentPage;
	//HashMap<WebElement,WebElement> combine=new HashMap<WebElement,WebElement>();
	HashMap<String,String> finalSmsTemplate=new HashMap<String,String>();
	boolean flag=true;
	
	
	while(flag==true)
	{
		System.out.println("Size of the disabled link is: "+smstemplatePageobjects.nextButtondisabled().size());
		if(smstemplatePageobjects.nextButtondisabled().size()>0)
		{
			flag=false;
		}
		
		System.out.println("Flag value is:"+flag);
		currentPage=smstemplatePageobjects.currentPage().getText();
		System.out.println("Current Page is:"+currentPage);
		List<WebElement> sms_id=smstemplatePageobjects.sms_id();
		System.out.println("number of ids is:"+sms_id.size());
		List<WebElement> smsTemplate_id=smstemplatePageobjects.smsTemplate_id();	
		System.out.println("number of template ids is:"+sms_id.size());
		for(int i=0;i<10 && i<sms_id.size();i++)
		{

			String templateid=sms_id.get(i).getText();
			//System.out.println("template id:"+templateid);
			String templatename=smsTemplate_id.get(i).getText();
			//System.out.println("template name:"+templatename);

			new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(sms_id.get(i))).click();
			if(driver.getCurrentUrl().contains(templateid) && smstemplatePageobjects.editSmsTemplateValue().getText().equals(templatename))
			{
				finalSmsTemplate.put(templateid,templatename);
				//System.out.println(finalSmsTemplate);
				new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.cancelButton())).click();
			}
			
			while(!smstemplatePageobjects.currentPage().getText().equals(currentPage))
			{
				new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.nextButton())).click();
			}
		}
		
		if(flag==true)
		{
			System.out.println("Next Button status:"+smstemplatePageobjects.nextButton().isEnabled());
			new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(smstemplatePageobjects.nextButton())).click();
		}
		//System.out.println("Next Button status:"+smstemplatePageobjects.nextButton().isEnabled());
		
	}
	
	
	System.out.println("Total number of SMS templates is"+finalSmsTemplate.size());
	System.out.println(finalSmsTemplate);

	return finalSmsTemplate;
}

public void filterUser(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException
{
	driver=this.getDriver();
	
	waitFor((usersListPageObjects.useradvancedsearch_button())).click();
	System.out.println("Clicked on Advanced search");

	waitFor((usersListPageObjects.filterfirstname()));
	usersListPageObjects.filterfirstname().click();
	usersListPageObjects.filterfirstname().sendKeys(firstname);
	System.out.println("Clicked on first name. Chosen Value is:"+usersListPageObjects.filterfirstname().getAttribute("value"));

	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterlastname())).click();
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterlastname())).sendKeys(lastname);
	System.out.println("Clicked on last name. Chosen Value is:"+usersListPageObjects.filterlastname().getAttribute("value"));

	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterusername())).click();
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterusername())).sendKeys(username);
	System.out.println("Clicked on user name. Chosen Value is:"+usersListPageObjects.filterusername().getAttribute("value"));

	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filteruseremail())).click();
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filteruseremail())).sendKeys(email);
	System.out.println("Clicked on useremail. Chosen Value is:"+usersListPageObjects.filteruseremail().getAttribute("value"));

	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterstatusdropdown())).click();
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterstatusdropdown())).sendKeys(accountstatus);
	System.out.println("Clicked on status. Chosen Value is:"+usersListPageObjects.filterstatusdropdown.getAttribute("value"));

	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.applyfilter())).click();
	System.out.println("Clicked on apply filter");


	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.usersearch_firstresult())).click();
	System.out.println("Clicked on the first result");
}

public void blockUser(String firstname, String lastname, String username, String email, String accountstatus, String targetaccountstatus, String blockreason) throws AWTException, InterruptedException
{
	driver=this.getDriver();
	filterUser(firstname,lastname,username,email,accountstatus);
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.useraccountstatus()));
	Select selectstatus=new Select(usersListPageObjects.useraccountstatus());
	selectstatus.selectByVisibleText(targetaccountstatus);
	System.out.println("Chosen Status is:"+usersListPageObjects.useraccountstatus().getAttribute("value"));

	waitFor(usersListPageObjects.blockreason());
	Select selectblockreason=new Select(usersListPageObjects.blockreason());
	selectblockreason.selectByVisibleText(blockreason);
	System.out.println("Chosen Reason is:"+usersListPageObjects.blockreason().getAttribute("value"));
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.saveButton())).click();
	System.out.println("Clicked on Save");
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.feedbackpanelinfo())).click();
	waitFor((usersListPageObjects.useradvancedsearch_button())).click();
	waitFor((usersListPageObjects.advancedsearchreset_button())).click();

}

public String getBlockReason(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException
{
	driver=this.getDriver();
	filterUser(firstname,lastname,username,email,accountstatus);
	Select selectblockreason=new Select(usersListPageObjects.blockreason());
	System.out.println("Status is:"+usersListPageObjects.useraccountstatus().getAttribute("value"));
	clickedAccountStatus=usersListPageObjects.useraccountstatus().getAttribute("value");
	System.out.println("Reason for blocking is:"+selectblockreason.getFirstSelectedOption().getText());
	return selectblockreason.getFirstSelectedOption().getText();
}

public String unBlockUser(String firstname, String lastname, String username, String email, String accountstatus, String targetaccountstatus) throws InterruptedException
{
	driver=this.getDriver();
	filterUser(firstname,lastname,username,email,accountstatus);
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.useraccountstatus()));
	Select selectstatus=new Select(usersListPageObjects.useraccountstatus());
	selectstatus.selectByVisibleText(targetaccountstatus);
	System.out.println("Chosen Status is:"+usersListPageObjects.useraccountstatus().getAttribute("value"));
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.saveButton())).click();
	System.out.println("Clicked on Save");
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.feedbackpanelinfo())).click();
	waitFor((usersListPageObjects.useradvancedsearch_button())).click();
	waitFor((usersListPageObjects.advancedsearchreset_button())).click();
	filterUser(firstname,lastname,username,email,targetaccountstatus);
	System.out.println("Chosen Status after saving is:"+usersListPageObjects.useraccountstatus().getAttribute("value"));
	return usersListPageObjects.useraccountstatus().getAttribute("value");


}

public void setAccountExpiryDate(String firstname, String lastname, String username, String email, String accountstatus, String day, String month, String year) throws AWTException, InterruptedException
{
	driver=this.getDriver();
	filterUser(firstname,lastname,username,email,accountstatus);
	if(new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.markForExpiry())).isSelected())
	{
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.markForExpiry())).click();
	}
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.markForExpiry())).click();
	waitFor(usersListPageObjects.accountexpiryday());
	new Select(usersListPageObjects.accountexpiryday()).selectByVisibleText(day);
	waitFor(usersListPageObjects.accountexpirymonth());
	new Select(usersListPageObjects.accountexpirymonth()).selectByVisibleText(month);
	waitFor(usersListPageObjects.accountexpiryyear());
	new Select(usersListPageObjects.accountexpiryyear()).selectByVisibleText(year);
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.saveButton())).click();
	System.out.println("Clicked on Save");
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.feedbackpanelinfo())).click();
	waitFor((usersListPageObjects.useradvancedsearch_button())).click();
	waitFor((usersListPageObjects.advancedsearchreset_button())).click();

}

public void getAccountExpiryDate(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException
{
	driver=this.getDriver();
	filterUser(firstname,lastname,username,email,accountstatus);
	expiryDay=new Select(usersListPageObjects.accountexpiryday()).getFirstSelectedOption().getText();
	expiryMonth=new Select(usersListPageObjects.accountexpirymonth()).getFirstSelectedOption().getText();
	expiryYear=new Select(usersListPageObjects.accountexpiryyear()).getFirstSelectedOption().getText();
}

public String checkIfPortalAccessIsBlocked(String firstname, String lastname, String username, String email, String accountstatus, String url, String password) throws InterruptedException
{
	driver=this.getDriver();
	filterUser(firstname,lastname,username,email,accountstatus);
	System.out.println("Account Status is:"+usersListPageObjects.useraccountstatus().getAttribute("value"));
	String status=usersListPageObjects.useraccountstatus().getAttribute("value");
	if(status.equalsIgnoreCase("BLOCKED"))
	{
		driver.get(url);
		waitFor(signonObjects.UserName()).sendKeys(username);
		waitFor(signonObjects.Password()).sendKeys(password);
		waitFor(signonObjects.Submit()).click();

		if(signonObjects.loginErrorMessage.isCurrentlyVisible() && signonObjects.loginErrorMessage().getText().contains("Your access to the portal is not permitted currently. Please contact the Call Centre."))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}

	else
	{
		Result="Account is not blocked. Account status is:"+status;
	}


	return Result;	
}

public String changeEmail(String username, String firstname, String lastname, String email, String accountstatus,String targetemail) throws InterruptedException
{
	driver=this.getDriver();
	filterUser(firstname,lastname,username,email,accountstatus);
	waitFor(usersListPageObjects.userEmailAddress);
	usersListPageObjects.userEmailAddress.clear();
	usersListPageObjects.userEmailAddress.sendKeys(targetemail);
	waitFor(usersListPageObjects.saveButton()).click();
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.feedbackpanelinfo())).click();
	waitFor((usersListPageObjects.useradvancedsearch_button())).click();
	waitFor((usersListPageObjects.advancedsearchreset_button())).click();
	filterUser(firstname,lastname,username,targetemail,accountstatus);
	System.out.println("Email after saving is:"+usersListPageObjects.userEmailAddress.getAttribute("value"));
	return usersListPageObjects.useraccountstatus().getAttribute("value");
}

public String getAccountStatus(String username, String firstname, String lastname, String email)
{
	driver=this.getDriver();

	waitFor((usersListPageObjects.useradvancedsearch_button())).click();


	waitFor((usersListPageObjects.filterfirstname()));
	usersListPageObjects.filterfirstname().click();
	usersListPageObjects.filterfirstname().sendKeys(firstname);
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterlastname())).click();
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterlastname())).sendKeys(lastname);
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterusername())).click();
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filterusername())).sendKeys(username);
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filteruseremail())).click();
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.filteruseremail())).sendKeys(email);
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.applyfilter())).click();
	System.out.println("Clicked on apply filter");
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.usersearch_firstresult())).click();
	System.out.println("Clicked on the first result");
	
	String accountStatus=new Select(usersListPageObjects.useraccountstatus()).getFirstSelectedOption().getText();
	
	if(accountStatus.isEmpty())
	{
		Result="Failed";
	}
	
	else
	{
		Result=accountStatus;
	}
	
	return Result;
}

public String changeAccountStatus(String url,String username,String password, String firstname, String lastname, String email, String accountstatus,String targetaccountstatus,String sqlQuery) throws Exception
{
	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;
	String initialAccountStatus=null;
	String windowHandle=driver.getWindowHandle();
	int count=0;

	filterUser(firstname,lastname,username,email,accountstatus);
	if(!usersListPageObjects.noRecordsPresent.isCurrentlyVisible())
	{
		Select status=new Select(usersListPageObjects.useraccountstatus);
		initialAccountStatus=status.getFirstSelectedOption().getText();
		usersListPageObjects.useraccountstatus.sendKeys(targetaccountstatus);
		if(status.getFirstSelectedOption().getText().contains(targetaccountstatus))
		{
			count++;
		}
		waitFor(usersListPageObjects.saveButton()).click();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.feedbackpanelinfo())).click();
		waitFor((usersListPageObjects.useradvancedsearch_button())).click();
		waitFor((usersListPageObjects.advancedsearchreset_button())).click();
		filterUser(firstname,lastname,username,email,targetaccountstatus);
		usersListPageObjects.useraccountstatus.sendKeys(initialAccountStatus);
		waitFor(usersListPageObjects.saveButton()).click();
	}
	
//	else
//	{
//		Result="No Records Found";
//	}


	executor.executeScript("window.open('"+url+"')");
		for(String handle:driver.getWindowHandles())
		{
			driver.switchTo().window(handle);
			if(driver.getCurrentUrl().contains(url))
			{
				break;
			}
		}
	String lockAccount=lockAccount(username, password);
	driver.switchTo().window(windowHandle);
	filterUser(firstname,lastname,username,email,accountstatus);
//	if(!usersListPageObjects.noRecordsPresent.isCurrentlyVisible())
//	{
		Select status=new Select(usersListPageObjects.useraccountstatus);
		initialAccountStatus=status.getFirstSelectedOption().getText();
		usersListPageObjects.useraccountstatus.sendKeys(targetaccountstatus);
		if(status.getFirstSelectedOption().getText().contains(targetaccountstatus))
		{
			count++;
		}
		waitFor(usersListPageObjects.saveButton()).click();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.feedbackpanelinfo())).click();
		waitFor((usersListPageObjects.useradvancedsearch_button())).click();
		waitFor((usersListPageObjects.advancedsearchreset_button())).click();
		filterUser(firstname,lastname,username,email,targetaccountstatus);
		usersListPageObjects.useraccountstatus.sendKeys(initialAccountStatus);
		waitFor(usersListPageObjects.saveButton()).click();
		waitFor((usersListPageObjects.useradvancedsearch_button())).click();
		waitFor((usersListPageObjects.advancedsearchreset_button())).click();
//	}
//	else
//	{
//		Result="No Records Found";
//	}
	
	executor.executeScript("window.open('"+url+"')");
	lockAccount(username, password);
	jdbcConnection.lockAccount(username, sqlQuery);
	lockAccountPermanently(username, password);
	
	driver.switchTo().window(windowHandle);
	filterUser(firstname,lastname,username,email,accountstatus);
//	if(!usersListPageObjects.noRecordsPresent.isCurrentlyVisible())
//	{
		Select status1=new Select(usersListPageObjects.useraccountstatus);
		initialAccountStatus=status.getFirstSelectedOption().getText();
		usersListPageObjects.useraccountstatus.sendKeys(targetaccountstatus);
		if(status1.getFirstSelectedOption().getText().contains(targetaccountstatus))
		{
			count++;
		}
		waitFor(usersListPageObjects.saveButton()).click();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.feedbackpanelinfo())).click();
		waitFor((usersListPageObjects.useradvancedsearch_button())).click();
		waitFor((usersListPageObjects.advancedsearchreset_button())).click();
		filterUser(firstname,lastname,username,email,targetaccountstatus);
		usersListPageObjects.useraccountstatus.sendKeys(initialAccountStatus);
		waitFor(usersListPageObjects.saveButton()).click();
		waitFor((usersListPageObjects.useradvancedsearch_button())).click();
		waitFor((usersListPageObjects.advancedsearchreset_button())).click();
//	}
	
//	else
//	{
//		Result="No Records Found";
//	}

	if(count==3)
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}

	return Result;
	
}






}






