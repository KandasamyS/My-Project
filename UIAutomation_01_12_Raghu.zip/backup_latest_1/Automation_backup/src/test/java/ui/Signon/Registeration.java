package ui.Signon;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.RegObjects;


	public class Registeration extends PageObject{
		
	

	//private static final long serialVersionUID = 1L;
	
	WebDriver driver =null;
	
	RegObjects regobjects;
@Step
public void loadbrowser(){
	
	System.out.println("Loading Browser");
	/*System.setProperty("webdriver.chrome.driver", 
    "C:\\Users\\504206\\Downloads\\chromedriver_win32\\chromedriver.exe");*/

	//driver=new ChromeDriver();
	System.out.println("Launched CHrome Browser");
	driver = this.getDriver();

	
}
	
@Step
public void navigate(String url) throws Exception{

	driver.get(url);
	
	
	
}
@Step
public void RememberMe() throws InterruptedException{
	for(int i=0;i<50;i++){};
	regobjects.RememberMe().click();
}
@Step
public void userInput(String fieldName, String fieldValue) throws InterruptedException{
	System.out.println(fieldName);
	for(int i=0;i<50;i++){};
	if (fieldName.equals("UserName")){
	regobjects.UserName().sendKeys(fieldValue);
	}
	
	else if(fieldName.equals("Password"))
	{
	for(int i=0;i<50;i++){};
	regobjects.Password().sendKeys(fieldValue);
	for(int i=0;i<50;i++){};
	}
	
	

/*	else if(fieldName.equals("email"))
	{	Random randomGenerator = new Random();
		int rnd = randomGenerator.nextInt(1000);
		String email="SerenityBddEmail" + rnd + "@gmail.com";
		regobjects.eMail().sendKeys(email);
	}
*/
}
	
@Step
public void Submitlogin() throws InterruptedException{
	regobjects.Submit().click();
	regobjects.AfterLogin.getText();
	System.out.println(regobjects.AfterLogin.getText());
	if(regobjects.AfterLogin.getText().contains("Welcome,"))
	{
		System.out.println("Login successful");
	}
	else
	{
		System.out.println("Login Failed");
	}
	for(int i=0;i<50;i++){};
	
	
	
}
@Step
public void Preauth() throws InterruptedException {
	// TODO Auto-generated method stub
	for(int i=0;i<50;i++){};
	regobjects.Preauth().click();
	for(int i=0;i<50;i++){};
}
@Step
public void Detail() throws InterruptedException {
	// TODO Auto-generated method stub
	for(int i=0;i<50;i++){};
	regobjects.Detail().click();
	for(int i=0;i<50;i++){};
}
@Step
public void LastLoginDate() throws InterruptedException {
	for(int i=0;i<50;i++){};
	
	
	
	Date today = new Date();
	SimpleDateFormat formatDate= new SimpleDateFormat("dd/MM/yyyy HH:mm"); 
	String date = formatDate.format(today);
	String[] dateTime=date.split(" ");
	System.out.println(date);
	String[] actualValue= regobjects.LastLoginDate().getText().split(",");
	System.out.println(actualValue[0]+"///"+dateTime[0].concat(",")+dateTime[1]);
	org.junit.Assert.assertEquals(dateTime[0],actualValue[0]);
	
}

@Step
public void DashboardDate(){
	Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
    String Day=simpleDateFormat.format(date);
    simpleDateFormat = new SimpleDateFormat("MMMM");
    String Month=simpleDateFormat.format(date);
    simpleDateFormat = new SimpleDateFormat("YYYY");
    String year=simpleDateFormat.format(date);
    simpleDateFormat=new SimpleDateFormat("dd");
    String curdate=simpleDateFormat.format(date);
    String Dashboarddate=Day+","+" "+Month+" "+curdate+","+" "+year;
    String actualValue= regobjects.DashboardDate().getText();
    System.out.println(actualValue+"\\\\"+Dashboarddate);
    org.junit.Assert.assertEquals(actualValue,Dashboarddate);
    
    
}

}






