/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SignonObjects;

public class EmailTemplatePage extends PageObject{


	String Result=null;
	String loginStatus=null;
	WebDriver driver =null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	SMSTemplatePageObjects smstemplatepageobjects;
	EmailTemplatePageObjects emailtemplatepageobjects;

	@Step
	public HashMap<String,String> getEmailTemplate(){

		driver = this.getDriver();	
		String currentPage;
		//HashMap<WebElement,WebElement> combine=new HashMap<WebElement,WebElement>();
		HashMap<String,String> finalEmailTemplate=new HashMap<String,String>();
		boolean flag=true;
		while(flag==true)
		{


				System.out.println("Size of the disabled link is: "+emailtemplatepageobjects.nextButtondisabled().size());
				if(emailtemplatepageobjects.nextButtondisabled().size()>0)
				{
					flag=false;
				}


				currentPage=emailtemplatepageobjects.currentPage().getText();
				System.out.println("Current Page is:"+currentPage);
				List<WebElement> email_id=emailtemplatepageobjects.email_id();
				System.out.println("number of ids is:"+email_id.size());
				List<WebElement> emailTemplate_id=emailtemplatepageobjects.emailTemplate_id();	
				System.out.println("number of template ids is:"+email_id.size());
				for(int i=0;i<10 && i<email_id.size();i++)
				{

					String templateid=email_id.get(i).getText();
					//System.out.println("template id:"+templateid);
					String templatename=emailTemplate_id.get(i).getText();
					//System.out.println("template name:"+templatename);

					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(email_id.get(i))).click();
					if(driver.getCurrentUrl().contains(templateid) && smstemplatepageobjects.editSmsTemplateValue().getText().equals(templatename))
					{
						finalEmailTemplate.put(templateid,templatename);
						//System.out.println(finalSmsTemplate);
						new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(emailtemplatepageobjects.cancelButton())).click();
					}

					while(!emailtemplatepageobjects.currentPage().getText().equals(currentPage))
					{
						new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(emailtemplatepageobjects.nextButton())).click();
					}
				}

				//sms_id.clear();
				//smsTemplate_id.clear();
				if(flag==true)
				{
					System.out.println("Next Button status:"+emailtemplatepageobjects.nextButton().isEnabled());
					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(emailtemplatepageobjects.nextButton())).click();
					System.out.println("Next Button status:"+emailtemplatepageobjects.nextButton().isEnabled());
				}
			}


	
		System.out.println("Total number of SMS templates is"+finalEmailTemplate.size());
		System.out.println(finalEmailTemplate);
		return finalEmailTemplate;	
	}
}



*/