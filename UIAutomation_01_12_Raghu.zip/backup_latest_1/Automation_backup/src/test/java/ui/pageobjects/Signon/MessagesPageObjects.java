package ui.pageobjects.Signon;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageObjects;
import net.serenitybdd.core.pages.WebElementFacade;

public class MessagesPageObjects extends PageObject {
	
	@FindBy(css="p[translate='MESSAGES.INBOX']")
	public WebElementFacade inbox;

	@FindBy(css="#main > div:nth-child(2) > div > div > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > ul > li:nth-child(2) > a")
	public WebElementFacade archivedMessages_Link;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > div.header.ng-scope > div > span:nth-child(2)")
	public WebElementFacade inbox_messages_list;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.search-container > input")
	public WebElementFacade search_Textbox;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope")
	public WebElementFacade messagelist_ul;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.ng-scope.read.un-checked.active > div.text-container > p.title.ng-binding")
	public WebElementFacade message_title;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.ng-scope.read.un-checked.active > div.text-container > p.ellipsis.ng-binding")
	public WebElementFacade message_subtitle;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.ng-scope")
	public List<WebElement> listOfMessages;
	
	@FindBy(css="p[translate='MESSAGES.NO_MESSAGE_FOUND']")
	public WebElementFacade noMessagesFound;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li > div.text-container > p.title.ng-binding")
	public WebElementFacade inbox_messages_messagetitles;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.ng-scope.read.un-checked.active > div.text-container > p.title.ng-binding")
	public WebElementFacade inboxsearch_firstresulttitle;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.right-side.ng-scope > div > div.header-section > div > button:nth-child(1)")
	public WebElementFacade archive_Button;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.ng-scope.unread.un-checked")
	public WebElementFacade first_unread_message;
	
//	@FindBy(css="input[type='checkbox']")
//	public List<WebElement> inboxMessagesCheckBox;
	
	public By inboxMessagesCheckBox=By.cssSelector("input[type='checkbox']");
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li:nth-child(2) > div.checkbox-container > label")
	public WebElementFacade inboxmessage2;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li:nth-child(3) > div.checkbox-container > label	")
	public WebElementFacade inboxmessage3;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > div.archive-section.ng-scope.opacity > button:nth-child(3)")
	public WebElementFacade addToArchive;
	
	@FindBy(css="div[class='messages-info'] > p")
	public WebElementFacade archivedNotification;
	
	@FindBy(css="p[class*='title']")
	public List<WebElement> messageTitles;
	
	@FindBy(css="p[class*='ellipsis']")
	public List<WebElement> messageSubtitles;
	
	@FindBy(css="p[class*='date']")
	public List<WebElement> messageReceivedDate;
	
	@FindBy(css="ul[class='ng-scope'] > li >div > i")
	public List<WebElement> messageType;
	
	@FindBy(css="ul[class='ng-scope'] > li[class*='ng-scope']")
	public List<WebElement> messageReadStatusAndArchivedFlag;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.pagination > pagination > ul > li.pagination-next.ng-scope")
	//#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.pagination > pagination > ul > li.pagination-next.ng-scope > a
	public WebElementFacade nexButtonStatus;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.left-side.ng-scope > ul > li.pagination > pagination > ul > li.pagination-next.ng-scope > a")
	public WebElementFacade nexButton;
	
	@FindBy(css="li.ng-scope.messages > a > span > span")
	public WebElementFacade messages_Link;

	@FindBy(css="div > div:nth-child(1) > div > h3")
	public WebElementFacade messages_text;

	@FindBy(css="div.right-side.ng-scope > div > div.header-section > div > button.default-button.x-small.blue.print.ng-scope")
	public WebElementFacade print_option;

	@FindBy(css="div.tab-pane.ng-scope.active > div > div.right-side.ng-scope > div > div.header-section > h4")
	public WebElementFacade Message_Title;

	@FindBy(css="body > div.ng-scope.logged-in > div > div > messages-content > article > header > h1")
	public WebElementFacade Message_Title_LBC;

	@FindBy(css="div.right-side.ng-scope > div > div.header-section > h5")
	public WebElementFacade message_subTitle;

	@FindBy(css="div.search-container > input")
	public WebElementFacade searchbox_message;

	@FindBy(css="div.search-container > button")
	public WebElementFacade search_Button;

	@FindBy(css="div.right-side.ng-scope > div > div.header-section > p")
	public WebElementFacade date_time;

	@FindBy(css="div.content-section > p#message-detail-content")
	public WebElementFacade message_body;

	@FindBy(css="body")
	public WebElementFacade message_bodyText;

	@FindBy(css="div.header-section > div > button:nth-child(1)")
	public WebElementFacade archieve_button;

	@FindBy(css="li.ng-scope.active.un-checked.read > div.checkbox-container > i")
	public WebElementFacade notification_flag_type;

	@FindBy(css="div.attachment-section > a.default-button.ng-scope")
	public WebElementFacade Download_all_attachment;

	@FindBy(css="li:nth-child(3) > div.checkbox-container > i")
	public WebElementFacade alert_flag_type;

	@FindBy(css="ul > li.ng-scope.active.read.un-checked")
	public WebElementFacade message_status_readunread;

	@FindBy(css="div.header.ng-scope > span:nth-child(3) > span")
	public WebElementFacade inbox_message_count;

	@FindBy(css="ul > li.pagination > pagination > ul > li.pagination-next.ng-scope > a")
	public WebElementFacade more_message_pagination;

	@FindBy(css="ul > li.ng-scope.read.un-checked.active > div.time-container > p")
	public WebElementFacade message_start_date_list;

	@FindBy(css="li:nth-child(6) > div.time-container > p")
	public WebElementFacade message_end_date_list;

	@FindBy(css="div.clo-lg-12 > div > p:nth-child(2)")
	public WebElementFacade no_message_found;
	
	public WebElement  archivedMessages_Link(){
		return  archivedMessages_Link;
	}
	public WebElement  inbox_messages_list(){
		return  inbox_messages_list;
	}
	public WebElement  search_Textbox(){
		return  search_Textbox;
	}	
	public WebElement messagelist_ul(){
		return messagelist_ul;
	}
	public WebElement message_title(){
		return message_title;
	}
	public WebElement message_subtitle(){
		return message_subtitle;
	}
	
	public WebElement inbox_messages_messagetitles(){
		return inbox_messages_messagetitles;
	}
	public WebElement inboxsearch_firstresulttitle(){
		return inboxsearch_firstresulttitle;
	}
	public WebElement archive_Button(){
		return archive_Button;
	}
	public WebElement first_unread_message(){
		return first_unread_message;
	}
	
	public WebElement inboxmessage2(){
		return inboxmessage2;
	}
	public WebElement inboxmessage3(){
		return inboxmessage3;
	}
	public WebElement addToArchive(){
		return addToArchive;
	}
	
	public WebElement nexButton(){
		return nexButton;
	}
	
	public WebElement no_message_found(){
		return no_message_found;
	}
	public WebElement message_start_date_list(){
		return message_start_date_list;
	}
	public WebElement message_end_date_list(){
		return message_end_date_list;
	}
	public WebElement more_message_pagination(){
		return more_message_pagination;
	}
	public WebElement inbox_message_count(){
		return inbox_message_count;
	}
	public WebElement Download_all_attachment(){
		return Download_all_attachment;
	}
	public WebElement messages_Link(){
	    return messages_Link;
	  }
	public WebElement messages_text(){
	    return messages_text;
	  }
	public WebElement print_option(){
	    return print_option;
	  }
	public WebElement Message_Title(){
	    return Message_Title;
	  }
	public WebElement Message_Title_LBC(){
	    return Message_Title_LBC;
	  }

	public WebElement message_subTitle() {
		return message_subTitle;
	}
	public WebElement search_Button() {
		return search_Button;
	}
	public WebElement searchbox_message() {
		return searchbox_message;
	}
	public WebElement date_time() {
		return date_time;
	}
	public WebElement message_body(){
		return message_body;
	}
	public WebElement message_bodyText(){
		return message_bodyText;
	}
	public WebElement archieve_button(){
		return archieve_button;
	}
	public WebElement notification_flag_type(){
		return notification_flag_type;
	}
	public WebElement alert_flag_type(){
		return alert_flag_type;
	}
	public WebElement message_status_readunread(){
		return message_status_readunread;
	}
	
	
	

}
