package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class TransactionsPageObjects extends PageObject{
	
@FindBy(css=".btn.flat-button")
public WebElementFacade date_dropdown;

@FindBy(css="div.extended-interface > button:nth-child(5) > span.date > input")
public WebElementFacade FromDate;

@FindBy(css="div.extended-interface > button:nth-child(6) > span.date > input")
public WebElementFacade ToDate;

@FindBy(css="button[type='button'][translate*='DIRECTIVES.DATE_PICKER.APPLY']")
public WebElementFacade applyDate;

@FindBy(css="[name*='oneSearchField']")
public WebElementFacade searchFieldText;

@FindBy(css="button[class*='default-button x-small blue mobile-only']")
public WebElementFacade search_button_mobile;

//@FindBy(css="div.tg-column.ng-scope.tg-col-id-1.tg-w-8.tg-fixed-w-8 > span > span.date-desktop")
public By transactionsDate=By.cssSelector("div.tg-column.ng-scope.tg-col-id-1 > span > span.date-desktop");
public By transactionsDate_mobile=By.cssSelector("div.tg-column.ng-scope.tg-col-id-1 > span > span.date-mobile");

//@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-1 > span > span.time")
public By transactionsTime=By.cssSelector("div.tg-row > div.tg-column.ng-scope.tg-col-id-1 > span > span.time");

@FindBy(css="span[translate='DIRECTIVES.SEARCH.NORECORDS.HEADER']")
public WebElementFacade noRecordsPresent;

//@FindBy(css="div[class*='tg-row tg-row-header'] > div > span")
public By transactionColumns=By.cssSelector("div[class*='tg-row tg-row-header'] > div > span");

@FindBy(css="label > span")
public List<WebElementFacade> additionalTransactionColumns;

@FindBy(css="span[translate='FINANCIAL.SETTINGS']")
public WebElementFacade showMoreColumns;

@FindBy(css="a[translate='FINANCIAL.RESTORE']")
public WebElementFacade restoreDefault;

@FindBy(css="button[translate='FINANCIAL.APPLY']")
public WebElementFacade apply;

//@FindBy(css="p[class='detail-row']")
//public By transactionDetails_Funding=By.cssSelector("p[class='detail-row']");
public By transactionDetails_FundingName=By.cssSelector("div:nth-child(3) > p > span[class='detail-column ng-binding']:nth-child(1))");
public By transactionDetails_FundingValue=By.cssSelector("div:nth-child(3) > p > span[class='detail-column ng-binding']:nth-child(2)");

@FindBy(css="p[class='detail-row']")
public List<WebElementFacade> transactionDetails_Funding/*=By.cssSelector("p[class='detail-row']")*/;

@FindBy(css="p[class='detail-row ng-scope']")
public List<WebElementFacade> transactionDetails_EMSFees/*=By.cssSelector("p[class='detail-row ng-scope']")*/;


//@FindBy(css="p[class='detail-row ng-scope]")
//public By transactionDetails_EMSFees=By.cssSelector("p[class='detail-row ng-scope']");
public By transactionDetails_EMSFeeName=By.cssSelector("div:nth-child(4) > p[class='detail-row ng-scope'] > span:nth-child(1)");
public By transactionDetails_EMSFeeValue=By.cssSelector("div:nth-child(4) > p[class='detail-row ng-scope'] > span:nth-child(2)");

@FindBy(css="p[class='detail-row border-top']")
public WebElementFacade transactionDetails_GrossCharge;
public By transactionDetails_Gross=By.cssSelector("p[class='detail-row border-top']>span:nth-child(1)");
public By transactionDetails_GrossValue=By.cssSelector("p[class='detail-row border-top']>span:nth-child(2)");

@FindBy(css="#search-container > ul > li:nth-child(5) > a > span:nth-child(3)")
public WebElementFacade search_transactionId;

//EMS	
//@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
//#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
//public WebElementFacade date_dropdown;
///.btn.flat-button

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(1)")
public WebElementFacade Todays_Date_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade LastsevenDays_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(3)")
public WebElementFacade this_week_filter;

@FindBy(css=".extended-interface > button:nth-child(4)")
public WebElementFacade Last_month_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade apply_button;

@FindBy(css="transaction-search > form > div.export > button > span.text.ng-scope")
public WebElementFacade export_button;

@FindBy(css="transaction-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade search_error_message;

@FindBy(css="div.modal.fade.ng-isolate-scope.popup.transaction-export.no-results.in > div > div > div.modal-body-norecords.ng-scope")
public WebElementFacade nodata_export_error_message;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(3) > p")
public WebElementFacade xmlFile_option;

@FindBy(css="div.modal-body.ng-scope > div.export-inside.ng-scope.selected > p")
public WebElementFacade xlsFile_option;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(2) > p > span:nth-child(3)")
public WebElementFacade csvFile_option;

@FindBy(css="div.modal-footer.ng-scope > button:nth-child(1)")
public WebElementFacade download_button;

@FindBy(css="span[class*=date-desktop]")
public WebElementFacade table_lastRow;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(5) > span.date > input")
public WebElementFacade fromdate;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(6) > span.date > input")
public WebElementFacade todate;

@FindBy(css="#search-container > ul > li:nth-child(2) > a > span:nth-child(3)")
public WebElementFacade merchantID_search;

@FindBy(css="#search-container > ul > li:nth-child(3) > a > span:nth-child(3)")
public WebElementFacade store_id_search;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade searchField_Text;

@FindBy(css="button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade search_button;

@FindBy(css=" div.tg-column.tg-header.ng-scope.tg-col-id-1> span > span.header-label.ng-binding.ng-scope")
public WebElementFacade postingDate_text;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-7.tg-fixed-w-7.tg-col-id-3 > span")
public List<WebElement> merchantID_list;

@FindBy(css="transaction-search > save-search > div > button > span.text.ng-binding")
public WebElementFacade save_this_search_button;

@FindBy(css="transaction-search > save-search > div > p")
public WebElementFacade save_search_text;

@FindBy(css="#saved-popup > p")
public WebElementFacade save_popup_text;

@FindBy(css="transaction-search > form > div.saved-searches.ng-scope > a")
public WebElementFacade save_search_link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > page-scroll > div > span")
public WebElementFacade Top_buttom_view_button;

@FindBy(css="transaction-search > form > form-search-input > div > button.default-button.x-small.gray > i")
public WebElementFacade close_the_search;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-2 > span > span.header-label.header-label-html.ng-binding.ng-scope")
public WebElementFacade ecom_pos_image;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-3 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade MerchantId_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-4 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade storeId_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-5 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade orderID_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-6 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade status_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-7 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade trans_date_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-8 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade trans_type_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-9 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade Brand_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-10 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade Trans_Amount_text;

@FindBy(css="div.tg-column.ng-scope.tg-w-5.tg-fixed-w-5.more-icon-column.no-overflow.sticky > span")
public List<WebElement> plus_icon;

@FindBy(css="transaction-details > div > div:nth-child(3) > p > span:nth-child(1)")
public List<WebElement> funding_fees_text;

@FindBy(css="transaction-details > div > div:nth-child(3) > p > span:nth-child(2)")
public List<WebElement> funding_fees_value;

@FindBy(css="transaction-details > div > div:nth-child(4) > p > span:nth-child(1)")
public List<WebElement> ems_fees_text;

@FindBy(css="transaction-details > div > div:nth-child(4) > p > span:nth-child(2)")
public List<WebElement> ems_fees_Value;

@FindBy(css="div.tg-column.ng-scope.tg-col-id-10.no-overflow.scaleable > span")
public List<WebElement> trans_amount_value;

@FindBy(css="div.tg-column.ng-scope.tg-col-id-7 > span > span.date-desktop")
public List<WebElement> transactionDate;

@FindBy(css="span[class*='time']")
public List<WebElement> transactionTime;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-7 > span > span.sort-icon.ng-scope > span.down-arrow.gray")
public WebElementFacade down_arrow_transaction_date;

@FindBy(css="transaction-details > div > div:nth-child(1) > div > div.ng-scope > p")
public WebElementFacade refund_details_text;

@FindBy(css="div.ng-scope > table > tbody > tr > td:nth-child(1)")
public List<WebElement> refund_detail_history;

@FindBy(css="div.ng-scope > table > tbody > tr > td:nth-child(2)")
public List<WebElement> refund_currency;

@FindBy(css="div.ng-scope > table > tbody > tr > td:nth-child(3)")
public List<WebElement> refund_Amount;

@FindBy(css="li:nth-child(5) > a > span.search-text.ng-binding")
public WebElementFacade transactionId_select;

@FindBy(css="transaction-details > div > div:nth-child(1) > div > div > button")
public WebElementFacade refund_button;

@FindBy(css="div.transaction.summary.clearfix > div.left-side > p")
public WebElementFacade leftTorefund_text;

@FindBy(css="div.modal-body.ng-scope > div > div.transaction.summary.clearfix > div.right-side > p")
public WebElementFacade amount_left_refund;

@FindBy(css="[name*=currRefundAmt]")
public WebElementFacade current_Refund_amount;

@FindBy(css="div.modal-body.ng-scope > div > form > button")
public WebElementFacade refund_button_inside_;

@FindBy(css="div.modal-body.ng-scope > div > form > div > p")
public WebElementFacade error_message_after_refund;

@FindBy(css="div.modal-body.ng-scope > div > h3")
public WebElementFacade confirm_with_passcode_text;

@FindBy(css="ul > li:nth-child(1) > a > span:nth-child(3)")
public WebElementFacade Order_id_search;

@FindBy(css="input[placeholder='One time passcode']")
public WebElementFacade passcode_enter_text;

@FindBy(css=" div.pass-code-info > p:nth-child(1) > span")
public WebElementFacade mobile_number_Text;

@FindBy(css="div.pass-code-info > p:nth-child(1)")
public WebElementFacade verification_Text;

@FindBy(css="div.modal-body.ng-scope > div > button")
public WebElementFacade confirm_button;

@FindBy(css=" div.pass-code-info > p:nth-child(2)")
public WebElementFacade resend_verification_text;

@FindBy(css="div.modal-body.ng-scope > div > div.input-container > p")
public WebElementFacade refund_Failed_error_message;

@FindBy(css="div.pass-code-info > a")
public WebElementFacade send_passcode_again_link;

@FindBy(css="div > button > span:nth-child(1)")
public WebElementFacade close_button;

@FindBy(css="table > tbody > tr:nth-child(15) > td:nth-child(3)")
public WebElementFacade available_refund_Amount;

@FindBy(css="div.modal-body.ng-scope > div > div.header > p.ng-binding")
public WebElementFacade refund_amount_for_refund;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.transaction > a > span > span")
public WebElementFacade Transactions_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade Txn_NoResult;

@FindBy(css="div.tg-row-outer.tg-row-header-outer > div > column-picker > div.tg-column.tg-header.column-picker-column > span")
public WebElementFacade Show_More;

@FindBy(css="div.tg-row-outer.tg-row-header-outer > div.tg-row.tg-row-header.sticky > column-picker > div.column-picker-content > div > div:nth-child(14) > label > span")
public WebElementFacade AddColumn_CardNo;

//@FindBy(css="div.tg-row-outer.tg-row-header-outer > div.tg-row.tg-row-header.sticky > column-picker > div.column-picker-content > div > p:nth-child(18) > button")
@FindBy(css="div.tg-row-outer.tg-row-header-outer > div.tg-row.tg-row-header.sticky > column-picker > div.column-picker-content > div > p:nth-child(23) > button")
public WebElementFacade Txn_Apply_Button;

@FindBy(css="div.tg-row-outer.tg-row-header-outer > div > div.tg-column.tg-header.ng-scope.tg-col-id-14.sortable.tg-w-8.tg-fixed-w-8 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade AddColumn_CardNo_Header;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade Search_Textbox;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade Search_button;

@FindBy(css="#search-container > ul > li:nth-child(1) > a")
public WebElementFacade Search_Autofill_OrderID;

@FindBy(css="#search-container > ul > li:nth-child(2) > a")
public WebElementFacade Search_Autofill_MerchantID;

@FindBy(css="#search-container > ul > li:nth-child(3) > a")
public WebElementFacade Search_Autofill_StoreID;

@FindBy(css="#search-container > ul > li:nth-child(4) > a")
public WebElementFacade Search_Autofill_Authcode;

@FindBy(css="#search-container > ul > li:nth-child(5) > a")
public WebElementFacade Search_Autofill_txnID;

@FindBy(css="#search-container > ul > li:nth-child(6) > a")
public WebElementFacade Search_Autofill_CardNumber;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.more-filters > a")
public WebElementFacade More_Filter;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.dropdown-container > div:nth-child(1) > div > button.btn.dropdown-toggle > span.fa.fa-caret-down.fa-lg")
public WebElementFacade ChannelType_dropdown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.dropdown-container > div:nth-child(1) > div > ul > li:nth-child(2) > p")
public WebElementFacade ChannelType_Ecommerce;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.dropdown-container > div:nth-child(1) > div > ul > li:nth-child(3) > p")
public WebElementFacade ChannelType_pos;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.dropdown-container > div:nth-child(2) > div > button.btn.dropdown-toggle")
public WebElementFacade PaymentType_dropdown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(2) > p")
public WebElementFacade PaymentType_Purchase;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(3) > p")
public WebElementFacade PaymentType_Payment;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(4) > p")
public WebElementFacade PaymentType_Refund;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > amounts-search > div:nth-child(2) > fieldset > input")
public WebElementFacade AmtFrom;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > amounts-search > div:nth-child(4) > fieldset > input")
public WebElementFacade AmtTo;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > reset-filters > a")
public WebElementFacade ResetFilter_button;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-5.tg-fixed-w-5.tg-col-id-0.more-icon-column.no-overflow.sticky > span")
public WebElementFacade Search_Result_Expand;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-5.tg-w-16.tg-fixed-w-16 > span")
public List<WebElementFacade> SearchResult_OrderID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-7.tg-fixed-w-7.tg-col-id-3 > span")
public List<WebElementFacade> SearchResult_MerchantID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-6.tg-fixed-w-6.tg-col-id-4 > span")
public List<WebElementFacade> SearchResult_StoreID;

@FindBy(css="ng-transclude > transaction-details > div > div:nth-child(1) > p:nth-child(6) > span.ng-binding.ng-scope.full-width")
public WebElementFacade SearchResult_Authcode;

@FindBy(css="ng-transclude > transaction-details > div > div:nth-child(1) > p:nth-child(4) > span.ng-binding.ng-scope.full-width")
public WebElementFacade SearchResult_txnID;

@FindBy(css="ng-transclude > transaction-details > div > div:nth-child(2) > p:nth-child(2) > span.ng-binding.ng-scope.full-width.big")
public WebElementFacade SearchResult_CardNumber;

@FindBy(css="i[class='card-3']")
public WebElementFacade SearchResult_ChannelType_Ecomm;

@FindBy(css="i[class='card-2']")
public WebElementFacade SearchResult_ChannelType_Pos;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-7.tg-fixed-w-7.tg-col-id-8 > span")
public List<WebElementFacade> SearchResult_PaymentType;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-8.tg-fixed-w-8.tg-col-id-10.no-overflow.scaleable.align-right > span")
public List<WebElementFacade> SearchResult_Amt;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > form-search-input > div > button.default-button.x-small.gray > i")
public WebElementFacade Search_Textbox_Close_icon;

@FindBy(css="ng-transclude > transaction-details > div > div:nth-child(1) > div > div > button")
public WebElementFacade Refund_button;

@FindBy(css="span[class='value ng-binding ng-scope'] > span.date-desktop")
public List<WebElement> Posting_Txn_date;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
public WebElementFacade Date_dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade DatePicker_Apply;

@FindBy(css="div.tg-row > div[class*='tg-column ng-scope tg-col-id-9'] > span[class='value ng-binding ng-scope']")
public WebElementFacade Brand;

@FindBy(css="ng-transclude > transaction-details > div > div:nth-child(4) > p > span:nth-child(2)")
public List<WebElement> EMS_fees;

public  WebElement Transactions_Link(){
    return Transactions_Link;
}

public  WebElement Txn_NoResult(){
    return Txn_NoResult;
}

public  WebElement Show_More(){
    return Show_More;
}

public  WebElement AddColumn_CardNo(){
    return AddColumn_CardNo;
}

public  WebElement Txn_Apply_Button(){
    return Txn_Apply_Button;
}

public WebElement AddColumn_CardNo_Header(){
	return AddColumn_CardNo_Header;
}

public WebElement Search_Textbox(){
	return Search_Textbox;
}

public WebElement Search_button(){
	return Search_button;
}

public WebElement Search_Autofill_OrderID(){
	return Search_Autofill_OrderID;
}

public WebElement Search_Autofill_MerchantID(){
	return Search_Autofill_MerchantID;
}

public WebElement Search_Autofill_StoreID(){
	return Search_Autofill_StoreID;
}

public WebElement Search_Autofill_Authcode(){
	return Search_Autofill_Authcode;
}

public WebElement Search_Autofill_txnID(){
	return Search_Autofill_txnID;
}

public WebElement Search_Autofill_CardNumber(){
	return Search_Autofill_CardNumber;
}

public WebElement More_Filter(){
	return More_Filter;
}

public WebElement ChannelType_dropdown(){
	return ChannelType_dropdown;
}

public WebElement ChannelType_Ecommerce(){
	return ChannelType_Ecommerce;
}

public WebElement ChannelType_pos(){
	return ChannelType_pos;
}

public WebElement PaymentType_dropdown(){
	return PaymentType_dropdown;
}

public WebElement PaymentType_Purchase(){
	return PaymentType_Purchase;
}

public WebElement PaymentType_Payment(){
	return PaymentType_Payment;
}

public WebElement PaymentType_Refund(){
	return PaymentType_Refund;
}

public WebElement AmtFrom(){
	return AmtFrom;
}

public WebElement AmtTo(){
	return AmtTo;
}

public WebElement ResetFilter_button(){
	return ResetFilter_button;
}

public WebElement Search_Result_Expand(){
	return Search_Result_Expand;
}

public List<WebElementFacade> SearchResult_OrderID(){
	return SearchResult_OrderID;
}

public List<WebElementFacade> SearchResult_MerchantID(){
	return SearchResult_MerchantID;
}

public List<WebElementFacade> SearchResult_StoreID(){
	return SearchResult_StoreID;
}

public WebElementFacade SearchResult_Authcode(){
	return SearchResult_Authcode;
}

public WebElementFacade SearchResult_txnID(){
	return SearchResult_txnID;
}

public WebElementFacade SearchResult_CardNumber(){
	return SearchResult_CardNumber;
}

public WebElementFacade SearchResult_ChannelType(){
	return SearchResult_ChannelType_Ecomm;
}

public WebElementFacade SearchResult_ChannelType_Pos(){
	return SearchResult_ChannelType_Pos;
}

public List<WebElementFacade> SearchResult_PaymentType(){
	return SearchResult_PaymentType;
}

public List<WebElementFacade> SearchResult_Amt(){
	return SearchResult_Amt;
}

public WebElement Search_Textbox_Close_icon(){
	return Search_Textbox_Close_icon;
}

public WebElement Refund_button(){
	return Refund_button;
}

public List<WebElement> Posting_Txn_date(){
	return Posting_Txn_date;
}

public WebElementFacade Date_dropdown(){
	return Date_dropdown;
}

public WebElementFacade FromDate(){
	return FromDate;
}

public WebElementFacade ToDate(){
	return ToDate;
}

public WebElementFacade DatePicker_Apply(){
	return DatePicker_Apply;
}

public WebElementFacade Brand(){
	return Brand;
}

public List<WebElement> EMS_fees(){
	return EMS_fees;
}

public WebElement Order_id_search(){
	return Order_id_search;
}
public WebElement passcode_enter_text(){
	return passcode_enter_text;
}
public WebElement confirm_with_passcode_text(){
	return confirm_with_passcode_text;
}
public WebElement leftTorefund_text(){
	return leftTorefund_text;
}
public WebElement refund_button_inside_(){
	return refund_button_inside_;
}
public WebElement error_message_after_refund(){
	return error_message_after_refund;
}
public WebElement amount_left_refund(){
	return amount_left_refund;
}
public WebElement current_Refund_amount(){
	return current_Refund_amount;
}
public WebElement refund_button(){
	return refund_button;
}
public WebElement transactionId_select(){
	return transactionId_select;
}
public WebElement MerchantId_text(){
	return MerchantId_text;
}
public WebElement storeId_text(){
	return storeId_text;
}
public WebElement orderID_text(){
	return orderID_text;
}
public WebElement status_text(){
	return status_text;
}
public WebElement trans_date_text(){
	return trans_date_text;
}
public WebElement trans_type_text(){
	return trans_type_text;
}
public WebElement Brand_text(){
	return Brand_text;
}
public WebElement Trans_Amount_text(){
	return Trans_Amount_text;
}
public WebElement ecom_pos_image(){
	return ecom_pos_image;
}
public WebElement store_id_search(){
	return store_id_search;
}
public WebElement close_the_search(){
	return close_the_search;
}
public WebElement Top_buttom_view_button(){
	return Top_buttom_view_button;
}
public WebElement save_popup_text(){
	return save_popup_text;
}
public WebElement save_search_link(){
	return save_search_link;
}
public WebElement save_search_text(){
	return save_search_text;
}
public WebElement save_this_search_button(){
	return save_this_search_button;
}
public List<WebElement> merchantID_list(){
	return merchantID_list;
}
public WebElement postingDate_text(){
	return postingDate_text;
}
public WebElement search_button(){
	return search_button;
}
public WebElement searchField_Text(){
	return searchField_Text;
}
public WebElement merchantID_search(){
	return merchantID_search;
}
public WebElement date_dropdown(){
	return date_dropdown;
}
public WebElement fromdate(){
	return fromdate;
}
public WebElement todate(){
	return todate;
}
public  WebElement Todays_Date_filter(){
    return Todays_Date_filter;
}
public  WebElement LastsevenDays_filter(){
    return LastsevenDays_filter;
}
public  WebElement this_week_filter(){
    return this_week_filter;
}
public  WebElement Last_month_filter(){
    return Last_month_filter;
}
public  WebElement apply_button(){
    return apply_button;
}
public WebElement search_error_message(){
	return search_error_message;
}
public WebElement export_button(){
	return export_button;
}
public WebElement nodata_export_error_message(){
	return nodata_export_error_message;
}
public WebElement xmlFile_option(){
	return xmlFile_option;
}
public WebElement xlsFile_option(){
	return xlsFile_option;
}
public WebElement csvFile_option(){
	return csvFile_option;
}
public WebElement download_button(){
	return download_button;
}
public WebElement table_lastRow(){
	return table_lastRow;
}
public WebElement down_arrow_transaction_date() {
	return down_arrow_transaction_date;
}
public WebElement transactionDetails_GrossCharge() {
	return transactionDetails_GrossCharge;
}




		
}
