package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class MerchantAdminPageObjects extends PageObject {
	

	
	//This is for logging into the admin console as a CC agent;
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='users-list']")
	public WebElementFacade userslist_link;
	
	//This is for logging into the admin console as an admin user;
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='users-list']")
	public WebElementFacade userslist_adminuser_link;
	
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='terms-and-conditions']")
	public WebElementFacade termsandconditions_link;
	
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='documents']")
	public WebElementFacade documents_link;
	
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='email-templates']")
	public WebElementFacade emailtemplates_link;
	
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='sms-templates']")
	public WebElementFacade smstemplates_link;
	
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='export-email']")
	public WebElementFacade exportEmail_link;
	
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='parameters']")
	public WebElementFacade parameters_link;
	
	@FindBy(css="div.home-menu > div#menu-links > div.menu-link-container > a.menu-link[href*='comm-summary']")
	public WebElementFacade communicationSummary_link;
	
	public WebElement documents_link(){
	    return documents_link;
	}
	public WebElement userslist_link(){
	    return userslist_link;
	  }
	public WebElement userslist_adminuser_link(){
	    return userslist_adminuser_link;
	  }
	public WebElement termsandconditions_link(){
	    return termsandconditions_link;
	  }
	public WebElement  emailtemplates_link(){
	    return emailtemplates_link;
	  }
	public WebElement  smstemplates_link(){
	    return  smstemplates_link;
	  }
	public WebElement  exportEmail_link(){
	    return  exportEmail_link;
	  }
	public WebElement  parameters_link(){
	    return  parameters_link;
	  }
	public WebElement  communicationSummary_link(){
	    return  communicationSummary_link;
	  }
	
	
}
