package ui.pageobjects.Signon;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SMSTemplatePageObjects extends PageObject{


@FindBy(css="table > tbody > tr > td.column0 > div")
public List<WebElement> sms_id;

@FindBy(css="table > tbody > tr > td.column1 > div")
public List<WebElement> smsTemplate_id;

@FindBy(css="h4 > span:nth-child(2)")
public WebElementFacade editSmsTemplateValue;

@FindBy(css="a[class='next']")
public WebElementFacade nextButton;

@FindBy(css="span[class='next'] > em")
public List<WebElement> nextButtondisabled;

@FindBy(css="a[class='action-link']")
public WebElementFacade cancelButton;

@FindBy(css="span[class='goto'] > span > em > span")
public WebElementFacade currentPage;

//EMS
	//#menu-links > div:nth-child(4) > a
	//a[href='./email-templates']
@FindBy(css="#menu-links > div:nth-child(5) > a")
public WebElementFacade SMS_template;

@FindBy(css="[name*=search-keyword]")
public WebElementFacade search_text_box;

@FindBy(css="[name*=search-button]")
public WebElementFacade search_button;

@FindBy(css="[id*=id] > table > tbody > tr > td.column2 > div")
public List<WebElement> selected_row_Language;

@FindBy(css="[id*=id] > table > tbody > tr > td.column1 > div")
public List<WebElement> selected_row_sms_template;

@FindBy(css="[name*=smsDescription]")
public WebElementFacade Description_sms_template;

@FindBy(css="[name*=smsSubject]")
public WebElementFacade Subject_sms_template;

@FindBy(css="[name*=language]")
public WebElementFacade language_selection;

@FindBy(css="[name*=submitButton]")
public WebElementFacade submit_button;

@FindBy(css="#feedbackPanel > ul > li > span")
public WebElementFacade Panel_message_success_error;

@FindBy(css="[id*=id] > table > tfoot > tr > td > div")
public WebElementFacade No_data_found;

@FindBy(css="[id*=id] > fieldset > div > a")
public WebElementFacade cancel_button;

public List<WebElement> sms_id(){
    return sms_id;
}
public List<WebElement> smsTemplate_id(){
    return smsTemplate_id;
}
public WebElement nextButton(){
    return nextButton;
}

public List<WebElement> nextButtondisabled(){
	return nextButtondisabled;
}

public WebElement cancelButton(){
    return cancelButton;
}

public WebElement editSmsTemplateValue(){
    return editSmsTemplateValue;
}

public WebElement currentPage(){
    return currentPage;
}

public WebElement cancel_button(){
	return cancel_button;
}
public WebElement language_selection(){
	return language_selection;
}
public WebElement submit_button(){
	return submit_button;
}
public WebElement No_data_found(){
	return No_data_found;
}
public WebElement Panel_message_success_error(){
	return Panel_message_success_error;
}
public WebElement search_text_box(){
	return search_text_box;
}
public WebElement search_button(){
	return search_button;
}
public WebElement Description_sms_template(){
	return Description_sms_template;
}
public WebElement Subject_sms_template(){
	return Subject_sms_template;
}
public WebElement SMS_template(){
	return SMS_template;
}




}

