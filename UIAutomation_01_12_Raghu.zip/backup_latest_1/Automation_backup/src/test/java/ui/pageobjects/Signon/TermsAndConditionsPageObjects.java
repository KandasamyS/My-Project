package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class TermsAndConditionsPageObjects  extends PageObject{
	
	@FindBy(css="a.action-button")
	public WebElementFacade addnewtermsandcondtions;
	
	@FindBy(css="#allianceName")
	public WebElementFacade alliancename;
	
	@FindBy(css="#tncType")
	public WebElementFacade type;
	
	@FindBy(css="#language")
	public WebElementFacade defaultlanguage;
	
	@FindBy(css="#name")
	public WebElementFacade name;
			
	@FindBy(css="#description")
	public WebElementFacade description;
	
	@FindBy(css="input[name='termsAndConditionsHtmlPanel:fileInput']")
	public WebElementFacade htmlfileinput;
	
	@FindBy(css="input[name='termsAndConditionsDocPanel:fileInput']")
	public WebElementFacade pdffileinput;
	
	@FindBy(css="input[type='submit'][name='termsAndConditionsHtmlPanel:uploadButton']")
	public WebElementFacade htmlfileupload;
	
	@FindBy(css="input[type='submit'][name='termsAndConditionsDocPanel:uploadButton']")
	public WebElementFacade pdffileupload;
	
	@FindBy(css="table > tbody > tr:nth-child(7) > td.right")
	public WebElementFacade uploadedtermsandconditions;
	
	@FindBy(css="input[name='submitButton']")
	public WebElementFacade savetermsandconditions;
	
	@FindBy(css="tr:nth-child(1) > td.column1 > div")
	public WebElementFacade newtermsandconditions;
	
	@FindBy(css="tr:nth-child(1) > td.column0 > div")
	public WebElementFacade newtermsandconditionsid;
	
	
	
	
	
	public WebElement addnewtermsandcondtions(){
	    return addnewtermsandcondtions;
	  }
	public WebElement alliancename(){
	    return alliancename;
	  }
	public WebElement type(){
	    return type;
	  }
	public WebElement defaultlanguage(){
	    return defaultlanguage;
	  }
	public WebElement name(){
	    return name;
	  }
	public WebElement description(){
	    return description;
	  }
	public WebElement htmlfileinput(){
	    return htmlfileinput;
	  }
	public WebElement pdffileinput(){
	    return pdffileinput;
	  }
	public WebElement htmlfileupload(){
	    return htmlfileupload;
	  }
	public WebElement pdffileupload(){
	    return pdffileupload;
	  }
	public WebElement uploadedtermsandconditions(){
	    return uploadedtermsandconditions;
	  }
	public WebElement savetermsandconditions(){
	    return savetermsandconditions;
	  }
	public WebElement newtermsandconditions(){
	    return newtermsandconditions;
	  }
	public WebElement newtermsandconditionsid(){
	    return newtermsandconditionsid;
	  }
	
	
	
	
	
}
