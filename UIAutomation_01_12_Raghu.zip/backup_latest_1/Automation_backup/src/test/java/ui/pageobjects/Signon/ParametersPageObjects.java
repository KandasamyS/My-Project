package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageObjects;
import net.serenitybdd.core.pages.WebElementFacade;

public class ParametersPageObjects extends PageObject{
	
	@FindBy(css="[id*=id] > table > tbody > tr > td.column0 > div")
	public WebElementFacade activeParameters;
	
	@FindBy(css="input#sessionExpTime")
	public WebElementFacade sessionExpiryTime;
	
	@FindBy(css="input#passwordExpDays")
	public WebElementFacade passwordExpiryDays;
	
	@FindBy(css="input#passcodeExpTime")
	public WebElementFacade passcodeExpiryTime;
	
	@FindBy(css="passwordLinkExpTime")
	public WebElementFacade passwordResetLinkExpiryTime;
	
	@FindBy(css="div[class='field-message']")
	public WebElementFacade parameterErrorMessage;
	
	@FindBy(css="input[type='submit']")
	public WebElementFacade saveButton;
	
	public WebElement activeParameters(){
		return activeParameters;
	}

}
