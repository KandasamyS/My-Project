package ui.pageobjects.Signon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class UserManagementPageObjects extends PageObject{

	@FindBy(css="#DROP_DOWN_USER_PROFILE")
	public WebElementFacade userProfile_DropDown;

	@FindBy(css="users-search > form > a > span")
	public WebElementFacade create_user;

	@FindBy(css="[name*=FIRST_NAME]")
	public WebElementFacade First_Name;

	@FindBy(css="form > user-input:nth-child(2) > div > label > div.error-side > span")
	public WebElementFacade Firstname_error_message;

	@FindBy(css="[name*=LAST_NAME]")
	public WebElementFacade last_name;

	@FindBy(css="form > user-input:nth-child(3) > div > label > div.error-side > span")
	public WebElementFacade Lasname_error_message;

	@FindBy(css="[name*=USERNAME]")
	public WebElementFacade UserName_new_alliance;

	@FindBy(css="form > user-input:nth-child(4) > div > label > div.error-side > span")
	public WebElementFacade username_error_message;

	@FindBy(css="[name*=EMAIL_ADDRESS]")
	public WebElementFacade email_id;

	@FindBy(css="form > user-input:nth-child(7) > div > label > div.error-side > span")
	public WebElementFacade emailid_error_message;

	@FindBy(css="[name*=MOBILE_PHONE_NUMBER]")
	public WebElementFacade mobile_number;

	@FindBy(css="form > user-input:nth-child(8) > div > label > div.error-side > span")
	public WebElementFacade mobileNumber_error_message;

	@FindBy(css="button[type*=submit]")
	public WebElementFacade Next_button;

	@FindBy(css="#DROP_DOWN_USER_PROFILE > span.ng-binding.ng-scope")
	public WebElementFacade profile_dropdown;

	@FindBy(css="div.modal-body.ng-scope > div > div.bottom-navigation > button")
	public WebElementFacade nextbutton_2ndpage;

	//input[id*=mid-selected-] [value*=merchantId] [name*=mid-selected]
	@FindBy(css="[value*=merchantId]")
	public WebElementFacade click23;

	@FindBy(css="div.radio-buttons-container > div:nth-child(1) > label")
	public WebElementFacade merchantUserSelection;

	@FindBy(css="div.modal-container > div.modal-body.ng-scope > div > div.bottom-navigation > button")
	public WebElementFacade save_button;


	@FindBy(css="#search")
	public WebElementFacade search_text;

	@FindBy(css="form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
	public WebElementFacade search_button;

	//@FindBy(css="#merchant-portal > div.container.ng-isolate-scope.dashboard-page > div > navigation > div > a")
	@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > a")
	public WebElementFacade page_load_text;

	//@FindBy(css="#merchant-portal > div.container.ng-isolate-scope.dashboard-page > div > navigation > div > ul > li.ng-scope.more > a")
	@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > a")
	public WebElementFacade More_Option;

	@FindBy(css="#merchant-portal > div.container.ng-isolate-scope.dashboard-page > div > navigation > div > ul > li.ng-scope.more > ul > li.ng-scope.users > a > span > span")
	//@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > ul > li.ng-scope.users > a > span > span")
	public WebElementFacade User_Management_Link;

	@FindBy(css="[name*=oneSearchField]")
	public WebElementFacade Search_Textbox;

	//@FindBy(css="#search-container > ul > li:nth-child(2) > a > span:nth-child(3)")
	@FindBy(css="#search-container > ul > li:nth-child(2) > a")
	public WebElementFacade Search_Textbox_AutoFill_Username;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div.col-lg-12.transactions-module.users-module.home-page.ng-scope > div > div.col-lg-12 > users-search > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
	public WebElementFacade Search_button;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div.col-lg-12.transactions-module.users-module.home-page.ng-scope > div > div.col-lg-12 > div > div > no-records > div > div > div.header > span:nth-child(2)")
	public WebElementFacade No_Result_Found;

	@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-5.tg-fixed-w-5.tg-col-id-0.more-icon-column.no-overflow.sticky > span")
	public WebElementFacade Search_Result_Expand;

	@FindBy(css="ng-transclude > user-table-row-details > div > div > div.user-details-btn-container.ng-scope > button.default-button.blue.ng-scope")
	public WebElementFacade Manage_User_Access_button;

	/*@FindBy(css="[id*=DROP_DOWN_USER_STATUS]")
public List<WebElementFacade> Profile_access;*/

	@FindBy(css="div[class='modal-body ng-scope'] > div > user-dropdown > dropdown > div > button#DROP_DOWN_USER_STATUS")
	public WebElementFacade Profile_access;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > user-dropdown > dropdown > div > ul > li:nth-child(2) > a")
	public WebElementFacade Profile_access_Blocked;

	@FindBy(css="div[class='modal-body ng-scope'] > div > div > dropdown > div > button#single-button2")
	public WebElementFacade Reason_dropdown;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.bottom-navigation > button")
	public WebElementFacade Save_Changes_button;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-header.text-center > h2 > span")
	public WebElementFacade success_message;
	//[type='checkbox']
	@FindBy(css="input[type='checkbox']")
	public WebElementFacade Check_box;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-header.text-center > h2 > span")
	public WebElementFacade Manage_user_access_text;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div.col-lg-12.transactions-module.users-module.home-page.ng-scope > div > div.col-lg-12 > system-error > div > div > div > div.body > span")
	public WebElementFacade Technical_Error;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div.col-lg-12.transactions-module.users-module.home-page.ng-scope > div > div.header-container.horizontal-fixed")
	public WebElementFacade Page_load_image;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.reason-container.ng-scope > dropdown > div > ul > li:nth-child(1) > a")
	public WebElementFacade Block_Reason1;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.reason-container.ng-scope > dropdown > div > ul > li:nth-child(2) > a")
	public WebElementFacade Block_Reason2;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.reason-container.ng-scope > dropdown > div > ul > li:nth-child(3) > a")
	public WebElementFacade Block_Reason3;

	@FindBy(css="ng-transclude > user-table-row-details > div > div > div.user-details-btn-container.ng-scope > button:nth-child(1)")
	public WebElementFacade Edit_user_details_button;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-header.text-center > h2 > span")
	public WebElementFacade Edit_user_Title;

	@FindBy(css="[name*='USERS.FIRST_NAME']")
	public WebElementFacade Firstname;

	//@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input.ng-pristine.ng-untouched.ng-isolate-scope.ng-empty.ng-invalid.ng-invalid-required > div > label > div.error-side > span")
	@FindBy(css="div[class='modal-body ng-scope'] > form > user-input > div > label > div[class='error-side']")
	public WebElementFacade Firstname_error;

	@FindBy(css="[name*='USERS.LAST_NAME']")
	public WebElementFacade Lastname;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(3) > div > label > div.error-side > span")
	public WebElementFacade Lastname_error;

	@FindBy(css="[name*='USERS.EMAIL_ADDRESS']")
	public WebElementFacade Email;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(7) > div > label > div.error-side > span")
	public WebElementFacade Email_error;

	@FindBy(css="[name*='USERS.MOBILE_PHONE_NUMBER']")
	public WebElementFacade mobileno;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(8) > div > label > div.error-side > span")
	public WebElementFacade mobileno_error;

	@FindBy(css="[name*='USERS.TELEPHONE_NUMBER']")
	public WebElementFacade telphoneno;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input.ng-pristine.ng-untouched.ng-valid.ng-isolate-scope.ng-empty > div > label > div.error-side > span")
	public WebElementFacade telphoneno_error;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > div > button")
	public WebElementFacade Next_button_Step1;

	@FindBy(css="div[class='text-left ng-scope'] > div > user-dropdown> dropdown > div > button#DROP_DOWN_USER_PROFILE")
	public WebElementFacade Select_Profile_drop_down;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.profile-preferences-container > user-dropdown > dropdown > div > ul > li:nth-child(1) > a")
	public WebElementFacade Business_Assistant;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.profile-preferences-container > user-dropdown > dropdown > div > ul > li:nth-child(2) > a")
	public WebElementFacade Business_Owner;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.bottom-navigation > button")
	public WebElementFacade Next_button_Step2;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.save-error-message.ng-binding.ng-scope")
	public WebElementFacade Save_Error;

	@FindBy(css="div[class='col-lg-12'] > users-search > form > a > i")
	public WebElementFacade Create_User;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.radio-buttons-container > div:nth-child(1) > label")
	public WebElementFacade Merchant_All_Radio_button;

	@FindBy(css="[name*='USERS.USERNAME']")
	public WebElementFacade User_name;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(4) > div > label > div.error-side > span")
	public WebElementFacade User_name_error;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > user-dropdown > dropdown > div > ul > li:nth-child(1) > a")
	public WebElementFacade Profile_access_Active;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > user-dropdown > dropdown > div > ul > li:nth-child(3) > a")
	public WebElementFacade Profile_access_Terminated;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > button > span:nth-child(1)")
	public WebElementFacade Close_button;

	public WebElement userProfile_DropDown(){
		return userProfile_DropDown;
	}

	public  WebElement page_load_text(){
		return page_load_text;
	}

	public  WebElement More_Option(){
		return More_Option;
	}

	public  WebElement User_Management_Link(){
		return User_Management_Link;
	}

	public  WebElement Search_Textbox(){
		return Search_Textbox;
	}

	public  WebElement Search_Textbox_AutoFill_Username(){
		return Search_Textbox_AutoFill_Username;
	}

	public  WebElement Search_button(){
		return Search_button;
	}

	public  WebElement No_Result_Found(){
		return No_Result_Found;
	}

	public  WebElement Search_Result_Expand(){
		return Search_Result_Expand;
	}

	public WebElement Manage_User_Access_button(){
		return Manage_User_Access_button;
	}

	/*public List<WebElementFacade> Profile_access(){
		return Profile_access;
	}*/

	public WebElementFacade Profile_access(){
		return Profile_access;
	}

	public WebElement Profile_access_Blocked(){
		return Profile_access_Blocked;
	}

	public WebElement Reason_dropdown(){
		return Reason_dropdown;
	}

	public WebElement Save_Changes_button(){
		return Save_Changes_button;
	}

	public WebElement success_message(){
		return success_message;
	}

	public WebElement Check_box(){
		return Check_box;
	}

	public WebElement Manage_user_access_text(){
		return Manage_user_access_text;
	}

	public WebElement Technical_Error(){
		return Technical_Error;
	}

	public WebElement Page_load_image(){
		return Page_load_image;
	}

	public WebElement Block_Reason1(){
		return Block_Reason1;
	}

	public WebElement Block_Reason2(){
		return Block_Reason2;
	}

	public WebElement Block_Reason3(){
		return Block_Reason3;
	}

	public WebElement Edit_user_details_button(){
		return Edit_user_details_button;
	}

	public WebElement Edit_user_Title(){
		return Edit_user_Title;
	}

	public WebElement Firstname(){
		return Firstname;
	}

	public WebElement Firstname_error(){
		return Firstname_error;
	}

	public WebElement Lastname(){
		return Lastname;
	}

	public WebElement Lastname_error(){
		return Lastname_error;
	}

	public WebElement Email(){
		return Email;
	}

	public WebElement Email_error(){
		return Email_error;
	}

	public WebElement mobileno(){
		return mobileno;
	}

	public WebElement mobileno_error(){
		return mobileno_error;
	}

	public WebElement telphoneno(){
		return telphoneno;
	}

	public WebElement telphoneno_error(){
		return telphoneno_error;
	}

	public WebElement Next_button_Step1(){
		return Next_button_Step1;
	}

	public WebElement Select_Profile_drop_down(){
		return Select_Profile_drop_down;
	}

	public WebElement Business_Assistant(){
		return Business_Assistant;
	}

	public WebElement Business_Owner(){
		return Business_Owner;
	}

	public WebElement Next_button_Step2(){
		return Next_button_Step2;
	}

	public WebElement Save_Error(){
		return Save_Error;
	}

	public WebElement Create_User(){
		return Create_User;
	}

	public WebElement Merchant_All_Radio_button(){
		return Merchant_All_Radio_button;
	}

	public WebElement User_name(){
		return User_name;
	}

	public WebElement User_name_error(){
		return User_name_error;
	}

	public WebElement Profile_access_Active(){
		return Profile_access_Active;
	}

	public WebElement Profile_access_Terminated(){
		return Profile_access_Terminated;
	}

	public WebElement Close_button(){
		return Close_button;
	}


	public WebElement save_button(){
		return save_button;
	}

	public WebElement create_user(){
		return create_user;
	}
	public WebElement First_Name(){
		return First_Name;
	}
	public WebElement last_name(){
		return last_name;
	}
	public WebElement UserName_new_alliance(){
		return UserName_new_alliance;
	}	
	public WebElement email_id(){
		return email_id;
	}
	public WebElementFacade mobile_number(){
		return mobile_number;
	}
	public WebElement Next_button(){
		return Next_button;
	}
	public WebElement profile_dropdown(){
		return profile_dropdown;
	}
	public WebElement nextbutton_2ndpage(){
		return nextbutton_2ndpage;
	}
	public WebElementFacade merchantUserSelection(){
		return merchantUserSelection;
	}
	public WebElementFacade search_text(){
		return search_text;
	}
	public WebElementFacade search_button(){
		return search_button;
	}
	public WebElement Lasname_error_message(){
		return Lasname_error_message;
	}
	public WebElement Firstname_error_message(){
		return Firstname_error_message;
	}
	public WebElement emailid_error_message(){
		return emailid_error_message;
	}
	public WebElement username_error_message(){
		return username_error_message;
	}
	public WebElement mobileNumber_error_message(){
		return mobileNumber_error_message;
	}
	public WebElement click23(){
		return click23;
	}

}
