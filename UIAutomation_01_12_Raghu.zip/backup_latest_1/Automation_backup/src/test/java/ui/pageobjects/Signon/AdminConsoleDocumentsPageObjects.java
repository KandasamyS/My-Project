package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AdminConsoleDocumentsPageObjects extends PageObject {

	
	@FindBy(css="a[class='action-button']")
	public WebElementFacade addDocument_button;
	
	@FindBy(css="input#documentname")
	public WebElementFacade documentName;
	
	@FindBy(css="select#allianceCode")
	public WebElementFacade allianceCode;
	
	@FindBy(css="select[name='language'][class='long']")
	public WebElementFacade defaultLanguage;
	
	@FindBy(css="input[type='file']")
	public WebElementFacade documentfile;
	
	@FindBy(css="select#attachmentPath")
	public WebElementFacade documentfilepath;
	
	@FindBy(css="select#attachmentPath >option")
	public List<WebElement> documentfilepathoptions;
	
	@FindBy(css="input[name='cmsAttachmentDocPanel:uploadButton']")
	public WebElementFacade documentfileupload_button;
	
	@FindBy(css="textarea[name='description']")
	public WebElementFacade documentdescription;
	
	@FindBy(css="input[name='priorityCheckFlag']")
	public WebElementFacade priority_checkbox;
	
	@FindBy(css="input[name='submitButton']")
	public WebElementFacade saveButton;
	
	@FindBy(css="div[class='home-menu'] > div > div> a[href*='documents']")
	public WebElementFacade document_link;

	@FindBy(css="#menu-links > div:nth-child(5) > a")
	public WebElementFacade document_link_other;

	@FindBy(css="#mainPanel > div.command-panel > span")
	public WebElementFacade Add_button;

	@FindBy(css="[name*=search-keyword]")
	public WebElement search_Textbox;

	@FindBy(css="[name*=search-button]")
	public WebElementFacade search_button;

	@FindBy(css="[id^=id] > table > tbody > tr:nth-child(8) > td.column0 > div")
	public WebElementFacade selected_text;

	@FindBy(css="[id*=id] > fieldset:nth-child(3) > table > tbody > tr:nth-child(10) > td.right")
	public WebElementFacade document_link_of_each_document;

	@FindBy(css="body > div.ng-scope.logged-in > div > sub-header")
	public WebElementFacade dashboard_text_LBC;

	@FindBy(css="[id*=id] > table > tfoot > tr > td > div")
	public WebElementFacade no_records_found_text;

	@FindBy(css="#mainPanel > div.command-panel > a")
	public WebElementFacade add_button;

/*	@FindBy(css="[id=documentname]")
	public WebElementFacade documentName;*/

	@FindBy(css="[id=allianceCode]")
	public WebElementFacade alliance_code;

	@FindBy(css="[name*=language]")
	public WebElementFacade language;

	@FindBy(css="[name*=fileInput]")
	public WebElementFacade documentPath;

	@FindBy(css="[name*=uploadButton]")
	public WebElementFacade uploadeButton;

	@FindBy(css="[name*=attachmentPath]")
	public WebElementFacade attachmentPath;

	@FindBy(css="[name*=description]")
	public WebElementFacade description;

	@FindBy(css="[name*=submitButton]")
	public WebElementFacade submit_button;

	@FindBy(css="#feedbackPanel > ul > li > span")
	public WebElementFacade message_top_panel;

	@FindBy(css="fieldset:nth-child(3) > table > tbody > tr:nth-child(1) > td.right > div")
	public WebElementFacade error_message;

	@FindBy(css="table > tbody > tr:nth-child(1) > td.column0 > div")
	public WebElementFacade selected_firstRow;

	@FindBy(css="table > tbody > tr:nth-child(1) > td.column0 > div")
	public List<WebElement> Document_Table_list;

	@FindBy(css="[id*=id] > table > tbody > tr > td.column3 > div > span > span:nth-child(2) > a > img")
	public WebElementFacade delete_button;

	
	public WebElement addDocument_button(){
	    return addDocument_button;
	  }
	public WebElement  documentName(){
	    return  documentName;
	  }
	public WebElement allianceCode(){
	    return allianceCode;
	  }
	public WebElement defaultLanguage(){
	    return defaultLanguage;
	  }
	public WebElement documentfile(){
	    return documentfile;
	  }
	public WebElement documentfilepath(){
	    return documentfilepath;
	  }
	public List<WebElement> documentfilepathoptions(){
		return documentfilepathoptions;
	}
	public WebElement documentfileupload_button(){
	    return documentfileupload_button;
	  }
	public WebElement  documentdescription(){
	    return  documentdescription;
	  }
	public WebElement priority_checkbox(){
	    return priority_checkbox;
	  }
	public WebElement saveButton(){
	    return saveButton;
	  }
	public WebElement delete_button(){
		return delete_button;
	}
	public WebElement selected_firstRow(){
		return selected_firstRow;
	}
	public WebElement add_button(){
		return add_button;
	}
/*	public WebElement documentName(){
		return documentName;
	}*/
	public WebElement alliance_code(){
		return alliance_code;
	}
	public WebElement language(){
		return language;
	}
	public WebElement uploadeButton(){
		return uploadeButton;
	}
	public WebElement attachmentPath(){
		return attachmentPath;
	}
	public WebElement description(){
		return description;
	}
	public WebElement submit_button(){
		return submit_button;
	}
	public WebElement message_top_panel(){
		return message_top_panel;
	}
	public WebElement error_message(){
		return error_message;
	}
	public WebElement documentPath(){
		return documentPath;
	}

	public WebElement document_link_other(){
		return document_link_other;
	}
	public WebElement no_records_found_text(){
		return no_records_found_text;
	}
	public WebElement document_link(){
		return document_link;
	}
	public WebElement Add_button(){
		return Add_button;
	}
	public WebElement search_Textbox(){
		return search_Textbox;
	}
	public WebElement search_button(){
		return search_button;
	}
	public WebElement selected_text(){
		return selected_text;
	}
	public WebElement document_link_of_each_document(){
		return document_link_of_each_document;
	}
	public WebElement dashboard_text_LBC() {
		return dashboard_text_LBC;
	}

	
	
}
