package ui.pageobjects.Signon;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ExportEmailPageObjects extends PageObject{


	@FindBy(css="tbody > tr > td:nth-child(1) > div")
	public List<WebElement> userName;

	@FindBy(css="tbody > tr > td:nth-child(2) > div")
	public List<WebElement> userProfile;

	@FindBy(css="tbody > tr > td:nth-child(15) > div")
	public List<WebElement> accountStatus;

	@FindBy(css="a[class='next']")
	public WebElementFacade nextButton;

	@FindBy(css="span[class='next'] > em")
	public List<WebElement> nextButtondisabled;
	
	@FindBy(css="select[name='allianceName']")
	public WebElementFacade allianceName;
	
	@FindBy(css="#menu-links > div:nth-child(4) > a")
	public WebElementFacade Export_email_link;

	@FindBy(css="[id*=id] > tfoot > tr > td > div")
	public WebElementFacade No_record_found_text;

	@FindBy(css="[name*=allianceName]")
	public WebElementFacade alliance_drop_down;

	@FindBy(css="[name*=csv]")
	public WebElementFacade csv_button;

	@FindBy(css="[id*=id] > tbody > tr:nth-child(1) > td:nth-child(1) > div")
	public WebElementFacade First_Record;

	public WebElement Export_email_link(){
		return Export_email_link;
	}
	public WebElement No_record_found_text(){
		return No_record_found_text;
	}
	public WebElement alliance_drop_down(){
		return alliance_drop_down;
	}
	public WebElement csv_button(){
		return csv_button;
	}
	public WebElement First_Record(){
		return First_Record;
	}
	public List<WebElement> userName(){
		return userName;
	}
	public List<WebElement> userProfile(){
		return userProfile;
	}
	public List<WebElement> accountStatus(){
		return accountStatus;
	}
	public WebElement nextButton(){
		return nextButton;
	}
	public List<WebElement> nextButtondisabled(){
		return nextButtondisabled;
	}


}

