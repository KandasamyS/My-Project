package common;



import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class SampleSauceTest {
 
public static WebDriver driver = null;
public static final String USERNAME = "RaghunathBalasubramanian";
public static final String ACCESS_KEY = "f4b7cdf8-133b-45bf-aa3a-5b6a85d95349";
public static final String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub";
//public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";
private static ThreadLocal<WebDriver> webDriverSauce = new ThreadLocal<WebDriver>();
private static ThreadLocal<String> sessionId = new ThreadLocal<String>();

public static WebDriver SauceTest() throws MalformedURLException {
		// TODO Auto-generated method stub
		// driver = createdriver("chrome", "41", "Windows 7", "Testcase");
	//driver.get("https://uat1.merchantportal.firstdata.eu/MerchantAdminWeb/login");
	System.out.println("title of page is: " + driver.getTitle());
	//driver.quit();
	return driver;

} 
public static WebDriver createdrivermobile(String appiumVersion,String deviceName,String platformVersion, String platformName,String browserName,  String methodName)throws MalformedURLException {
	 if(platformName.equalsIgnoreCase("iOS"))
	 {
		 DesiredCapabilities capabilities = DesiredCapabilities.iphone();
		 capabilities.setCapability("appiumVersion",appiumVersion);
		 capabilities.setCapability("deviceName",deviceName);
		 capabilities.setCapability("platformVersion",platformVersion);
		 capabilities.setCapability("platformName", platformName);
		 capabilities.setCapability("browserName", browserName);
				 
				String jobName = methodName + '_' +deviceName+ "_" + browserName + '_' + platformName + '_' + '_' + System.currentTimeMillis();
				capabilities.setCapability("name", jobName);
				 
				webDriverSauce.set(new RemoteWebDriver(
						new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
						String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
						sessionId.set(id);
						 
						String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
						System.out.println(message);
	 }
	 else  if(platformName.equalsIgnoreCase("Android"))
	 {
		 DesiredCapabilities capabilities = DesiredCapabilities.android();
		 capabilities.setCapability("appiumVersion",appiumVersion);
		 capabilities.setCapability("deviceName",deviceName);
		 capabilities.setCapability("platformVersion",platformVersion);
		 capabilities.setCapability("platformName", platformName);
		 capabilities.setCapability("browserName", browserName);
				 
				String jobName = methodName + '_' +deviceName+ "_" + browserName + '_' + platformName + '_' + '_' + System.currentTimeMillis();
				capabilities.setCapability("name", jobName);
				 
				webDriverSauce.set(new RemoteWebDriver(
						new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
						String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
						sessionId.set(id);
						 
						String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
						System.out.println(message);
	 }
		return webDriverSauce.get();
}
public static WebDriver createdriver(String browser, String version, String os, String methodName)throws MalformedURLException {
 if(browser.equalsIgnoreCase("chrome"))
 {
	 DesiredCapabilities capabilities = DesiredCapabilities.chrome();
	 if (version != null) {
			capabilities.setCapability(CapabilityType.VERSION, version);
			}
			capabilities.setCapability(CapabilityType.PLATFORM, os);
			 
			String jobName = methodName + '_' + os + '_' + browser + '_' + version + '_' + System.currentTimeMillis();
			capabilities.setCapability("name", jobName);
			 
			webDriverSauce.set(new RemoteWebDriver(
			new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
			String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
			sessionId.set(id);
			 
			String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
			System.out.println(message);
 }
 else if(browser.equalsIgnoreCase("IE"))
{
	 		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
	 		if (version != null) {
	 			capabilities.setCapability(CapabilityType.VERSION, version);
	 			}
	 			capabilities.setCapability(CapabilityType.PLATFORM, os);
	 			 
	 			String jobName = methodName + '_' + os + '_' + browser + '_' + version + '_' + System.currentTimeMillis();
	 			capabilities.setCapability("name", jobName);
	 			 
	 			webDriverSauce.set(new RemoteWebDriver(
	 			new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
	 			String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
	 			sessionId.set(id);
	 			 
	 			String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
	 			System.out.println(message);
}
 else if(browser.equalsIgnoreCase("MS Edge"))
{
	 		DesiredCapabilities capabilities = DesiredCapabilities.edge();
	 		if (version != null) {
	 			capabilities.setCapability(CapabilityType.VERSION, version);
	 			}
	 			capabilities.setCapability(CapabilityType.PLATFORM, os);
	 			 
	 			String jobName = methodName + '_' + os + '_' + browser + '_' + version + '_' + System.currentTimeMillis();
	 			capabilities.setCapability("name", jobName);
	 			 
	 			webDriverSauce.set(new RemoteWebDriver(
	 			new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
	 			String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
	 			sessionId.set(id);
	 			 
	 			String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
	 			System.out.println(message);
}
 else if(browser.equalsIgnoreCase("Firefox"))
{
	 		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
	 		if (version != null) {
	 			capabilities.setCapability(CapabilityType.VERSION, version);
	 			}
	 			capabilities.setCapability(CapabilityType.PLATFORM, os);
	 			 
	 			String jobName = methodName + '_' + os + '_' + browser + '_' + version + '_' + System.currentTimeMillis();
	 			capabilities.setCapability("name", jobName);
	 			 
	 			webDriverSauce.set(new RemoteWebDriver(
	 			new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
	 			String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
	 			sessionId.set(id);
	 			 
	 			String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
	 			System.out.println(message);
}

 else if(browser.equalsIgnoreCase("Safari"))
{
	 		DesiredCapabilities capabilities = DesiredCapabilities.safari();
	 		if (version != null) {
	 			capabilities.setCapability(CapabilityType.VERSION, version);
	 			}
	 			capabilities.setCapability(CapabilityType.PLATFORM, os);
	 			 
	 			String jobName = methodName + '_' + os + '_' + browser + '_' + version + '_' + System.currentTimeMillis();
	 			capabilities.setCapability("name", jobName);
	 			 
	 			webDriverSauce.set(new RemoteWebDriver(
	 			new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
	 			String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
	 			sessionId.set(id);
	 			 
	 			String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
	 			System.out.println(message);
}
	
	
	 
	return webDriverSauce.get();
 
}
 
public static WebDriver getWebDriver() {
	System.out.println("WebDriver" + webDriverSauce.get());
	return webDriverSauce.get();
}
 
public String getSessionId() {
	return sessionId.get();
}


}


