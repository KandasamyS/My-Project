package common;

import java.sql.*;
public class JDBCConnection {
//public static void main(String[] args){
	public static String GetTheDbqueryValue(String sqlQuery) throws ClassNotFoundException, SQLException {
		String passcode=null;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection Con = DriverManager.getConnection("jdbc:oracle:thin:@10.68.47.122:1521/MPSAUAT_HA","PORTAL_ADM", "d3fPWgb_mpw");		
		//System.out.println("connection Successful");
		if (Con != null) {
            System.out.println("Connection Established");
        } else {
            System.out.println("Failed to make connection!");
        }
		
		Statement stmt = Con.createStatement();
		
		 ResultSet rs=  stmt.executeQuery(sqlQuery);
		//ResultSet rs= stmt.executeQuery("select username,passcode from usr u where u.username='TestAutomationBO';");
		 while(rs.next()){
		 passcode=    rs.getString("passcode");
		 System.out.println("Passcode is : "+passcode);
		   
		  }
		}
		  catch (Exception e) 
		{
		         System.out.println(e.getMessage());
		  }
		return passcode;
	}

}
