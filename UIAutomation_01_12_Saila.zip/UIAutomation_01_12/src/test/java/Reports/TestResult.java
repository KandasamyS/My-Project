package Reports;


import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
/*     */ 

/*     */ 
/*     */ public class TestResult
/*     */ {
                                                
                                                                
/*     */   private PrintWriter error_log;
/*     */   private FileOutputStream htmlFile;
/*     */   private FileOutputStream endReport;
/*     */   private String strTestStatus;
/*     */   private String fileName;
/*     */   private String parentPath;
/*     */   private String testCaseName;
/*     */   private int stepCount;
/*     */   private String executionDate;
/*     */   private boolean executionWarning;
/*     */   private long executionStartTime_inSecs;
/*     */   private String executionStartTime;
/*     */   private long executionEndTime_inSecs;
/*     */   private String executionEndTime;
/*     */   private int passedStepCount;
/*     */   private int failedStepCount;
/*     */   private int warningStepCount;
/*     */   private int dataSetNo;
/*     */   private static int stepNo;
/*     */   private static int subStepNo;
/*     */   private boolean capturedScrnShot;
/*     */   private String ScrShotName;
                                                
                                                
/*     */   public TestResult()
/*     */   {
/*  54 */     this.strTestStatus = "PASSED";
/*  55 */     this.capturedScrnShot = false;
/*  56 */ //  this.parentPath = AppConstants.RESULT;

              /*this.parentPath = "C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results";*/
              this.parentPath = System.getProperty("user.dir") + "/Results";
                                                                
/*  57 */     this.stepCount = 0;
/*  58 */     this.executionDate = getCurrentDate("");
/*  59 */     this.executionWarning = false;
/*  61 */     this.capturedScrnShot = false;
/*  62 */     this.passedStepCount = 0;
/*  63 */     this.failedStepCount = 0;
/*  64 */     this.warningStepCount = 0;
/*  65 */     this.executionStartTime_inSecs = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
/*  66 */     this.executionStartTime = getCurrentTime();
/*     */     try
/*     */     {
/*  69 */       this.error_log = new PrintWriter(new FileWriter(this.parentPath + "/errorLog.log", true));
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  73 */       System.out.println("FATAL ERROR - Could not Initiate the error log");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public TestResult(String parentPath)
/*     */   {
/*  80 */     this.parentPath = parentPath;
/*  82 */     this.strTestStatus = "PASSED";
/*  83 */     this.capturedScrnShot = false;
/*  84 */     this.executionWarning = false;
/*  85 */     this.passedStepCount = 0;
/*  86 */     this.failedStepCount = 0;
/*  87 */     this.warningStepCount = 0;
/*  88 */     this.executionStartTime_inSecs = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
/*  89 */     this.executionStartTime = getCurrentTime();
/*  90 */     this.executionDate = getCurrentDate("");
/*     */     try
/*     */     {
/*  93 */       this.error_log = new PrintWriter(new FileWriter(parentPath + "/errorLog.log", true));
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  97 */       System.out.println("FATAL ERROR - Could not Initiate the error log");
/*     */     }
/*     */   }
/*     */   
/*     */   public String getCurrentTime()
/*     */   {
/* 103 */     Calendar calendar = new GregorianCalendar();
/*     */     
/* 105 */     int hour = calendar.get(10);
/* 106 */     int minute = calendar.get(12);
/* 107 */     int second = calendar.get(13);
/* 108 */     String am_pm;  if (calendar.get(9) == 0) {
/* 109 */       am_pm = "AM";
/*     */     } else
/* 111 */       am_pm = "PM";
/* 112 */     String currentTime = "";
/*     */     
/* 114 */     if ((hour < 10) && (hour >= 0)) {
/* 115 */       currentTime = currentTime + "0" + hour;
/*     */     } else {
/* 117 */       currentTime = currentTime + hour;
/*     */     }
/* 119 */     if ((minute < 10) && (minute >= 0)) {
/* 120 */       currentTime = currentTime + ":0" + minute;
/*     */     } else {
/* 122 */       currentTime = currentTime + ":" + minute;
/*     */     }
/* 124 */     if ((second < 10) && (second >= 0)) {
/* 125 */       currentTime = currentTime + ":0" + second;
/*     */     } else {
/* 127 */       currentTime = currentTime + ":" + second;
/*     */     }
/* 129 */     currentTime = currentTime + " " + am_pm;
/* 130 */     return currentTime;
/*     */   }
/*     */   
/*     */   public PrintWriter getErrorLog()
/*     */   {
/* 135 */     return this.error_log;
/*     */   }
/*     */   
/*     */   public void setParentPath(String parentPath)
/*     */   {
/* 140 */     this.parentPath = parentPath;
/*     */     try
/*     */     {
/* 144 */       this.error_log = new PrintWriter(new FileWriter(parentPath + "/errorLog.log", true));
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 148 */       System.out.println("FATAL ERROR - Could not Initiate the error log");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getCurrentDate(String strDateFormat)
/*     */   {
/*     */     try
/*     */     {
/* 157 */       Calendar currentDate = Calendar.getInstance();
/* 158 */       if ((strDateFormat == null) || (strDateFormat.equals("")))
/*     */       {
/* 160 */         strDateFormat = "dd/MMM/yyyy";
/*     */       }
/* 162 */       SimpleDateFormat formatter = new SimpleDateFormat(strDateFormat);
/* 163 */       String dateNow = formatter.format(currentDate.getTime());
/* 164 */       //System.out.println("Current Date: " + dateNow);
/* 165 */       return dateNow;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 169 */       System.out.println("Exception: " + e.getLocalizedMessage()); }
/* 170 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void initializeTest(String testCase)
/*     */   {

/* 177 */     this.testCaseName = testCase;
/* 178 */     stepNo = 0;
/* 179 */     subStepNo = 0;
/* 180 */     this.dataSetNo = 0;
/* 181 */     this.fileName = (this.parentPath + "/" + this.testCaseName+" "+getCurrentDate("MMddyyyy")+ ".html");
/*     */     
/* 183 */     String temp = "<HTML>";
/* 184 */     writeToFile(temp, false);
/*     */     
/*     */ 
/* 187 */     //temp = "<head><link rel='stylesheet' type='text/css' href='C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results/Images/report_stylesv1.css'></head>";
/* 188 */     temp = "<head><link rel='stylesheet' type='text/css' href='Images/report_stylesv1.css'></head>";
/* 188 */     
			  writeToFile(temp, true);
/*     */     
/* 190 */     temp = "<hr class='divline'>";
/* 191 */     writeToFile(temp, true);
/*     */     
/* 193 */     temp = "<table class='reportheader' width=100%>";
/* 194 */     writeToFile(temp, true);
/* 195 */     //temp = "<TR>\n<td height=50px align=left>\n<Table class='developer'>\n<TR>\n<td class='desc1'>\n<Center>\n<table>\n<TR>\n<TD class='desccpy'>Automation Test Execution Report</TD>\n</TR>\n<TR>\n<TD class='dev'>Tool Used : Selenium - Serenity BDD </TD>\n</TR>\n<TR>\n<TD class='dev'>Developed by : Cognizant </TD>\n</TR>\n</Table>\n</TD>\n</TR>\n</Table>\n</TD>\n<BR>\n<td height=50px align=right>\n<img src = 'C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results/Images/fdv.png'>\n</td>\n<BR>";
/* 196 */     temp = "<TR>\n<td height=50px align=left>\n<Table class='developer'>\n<TR>\n<td class='desc1'>\n<Center>\n<table>\n<TR>\n<TD class='desccpy'>Automation Test Execution Report</TD>\n</TR>\n<TR>\n<TD class='dev'>Tool Used : Selenium - Serenity BDD </TD>\n</TR>\n<TR>\n<TD class='dev'>Developed by : Cognizant </TD>\n</TR>\n</Table>\n</TD>\n</TR>\n</Table>\n</TD>\n<BR>\n<td height=50px align=right>\n<img src = Images/fdv.png>\n</td>\n<BR>";
			  writeToFile(temp, true);
/*     */     
/* 198 */     temp = "</tr>\n</table>\n<hr class='divline'>\n<BR>";
/* 199 */     writeToFile(temp, true);
/*     */     
/* 201 */     temp = "<table class='subheader' width=100%><tr>";
/* 202 */     writeToFile(temp, true);
/*     */     
/* 204 */     temp = "<tr><td width=100% class='subheader'>Test Case Desription - " + this.testCaseName + "</td></tr>";
/* 205 */     writeToFile(temp, true);
/*     */     
/* 207 */     temp = "<tr><td width=100% class='subcontents'></td></tr>";
/* 208 */     writeToFile(temp, true);
/*     */     
/* 210 */     temp = "\n</tr></table> <hr class='divline'>\n<BR>\n";
/* 211 */     writeToFile(temp, true);
/*     */     
/* 213 */     temp = "\n<table class='teststeps' width=100%>\n<TR>";
/* 214 */     writeToFile(temp, true);
/*     */     
/* 216 */     temp = "\n<TD class='tsheader' width=75px>Step # </TD>";
/* 217 */     writeToFile(temp, true);
/*     */     
/* 219 */     temp = "\n<TD class='tsheader' width=155px>Step Description</TD>";
/* 220 */     writeToFile(temp, true);
/*     */     
/* 222 */     temp = "\n<TD class='tsheader' width=285px>Expected Result</TD>";
/* 223 */     writeToFile(temp, true);
/*     */     
/* 225 */     temp = "\n<TD class='tsheader' width=285px>Actual Result</TD>";
/* 226 */     writeToFile(temp, true);
/*     */     
/* 228 */     temp = "\n<TD class='tsheader' width=50px>Status</TD>";
/* 229 */     writeToFile(temp, true);
/*     */     
/* 231 */     temp = "\n<TD class='tsheader' width=50px>Screen shot</TD></TR>\n";
/* 232 */     writeToFile(temp, true);
/*     */     
/* 234 */    // incrementDataSet();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean writeToFile(String msg, boolean append)
/*     */   {
/*     */     try
/*     */     {
/* 242 */       this.htmlFile = new FileOutputStream(this.fileName, append);
/* 243 */       this.htmlFile.write(msg.getBytes());
/* 244 */       this.htmlFile.close();
/* 245 */       return true;
/*     */     }
/*     */     catch (IOException ie) {
/* 248 */       ie.printStackTrace(this.error_log); }
/* 249 */     return false;
/*     */   }
/*     */   

/*     */ 
/*     */   public boolean WriteReportStep(String level, String s_Name, String s_Expected, String s_Actual, String status)
/*     */   {
/* 259 */     if (level.equals("1"))
/*     */     {
/* 261 */       subStepNo = 0;
/* 262 */       this.stepCount += 1;
/* 263 */       stepNo += 1;
/* 264 */       writeToFile("<TR>\n", true);
/* 265 */       String testStep = "<TD class='tsindlevel1' width=75px>" + stepNo + "</TD>\n";
/* 266 */       writeToFile(testStep, true);
/* 267 */       testStep = "<TD class='tsindlevel1' height=30px colspan = '5'>" + s_Name.trim() + "</TD>\n";
/* 268 */       writeToFile(testStep, true);
/* 269 */       writeToFile("</TR>\n", true);
/*     */ 
/*     */ 
/*     */     }
/* 273 */     else if (level.equals("2"))
/*     */     {
/* 275 */       subStepNo += 1;
/* 276 */       String subStep = stepNo + "." + subStepNo;
/* 277 */       writeToFile("\n<TR>\n", true);
/*     */       
/*     */ 
/*     */ 
/* 281 */       if (status.equalsIgnoreCase("Passed"))
/*     */       {
/* 283 */         this.passedStepCount += 1;
/* 284 */         String testStep = "<TD class='tsindlevel2' width=75px>" + subStep + "</TD>\n";
/* 285 */         writeToFile(testStep, true);
/* 286 */         testStep = "<TD class='tsgen' width=155px>" + s_Name.trim() + "</TD>\n";
/* 287 */         writeToFile(testStep, true);
/* 288 */         testStep = "<TD class='tsgen' width=285px>" + s_Expected.trim() + "</TD>\n";
/* 289 */         writeToFile(testStep, true);
/* 290 */         testStep = "<TD class='tsgen' width=285px>" + s_Actual.trim() + "</TD>\n";
/* 291 */         writeToFile(testStep, true);
/* 292 */         //testStep = "<TD class='tsgen' width=50px align=center><img class='screen' src = 'C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results/Images/tick.png'></TD>\n";
/* 293 */         testStep = "<TD class='tsgen' width=50px align=center><img class='screen' src = 'Images/tick.png'></TD>\n";
				  writeToFile(testStep, true);
/*     */       }
/* 295 */       else if (status.equalsIgnoreCase("Failed"))
/*     */       {
/* 297 */         this.strTestStatus = "FAILED";
/* 298 */         this.failedStepCount += 1;
/* 299 */         String testStep = "<TD class='tsindFaillevel2' width=75px>" + subStep + "</TD>\n";
/* 300 */         writeToFile(testStep, true);
/* 301 */         testStep = "<TD class='tsgenFail' width=155px>" + s_Name.trim() + "</TD>\n";
/* 302 */         writeToFile(testStep, true);
/* 303 */         testStep = "<TD class='tsgenFail' width=285px>" + s_Expected.trim() + "</TD>\n";
/* 304 */         writeToFile(testStep, true);
/* 305 */         testStep = "<TD class='tsgenFail' width=285px>" + s_Actual.trim() + "</TD>\n";
/* 306 */         writeToFile(testStep, true);
/* 307 */         //testStep = "<TD class='tsgenFail' width=50px align=center><img class='screen' src = 'C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results/Images/cross.png'></TD>\n";
/* 308 */         testStep = "<TD class='tsgenFail' width=50px align=center><img class='screen' src = 'Images/cross.png'></TD>\n";
				  writeToFile(testStep, true);
/*     */       }
/* 310 */       else if (status.equalsIgnoreCase("Warning"))
/*     */       {
/* 312 */         this.executionWarning = true;
/* 313 */         this.warningStepCount += 1;
/* 314 */         String testStep = "<TD class='tsindlevel2' width=75px>" + subStep + "</TD>\n";
/* 315 */         writeToFile(testStep, true);
/* 316 */         testStep = "<TD class='tsgen' width=155px>" + s_Name.trim() + "</TD>\n";
/* 317 */         writeToFile(testStep, true);
/* 318 */         testStep = "<TD class='tsgen' width=285px>" + s_Expected.trim() + "</TD>\n";
/* 319 */         writeToFile(testStep, true);
/* 320 */         testStep = "<TD class='tsgen' width=285px>" + s_Actual.trim() + "</TD>\n";
/* 321 */         writeToFile(testStep, true);
/* 322 */         //testStep = "<TD class='tsgenFail' width=50px align=center><img class='screen' src = 'C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results/Images/warning.png'></TD>\n";
/* 323 */         testStep = "<TD class='tsgenFail' width=50px align=center><img class='screen' src = 'Images/warning.png'></TD>\n";
				  writeToFile(testStep, true); }
/*     */       String testStep;
/* 325 */       if (this.capturedScrnShot)
/*     */       {
/*     */ 
/* 328 */          //testStep = "<TD class='tsgen' width=50px align=center><a target='_blank' class='anibutton' href='" + this.ScrShotName + "'><img class='screen' src ='C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results/Images/Screenshot.jpg'></a></TD>\n";
/*     */          testStep = "<TD class='tsgen' width=50px align=center><a target='_blank' class='anibutton' href='" + this.ScrShotName + "'><img class='screen' src ='Images/Screenshot.jpg'></a></TD>\n";
/* 330 */         this.capturedScrnShot = false;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 335 */         testStep = "<TD class='tsgen' width=50px></TD>\n";
/*     */       }
/*     */       
/* 338 */       writeToFile(testStep, true);
/*     */       
/* 340 */       writeToFile("</TR>\n", true);
/*     */     }
/* 342 */     return true;
/*     */   }
/*     */   
/*     */   public void incrementDataSet()
/*     */   {
/* 347 */     this.dataSetNo += 1;
/* 348 */     stepNo = 0;
/* 349 */     subStepNo = 0;
/* 350 */     String dataSet = "\n<TR><TD class='dataset' height=30px colspan = '6'><center>Data Set : " + this.dataSetNo + "</center></TD></TR>\n";
/* 351 */     writeToFile(dataSet, true);
/*     */   }
/*     */   
/*     */ 
/*     */   public void closeTestReport()
{
    this.executionEndTime_inSecs = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
    this.executionEndTime = getCurrentTime();
    long totalExecutionTime = this.executionEndTime_inSecs - this.executionStartTime_inSecs;

    writeToFile("\n</table>", true);

    String temp = "\n<hr class='divline'>\n<br>";
    writeToFile(temp, true);

    temp = "\n<table class='subheader' width=100%><tr><tr><td width=100% class='subheader'>Test Execution Summary</td></tr><tr><td width=100% class='subcontents'></td></tr></tr></table>";
    writeToFile(temp, true);

    temp = "\n<hr class='divline'>\n<br>";
    writeToFile(temp, true);

    temp = "\n<table>\n<tr>";
    writeToFile(temp, true);

    temp = "\n<td><table class = 'releasesummary'><tr><td class='summaryheader' colspan=2>Execution Time Summary</td></tr><tr><td class ='summaryelement' width=100>Test Executed On</td><td class ='summarybody' width=450>" + this.executionDate + "</td></tr><tr><td class ='summaryelement' width=100>Test Execution Start Time</td><td class ='summarybody' width=450>" + this.executionStartTime + "</td></tr><tr><td class ='summaryelement'>Test Execution End Time</td><td class ='summarybody'>" + this.executionEndTime + "</td></tr><tr><td class ='summaryelement'>Total Execution Time</td><td class ='summarybody'>" + totalExecutionTime + " secs</td></tr></table></td>";
    writeToFile(temp, true);

    temp = "\n<td></td>\n";
    writeToFile(temp, true);

    temp = "\n<td><table class = 'releasesummary'><tr><td class='summaryheader' colspan=2>Execution Steps Summary</td></tr><tr><td class ='summaryelement' width=100>Test Steps Executed</td><td class ='summarybody'width=450>" + this.stepCount + "</td></tr><tr><td class ='summaryelement'>Number of SubSteps Passed</td><td class ='summarybody'>" + this.passedStepCount + "</td></tr><tr><td class ='summaryelement'>Number of SubSteps Failed</td><td class ='summarybody'>" + this.failedStepCount + "</td></tr><tr><td class ='summaryelement'>Number of Warnings</td><td class ='summarybody'>" + this.warningStepCount + "</td></tr></table></td>";
    writeToFile(temp, true);

    temp = "\n</tr>\n</table>";
    writeToFile(temp, true);

    temp = "\n<hr class='divline'>\n<hr class='divline'>\n<br>";
    writeToFile(temp, true);
    String spanType = null;
    if (this.strTestStatus.equalsIgnoreCase("PASSED"))
    {
           if (this.executionWarning)
           {
                  spanType = "testwarning";
                  this.strTestStatus += " (with WARNINGS)";
           }
           else {
                  spanType = "testpassed";
           }
    } else if (this.strTestStatus.equalsIgnoreCase("FAILED")) {
           spanType = "testfailed";
    }
    temp = "\n<table class='subheader' width=100%><tr><tr><td width=100% class='subheader' align='center'>Overall Test Status : <span class = '" + spanType + "' id='overallstatus'>" + this.strTestStatus + "</span></td></tr></tr></table>";
    writeToFile(temp, true);

    temp = "\n<hr class='divline'>\n<br>";
    writeToFile(temp, true);

    temp = "<center><span>Cognizant</span></center>";
    writeToFile(temp, true);

    temp = "\n</body>\n</html>";
    writeToFile(temp, true);
   
}

/*     */   
/*     */   public void endTestReport()
/*     */   {
/*     */     try
/*     */     {
/* 420 */       File[] testReports = new File(this.parentPath).listFiles(new MyFilter());
/* 421 */       this.endReport = new FileOutputStream(this.parentPath + "/index.html", false);
/*     */       
/* 423 */       String temp = "<HTML>/n<title>Final Test Execution Report</title>\n<body bgcolor=#87cefa>\n"; //#33ccff 454523
/* 424 */       this.endReport.write(temp.getBytes());
/*     */       
/* 426 */       temp = "<Table border='1'><TR><TD> <b>Test Case Name</b> </TD><TD> <b>Status</b> </TD></TR>";
/* 427 */       this.endReport.write(temp.getBytes());
/*     */       
/* 429 */       for (int i = 0; i < testReports.length; i++)
/*     */       {
/* 431 */         temp = "<TR><TD> <a href='" + testReports[i].getAbsolutePath() + "'>" + testReports[i].getName() + "</a></TD><TD></TD>";
/* 432 */         this.endReport.write(temp.getBytes());
/*     */       }
/*     */       
/* 435 */       this.endReport.write("</Table>".getBytes());
/* 436 */       this.endReport.write("</Body></HTML>".getBytes());
/* 437 */       this.endReport.close();
				
                                                                
/*     */     }
/*     */     catch (IOException e) {
/* 440 */       e.printStackTrace(this.error_log);
/*     */     }
/*     */   }

public void SummarizeTestReport()
{
       try
       {
              File[] testReports = new File(this.parentPath).listFiles(new MyFilter());
              this.endReport = new FileOutputStream(this.parentPath + "/SummarizeReport.html", false);
              
                
              String temp = "<HTML><title>Final Test Execution Report</title>\n<body bgcolor=#87cefa>\n"; //#33ccff 454523
              //temp = "<TR>\n<td height=50px align=left>\n<Table class='developer'>\n<TR>\n<td class='desc1'>\n<Center>\n<table>\n<TR>\n<TD class='desccpy'>Summarized Automation Test Execution Report</TD>\n</TR>\n<TR>\n<TD class='dev'>Tool Used : Selenium - Serenity BDD </TD>\n</TR>\n<TR>\n<TD class='dev'>Developed by : Cognizant </TD>\n</TR>\n</Table>\n</TD>\n</TR>\n</Table>\n</TD>\n<BR>\n<tr height=50px align=right>\n<img src = 'C:/Users/F8T9I50/Desktop/FAB_Automation/SerenityBDD_Latest/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Results/Images/fdv.png'>\n</tr>\n<BR>";
              temp = "<TR>\n<td height=50px align=left>\n<Table class='developer'>\n<TR>\n<td class='desc1'>\n<Center>\n<table>\n<TR>\n<TD class='desccpy'>Summarized Automation Test Execution Report</TD>\n</TR>\n<TR>\n<TD class='dev'>Tool Used : Selenium - Serenity BDD </TD>\n</TR>\n<TR>\n<TD class='dev'>Developed by : Cognizant </TD>\n</TR>\n</Table>\n</TD>\n</TR>\n</Table>\n</TD>\n<BR>\n<tr height=50px align=right>\n<img src = 'Images/fdv.png'>\n</tr>\n<BR>";
              
              this.endReport.write(temp.getBytes());

              temp = "<Table border='1'><TR><TD> <b>Test Case Name</b> </TD><TD> <b>Status</b> </TD></TR>";
              this.endReport.write(temp.getBytes());

              for (int i = 0; i < testReports.length; i++)
              {
                     if(testReports[i].getName().equalsIgnoreCase("index.html")==true || testReports[i].getName().equalsIgnoreCase("SummarizeReport.html")==true)
                     {
                           //do nothing
                     }
                     else
                     {
                     //System.out.println("***Test Case****"+testReports[i].getAbsolutePath());
                     //System.out.println("Extract Test Status for :"+extractText(testReports[i].getAbsolutePath())); 
                     temp = "<TR><TD> <a href='" + testReports[i].getAbsolutePath() + "'>" + testReports[i].getName() + "</a></TD><TD>"+extractText(testReports[i].getAbsolutePath())+"</TD></TR>";
                     this.endReport.write(temp.getBytes());
                     }
                     
              }

              this.endReport.write("</Table>".getBytes());
              this.endReport.write("</Body></HTML>".getBytes());
              this.endReport.close();
       }
       catch (IOException e) {
              e.printStackTrace(this.error_log);
       }
}

public static String extractText(String strFile) throws IOException 
{
      try{        String status=null;
              FileReader reader = new FileReader(strFile);
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(reader);
        String line;
        while ((line = br.readLine()) != null) 
        {
            sb.append(line);
        }
        
        String textOnly = Jsoup.parse(sb.toString()).text();
        Element a= Jsoup.parse(sb.toString()).getElementById("overallstatus");
        //System.out.println("Test Status:"+a.text());
        status=a.text();
        return status;
      }catch(Exception e)
      {
                  //System.out.println(e.getLocalizedMessage());
                  return e.getLocalizedMessage();
      }
                       
       
}

                }



