package runner;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(monochrome=true,
features="src/test/resources/features",
glue="stepdefinitions",
strict=true,
tags="@MEPOE-5325_User_Management,@MEPOE-5326_User_Management,@MEPOE-5372_Dashboard_navigation,@MEPOE-5373_Dashboard_navigation,@MEPOE-5374_Dashboard_navigation,@MEPOE-5377_Dashboard_navigation,@MEPOE-6292_Dashboard_navigation,@MEPOE-5491_Dashboard_navigation,@MEPOE-5486_Dashboard_navigation,@MEPOE-5483_Dashboard_navigation")
public class TestRunner {
}