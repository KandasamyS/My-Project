/*package api;

import net.thucydides.core.annotations.Step;
//import stepdefinitions.Apidefinitions;

import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.HttpsURLConnection;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Scanner;

import com.jayway.restassured.specification.RequestSpecification;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;

public class LoadRequest {
	public static Map<String, String> jsonAsMap = new HashMap<String,String>();
	public static Map<String, Object> jsonAsMap1 = new HashMap<>();
	public static String countryCode=null;
	public static String tag=null;
	
	public String getTag(String arg1)
	{
		tag= arg1;
		System.out.println("Tag:"+arg1);
		return tag;
	}

	@Step
	public void loadgetrequestdata(String appurl){
		requestHeaders();
	}
	
	@Step
	public void loadgetrequestdata_authenticated(String appurl, String token){
		requestHeaders_authenticated();
	}
	
	@Step
	public void loadpostrequestdata(String url ,String filepath) throws IOException{

		requestHeaders();
		requestbody(url, filepath);
	
	}
	public void requestHeaders(){
		jsonAsMap1.put("contentType", "application/json");
	
	}

	public void requestHeaders_authenticated(){
		String strtoken=Apidefinitions.token;
		jsonAsMap.put("contentType", "application/json");
		jsonAsMap.put("X-CSRF-TOKEN", strtoken);
		
	}
	


	public void requestbody(String url,String BodyFile) throws IOException
	{
		@SuppressWarnings("resource")
		String input = new Scanner(new File(BodyFile)).useDelimiter("\\Z").next();

		//Below getoutputstream method returns an OutputStream where the data can be written
		OutputStream os = conn.getOutputStream();
		System.out.println(input.getBytes());
		os.write(input.getBytes());
		os.flush();

		System.out.println("ResponseCode : "+conn.getResponseCode());
		//Verify getResponseCode
		if (conn.getResponseCode() != 200) 
		{    

			throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
		}else
		{

		}
		// Returns an input stream that reads from the given connection.
		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

		String output;
		String xmlResponse = "";
		System.out.println("Output from Server .... \n");
		while ((output = br.readLine()) != null) 
		{
			System.out.println(output);
			xmlResponse = output;
		}
		conn.disconnect();


	}
	public static class DefaultTrustManager implements X509TrustManager 
	{

		@Override
		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

		@Override
		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

		@Override
		public X509Certificate[] getAcceptedIssuers() 
		{
			return null;
		}
	}

		
	public HttpsURLConnection POST_API(String strurl)
	{ 
	      try 
	      {   
	      // configure the SSLContext with a TrustManager
	      SSLContext ctx = SSLContext.getInstance("TLS");
	      ctx.init(new KeyManager[0], new TrustManager[] {(TrustManager) new DefaultTrustManager()}, new SecureRandom());
	      SSLContext.setDefault(ctx);

	      // Creates a URL object from the String representation.
	      URL url = new URL(strurl);

	      // Returns a URLConnection instance that represents a connection to the remote object referred to by the URL.
	      HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
	      conn.setDoOutput(true);

	      // Set the method for the URL request,
	      conn.setRequestMethod("POST");

	      //Sets the general request property (Request Header).
	      conn.setRequestProperty("Content-Type", "application/JSON");
	      return conn; 
	      }catch(Exception e)
	      {
	    	  System.out.println(e.getLocalizedMessage());
	    	  return null; 
	      }
	     
	}

	public String GET_ExeAPI_ReqPropertyJSON(String strurl)
    { 
          try 
          {   
          // configure the SSLContext with a TrustManager
          SSLContext ctx = SSLContext.getInstance("TLS");
          ctx.init(new KeyManager[0], new TrustManager[] {(TrustManager) new DefaultTrustManager()}, new SecureRandom());
          SSLContext.setDefault(ctx);

          // Creates a URL object from the String representation.
          URL url = new URL(strurl);
          // Returns a URLConnection instance that represents a connection to the remote object referred to by the URL.
          HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
          // Set the method for the URL request,
          conn.setRequestMethod("GET");
    
          //Sets the general request property (Request Header).
          
          conn.setRequestProperty("Accept", "application/JSON");
          System.out.println("ResponseCode : "+conn.getResponseCode());
          //Verify getResponseCode
          if (conn.getResponseCode() != 200) 
          {    
             
               throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
          }else
          {
              
          }
          // Returns an input stream that reads from the given connection.
          BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

          String output;
          String xmlResponse = "";
          System.out.println("Output from Server .... \n");
          while ((output = br.readLine()) != null) 
          {
               xmlResponse = output;
          }

          conn.disconnect();
         
          return xmlResponse;
          }
          catch(Exception e)
          {
               
               return null;
          } 
    }

	

	


}
*/