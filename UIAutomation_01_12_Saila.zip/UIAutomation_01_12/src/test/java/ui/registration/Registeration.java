package ui.registration;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.registration.RegObjects;


	public class Registeration extends PageObject{
		
	

	//private static final long serialVersionUID = 1L;
	
	WebDriver driver =null;
	
	RegObjects regobjects;
@Step
public void loadbrowser(){
	
	System.out.println("Loading Browser");
	/*System.setProperty("webdriver.chrome.driver", 
    "C:\\Users\\504206\\Downloads\\chromedriver_win32\\chromedriver.exe");*/

	//driver=new ChromeDriver();
	System.out.println("Launched CHrome Browser");
	driver = this.getDriver();

	
}
	
@Step
public void navigate(String url) throws Exception{

	driver.get(url);
	
	
	
}
@Step
public void RememberMe() throws InterruptedException{
	Thread.sleep(10000);
	regobjects.RememberMe().click();
}
@Step
public void userInput(String fieldName, String fieldValue) throws InterruptedException{
	System.out.println(fieldName);
	Thread.sleep(5000);
	if (fieldName.equals("UserName")){
	regobjects.UserName().sendKeys(fieldValue);
	}
	
	else if(fieldName.equals("Password"))
	{
	Thread.sleep(5000);
	regobjects.Password().sendKeys(fieldValue);
	Thread.sleep(5000);
	}
	
	

/*	else if(fieldName.equals("email"))
	{	Random randomGenerator = new Random();
		int rnd = randomGenerator.nextInt(1000);
		String email="SerenityBddEmail" + rnd + "@gmail.com";
		regobjects.eMail().sendKeys(email);
	}
*/
}
	
@Step
public void Submitlogin() throws InterruptedException{
	regobjects.Submit().click();
	regobjects.AfterLogin.getText();
	System.out.println(regobjects.AfterLogin.getText());
	if(regobjects.AfterLogin.getText().contains("Welcome,"))
	{
		System.out.println("Login successful");
	}
	else
	{
		System.out.println("Login Failed");
	}
	Thread.sleep(15000);
	
	
	
}
@Step
public void Preauth() throws InterruptedException {
	// TODO Auto-generated method stub
	Thread.sleep(5000);
	regobjects.Preauth().click();
	Thread.sleep(15000);
}
@Step
public void Detail() throws InterruptedException {
	// TODO Auto-generated method stub
	Thread.sleep(5000);
	regobjects.Detail().click();
	Thread.sleep(15000);
}
@Step
public void LastLoginDate() throws InterruptedException {
	Thread.sleep(5000);
	
	
	
	Date today = new Date();
	SimpleDateFormat formatDate= new SimpleDateFormat("dd/MM/yyyy HH:mm"); 
	String date = formatDate.format(today);
	String[] dateTime=date.split(" ");
	System.out.println(date);
	String[] actualValue= regobjects.LastLoginDate().getText().split(",");
	System.out.println(actualValue[0]+"///"+dateTime[0].concat(",")+dateTime[1]);
	org.junit.Assert.assertEquals(dateTime[0],actualValue[0]);
	
}

@Step
public void DashboardDate(){
	Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
    String Day=simpleDateFormat.format(date);
    simpleDateFormat = new SimpleDateFormat("MMMM");
    String Month=simpleDateFormat.format(date);
    simpleDateFormat = new SimpleDateFormat("YYYY");
    String year=simpleDateFormat.format(date);
    simpleDateFormat=new SimpleDateFormat("dd");
    String curdate=simpleDateFormat.format(date);
    String Dashboarddate=Day+","+" "+Month+" "+curdate+","+" "+year;
    String actualValue= regobjects.DashboardDate().getText();
    System.out.println(actualValue+"\\\\"+Dashboarddate);
    org.junit.Assert.assertEquals(actualValue,Dashboarddate);
    
    
}

}






