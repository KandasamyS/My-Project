package ui.pageobjects.registration;



import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class RegObjects extends PageObject{
	
@FindBy(xpath="//*[@id='main']/div[2]/div/div/div/div[1]/div/div/section/div/form/div[2]/div[2]/label")
public WebElementFacade RememberMe;	

@FindBy(id="username")
public WebElementFacade UserName;

@FindBy(id="password")
public WebElementFacade Password;

@FindBy(id="submit")
public WebElementFacade Submit;

@FindBy(xpath="//*[@id='main']/div[2]/div/div[1]/div/div[3]/profile-information/div/p[1]")
public WebElementFacade AfterLogin;

@FindBy(xpath="//*[@id='main']/div[2]/div/div[1]/div/div[3]/profile-information/div/p[3]/time")
public  WebElement LastLoginDate;

@FindBy(xpath="//*[@id='main']/div[2]/div/div[2]/div/div[1]/div/div[2]/section/div[1]/div/date-selector/div/div")
public WebElement DashboardDate;

@FindBy(xpath="/html/body/div[2]/div/navigation/div/ul/li[2]/a/span")
public WebElementFacade Preauth;

@FindBy(xpath="/html/body/div[2]/div/navigation/div/ul/li[8]/a")
public WebElementFacade Detail;

public  WebElement UserName(){
    return UserName;
  }

public WebElement Password(){
    return Password;
  }

public WebElement Submit(){
    return Submit;
  }
public WebElement AfterLogin(){
    return AfterLogin;
  }
public WebElement LastLoginDate() {
	return LastLoginDate;
}
public WebElement DashboardDate(){
	return DashboardDate;
}

public WebElement Preauth() {
	return Preauth;
}

public WebElement Detail() {
	
	return Detail;
	
}

public WebElement RememberMe() {
	// TODO Auto-generated method stub
	return RememberMe;
}


  }

