package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class EmailTemplatesAdminPage_object extends PageObject{

//EMS
	//#menu-links > div:nth-child(4) > a
	//a[href='./email-templates']
@FindBy(css="div[class='home-menu'] > div > div> a[href*='./email-templates']")
public WebElementFacade Email_template;

@FindBy(css="[name*=search-keyword]")
public WebElementFacade search_text_box;

@FindBy(css="[name*=search-button]")
public WebElementFacade search_button;

@FindBy(css="[id*=id] > table > tbody > tr > td.column2 > div")
public List<WebElement> selected_row_Language;

@FindBy(css="[id*=id] > table > tbody > tr > td.column1 > div")
public List<WebElement> selected_row_email_type;

@FindBy(css="[name*=templateDescr]")
public WebElementFacade Description_emeil_template;

@FindBy(css="[name*=emailSubject]")
public WebElementFacade Subject_email_template;

@FindBy(css="[name*=submitButton]")
public WebElementFacade submit_button;

@FindBy(css="#feedbackPanel > ul > li > span")
public WebElementFacade Panel_message_success_error;

@FindBy(css="[id*=id] > table > tfoot > tr > td > div")
public WebElementFacade No_data_found;

public WebElement submit_button(){
	return submit_button;
}
public WebElement No_data_found(){
	return No_data_found;
}
public WebElement Panel_message_success_error(){
	return Panel_message_success_error;
}
public WebElement search_text_box(){
	return search_text_box;
}
public WebElement search_button(){
	return search_button;
}
public WebElement Description_emeil_template(){
	return Description_emeil_template;
}
public WebElement Subject_email_template(){
	return Subject_email_template;
}
public WebElement Email_template(){
	return Email_template;
}
}
