package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class RegistrationPage_object extends PageObject{

	
@FindBy(css="#verificationCode")
public WebElementFacade verification_code;

@FindBy(css="section > div > form > div > div > div.row > div > button")
public WebElementFacade lets_go_link;

@FindBy(css="div:nth-child(2) > section > div > form > div > div > p.title.ng-scope")
public WebElementFacade Enter_passcode_text;

@FindBy(css="section > div > form > div > div > p.hint.third > a")
public WebElementFacade send_new_code_link;

@FindBy(css="section > div > form > div > div > div.button-container > button")
public WebElementFacade proceed_button;

@FindBy(css="div:nth-child(2) > section > div > form > div > div > div > p.title.ng-scope")
public WebElementFacade create_password_text;

@FindBy(css="section > div > form > div > div > div > p.username.ng-binding")
public WebElementFacade userName_textbox;

@FindBy(css="#password")
public WebElementFacade password_textbox;

@FindBy(css="#passwordConfirm")
public WebElementFacade repeatPassword_textbox;

@FindBy(css="button.btn.dropdown-toggle > span.glyphicon.glyphicon-chevron-down")
public WebElementFacade language_selection;

@FindBy(css="section > div > form > div > div > div > div:nth-child(9) > label")
public WebElementFacade accept_terms_link;

@FindBy(css="section > div > form > div > div > div > div.button-container > button")
public WebElementFacade continue_button;


public WebElement lets_go_link(){
	return lets_go_link;
}
public WebElement verification_code(){
	return verification_code;
}
}
