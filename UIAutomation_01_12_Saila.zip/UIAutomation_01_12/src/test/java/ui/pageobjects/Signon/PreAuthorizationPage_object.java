package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class PreAuthorizationPage_object extends PageObject{

//EMS	
@FindBy(css=".btn.flat-button")
//#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
public WebElementFacade date_dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(1)")
public WebElementFacade Todays_Date_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade LastsevenDays_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(3)")
public WebElementFacade this_week_filter;

@FindBy(css=".extended-interface > button:nth-child(4)")
public WebElementFacade Last_month_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade apply_button;

@FindBy(css="preauthorization-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade search_error_message;

@FindBy(css="div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.export > button > span.text.ng-scope")
public WebElementFacade Export_button;

@FindBy(css="div.modal-body.ng-scope > div.export-inside.ng-scope.selected > p > span:nth-child(3)")
public WebElementFacade XLS_file_option;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(2) > p > span:nth-child(3)")
public WebElementFacade CSV_file_option;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(3) > p > span:nth-child(3)")
public WebElementFacade XML_file_option;

@FindBy(css="div.modal-footer.ng-scope > button:nth-child(1)")
public WebElementFacade download_button;

@FindBy(css="div.extended-interface > button:nth-child(5) > span.date > input")
public WebElementFacade FromDate;

@FindBy(css="div.extended-interface > button:nth-child(6) > span.date > input")
public WebElementFacade ToDate;

@FindBy(css="#search-container > ul > li:nth-child(1) > a > span:nth-child(3)")
public WebElementFacade _search_merchantID;

@FindBy(css="preauthorization-search > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade search_button;

@FindBy(css="div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > save-search > div > button > span.text.ng-binding")
public WebElementFacade saved_search_button;

@FindBy(css="preauthorization-search > save-search > div > p")
public WebElementFacade saved_search_text;

@FindBy(css="preauthorization-search > form > div.saved-searches.ng-scope > a")
public WebElementFacade saved_search_link;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade search_text;

@FindBy(css="#saved-popup > p")
public WebElementFacade save_popup_text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > page-scroll > div > span")
public WebElementFacade Top_buttom_view_button;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > button.close > span")
public WebElementFacade close_the_cookie;

@FindBy(css="div.tg-column.ng-scope.more-icon-column.no-overflow.sticky > span")
public List<WebElement> plus_icon;

@FindBy(css="div.tg-column.ng-scope.tg-col-id-4.tg-w-7.tg-fixed-w-7 > span")
public List<WebElement> merchant_id_value;

@FindBy(css="preauthorization-details > complete-cancel-preauthorization > button")
public WebElementFacade preAuth_complete_button;

@FindBy(css="div.tg-column.ng-scope.tg-col-id-2 > span > div > span:nth-child(2)")
public List<WebElement> complete_before_date;

@FindBy(css="preauthorization-details > complete-cancel-preauthorization > div > voiding > button")
public WebElementFacade Void_button;

@FindBy(css="span[class*='date-desktop']")
public List<WebElement> preAuthorizationDate;

@FindBy(css="span > span.date-mobile")
public List<WebElement> preauthDate_mobile;

@FindBy(css="span[class*='time']")
public List<WebElement> preAuthorizationTime;

@FindBy(css=" ul > li:nth-child(3) > a > span:nth-child(3)")
public WebElementFacade search_order_id;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1 > span > span.sort-icon.ng-scope > span.down-arrow.gray")
public WebElementFacade down_arrow_transaction_date;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade Transaction_date_text;

@FindBy(css="div.modal-body.ng-scope > div > div > i")
public WebElementFacade success_tick_mark;

@FindBy(css=" div.modal-body.ng-scope > div > div > h3")
public WebElementFacade preAuth_comfirm_text;

@FindBy(css="preauthorization-edit-detail > div:nth-child(3) > p.ng-binding")
public WebElementFacade preauth_completion_currency_after__befor_confirmation;

@FindBy(css="div.modal-body.ng-scope > div > div > button")
public WebElementFacade close_button;

@FindBy(css="div.modal-body.ng-scope > div > div.bottom-navigation.ng-scope > form > button")
public WebElementFacade complete_preAuth_buton;

@FindBy(css="div.modal-body.ng-scope > div > div.bottom-navigation.ng-scope > a > span")
public WebElementFacade cancel_button;

@FindBy(css="div.modal-body.ng-scope > div > div > div.input-container > input")
public WebElementFacade one_time_passcode_textbox;

@FindBy(css="div.modal-body.ng-scope > div > div > div.input-container.invalid > div")
public WebElementFacade invalid_passcode_error_message;

@FindBy(css="div.modal-body.ng-scope > div > div > div.pass-code-info > a")
public WebElementFacade send_passcode_again_link;

@FindBy(css="div.modal-body.ng-scope > div > div > div.bottom-navigation > form > button")
public WebElementFacade confirm_button;

@FindBy(css="preauthorization-details > div > card-information > p:nth-child(2) > span")
public WebElementFacade card_number;

@FindBy(css="preauthorization-details > div > preauthorizations-history > table > tbody > tr.ng-scope > td.amount.ng-binding")
public WebElementFacade preauth_amount;

@FindBy(css="preauthorization-edit-detail > div:nth-child(1) > p.ng-binding")
public WebElementFacade completion_page_card_number;

@FindBy(css="div.modal-body.ng-scope > div > div > div.pass-code-info > p")
public WebElementFacade resend_passcode_text;

@FindBy(css="div.modal-body.ng-scope > div > div > div.pass-code-info > p > span")
public WebElementFacade mobile_number_text;

@FindBy(css="div.modal-body.ng-scope > div > div > div.pass-code-info > p")
public WebElementFacade verfication_text;


@FindBy(css=" div.modal-container > div.modal-body > ng-include > div > div.bottom-navigation > button")
public WebElementFacade void_preauth_button;

@FindBy(css="div.modal-container > div.modal-body > div > div:nth-child(5) > span")
public WebElementFacade amount_for_voiding_transaction;

@FindBy(css="div.modal-container > div.modal-body > ng-include > div.void-info-text.ng-scope")
public WebElementFacade verification_text_for_void;

@FindBy(css="ng-include > form > div.input-container > input")
public WebElementFacade one_time_passcode_void;

@FindBy(css="div.modal-body > ng-include > form > div.bottom-navigation > button")
public WebElementFacade confirm_button_for_void;

@FindBy(css="ng-include > form > div.input-container.invalid > div")
public WebElementFacade error_message_after_passcode_for_void;

@FindBy(css="div.modal-container > div.modal-header.text-center > h2 > span")
public WebElementFacade voiding_confirm_validation_text;

@FindBy(css=" div.modal-container > div.modal-body > ng-include > div > button")
public WebElementFacade close_button_for_void;

@FindBy(css="preauthorization-details > div > preauthorizations-history > table > tbody > tr:nth-child(2)")
public WebElementFacade preauth_history;

@FindBy(css="div[class='input-container'] > input#username")
public WebElementFacade impersonationUserName;

@FindBy(css="p[class='validation-error ng-binding ng-scope']")
public WebElementFacade impersonationErrorMessage;

@FindBy(css="div[class='header-conatiner horizontal-fixed ng-scope'] > div > a")
public WebElementFacade impersonatedUserNameText;
	
@FindBy(css="button[translate='IMPERSONATION.LOGIN']")
public WebElementFacade impersonationLogin;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.preauthorisations > a > span > span")
public WebElementFacade preauthorization_link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade preauth_homepage_text;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade Search_Textbox;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade Search_button;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade Preauth_NoResult;

//@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-2.tg-w-11.tg-fixed-w-11 > span > div > span:nth-child(2)")
@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-5.tg-fixed-w-5.tg-col-id-0.more-icon-column.no-overflow.sticky > span")
public List<WebElement> Preauth_SearchResult;

@FindBy(css="ng-transclude > preauthorization-details > complete-cancel-preauthorization > button")
public WebElementFacade Complete_preauthorization_button;

@FindBy(css="#search-container > ul > li:nth-child(3) > a")
public WebElementFacade Preauth_Search_autofill_OrderID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-5.tg-fixed-w-5.tg-col-id-0.more-icon-column.no-overflow.sticky > span")
public WebElementFacade Preauth_search_Expand;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-9.no-overflow.negative.scaleable.align-right.tg-w-6.tg-fixed-w-6 > span")
public WebElementFacade Preauth_Amount;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-1.tg-w-8.tg-fixed-w-8 > span > span.date-desktop")
public WebElementFacade Preauth_Date;

@FindBy(css="ng-transclude > preauthorization-details > div > card-information > p:nth-child(2) > span")
public WebElementFacade Preauth_Cardno;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > ng-include > div > div.bottom-navigation > button")
public WebElementFacade Preauth_void_authorization;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > ng-include > div > div.bottom-navigation > a > span")
public WebElementFacade Preauth_void_S1_Cancel;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-header.text-center > h2 > span")
public WebElementFacade Preauth_vc_header;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div:nth-child(1) > strong")
public WebElementFacade Preauth_vc_heading_Cardno;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div.ng-binding")
public WebElementFacade Preauth_vc_Cardno;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div:nth-child(4) > strong")
public WebElementFacade Preauth_vc_Date;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div:nth-child(5) > span")
public WebElementFacade Preauth_vc_Amount;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > ng-include > form > div.bottom-navigation > a > span")
public WebElementFacade Preauth_vc_Back;

@FindBy(css="#search-container > ul > li:nth-child(1) > a")
public WebElementFacade Preauth_Search_autofill_MerchantID;

@FindBy(css="#search-container > ul > li:nth-child(2) > a")
public WebElementFacade Preauth_Search_autofill_StoreID;

@FindBy(css="#search-container > ul > li:nth-child(4)")
public WebElementFacade Preauth_Search_autofill_Preauthcode;

@FindBy(css="#search-container > ul > li:nth-child(5)")
public WebElementFacade Preauth_Search_autofill_Reservationno;

@FindBy(css="#search-container > ul > li:nth-child(6) > a")
public WebElementFacade Preauth_Search_autofill_CardNumber;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.more-filters > a")
public WebElementFacade More_Filter;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.dropdown-container > div:nth-child(1) > div > button.btn.dropdown-toggle > span.fa.fa-caret-down.fa-lg")
public WebElementFacade ChannelType_dropdown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.dropdown-container > div:nth-child(1) > div > ul > li:nth-child(2) > p")
public WebElementFacade ChannelType_Ecommerce;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.dropdown-container > div:nth-child(1) > div > ul > li:nth-child(3) > p")
public WebElementFacade ChannelType_pos;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.dropdown-container > div:nth-child(2) > div > button.btn.dropdown-toggle > span.fa.fa-caret-down.fa-lg")
public WebElementFacade Txntype_dropdown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(2) > p")
public WebElementFacade Txntype_Purchase;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(3) > p")
public WebElementFacade Txntype_Payment;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(4) > p")
public WebElementFacade Txntype_Refund;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > amounts-search > div:nth-child(2) > fieldset > input")
public WebElementFacade AmtFrom;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > amounts-search > div:nth-child(4) > fieldset > input")
public WebElementFacade AmtTo;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > reset-filters > a")
public WebElementFacade ResetFilter_button;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-7.tg-w-16.tg-fixed-w-16 > span")
public List<WebElementFacade> SearchResult_OrderID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-4.tg-w-7.tg-fixed-w-7 > span")
public List<WebElementFacade> SearchResult_MerchantID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-5.tg-w-6.tg-fixed-w-6 > span")
public List<WebElementFacade> SearchResult_StoreID;

@FindBy(css="ng-transclude > preauthorization-details > div > div.details-info.col-width-25 > p:nth-child(4) > span")
public WebElementFacade SearchResult_Preauthcode;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-6.tg-w-8.tg-fixed-w-8")
public List<WebElementFacade> SearchResult_Reservationno;

@FindBy(css="i[class='card-3']")
public WebElementFacade SearchResult_ChannelType_Ecomm;

@FindBy(css="i[class='card-2']")
public WebElementFacade SearchResult_ChannelType_Pos;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-9.no-overflow.scaleable.align-right.tg-w-6.tg-fixed-w-6 > span")
public List<WebElementFacade> SearchResult_Amt;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > form > form-search-input > div > button.default-button.x-small.gray > i")
public WebElementFacade Search_Textbox_Close_icon;

@FindBy(css="ng-transclude > preauthorization-details")
public List<WebElement> Preauth_Details;

public  WebElement impersonationUserName(){
    return impersonationUserName;
}

public  WebElement impersonationErrorMessage(){
    return impersonationErrorMessage;
}

public  WebElement impersonatedUserNameText(){
    return impersonatedUserNameText;
}

public  WebElement impersonationLogin(){
    return impersonationLogin;
}

public  WebElement preauthorization_link(){
    return preauthorization_link;
}

public WebElement preauth_homepage_text(){
	return preauth_homepage_text;
}

public WebElement Search_Textbox(){
	return Search_Textbox;
}

public WebElement Search_button(){
	return Search_button;
}

public  WebElement Preauth_NoResult(){
    return Preauth_NoResult;
}

public  List<WebElement> Preauth_SearchResult(){
    return Preauth_SearchResult;
}

public  WebElement Complete_preauthorization_button(){
    return Complete_preauthorization_button;
}

public  WebElement Void_button(){
    return Void_button;
}

public WebElement Preauth_Search_autofill_OrderID(){
	return Preauth_Search_autofill_OrderID;
}

public WebElement Preauth_search_Expand(){
	return Preauth_search_Expand;
}

public WebElement Preauth_Amount(){
	return Preauth_Amount;
}

public WebElement Preauth_Date(){
	return Preauth_Date;
}

public WebElement Preauth_Cardno(){
	return Preauth_Cardno;
}

public WebElement Preauth_void_authorization(){
	return Preauth_void_authorization;
}

public WebElement Preauth_void_S1_Cancel(){
	return Preauth_void_S1_Cancel;
}

public WebElement Preauth_vc_header(){
	return Preauth_vc_header;
}

public WebElement Preauth_vc_heading_Cardno(){
	return Preauth_vc_heading_Cardno;
}

public WebElement Preauth_vc_Cardno(){
	return Preauth_vc_Cardno;
}

public WebElement Preauth_vc_Date(){
	return Preauth_vc_Date;
}

public WebElement Preauth_vc_Amount(){
	return Preauth_vc_Amount;
}

public WebElement Preauth_vc_Back(){
	return Preauth_vc_Back;
}


public WebElementFacade Preauth_Search_autofill_MerchantID(){
	return Preauth_Search_autofill_MerchantID;
}

public WebElementFacade Preauth_Search_autofill_StoreID(){
	return Preauth_Search_autofill_StoreID;
}

public WebElementFacade Preauth_Search_autofill_Preauthcode(){
	return Preauth_Search_autofill_Preauthcode;
}

public WebElementFacade Preauth_Search_autofill_Reservationno(){
	return Preauth_Search_autofill_Reservationno;
}

public WebElementFacade Preauth_Search_autofill_CardNumber(){
	return Preauth_Search_autofill_CardNumber;
}

public WebElementFacade More_Filter(){
	return More_Filter;
}

public WebElementFacade ChannelType_dropdown(){
	return ChannelType_dropdown;
}

public WebElementFacade ChannelType_Ecommerce(){
	return ChannelType_Ecommerce;
}

public WebElementFacade ChannelType_pos(){
	return ChannelType_pos;
}

public WebElementFacade Txntype_dropdown(){
	return Txntype_dropdown;
}

public WebElementFacade Txntype_Purchase(){
	return Txntype_Purchase;
}

public WebElementFacade Txntype_Payment(){
	return Txntype_Payment;
}

public WebElementFacade Txntype_Refund(){
	return Txntype_Refund;
}

public WebElementFacade AmtFrom(){
	return AmtFrom;
}

public WebElementFacade AmtTo(){
	return AmtTo;
}

public WebElementFacade ResetFilter_button(){
	return ResetFilter_button;
}

public List<WebElementFacade> SearchResult_OrderID(){
	return 	SearchResult_OrderID;
}

public List<WebElementFacade> SearchResult_MerchantID(){
	return SearchResult_MerchantID;
}

public List<WebElementFacade> SearchResult_StoreID(){
	return SearchResult_StoreID;
}

public WebElementFacade SearchResult_Preauthcode(){
	return SearchResult_Preauthcode;
}

public List<WebElementFacade> SearchResult_Reservationno(){
	return SearchResult_Reservationno;
}

public WebElementFacade SearchResult_ChannelType_Ecomm(){
	return SearchResult_ChannelType_Ecomm;
}

public WebElementFacade SearchResult_ChannelType_Pos(){
	return SearchResult_ChannelType_Pos;
}

public List<WebElementFacade> SearchResult_Amt(){
	return SearchResult_Amt;
}

public WebElementFacade Search_Textbox_Close_icon(){
	return Search_Textbox_Close_icon;
}

public List<WebElement> Preauth_Details(){
	return Preauth_Details;
}
public WebElement confirm_button_for_void(){
	return confirm_button_for_void;
}
public WebElement one_time_passcode_void(){
	return one_time_passcode_void;
}
public WebElement void_preauth_button(){
	return void_preauth_button;
}
public WebElement completion_page_card_number(){
	return completion_page_card_number;
}
public WebElement resend_passcode_text(){
	return resend_passcode_text;
}
public WebElement preauth_amount(){
	return preauth_amount;
}
public WebElement card_number(){
	return card_number;
}
public WebElement confirm_button(){
	return confirm_button;
}
public WebElement send_passcode_again_link(){
	return send_passcode_again_link;
}
public WebElement invalid_passcode_error_message(){
	return invalid_passcode_error_message;
}
public WebElement one_time_passcode_textbox(){
	return one_time_passcode_textbox;
}
public WebElement cancel_button(){
	return cancel_button;
}
public WebElement complete_preAuth_buton(){
	return complete_preAuth_buton;
}
public WebElement preauth_completion_currency_after__befor_confirmation(){
	return preauth_completion_currency_after__befor_confirmation;
}
public WebElement success_tick_mark(){
	return success_tick_mark;
}
public WebElement preAuth_comfirm_text(){
	return preAuth_comfirm_text;
}

public WebElement close_button(){
	return close_button;
}
public WebElement search_order_id(){
	return search_order_id;
}
public WebElement Transaction_date_text(){
	return Transaction_date_text;
}
public WebElement down_arrow_transaction_date(){
	return down_arrow_transaction_date;
}
public WebElement close_the_cookie(){
	return close_the_cookie;
}
public WebElement Top_buttom_view_button(){
	return Top_buttom_view_button;
}
public WebElement search_text(){
	return search_text;
}
public WebElement save_popup_text(){
	return save_popup_text;
}
public WebElement saved_search_link(){
	return saved_search_link;
}
public WebElement saved_search_text(){
	return saved_search_text;
}
public WebElement saved_search_button(){
	return saved_search_button;
}
public WebElement search_button(){
	return search_button;
}
public WebElement _search_merchantID(){
	return _search_merchantID;
}
public WebElement download_button(){
	return download_button;
}
public WebElement Export_button(){
	return Export_button;
}
public WebElement XLS_file_option(){
	return XLS_file_option;
}
public WebElement CSV_file_option(){
	return CSV_file_option;
}
public WebElement XML_file_option(){
	return XML_file_option;
}
public WebElement date_dropdown(){
	return date_dropdown;
}
public  WebElement Todays_Date_filter(){
    return Todays_Date_filter;
}
public  WebElement LastsevenDays_filter(){
    return LastsevenDays_filter;
}
public  WebElement this_week_filter(){
    return this_week_filter;
}
public  WebElement Last_month_filter(){
    return Last_month_filter;
}
public  WebElement apply_button(){
    return apply_button;
}
public WebElement search_error_message(){
	return search_error_message;
}
public WebElement FromDate() {
	return FromDate;
}
public WebElement ToDate() {
	return ToDate;
}
}
