package ui.Signon;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.apache.poi.poifs.crypt.dsig.ExpiredCertificateSecurityException;
import org.joda.time.DateTime;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import common.JDBCConnection;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.scheduling.ExpectedBackendCondition;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.AuthorizationPage_object;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.DocumentPage_object;
import ui.pageobjects.Signon.FundingPage_object;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.PreAuthorizationPage_object;
import ui.pageobjects.Signon.SettingsuserPage_object;
import ui.pageobjects.Signon.SignonPage_objects;
import ui.pageobjects.Signon.TransactionPage_object;
import ui.pageobjects.Signon.UserManagementPage_objects;

public class Financial_Activity extends PageObject{
	WebDriver driver =null;
	String Result=null;
	boolean Status=false;
	MessagePage_object messagepageObjects;
	AdminPage_object adminpageObjects;
	DashboardPage_objects dasboardpageobjects;
	SignonPage_objects signonObjects;
	DocumentPage_object documentpageobjects;
	PreAuthorizationPage_object preauthorizationpageobjects;
	TransactionPage_object transactionpageobjects;
	FundingPage_object fundingpageobjects;
	AuthorizationPage_object authorizationpageobjects;
	SettingsuserPage_object settingsuserpageobjects;
	UserManagementPage_objects usermanagementpageobject;
	String message_link=null;
	ArrayList<WebElement> postingDate=new ArrayList<WebElement>();
	ArrayList<WebElement> transactionID=new ArrayList<WebElement>();
	ArrayList<WebElement> postingDate_fees_and_vat=new ArrayList<WebElement>();
	ArrayList<WebElement> Payment_method_MC_visa=new ArrayList<WebElement>();
	ArrayList<WebElement> orderIDValue=new ArrayList<WebElement>();
	ArrayList<WebElement> MerchantID=new ArrayList<WebElement>();
	public ArrayList<String> fundingDetails=new ArrayList<String>();
	public ArrayList<Date> preAuthorizationDateAndTime=new ArrayList<Date>();
	public ArrayList<Date> preAuthorizationDateAndTime_Ascending=new ArrayList<Date>();
	public ArrayList<Date> TransactionDateAndTime=new ArrayList<Date>();
	public ArrayList<Date> TransactionDateAndTime_Ascending=new ArrayList<Date>();
	public ArrayList<String> EMS_fees_list=new ArrayList<String>();
	public ArrayList<String> transaction_details=new ArrayList<String>();
	public ArrayList<String> Funding_fees_list=new ArrayList<String>();
	public ArrayList<String> RefundHistoryDetails=new ArrayList<String>();
	public ArrayList<String> TempResult=new ArrayList<String>();
	
	
@Step	
public String Verify_Time_Period_filter_For_Preauthorization(){
	driver = this.getDriver();
	String Result1,Result2,Result3,Result4=null;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		System.out.println(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
		if(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible() || preauthorizationpageobjects.LastsevenDays_filter.isCurrentlyVisible() 
				|| preauthorizationpageobjects.this_week_filter.isCurrentlyVisible() || preauthorizationpageobjects.Last_month_filter.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Todays_Date_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result1="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result1="Passed " +"Transaction data is present for today ";
			}
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.LastsevenDays_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.LastsevenDays_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result2="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result2="Passed " +"Transaction data is present for Last_seven_days ";
			}
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.this_week_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.this_week_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result3="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result3="Passed " +"Transaction data is present for This week ";
			}
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Last_month_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Last_month_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result4="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result4="Passed " +"Transaction data is present for This week ";
			}
			Result=Result1 +"   "+Result2+"  "+Result3+"  "+Result4;
		}
		else
		{
			Result="Failed "+"Service is unavailable for now come back later";
		}
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		System.out.println(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
		if(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible() || preauthorizationpageobjects.LastsevenDays_filter.isCurrentlyVisible() 
				|| preauthorizationpageobjects.this_week_filter.isCurrentlyVisible() || preauthorizationpageobjects.Last_month_filter.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Todays_Date_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result1="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result1="Passed " +"Transaction data is present for today ";
			}
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.LastsevenDays_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.LastsevenDays_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result2="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result2="Passed " +"Transaction data is present for Last_seven_days ";
			}
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.this_week_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.this_week_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result3="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result3="Passed " +"Transaction data is present for This week ";
			}
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Last_month_filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Last_month_filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result4="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result4="Passed " +"Transaction data is present for This week ";
			}
			Result=Result1 +"   "+Result2+"  "+Result3+"  "+Result4;
		}
		else
		{
			Result="Failed "+"Service is unavailable for now come back later";
		}

	}
	return Result;	
}
@Step	
public String Verify_transaction_xml_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	for(int i=0;i<=150;i++)
	{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
	checkPageIsReady();

	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
	checkPageIsReady();
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		transactionpageobjects.export_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.nodata_export_error_message()));
		if(transactionpageobjects.nodata_export_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.nodata_export_error_message().getText();
		}
	}
	else
	{
		transactionpageobjects.export_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.xmlFile_option()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.xmlFile_option());
		transactionpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("A"))
	    	{
	    		Result="Passed "+fileName+" Its Related to authorization transaction";
	    	}
	    else if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("T"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Transaction detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
		return Result;	
}
@Step	
public String Verify_transaction_xls_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	waitFor(dasboardpageobjects.transaction_text());
	//waitFor(transactionpageobjects.table_lastRow());
	for(int i=0;i<=200;i++)
	{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
	waitFor(transactionpageobjects.export_button());}
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.nodata_export_error_message()));
		if(transactionpageobjects.nodata_export_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.nodata_export_error_message().getText();
		}
	}
	else
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.xlsFile_option()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.xlsFile_option());
		transactionpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xls") && filedetails[1].equals("T"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Transaction detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	return Result;
}
@Step	
public String Verify_transaction_csv_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	//waitFor(transactionpageobjects.table_lastRow());
	for(int i=0;i<=350;i++)
	{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	 wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
	checkPageIsReady();}
	//waitFor(transactionpageobjects.export_button());
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.nodata_export_error_message()));
		if(transactionpageobjects.nodata_export_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.nodata_export_error_message().getText();
		}
	}
	else
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.csvFile_option()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.csvFile_option());
		transactionpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		for(int i=0;i<=100;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
		checkPageIsReady();}
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".csv") && filedetails[1].equals("T"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Transaction detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	return Result;
}
@Step	
public String Verify_funding_csv_file_download(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=80;i++)
	{waitFor(dasboardpageobjects.funding_text());
	checkPageIsReady();
	waitFor(fundingpageobjects.searchFieldText());}
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	waitFor(fundingpageobjects.search_button());
	executor.executeScript("arguments[0].click()",fundingpageobjects.search_button());
	for(int i=0;i<=50;i++){waitFor(dasboardpageobjects.funding_text());
	checkPageIsReady();}
	if(!fundingpageobjects.no_results_found.isCurrentlyVisible())
	{
		waitFor(fundingpageobjects.funding_refrence_number());
		if(fundingpageobjects.funding_refrence_number().getText().equals(Funding_Reference_number))
			{
				waitFor(fundingpageobjects.funding_refrence_number());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.Export_button());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.csvFile_option()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.csvFile_option());
				executor.executeScript("arguments[0].click()",fundingpageobjects.Download_button());
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				for(int i=0;i<=80;i++){wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));}
				File getLatestFile = getLatestFilefromDir(downloaded_Path);
			    String fileName = getLatestFile.getName();
			    String []filedetails=fileName.split("_");
			    long length = getLatestFile.length();
			    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
			    		&& isDateValid(filedetails[2]) && fileName.endsWith(".csv") && filedetails[1].equals("F"))
			    	{
			    		Result="Passed "+fileName+" Its Related to Funding detail";
			    	}
			    else
			    	{
			    		Result="Failed "+"We didnot find the document in the folder";
			    	}
			}
		else
		{
			Result="Failed "+" We couldnot find the data for this particular refrence number ";
		}
	}
	else
	{
		Result="Failed "+fundingpageobjects.no_results_found().getText();
	}
return Result;
}
@Step	
public String Verify_Authorization_csv_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
	dasboardpageobjects.Authorizations_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
	System.out.println("dsdffdgg"+authorizationpageobjects.search_error_message().getText());
	System.out.println(authorizationpageobjects.search_error_message.isCurrentlyVisible());
	if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",authorizationpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.noRecords_after_export()));
		if(authorizationpageobjects.noRecords_after_export.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.noRecords_after_export().getText();
			authorizationpageobjects.close_button().click();
		}
	}
	else
	{
		waitFor(authorizationpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.csv_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.csv_button());
		authorizationpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".csv") && filedetails[1].equals("A"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Authorization detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	return Result;
	
}
@Step	
public String Verify_Time_picker_in_transaction_view(String From_date, String To_date) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		for(int i=0;i<=100;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();}
		//waitFor(transactionpageobjects.date_dropdown());
		
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			transactionpageobjects.apply_button().click();
			Result="Passed "+"From Date and To date is valid date";
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"From date and To date is not a valid date";
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		for(int i=0;i<=100;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();}
		//waitFor(transactionpageobjects.date_dropdown());
		
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			transactionpageobjects.apply_button().click();
			Result="Passed "+"From Date and To date is valid date";
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"From date and To date is not a valid date";
		}
	}
	return Result;
}

@Step
public String Verify_Time_Period_filter_For_Transaction() throws Throwable{
	driver = this.getDriver();
	String Result1,Result2,Result3,Result4=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		checkPageIsReady();
		waitForWithRefresh();
		checkPageIsReady();
	    System.out.println(dasboardpageobjects.transaction_text.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		System.out.println(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
		if(transactionpageobjects.Todays_Date_filter.isCurrentlyVisible() || transactionpageobjects.LastsevenDays_filter.isCurrentlyVisible() 
				|| transactionpageobjects.this_week_filter.isCurrentlyVisible() || transactionpageobjects.Last_month_filter.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Todays_Date_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Todays_Date_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result1="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result1="Passed " +"Transaction data is present for today ";
			}
			waitForWithRefresh();
			executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.LastsevenDays_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.LastsevenDays_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result2="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result2="Passed " +"Transaction data is present for Last_seven_days ";
			}
			waitForWithRefresh();
			executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.this_week_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.this_week_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result3="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result3="Passed " +"Transaction data is present for This week ";
			}
			waitForWithRefresh();
			executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Last_month_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Last_month_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result4="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result4="Passed " +"Transaction data is present for This week ";
			}
			waitForWithRefresh();
			Result=Result1 +"   "+Result2+"  "+Result3+"  "+Result4;
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"Service is unavailable for now come back later";
		}
	 }
	else
	{
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		checkPageIsReady();
		waitForWithRefresh();
		checkPageIsReady();
	    System.out.println(dasboardpageobjects.transaction_text.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		System.out.println(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
		if(transactionpageobjects.Todays_Date_filter.isCurrentlyVisible() || transactionpageobjects.LastsevenDays_filter.isCurrentlyVisible() 
				|| transactionpageobjects.this_week_filter.isCurrentlyVisible() || transactionpageobjects.Last_month_filter.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Todays_Date_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Todays_Date_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result1="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result1="Passed " +"Transaction data is present for today ";
			}
			waitForWithRefresh();
			executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.LastsevenDays_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.LastsevenDays_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result2="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result2="Passed " +"Transaction data is present for Last_seven_days ";
			}
			waitForWithRefresh();
			executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.this_week_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.this_week_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result3="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result3="Passed " +"Transaction data is present for This week ";
			}
			waitForWithRefresh();
			executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Last_month_filter()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Last_month_filter());
			executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				waitForWithRefresh();
				Result4="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				waitForWithRefresh();
				Result4="Passed " +"Transaction data is present for This week ";
			}
			waitForWithRefresh();
			Result=Result1 +"   "+Result2+"  "+Result3+"  "+Result4;
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"Service is unavailable for now come back later";
		}
	}
	return Result;	
}
@Step
public String Verify_From_date_should_be_before_to_date(String From_date, String To_date) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		//waitFor(transactionpageobjects.date_dropdown());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			checkPageIsReady();
		}
		waitForWithRefresh();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
	    Date From_date1 = sdf.parse(From_date);
	    Date To_date1 = sdf.parse(To_date);
	
	    System.out.println("date1 : " + sdf.format(From_date1));
	    System.out.println("date2 : " + sdf.format(To_date1));
	
	    if (From_date1.compareTo(To_date1) > 0) {
	        Result="Failed "+"From Date should not be after To date";
	    } else if (From_date1.compareTo(To_date1) < 0) {
	    	executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			transactionpageobjects.apply_button().click();
			//wait.until(ExpectedConditions.elementToBeSelected(transactionpageobjects.date_dropdown()));
			Result="Passed "+"From Date is before to date";
	    }
	    else if(From_date1.compareTo(To_date1) == 0) {
	        Result="Failed "+"From date is same as to date";
	    }
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		//waitFor(transactionpageobjects.date_dropdown());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			checkPageIsReady();
		}
		waitForWithRefresh();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
	    Date From_date1 = sdf.parse(From_date);
	    Date To_date1 = sdf.parse(To_date);
	
	    System.out.println("date1 : " + sdf.format(From_date1));
	    System.out.println("date2 : " + sdf.format(To_date1));
	
	    if (From_date1.compareTo(To_date1) > 0) {
	        Result="Failed "+"From Date should not be after To date";
	    } else if (From_date1.compareTo(To_date1) < 0) {
	    	executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			transactionpageobjects.apply_button().click();
			//wait.until(ExpectedConditions.elementToBeSelected(transactionpageobjects.date_dropdown()));
			Result="Passed "+"From Date is before to date";
	    }
	    else if(From_date1.compareTo(To_date1) == 0) {
	        Result="Failed "+"From date is same as to date";
	    }
	}

	return Result;
}
@Step	
public String Verify_funding_xml_file_download(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	waitFor(dasboardpageobjects.funding_text());
	//wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	waitFor(fundingpageobjects.searchFieldText());
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	waitFor(fundingpageobjects.search_button());
	fundingpageobjects.search_button().click();
	checkPageIsReady();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	if(!fundingpageobjects.no_results_found.isCurrentlyVisible())
	{
		waitFor(fundingpageobjects.funding_refrence_number());
		if(fundingpageobjects.funding_refrence_number().getText().equals(Funding_Reference_number))
		
			{
			waitFor(fundingpageobjects.funding_refrence_number());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.Export_button());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.xmlFile_option()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.xmlFile_option());
			executor.executeScript("arguments[0].click()",fundingpageobjects.Download_button());
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("F"))
		    	{
		    		Result="Passed "+fileName+" Its Related to Funding detail";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
			}
		else
		{
			Result="Failed "+"We couldnot find the data for this particular refrence number";
		}
	}
	else
	{
		Result="Failed "+fundingpageobjects.no_results_found().getText();
	}
return Result;
}
@Step
public String Verify_the_transaction_details_after_giving_dates(String From_date, String To_date) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		//waitFor(transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
		transactionpageobjects.fromdate().clear();
		transactionpageobjects.fromdate().sendKeys(From_date);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
		transactionpageobjects.todate().clear();
		transactionpageobjects.todate().sendKeys(To_date);
		transactionpageobjects.apply_button().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
		Result="Passed "+transactionpageobjects.search_error_message().getText();
	    }
	    else
	    {
	        Result="Passed "+"Transaction details are available for this particular date";
	    }
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		//waitFor(transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
		transactionpageobjects.fromdate().clear();
		transactionpageobjects.fromdate().sendKeys(From_date);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
		transactionpageobjects.todate().clear();
		transactionpageobjects.todate().sendKeys(To_date);
		transactionpageobjects.apply_button().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
		Result="Passed "+transactionpageobjects.search_error_message().getText();
	    }
	    else
	    {
	        Result="Passed "+"Transaction details are available for this particular date";
	    }
	}

	return Result;
}
@Step	
public String Verify_Authorization_xml_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
	dasboardpageobjects.Authorizations_Link().click();
	for(int i=0;i<=100;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
	checkPageIsReady();}
	System.out.println(authorizationpageobjects.search_error_message.isCurrentlyVisible());
	if(!authorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		//executor.executeScript("arguments[0].click()",authorizationpageobjects.export_button());
		//executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
		waitForWithRefresh();
		/*executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.LastsevenDays_filter()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.LastsevenDays_filter());
		executor.executeScript("arguments[0].click()",authorizationpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));*/
		for(int i=0;i<=80;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
		checkPageIsReady();
		waitFor(authorizationpageobjects.export_button());
		checkPageIsReady();}
		authorizationpageobjects.export_button().click();
		waitFor(authorizationpageobjects.export_button());
		
		if(!authorizationpageobjects.noRecords_after_export.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.xml_button()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.xml_button());
			authorizationpageobjects.download_button().click();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			for(int i=0;i<=50;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
			checkPageIsReady();}
			}
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("A"))
		    	{
		    		Result="Passed "+fileName+" Its Related to Authorization detail";
		    	}
		    else if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("T"))
		    	{
		    		Result="Passed "+fileName+" Its Related to Transaction detail";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
			
		}
		else
		{
			executor.executeScript("arguments[0].click()",authorizationpageobjects.close_button());
			Result="Failed"+"No data is available for export "+authorizationpageobjects.noRecords_after_export().getText();
		/*wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.noRecords_after_export()));
		if(authorizationpageobjects.noRecords_after_export.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.noRecords_after_export().getText();
			authorizationpageobjects.close_button().click();
		}*/
		}

	return Result;
	
}
@Step	
public String verify_the_authorization_detail(String Order_ID,String From_date, String To_date) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		dasboardpageobjects.Authorizations_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
		for(int i=0;i<=100;i++)
		{checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));}
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.from_date()));
			if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
			{
				authorizationpageobjects.from_date().clear();
				authorizationpageobjects.from_date().sendKeys(From_date);
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.to_date()));
				authorizationpageobjects.to_date().clear();
				authorizationpageobjects.to_date().sendKeys(To_date);
				authorizationpageobjects.apply_button().click();
			}
			checkPageIsReady();
			waitForWithRefresh();
			System.out.println(Order_ID);
			authorizationpageobjects.searchFieldText().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",authorizationpageobjects.search_orderId());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
			checkPageIsReady();
			waitForWithRefresh();
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
			System.out.println(authorizationpageobjects.search_success_message().getText().contains(Order_ID));
			if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+authorizationpageobjects.search_error_message().getText();
			}
			else if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() 
					&& authorizationpageobjects.search_success_message().getText().contains(Order_ID))
			{
				Result="Passed "+authorizationpageobjects.search_success_message().getText();
			}
		}
		else
		{
			checkPageIsReady();
			waitForWithRefresh();
			authorizationpageobjects.searchFieldText().sendKeys(Order_ID);
			authorizationpageobjects.search_orderId().click();
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
			checkPageIsReady();
			waitForWithRefresh();
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
			if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+authorizationpageobjects.search_error_message().getText();
			}
			else if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() 
					&& authorizationpageobjects.search_success_message().getText().contains(Order_ID))
			{
				Result="Passed "+authorizationpageobjects.search_success_message().getText();
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		dasboardpageobjects.Authorizations_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
		for(int i=0;i<=100;i++)
		{checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));}
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.from_date()));
			if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
			{
				authorizationpageobjects.from_date().clear();
				authorizationpageobjects.from_date().sendKeys(From_date);
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.to_date()));
				authorizationpageobjects.to_date().clear();
				authorizationpageobjects.to_date().sendKeys(To_date);
				authorizationpageobjects.apply_button().click();
			}
			checkPageIsReady();
			waitForWithRefresh();
			System.out.println(Order_ID);
			authorizationpageobjects.searchFieldText().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",authorizationpageobjects.search_orderId());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
			checkPageIsReady();
			waitForWithRefresh();
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
			System.out.println(authorizationpageobjects.search_success_message().getText().contains(Order_ID));
			if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+authorizationpageobjects.search_error_message().getText();
			}
			else if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() 
					&& authorizationpageobjects.search_success_message().getText().contains(Order_ID))
			{
				Result="Passed "+authorizationpageobjects.search_success_message().getText();
			}
		}
		else
		{
			checkPageIsReady();
			waitForWithRefresh();
			authorizationpageobjects.searchFieldText().sendKeys(Order_ID);
			authorizationpageobjects.search_orderId().click();
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
			checkPageIsReady();
			waitForWithRefresh();
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
			if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+authorizationpageobjects.search_error_message().getText();
			}
			else if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() 
					&& authorizationpageobjects.search_success_message().getText().contains(Order_ID))
			{
				Result="Passed "+authorizationpageobjects.search_success_message().getText();
			}
		}
	}
	return Result;
}
@Step	
public String Search_the_transaction_detail_by_giving_single_search_criteria(String Merchant_ID) throws Throwable{
	driver = this.getDriver();
	int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
		checkPageIsReady();
		waitForWithRefresh();
		transactionpageobjects.searchField_Text().sendKeys(Merchant_ID);
		transactionpageobjects.merchantID_search().click();
		transactionpageobjects.search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.postingDate_text()));
			int count=transactionpageobjects.merchantID_list.size();
	        System.out.println("Number of rows in this page is:"+count);
	
	        for(WebElement element:transactionpageobjects.merchantID_list)
	        {
	                if(element.getText().equalsIgnoreCase(Merchant_ID))
	                {
	                	count1=count1+1;
	                    System.out.println(element.getText());
	                }
	        }
	        Result="Passed "+"Total merchant ID is : ";
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
		checkPageIsReady();
		waitForWithRefresh();
		transactionpageobjects.searchField_Text().sendKeys(Merchant_ID);
		transactionpageobjects.merchantID_search().click();
		transactionpageobjects.search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.postingDate_text()));
			int count=transactionpageobjects.merchantID_list.size();
	        System.out.println("Number of rows in this page is:"+count);
	
	        for(WebElement element:transactionpageobjects.merchantID_list)
	        {
	                if(element.getText().equalsIgnoreCase(Merchant_ID))
	                {
	                	count1=count1+1;
	                    System.out.println(element.getText());
	                }
	        }
	        Result="Passed "+"Total merchant ID is : ";
		}
	}

	return Result;
}
@Step	
public String verify_the_funding_Activities_view_for_store_details(String From_date,String To_date,String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	String Result1=null,Result2=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	checkPageIsReady();
	}
	if(fundingpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.date_drop_down());
		fundingpageobjects.from_date().clear();
		fundingpageobjects.from_date().sendKeys(From_date);
		fundingpageobjects.To_date().clear();
		fundingpageobjects.To_date().sendKeys(To_date);
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Apply_button()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.Apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
		fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
		executor.executeScript("arguments[0].click()",fundingpageobjects.search_button());
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		if(fundingpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
			Result="Failed "+"No record found for this refrence number ";
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.store_link()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.store_link());
			for(int i=0;i<=100;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.posting_date_text()));
				checkPageIsReady();
			}
			if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
					&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
					&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
					&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
			{
				
				
				for(WebElement element:fundingpageobjects.postingDate)
				{
					if(!element.getText().equalsIgnoreCase("Sub totals"))
							{
								postingDate.add(element);
							}
				}
				System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
					for(WebElement transactionID1:postingDate)
					{
						
						executor.executeScript("arguments[0].click()",transactionID1);
			//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon_inside_store_details()));
			//			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon_inside_store_details());
						if(fundingpageobjects.Transaction_details_text.isCurrentlyVisible() && fundingpageobjects.payment_method_details.isCurrentlyVisible())
						{
							String DCC_indicator=fundingpageobjects.DCC_Indicator().getText();
							String transaction_id=fundingpageobjects.Transaction_id().getText();
							String cardNumber=fundingpageobjects.card_number_details().getText();
							String Card_type=fundingpageobjects.Card_type().getText();
							String emsFees=fundingpageobjects.ems_fees_value().getText();
							Result1="Passed "+"DCC_indicator : "+DCC_indicator+" transaction_id : "+transaction_id+" cardNumber : "+cardNumber+" Card_type : "+Card_type+"emsFees : "+emsFees;
						}
						else
						{
							Result1="Failed "+"No Details are available right now ";
						}
					}
					Result2=Result1;
				}
			

			else
			{
				Result="Failed "+"No Data are available right now Come back later "+fundingpageobjects.No_records_found();
			}
			if(Result2.contains("Passed"))
			{
				Result=Result2;
			}
		}
	}
	else
	{
		executor.executeScript("arguments[0].click()",fundingpageobjects.date_drop_down());
		fundingpageobjects.from_date().clear();
		fundingpageobjects.from_date().sendKeys(From_date);
		fundingpageobjects.To_date().clear();
		fundingpageobjects.To_date().sendKeys(To_date);
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Apply_button()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.Apply_button());
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	executor.executeScript("arguments[0].click()",fundingpageobjects.search_button());
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	if(fundingpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
		Result="Failed "+"No record found for this refrence number ";
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.store_link()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.store_link());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.posting_date_text()));
			checkPageIsReady();
		}
		if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
				&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
				&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
				&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
		{
			
			
			for(WebElement element:fundingpageobjects.postingDate)
			{
				if(!element.getText().equalsIgnoreCase("Sub totals"))
						{
							postingDate.add(element);
						}
			}
			System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
				for(WebElement transactionID1:postingDate)
				{
					
					executor.executeScript("arguments[0].click()",transactionID1);
		//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon_inside_store_details()));
		//			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon_inside_store_details());
					if(fundingpageobjects.Transaction_details_text.isCurrentlyVisible() && fundingpageobjects.payment_method_details.isCurrentlyVisible())
					{
						String DCC_indicator=fundingpageobjects.DCC_Indicator().getText();
						String transaction_id=fundingpageobjects.Transaction_id().getText();
						String cardNumber=fundingpageobjects.card_number_details().getText();
						String Card_type=fundingpageobjects.Card_type().getText();
						String emsFees=fundingpageobjects.ems_fees_value().getText();
						Result1="Passed "+"DCC_indicator : "+DCC_indicator+" transaction_id : "+transaction_id+" cardNumber : "+cardNumber+" Card_type : "+Card_type+"emsFees : "+emsFees;
					}
					else
					{
						Result="Failed "+"No Details are available right now ";
					}
				}
				Result2=Result1;
			}
		

		else
		{
			Result="Failed "+"No Data are available right now Come back later "+fundingpageobjects.No_records_found();
		}
		if(Result2.contains("Passed"))
		{
			Result=Result2;
		}
	}
	}
	return Result;
}
@Step	
public String verify_the_funding_Activities_view_for_feesAndVat_details(String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	String Result1=null,Result2=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	fundingpageobjects.search_button().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	if(fundingpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
		Result="Failed "+"No record found for this refrence number ";
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.fees_vat_link()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.fees_vat_link());
		for(int i=0;i<=100;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.postingDate_text_fees_vat()));
			checkPageIsReady();
		}
		if(fundingpageobjects.postingDate_text_fees_vat.isCurrentlyVisible() && fundingpageobjects.MerchantId_text_fees_vat.isCurrentlyVisible()
				&& fundingpageobjects.Type_fees_and__vat.isCurrentlyVisible() && fundingpageobjects.EMS_fees_and_vat.isCurrentlyVisible()
				&& fundingpageobjects.vat_text.isCurrentlyVisible())
		{
			for(WebElement element:fundingpageobjects.posting_date_list_fees_and_vat)
			{
				if(!element.getText().equalsIgnoreCase("Sub totals") && !element.getText().equalsIgnoreCase("Posting date"))
						{
							postingDate_fees_and_vat.add(element);
						}
			}
			System.out.println("Size of the posting Date is:"+postingDate_fees_and_vat.size());
				for(int i=0;i<postingDate_fees_and_vat.size();i++)
				{
					
					executor.executeScript("arguments[0].click()",postingDate_fees_and_vat.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Vat_value()));
						String vat=fundingpageobjects.Vat_value().getText();
						String type=fundingpageobjects.type_value_fees_and_vat().getText();
						String emsFees=fundingpageobjects.Ems_fees_value_in_vat_details.get(i).getText();
						Result1="Passed "+" Type : "+type+"emsFees : "+emsFees+"vat : "+vat;

					
				}
				Result=Result1;
			}
		

		else
		{
			Result="Failed "+"No Data are available right now Come back later ";
		}
	}
	return Result;
}
@Step	
public String Export_PreAuthorization_details(String downloaded_Path, String Alliance_code,String File_type_Format) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
	dasboardpageobjects.preauthorization_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
	checkPageIsReady();
	}
	if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Export_button()));
		
		if(File_type_Format.equals("XLS"))
		{
			preauthorizationpageobjects.Export_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.XLS_file_option()));
			preauthorizationpageobjects.XLS_file_option().click();
			preauthorizationpageobjects.download_button().click();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			for(int i=0;i<=50;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Export_button()));
			}
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xls") && filedetails[1].equals("PA"))
		    	{
		    		Result="Passed "+fileName+" Its Related to PreAuthorization detail";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
		}
		else if(File_type_Format.equals("CSV"))
		{
			preauthorizationpageobjects.Export_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.CSV_file_option()));
			preauthorizationpageobjects.CSV_file_option().click();
			preauthorizationpageobjects.download_button().click();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			for(int i=0;i<=50;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Export_button()));
			}
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".csv") && filedetails[1].equals("PA"))
		    	{
		    		Result="Passed "+fileName+" Its Related to PreAuthorization detail";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
		}
		else if(File_type_Format.equals("XML"))
		{
			preauthorizationpageobjects.Export_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.XML_file_option()));
			preauthorizationpageobjects.XML_file_option().click();
			preauthorizationpageobjects.download_button().click();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			for(int i=0;i<=50;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Export_button()));
			}
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("PA"))
		    	{
		    		Result="Passed "+fileName+" Its Related to PreAuthorization detail";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
		}
		else
		{
			Result="Failed "+File_type_Format+"FileType is not a valid format";
		}
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
		Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
	}
	return Result;
}
@Step	
public String Export_XML_PreAuthorization_details(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
	dasboardpageobjects.preauthorization_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
	checkPageIsReady();
	}
	if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Export_button()));
		preauthorizationpageobjects.Export_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.XML_file_option()));
		preauthorizationpageobjects.XML_file_option().click();
		preauthorizationpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Export_button()));
		}
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("PA"))
	    	{
	    		Result="Passed "+fileName+" Its Related to PreAuthorization detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
		Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
	}
	return Result;
}
@Step	
public String verify_the_funding_Activities_view_for_payment_method(String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	String Result1=null,Result2=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	fundingpageobjects.search_button().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	if(fundingpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
		Result="Failed "+"No record found for this refrence number ";
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Payment_method_MC_visa()));
		String Payment_card_type=fundingpageobjects.Payment_method_MC_visa().getText();
		executor.executeScript("arguments[0].click()",fundingpageobjects.Payment_method_MC_visa());
	
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.posting_date_text()));
			checkPageIsReady();
		}
		if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
				&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
				&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
				&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
		{
			
			
			for(WebElement element:fundingpageobjects.postingDate)
			{
				if(!element.getText().equalsIgnoreCase("Sub totals"))
						{
							postingDate.add(element);
						}
			}
			System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
				for(WebElement transactionID1:postingDate)
				{
					
					executor.executeScript("arguments[0].click()",transactionID1);
		//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon_inside_store_details()));
		//			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon_inside_store_details());
					if(fundingpageobjects.Transaction_details_text.isCurrentlyVisible() && fundingpageobjects.payment_method_details.isCurrentlyVisible())
					{
						String DCC_indicator=fundingpageobjects.DCC_Indicator().getText();
						String transaction_id=fundingpageobjects.Transaction_id().getText();
						String cardNumber=fundingpageobjects.card_number_details().getText();
						String Card_type=fundingpageobjects.Card_type().getText();
						String emsFees=fundingpageobjects.ems_fees_value().getText();
						Result1="Passed "+"The payment type is : "+Payment_card_type+" DCC_indicator : "+DCC_indicator+" transaction_id : "+transaction_id+" cardNumber : "+cardNumber+" Card_type : "+Card_type+"emsFees : "+emsFees;
					}
					else
					{
						Result1="Failed "+"No Details are available right now ";
					}
				}
				Result2=Result1;
			}
	

		else
		{
			Result="Failed "+"No Data are available right now Come back later "+fundingpageobjects.No_records_found();
		}
		if(Result2.contains("Passed"))
			{
				Result=Result2;
			}
		
		}
	return Result;
}
	
@Step	
public String verify_the_funding_Activities_view_for_Batch_details(String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	String Result1=null,Result2=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	fundingpageobjects.search_button().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	if(fundingpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
		Result="Failed "+"No record found for this refrence number ";
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.posting_date_text()));
			checkPageIsReady();
		}
		if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
				&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
				&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
				&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
		{
			
			
			for(WebElement element:fundingpageobjects.postingDate)
			{
				if(!element.getText().equalsIgnoreCase("Sub totals"))
						{
							postingDate.add(element);
						}
			}
			System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
				for(WebElement transactionID1:postingDate)
				{
					
					executor.executeScript("arguments[0].click()",transactionID1);
		//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon_inside_store_details()));
		//			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon_inside_store_details());
					if(fundingpageobjects.Transaction_details_text.isCurrentlyVisible() && fundingpageobjects.payment_method_details.isCurrentlyVisible())
					{
						String DCC_indicator=fundingpageobjects.DCC_Indicator().getText();
						String transaction_id=fundingpageobjects.Transaction_id().getText();
						String cardNumber=fundingpageobjects.card_number_details().getText();
						String Card_type=fundingpageobjects.Card_type().getText();
						String emsFees=fundingpageobjects.ems_fees_value().getText();
						Result1="Passed "+"DCC_indicator : "+DCC_indicator+" transaction_id : "+transaction_id+" cardNumber : "+cardNumber+" Card_type : "+Card_type+"emsFees : "+emsFees;
					}
					else
					{
						Result1="Failed "+"No Details are available right now ";
					}
				}
				Result2=Result1;
			}
		

		else
		{
			Result="Failed "+"No Data are available right now Come back later "+fundingpageobjects.No_records_found();
		}
		if(Result2.contains("Passed"))
		{
			Result=Result2;
		}
	}
	return Result;
}
@Step
public String Verify_From_date_should_be_before_to_date_in_preAuth_view(String From_date, String To_date) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		waitForWithRefresh();
		//waitFor(transactionpageobjects.date_dropdown());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			checkPageIsReady();
		}
		waitForWithRefresh();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
	    Date From_date1 = sdf.parse(From_date);
	    Date To_date1 = sdf.parse(To_date);
	
	    System.out.println("date1 : " + sdf.format(From_date1));
	    System.out.println("date2 : " + sdf.format(To_date1));
	
	    if (From_date1.compareTo(To_date1) > 0) {
	        Result="Failed "+"From Date should not be after To date";
	    } else if (From_date1.compareTo(To_date1) < 0) {
	    	executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.FromDate()));
	    	preauthorizationpageobjects.FromDate().clear();
	    	preauthorizationpageobjects.FromDate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.ToDate()));
			preauthorizationpageobjects.ToDate().clear();
			preauthorizationpageobjects.ToDate().sendKeys(To_date);
			preauthorizationpageobjects.apply_button().click();
			//wait.until(ExpectedConditions.elementToBeSelected(transactionpageobjects.date_dropdown()));
			Result="Passed "+"From Date is before to date";
	    }
	    else if(From_date1.compareTo(To_date1) == 0) {
	        Result="Failed "+"From date is same as to date";
	    }
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		waitForWithRefresh();
		//waitFor(transactionpageobjects.date_dropdown());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			checkPageIsReady();
		}
		waitForWithRefresh();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
	    Date From_date1 = sdf.parse(From_date);
	    Date To_date1 = sdf.parse(To_date);
	
	    System.out.println("date1 : " + sdf.format(From_date1));
	    System.out.println("date2 : " + sdf.format(To_date1));
	
	    if (From_date1.compareTo(To_date1) > 0) {
	        Result="Failed "+"From Date should not be after To date";
	    } else if (From_date1.compareTo(To_date1) < 0) {
	    	executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.FromDate()));
	    	preauthorizationpageobjects.FromDate().clear();
	    	preauthorizationpageobjects.FromDate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.ToDate()));
			preauthorizationpageobjects.ToDate().clear();
			preauthorizationpageobjects.ToDate().sendKeys(To_date);
			preauthorizationpageobjects.apply_button().click();
			//wait.until(ExpectedConditions.elementToBeSelected(transactionpageobjects.date_dropdown()));
			Result="Passed "+"From Date is before to date";
	    }
	    else if(From_date1.compareTo(To_date1) == 0) {
	        Result="Failed "+"From date is same as to date";
	    }
	}

	return Result;
}
@Step
public String set_and_save_search_criteria_for_each_view(String Merchant_ID) throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null,Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
		preauthorizationpageobjects.search_text().sendKeys(Merchant_ID);
		preauthorizationpageobjects._search_merchantID().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_button()));
		preauthorizationpageobjects.search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_text()));
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.saved_search_text().getText());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_link()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_link());
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible());
		if(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.save_popup_text()));
			Result1="Passed "+preauthorizationpageobjects.save_popup_text().getText();
		}
		else
		{
			Result1="Failed "+"Search Result cant be saved ";
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.Authorizations_Link());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
			checkPageIsReady();
		}
		for(int i=0;i<=100;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.searchFieldText()));
			checkPageIsReady();
		}
		
		authorizationpageobjects.searchFieldText().sendKeys(Merchant_ID);
		authorizationpageobjects._search_merchantId().click();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.save_search_text()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.save_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.save_search_link()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.save_search_link());
		checkPageIsReady();
		if(authorizationpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.save_popup_text()));
			Result2="Passed "+authorizationpageobjects.save_popup_text().getText();
		}
		else
		{
			Result2="Failed "+"Search Result cant be saved ";
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.transaction_Link());
		for(int i=0;i<=70;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
		}
		for(int i=0;i<=70;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			checkPageIsReady();
		}
		
		transactionpageobjects.searchField_Text().sendKeys(Merchant_ID);
		transactionpageobjects.merchantID_search().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.search_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_search_text()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.save_this_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_search_link()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.save_search_link());
		checkPageIsReady();
		if(transactionpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_popup_text()));
			Result3="Passed "+transactionpageobjects.save_popup_text().getText();
		}
		else
		{
			Result3="Failed "+"Search Result cant be saved ";
		}
	
		Result=Result1+System.getProperty("line.separator")+Result2+System.getProperty("line.separator")+Result3;
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
		preauthorizationpageobjects.search_text().sendKeys(Merchant_ID);
		preauthorizationpageobjects._search_merchantID().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_button()));
		preauthorizationpageobjects.search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_text()));
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.saved_search_text().getText());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_link()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_link());
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible());
		if(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.save_popup_text()));
			Result1="Passed "+preauthorizationpageobjects.save_popup_text().getText();
		}
		else
		{
			Result1="Failed "+"Search Result cant be saved ";
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.Authorizations_Link());
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
			checkPageIsReady();
		}
		for(int i=0;i<=100;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.searchFieldText()));
			checkPageIsReady();
		}
		
		authorizationpageobjects.searchFieldText().sendKeys(Merchant_ID);
		authorizationpageobjects._search_merchantId().click();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.save_search_text()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.save_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.save_search_link()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.save_search_link());
		checkPageIsReady();
		if(authorizationpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.save_popup_text()));
			Result2="Passed "+authorizationpageobjects.save_popup_text().getText();
		}
		else
		{
			Result2="Failed "+"Search Result cant be saved ";
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.transaction_Link());
		for(int i=0;i<=70;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
		}
		for(int i=0;i<=70;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			checkPageIsReady();
		}
		
		transactionpageobjects.searchField_Text().sendKeys(Merchant_ID);
		transactionpageobjects.merchantID_search().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.search_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_search_text()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.save_this_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_search_link()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.save_search_link());
		checkPageIsReady();
		if(transactionpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_popup_text()));
			Result3="Passed "+transactionpageobjects.save_popup_text().getText();
		}
		else
		{
			Result3="Failed "+"Search Result cant be saved ";
		}
	
		Result=Result1+System.getProperty("line.separator")+Result2+System.getProperty("line.separator")+Result3;
	}

return Result;
}
@Step
public String Navigate_to_top_and_buttom_view() throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		
		if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.close_the_cookie()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.close_the_cookie());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Top_buttom_view_button()));
			executor.executeScript("arguments[0].scrollIntoView(true);",preauthorizationpageobjects.Top_buttom_view_button());
			if(preauthorizationpageobjects.Top_buttom_view_button.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Top_buttom_view_button()));
				executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Top_buttom_view_button());
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
				Result="Passed "+" Now its navigated to Top";	
			}
			else
			{
				Result="Failed "+"Its not navigated to the top view";
			}
		}
		else
		{
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		
		if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.close_the_cookie()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.close_the_cookie());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Top_buttom_view_button()));
			executor.executeScript("arguments[0].scrollIntoView(true);",preauthorizationpageobjects.Top_buttom_view_button());
			if(preauthorizationpageobjects.Top_buttom_view_button.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Top_buttom_view_button()));
				executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Top_buttom_view_button());
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
				Result="Passed "+" Now its navigated to Top";	
			}
			else
			{
				Result="Failed "+"Its not navigated to the top view";
			}
		}
		else
		{
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
	}
	return Result;
	
}
@Step	
public String verify_the_funding_Activities_view_for_Webshop_details(String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	StringBuilder sb = new StringBuilder();
	String Result1=null,Result2=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	fundingpageobjects.search_button().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	if(fundingpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
		Result="Failed "+"No record found for this refrence number ";
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.WebShop_link()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.WebShop_link());
		for(int i=0;i<=100;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.posting_date_text()));
			checkPageIsReady();
		}
		if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
				&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
				&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
				&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
		{
			
			
			for(WebElement element:fundingpageobjects.postingDate)
			{
				if(!element.getText().equalsIgnoreCase("Sub totals"))
						{
							postingDate.add(element);
						}
			}
			System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
				for(WebElement transactionID1:postingDate)
				{
					
					executor.executeScript("arguments[0].click()",transactionID1);
		//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon_inside_store_details()));
		//			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon_inside_store_details());
					if(fundingpageobjects.Transaction_details_text.isCurrentlyVisible() && fundingpageobjects.payment_method_details.isCurrentlyVisible())
					{
						
						String DCC_indicator=fundingpageobjects.DCC_Indicator().getText();
						String transaction_id=fundingpageobjects.Transaction_id().getText();
						String cardNumber=fundingpageobjects.card_number_details().getText();
						String Card_type=fundingpageobjects.Card_type().getText();
						String emsFees=fundingpageobjects.ems_fees_value().getText();
						Result1="Passed "+"DCC_indicator : "+DCC_indicator+" transaction_id : "+transaction_id+" cardNumber : "+cardNumber+" Card_type : "+Card_type+"emsFees : "+emsFees+System.lineSeparator();
					
					}
					else
					{
						Result="Failed "+"No Details are available right now ";
					}
					
				}
				Result2=Result1;
				System.out.println(Result2);
			}
		

		else
		{
			Result="Failed "+"No Data are available right now Come back later "+fundingpageobjects.No_records_found();
		}
		if(Result2.contains("Passed"))
		{
			Result=Result2;
		}
	}
	return Result;
}
@Step	
public String summary_of_fees_by_card_type(String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null,Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
		dasboardpageobjects.funding_Link().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
		fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
		fundingpageobjects.search_button().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		if(fundingpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
			Result="Failed "+"No record found for this refrence number ";
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
			for(int i=0;i<=25;i++)
			{checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.maestro_card_link()));}
			if(fundingpageobjects.maestro_card_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.maestro_card_link()));
				Result1="Card_Type is : "+fundingpageobjects.maestro_card_link().getText()+
						"Summary of fees for the card_type : "+fundingpageobjects.maestro_card_fees().getText();
			}
			else
			{
				Result1="No Link is Present for payment_card_type now ";
			}
			if(fundingpageobjects.mastercard_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.mastercard_link()));
				Result2="Card_Type is : "+fundingpageobjects.mastercard_link().getText()+
						"Summary of fees for the card_type : "+fundingpageobjects.master_card_fees().getText();
			}
			else
			{
				Result2="No Link is Present for payment_card_type now ";
			}
			if(fundingpageobjects.visa_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.visa_link()));
				Result3="Card_Type is : "+fundingpageobjects.visa_link().getText()+
						"Summary of fees for the card_type : "+fundingpageobjects.visa_card_fees().getText();
			}
			else
			{
				Result3="No Link is Present for payment_card_type now ";
			}
			Result="Passed "+Result1+System.lineSeparator()+Result2+System.lineSeparator()+Result3+System.lineSeparator();
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
		dasboardpageobjects.funding_Link().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
		fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
		fundingpageobjects.search_button().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		if(fundingpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
			Result="Failed "+"No record found for this refrence number ";
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
			for(int i=0;i<=25;i++)
			{checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.maestro_card_link()));}
			if(fundingpageobjects.maestro_card_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.maestro_card_link()));
				Result1="Card_Type is : "+fundingpageobjects.maestro_card_link().getText()+
						"Summary of fees for the card_type : "+fundingpageobjects.maestro_card_fees().getText();
			}
			else
			{
				Result1="No Link is Present for payment_card_type now ";
			}
			if(fundingpageobjects.mastercard_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.mastercard_link()));
				Result2="Card_Type is : "+fundingpageobjects.mastercard_link().getText()+
						"Summary of fees for the card_type : "+fundingpageobjects.master_card_fees().getText();
			}
			else
			{
				Result2="No Link is Present for payment_card_type now ";
			}
			if(fundingpageobjects.visa_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.visa_link()));
				Result3="Card_Type is : "+fundingpageobjects.visa_link().getText()+
						"Summary of fees for the card_type : "+fundingpageobjects.visa_card_fees().getText();
			}
			else
			{
				Result3="No Link is Present for payment_card_type now ";
			}
			Result="Passed "+Result1+System.lineSeparator()+Result2+System.lineSeparator()+Result3+System.lineSeparator();
		}
	}
	
	return Result;
}
@Step	
public String verify_the_funding_summary_view_in_funding_view() throws Throwable{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 100);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
		dasboardpageobjects.funding_Link().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
		
		}
		System.out.println(fundingpageobjects.Todays_curency.isCurrentlyVisible());
		if(fundingpageobjects.Todays_curency.isCurrentlyVisible())
		{
			String Todays_currency=fundingpageobjects.Todays_curency().getText();
			for(int i=0;i<fundingpageobjects.reference_number_list.size();i++)	
			{
				String referenceNumber=fundingpageobjects.reference_number_list.get(i).getText();
				String fundingAmount=fundingpageobjects.funding_amount_list.get(i).getText();
				String fundingDate=fundingpageobjects.funding_date_list.get(i).getText();
				executor.executeScript("arguments[0].click()",fundingpageobjects.reference_number_list.get(i));
				if(fundingpageobjects.store_link.isCurrentlyVisible() && 
						fundingpageobjects.WebShop_link.isCurrentlyVisible() && fundingpageobjects.Payment_method_MC_visa.isCurrentlyVisible()
						&& fundingpageobjects.fees_vat_link.isCurrentlyVisible() && 
						fundingpageobjects.view_batch_details.isCurrentlyVisible())
			{	
				String funding=referenceNumber+" "+fundingAmount+" "+fundingDate;
				System.out.println(funding);
				fundingDetails.add(funding);
				
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
			Result="Passed "+"Funding currency for the today's date : "+Todays_currency+ fundingDetails ;
			}
		}
		else
		{
			Result="Failed ";
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
		dasboardpageobjects.funding_Link().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
		
		}
		System.out.println(fundingpageobjects.Todays_curency.isCurrentlyVisible());
		if(fundingpageobjects.Todays_curency.isCurrentlyVisible())
		{
			String Todays_currency=fundingpageobjects.Todays_curency().getText();
			for(int i=0;i<fundingpageobjects.reference_number_list.size();i++)	
			{
				String referenceNumber=fundingpageobjects.reference_number_list.get(i).getText();
				String fundingAmount=fundingpageobjects.funding_amount_list.get(i).getText();
				String fundingDate=fundingpageobjects.funding_date_list.get(i).getText();
				executor.executeScript("arguments[0].click()",fundingpageobjects.reference_number_list.get(i));
				if(fundingpageobjects.store_link.isCurrentlyVisible() && 
						fundingpageobjects.WebShop_link.isCurrentlyVisible() && fundingpageobjects.Payment_method_MC_visa.isCurrentlyVisible()
						&& fundingpageobjects.fees_vat_link.isCurrentlyVisible() && 
						fundingpageobjects.view_batch_details.isCurrentlyVisible())
			{	
				String funding=referenceNumber+" "+fundingAmount+" "+fundingDate;
				System.out.println(funding);
				fundingDetails.add(funding);
				
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
			Result="Passed "+"Funding currency for the today's date : "+Todays_currency+ fundingDetails ;
			}
		}
		else
		{
			Result="Failed ";
		}
	}
	return Result;
	
}
@Step	
public String detailed_list_of_all_fees_applied_to_account(String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	String Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	StringBuilder sb=new StringBuilder();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	fundingpageobjects.search_button().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
	if(fundingpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
		Result="Failed "+"No record found for this refrence number ";
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
		executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
		for(int i=0;i<=50;i++)
		{checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));}
		executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
		for(int i=0;i<=350;i++)
		{checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));}
		if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
				&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
				&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
				&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
		{
			
			
			for(WebElement element:fundingpageobjects.postingDate)
			{
				if(!element.getText().equalsIgnoreCase("Sub totals"))
						{
							postingDate.add(element);
						}
			}
			System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
				for(WebElement transactionID1:postingDate)
				{
					
					executor.executeScript("arguments[0].click()",transactionID1);
					if(fundingpageobjects.issuer_fees.isCurrentlyVisible() && fundingpageobjects.EMS_service_charges.isCurrentlyVisible() 
							&& fundingpageobjects.card_scheme_fees.isCurrentlyVisible() && fundingpageobjects.EMS_fixed_transaction_fees.isCurrentlyVisible())
					{
						Result3=sb.append(fundingpageobjects.issuer_fees().getText()+":"+fundingpageobjects.Issuer_fees_value().getText())
						.append(fundingpageobjects.EMS_service_charges().getText()+":"+fundingpageobjects.EMS_service_charge_value().getText())
						.append(fundingpageobjects.card_scheme_fees().getText()+":"+fundingpageobjects.card_scheme_fees().getText())
						.append(fundingpageobjects.EMS_fixed_transaction_fees().getText()+":"+fundingpageobjects.EMS_fixed_transaction_fees().getText()).append("*******")
						.toString();
					}
		
				}
				Result="Passed "+Result3;
		}
		else
		{
			Result="Failed ";
		}
	}
	return Result;
}
@Step	
public String filter_transactions_in_Funding_Summary_view(String From_date,String To_date,String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null,Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	StringBuilder sb=new StringBuilder();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	for(int i=0;i<=50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.date_drop_down()));
	checkPageIsReady();
	}
	
	fundingpageobjects.date_drop_down().click();
	if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
	{
		fundingpageobjects.from_date().clear();
		fundingpageobjects.from_date().sendKeys(From_date);
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.To_date()));
		fundingpageobjects.To_date().clear();
		fundingpageobjects.To_date().sendKeys(To_date);
		fundingpageobjects.Apply_button().click();
		
		for(int i=0;i<=80;i++)
		{
			checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
		}
		fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
		fundingpageobjects.search_button().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		if(fundingpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
			Result="Failed "+"No record found for this refrence number ";
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
			for(int i=0;i<=50;i++)
			{checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));}
			executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
			for(int i=0;i<=200;i++)
			{checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));}
			if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
					&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
					&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
					&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
			{
				if(fundingpageobjects.batch_detail_header().getText().contains(Funding_Reference_number))
				{Result="Passed "+fundingpageobjects.batch_detail_header().getText();}
				else
				{
					Result="Failed"+"Reference number is not related to what we have searched";
				}
			}
		}	
	}
	else
	{
		Result="Failed "+"From Date and To date is not a valid date";
	}
	wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	
	return Result;
}
@Step	
public String Display_Order_ID_in_Authorization_view() throws Throwable{
	driver = this.getDriver();
	ArrayList<String> Result1=new ArrayList<String>();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		dasboardpageobjects.Authorizations_Link().click();
		for(int i=0;i<=80;i++)
		{
			checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
		}
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.search_error_message().getText();
		}
		else
		{
			if(authorizationpageobjects.orderID_text.isCurrentlyVisible())
			{
				for(WebElement element:authorizationpageobjects.orderID_value)
				{
					if(!element.getText().contains("Order ID"))
							{
								orderIDValue.add(element);
							}
				}
				System.out.println(orderIDValue.size());
				for(int i=0;i<orderIDValue.size();i++)
				{
					String orderID=orderIDValue.get(i).getText();
					Result1.add(orderID);
					
				}
				Result="Passed "+Result1;
			}
			else
			{
				Result="Failed "+"No order Id column is present in the auth view";
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		dasboardpageobjects.Authorizations_Link().click();
		for(int i=0;i<=80;i++)
		{
			checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
		}
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.search_error_message().getText();
		}
		else
		{
			if(authorizationpageobjects.orderID_text.isCurrentlyVisible())
			{
				for(WebElement element:authorizationpageobjects.orderID_value)
				{
					if(!element.getText().contains("Order ID"))
							{
								orderIDValue.add(element);
							}
				}
				System.out.println(orderIDValue.size());
				for(int i=0;i<orderIDValue.size();i++)
				{
					String orderID=orderIDValue.get(i).getText();
					Result1.add(orderID);
					
				}
				Result="Passed "+Result1;
			}
			else
			{
				Result="Failed "+"No order Id column is present in the auth view";
			}
		}
	}
	return Result;
}
@Step	
public String filter_and_view_individual_stores_via_searching_on_MID_or_TID_level(String Merchant_ID, String Store_ID) throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	for(int i=0;i<=80;i++)
	{
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	}
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		Result="Failed "+transactionpageobjects.search_error_message().getText();
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
		transactionpageobjects.searchField_Text().sendKeys(Merchant_ID);
		transactionpageobjects.merchantID_search().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
		transactionpageobjects.search_button().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_this_search_button()));
		}
		if(transactionpageobjects.save_search_text.isCurrentlyVisible())
		{
			if(transactionpageobjects.save_search_text().getText().contains(Merchant_ID) &&
					!transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result1=transactionpageobjects.save_search_text().getText();
			}
			else
			{
				Result1=transactionpageobjects.search_error_message().getText();
			}
		}
		executor.executeScript("arguments[0].click()",transactionpageobjects.close_the_search());
		for(int i=0;i<=25;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));}
		transactionpageobjects.searchField_Text().sendKeys(Store_ID);
		executor.executeScript("arguments[0].click()",transactionpageobjects.store_id_search());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
		transactionpageobjects.search_button().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_this_search_button()));
		}
		if(transactionpageobjects.save_search_text.isCurrentlyVisible())
		{
			if(transactionpageobjects.save_search_text().getText().contains(Store_ID) && !transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result2=transactionpageobjects.save_search_text().getText();
			}
			else
			{
				Result2=transactionpageobjects.search_error_message().getText();
			}
		}
		Result="Passed "+Result1+"::"+Result2;
	   }
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=80;i++)
		{
			checkPageIsReady();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Merchant_ID);
			transactionpageobjects.merchantID_search().click();
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
			transactionpageobjects.search_button().click();
			for(int i=0;i<=50;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_this_search_button()));
			}
			if(transactionpageobjects.save_search_text.isCurrentlyVisible())
			{
				if(transactionpageobjects.save_search_text().getText().contains(Merchant_ID) &&
						!transactionpageobjects.search_error_message.isCurrentlyVisible())
				{
					Result1=transactionpageobjects.save_search_text().getText();
				}
				else
				{
					Result1=transactionpageobjects.search_error_message().getText();
				}
			}
			executor.executeScript("arguments[0].click()",transactionpageobjects.close_the_search());
			for(int i=0;i<=25;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));}
			transactionpageobjects.searchField_Text().sendKeys(Store_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.store_id_search());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
			transactionpageobjects.search_button().click();
			for(int i=0;i<=50;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.save_this_search_button()));
			}
			if(transactionpageobjects.save_search_text.isCurrentlyVisible())
			{
				if(transactionpageobjects.save_search_text().getText().contains(Store_ID) && !transactionpageobjects.search_error_message.isCurrentlyVisible())
				{
					Result2=transactionpageobjects.save_search_text().getText();
				}
				else
				{
					Result2=transactionpageobjects.search_error_message().getText();
				}
			}
			Result="Passed "+Result1+"::"+Result2;
		}
	}
	return Result;
}
@Step
public String search_through_preauth_data_by_entering_single_criteria_into_a_search_field (String Merchant_ID) throws Throwable{
	driver = this.getDriver(); int Count=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
		preauthorizationpageobjects.search_text().sendKeys(Merchant_ID);
		preauthorizationpageobjects._search_merchantID().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_button()));
		preauthorizationpageobjects.search_button().click();
		for(int i=0;i<=50;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_text()));
		checkPageIsReady();}
		if(preauthorizationpageobjects.saved_search_text().getText().contains(Merchant_ID) 
				&& preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else if(preauthorizationpageobjects.saved_search_text().getText().contains(Merchant_ID) 
				&& !preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			for(WebElement element:preauthorizationpageobjects.merchant_id_value)
			{
				if(!element.getText().contains("Merchant ID"))
						{
							MerchantID.add(element);
						}
			}
			System.out.println(MerchantID.size());
			for(int i=0;i<MerchantID.size();i++)
			{
				if(MerchantID.get(i).getText().contains(Merchant_ID)){
					Count=Count+1;
				}
				
			}
			Result="Passed "+"We got this many record for the search criteria : "+Count;
			
			}
	 }
	else
	{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
			dasboardpageobjects.preauthorization_Link().click();
			for(int i=0;i<=50;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
				checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Merchant_ID);
			preauthorizationpageobjects._search_merchantID().click();
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_button()));
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=50;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_text()));
			checkPageIsReady();}
			if(preauthorizationpageobjects.saved_search_text().getText().contains(Merchant_ID) 
					&& preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else if(preauthorizationpageobjects.saved_search_text().getText().contains(Merchant_ID) 
					&& !preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				for(WebElement element:preauthorizationpageobjects.merchant_id_value)
				{
					if(!element.getText().contains("Merchant ID"))
							{
								MerchantID.add(element);
							}
				}
				System.out.println(MerchantID.size());
				for(int i=0;i<MerchantID.size();i++)
				{
					if(MerchantID.get(i).getText().contains(Merchant_ID)){
						Count=Count+1;
					}
					
				}
				Result="Passed "+"We got this many record for the search criteria : "+Count;
				
		  }
	}
	return Result;
}
@Step
public String set_and_save_search_criteria_for_preAuth_view(String Merchant_ID) throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null,Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
		preauthorizationpageobjects.search_text().sendKeys(Merchant_ID);
		preauthorizationpageobjects._search_merchantID().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_button()));
		preauthorizationpageobjects.search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_text()));
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.saved_search_text().getText());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_link()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_link());
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible());
		if(preauthorizationpageobjects.saved_search_text().getText().contains(Merchant_ID) && !preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Passed "+preauthorizationpageobjects.saved_search_text().getText();
		}
		else
		{
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
		preauthorizationpageobjects.search_text().sendKeys(Merchant_ID);
		preauthorizationpageobjects._search_merchantID().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_button()));
		preauthorizationpageobjects.search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_text()));
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.saved_search_text().getText());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_link()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_link());
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible());
		if(preauthorizationpageobjects.saved_search_text().getText().contains(Merchant_ID) && !preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Passed "+preauthorizationpageobjects.saved_search_text().getText();
		}
		else
		{
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
	}
	return Result;
}
@Step
public String check_next_time_in_preAuth_view_for_same_search(String appurl,String username,String password) throws Throwable{
	driver = this.getDriver();
	driver.get(appurl);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
		signonObjects.UserName().sendKeys(username);
		signonObjects.Password().sendKeys(password);
		signonObjects.Submit().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_link()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_link());
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible());
		if(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.save_popup_text()));
			Result="Passed "+preauthorizationpageobjects.save_popup_text().getText();
		}
		else
		{
			Result="Failed "+"Search Result cant be saved ";
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
		signonObjects.UserName().sendKeys(username);
		signonObjects.Password().sendKeys(password);
		signonObjects.Submit().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=50;i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.saved_search_link()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.saved_search_link());
		checkPageIsReady();
		System.out.println(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible());
		if(preauthorizationpageobjects.save_popup_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.save_popup_text()));
			Result="Passed "+preauthorizationpageobjects.save_popup_text().getText();
		}
		else
		{
			Result="Failed "+"Search Result cant be saved ";
		}
	}
	return Result;
	
}
@Step
public String no_transactions_for_search_criteria(String From_date,String To_date) throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null,Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=100;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();}
		//waitFor(transactionpageobjects.date_dropdown());
		
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			transactionpageobjects.apply_button().click();
			for(int i=0;i<=300;i++)
			{
				checkPageIsReady();
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
				waitForWithRefresh();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
				Result="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				Result="Failed "+"Transaction data is present for this particular time period ";
			}
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"From date and To date is not a valid date";
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=100;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		waitForWithRefresh();}
		//waitFor(transactionpageobjects.date_dropdown());
		
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			transactionpageobjects.apply_button().click();
			for(int i=0;i<=300;i++)
			{
				checkPageIsReady();
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
				waitForWithRefresh();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
				Result="Passed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				Result="Failed "+"Transaction data is present for this particular time period ";
			}
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"From date and To date is not a valid date";
		}
	}
	return Result;
}
	
@Step
public String no_preAuth_data_for_search_criteria(String From_date,String To_date) throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null,Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=200;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		waitForWithRefresh();}
		//waitFor(transactionpageobjects.date_dropdown());
		
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.FromDate()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			preauthorizationpageobjects.FromDate().clear();
			preauthorizationpageobjects.FromDate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.ToDate()));
			preauthorizationpageobjects.ToDate().clear();
			preauthorizationpageobjects.ToDate().sendKeys(To_date);
			preauthorizationpageobjects.apply_button().click();
			for(int i=0;i<=150;i++)
			{
				checkPageIsReady();
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
				waitForWithRefresh();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result="Failed "+"PreAuth data is present for this particular time period ";
			}
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"From date and To date is not a valid date";
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=200;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		waitForWithRefresh();}
		//waitFor(transactionpageobjects.date_dropdown());
		
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
		checkPageIsReady();
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.FromDate()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			preauthorizationpageobjects.FromDate().clear();
			preauthorizationpageobjects.FromDate().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.ToDate()));
			preauthorizationpageobjects.ToDate().clear();
			preauthorizationpageobjects.ToDate().sendKeys(To_date);
			preauthorizationpageobjects.apply_button().click();
			for(int i=0;i<=150;i++)
			{
				checkPageIsReady();
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
				waitForWithRefresh();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Passed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				Result="Failed "+"PreAuth data is present for this particular time period ";
			}
		}
		else
		{
			waitForWithRefresh();
			Result="Failed "+"From date and To date is not a valid date";
		}
	}
	return Result;
}

@SuppressWarnings("unchecked")
@Step
public String Default_Descending_order_data_in_PreAuth_view() throws Throwable{
	driver = this.getDriver();
	String Result1=null,Result2=null,Result3=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=100;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		waitForWithRefresh();}
		//waitFor(transactionpageobjects.date_dropdown());
		
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			
			SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");
		
		    for(int i=0;i<preauthorizationpageobjects.preAuthorizationDate.size() && i<preauthorizationpageobjects.preAuthorizationTime.size();i++)
		    {
		          String dateAndTime= preauthorizationpageobjects.preAuthorizationDate.get(i).getText()+" "+preauthorizationpageobjects.preAuthorizationTime.get(i).getText();
		          System.out.println("Date And Time value is:"+dateAndTime);
		          preAuthorizationDateAndTime.add(sdf.parse(dateAndTime));
		    }
		
		    System.out.println("The Date and Time are:"+preAuthorizationDateAndTime);
		
		    ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
		    duplicateDateAndTime=(ArrayList<Date>) preAuthorizationDateAndTime.clone();
		    Collections.sort(duplicateDateAndTime);
		    Collections.reverse(duplicateDateAndTime);
		
		    System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);
		    for(int i=0;i<=550;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
		    if(preAuthorizationDateAndTime.equals(duplicateDateAndTime))
		    {
		          Result="Passed "+"Default view of the data is in descending order";
		    }
		    else
		    {
		          Result="Failed "+"Default view of the data is in ascending order";
		    }
		}
	 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
			dasboardpageobjects.preauthorization_Link().click();
			for(int i=0;i<=100;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			waitForWithRefresh();}
			//waitFor(transactionpageobjects.date_dropdown());
			
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				
				SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");
			
			    for(int i=0;i<preauthorizationpageobjects.preAuthorizationDate.size() && i<preauthorizationpageobjects.preAuthorizationTime.size();i++)
			    {
			          String dateAndTime= preauthorizationpageobjects.preAuthorizationDate.get(i).getText()+" "+preauthorizationpageobjects.preAuthorizationTime.get(i).getText();
			          System.out.println("Date And Time value is:"+dateAndTime);
			          preAuthorizationDateAndTime.add(sdf.parse(dateAndTime));
			    }
			
			    System.out.println("The Date and Time are:"+preAuthorizationDateAndTime);
			
			    ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
			    duplicateDateAndTime=(ArrayList<Date>) preAuthorizationDateAndTime.clone();
			    Collections.sort(duplicateDateAndTime);
			    Collections.reverse(duplicateDateAndTime);
			
			    System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);
			    for(int i=0;i<=550;i++)
				{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
				checkPageIsReady();
				}
			    if(preAuthorizationDateAndTime.equals(duplicateDateAndTime))
			    {
			          Result="Passed "+"Default view of the data is in descending order";
			    }
			    else
			    {
			          Result="Failed "+"Default view of the data is in ascending order";
			    }
		}
	}
	return Result;

}

@Step	
public String verify_the_transaction_details_and_Activities_in_Transaction_view() throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	String Result1=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();	
		}
		else
		{
			if(transactionpageobjects.postingDate_text.isCurrentlyVisible() && transactionpageobjects.MerchantId_text.isCurrentlyVisible() 
					)
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
					for(int i1=0;i1<transactionpageobjects.funding_fees_text.size();i1++)
					{
						String funding_fees_value=transactionpageobjects.funding_fees_text.get(i1).getText()+" : "+transactionpageobjects.funding_fees_value.get(i1).getText()+System.lineSeparator();
						Funding_fees_list.add(funding_fees_value);
					}
					for(int i1=0;i1<transactionpageobjects.ems_fees_text.size();i1++)
					{
						String EMS_fees=transactionpageobjects.ems_fees_text.get(i1).getText()+" : "+transactionpageobjects.ems_fees_Value.get(i1).getText()+System.lineSeparator();
						EMS_fees_list.add(EMS_fees);
					}
					Result1=transactionpageobjects.trans_amount_value.get(i).getText()+System.lineSeparator()+Funding_fees_list+System.lineSeparator()+EMS_fees_list;
				}
				Result="Passed "+Result1;
				
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();	
		}
		else
		{
			if(transactionpageobjects.postingDate_text.isCurrentlyVisible() && transactionpageobjects.MerchantId_text.isCurrentlyVisible()
			&& transactionpageobjects.ecom_pos_image.isCurrentlyVisible() && transactionpageobjects.storeId_text.isCurrentlyVisible()
			&& transactionpageobjects.orderID_text.isCurrentlyVisible() && transactionpageobjects.status_text.isCurrentlyVisible() 
			&& transactionpageobjects.trans_date_text.isCurrentlyVisible() && transactionpageobjects.trans_type_text.isCurrentlyVisible()
			&& transactionpageobjects.Brand_text.isCurrentlyVisible() && transactionpageobjects.Trans_Amount_text.isCurrentlyVisible())
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
					for(int i1=0;i1<transactionpageobjects.funding_fees_text.size();i1++)
					{
						String funding_fees_value=transactionpageobjects.funding_fees_text.get(i1).getText()+" : "+transactionpageobjects.funding_fees_value.get(i1).getText()+System.lineSeparator();
						Funding_fees_list.add(funding_fees_value);
					}
					for(int i1=0;i1<transactionpageobjects.ems_fees_text.size();i1++)
					{
						String EMS_fees=transactionpageobjects.ems_fees_text.get(i1).getText()+" : "+transactionpageobjects.ems_fees_Value.get(i1).getText()+System.lineSeparator();
						EMS_fees_list.add(EMS_fees);
					}
					Result1=transactionpageobjects.trans_amount_value.get(i).getText()+System.lineSeparator()+Funding_fees_list+System.lineSeparator()+EMS_fees_list;
				}
				Result="Passed "+Result1;
				
			}
		}
	}
	return Result;
}
@Step	
public String verify_the_Authorization_data_and_Activities_in_authorization_view(String From_date,String To_date) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		dasboardpageobjects.Authorizations_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
		checkPageIsReady();
		}
		executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.from_date()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			authorizationpageobjects.from_date().clear();
			authorizationpageobjects.from_date().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.to_date()));
			authorizationpageobjects.to_date().clear();
			authorizationpageobjects.to_date().sendKeys(To_date);
			authorizationpageobjects.apply_button().click();
			for(int i=0;i<=150;i++)
			{
				checkPageIsReady();
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
				waitForWithRefresh();
			}
		}
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_error_message()));
			Result="Failed "+authorizationpageobjects.search_error_message().getText();	
		}
		else
		{
			if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() && authorizationpageobjects.merchant_id_text.isCurrentlyVisible())
			{
				for(int i=0;i< authorizationpageobjects.plus_icon.size();i++)
				{	
					executor.executeScript("arguments[0].click()", authorizationpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_code.get(i)));
					System.out.println(authorizationpageobjects.auth_code.get(i).getText());
					System.out.println(authorizationpageobjects.card_number.get(i).getText());
					String details_each_transaction="Auth code : "+authorizationpageobjects.auth_code.get(i).getText()
							+"Card number : "+authorizationpageobjects.card_number.get(i).getText()+"Card type : "+authorizationpageobjects.card_type.get(i).getText();
					transaction_details.add(details_each_transaction);
				}
				Result="Passed "+transaction_details;
				
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
		dasboardpageobjects.Authorizations_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
		checkPageIsReady();
		}
		executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.from_date()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			authorizationpageobjects.from_date().clear();
			authorizationpageobjects.from_date().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.to_date()));
			authorizationpageobjects.to_date().clear();
			authorizationpageobjects.to_date().sendKeys(To_date);
			authorizationpageobjects.apply_button().click();
			for(int i=0;i<=150;i++)
			{
				checkPageIsReady();
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
				waitForWithRefresh();
			}
		}
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_error_message()));
			Result="Failed "+authorizationpageobjects.search_error_message().getText();	
		}
		else
		{
			if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() && authorizationpageobjects.ecom_pos_image.isCurrentlyVisible()
				&& authorizationpageobjects.merchant_id_text.isCurrentlyVisible() && authorizationpageobjects.store_id_text.isCurrentlyVisible()
				&& authorizationpageobjects.orderID_text.isCurrentlyVisible() && authorizationpageobjects.Brand_text.isCurrentlyVisible() 
				&& authorizationpageobjects.auth_type_text.isCurrentlyVisible() && authorizationpageobjects.status_text.isCurrentlyVisible()
				&& authorizationpageobjects.auth_code_text.isCurrentlyVisible() && authorizationpageobjects.amount_text.isCurrentlyEnabled()
				&& authorizationpageobjects.dcc_transaction.isCurrentlyVisible() && authorizationpageobjects.card_number_text.isCurrentlyVisible()
				&& authorizationpageobjects.currency_text.isCurrentlyVisible())
			{
				for(int i=0;i< authorizationpageobjects.plus_icon.size();i++)
				{	
					executor.executeScript("arguments[0].click()", authorizationpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_code.get(i)));
					System.out.println(authorizationpageobjects.auth_code.get(i).getText());
					System.out.println(authorizationpageobjects.card_number.get(i).getText());
					String details_each_transaction="Auth code : "+authorizationpageobjects.auth_code.get(i).getText()
							+"Card number : "+authorizationpageobjects.card_number.get(i).getText()+"Card type : "+authorizationpageobjects.card_type.get(i).getText();
					transaction_details.add(details_each_transaction);
				}
				Result="Passed "+transaction_details;
				
			}
		}
	}
	return Result;
}
@Step	
public String sort_preauth_data_into_ascending_and_descending_order(String From_date,String To_Date) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
	dasboardpageobjects.preauthorization_Link().click();
	for(int i=0;i<=150;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
	checkPageIsReady();
	}
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
	executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown);
	preauthorizationpageobjects.FromDate.clear();
	preauthorizationpageobjects.FromDate.sendKeys(From_date);
	preauthorizationpageobjects.ToDate.clear();
	preauthorizationpageobjects.ToDate.sendKeys(To_Date);
	executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button);
	for(int i=0;i<=150;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
	checkPageIsReady();
	}
	if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
		Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
	}
	
	else
	{
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.Transaction_date_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Transaction_date_text()));
			SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");
			
		    for(int i=0;i<preauthorizationpageobjects.preAuthorizationDate.size() && i<preauthorizationpageobjects.preAuthorizationTime.size();i++)
		    {
		          String dateAndTime= preauthorizationpageobjects.preAuthorizationDate.get(i).getText()+" "+preauthorizationpageobjects.preAuthorizationTime.get(i).getText();
		          //System.out.println("Date And Time value is:"+dateAndTime);
		          preAuthorizationDateAndTime.add(sdf.parse(dateAndTime));
		    }
		
		    System.out.println("The Date and Time are:"+preAuthorizationDateAndTime);
		    preauthorizationpageobjects.down_arrow_transaction_date().click();
		    for(int i=0;i<=150;i++)
		    { wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Transaction_date_text()));}
		    for(int i=0;i<preauthorizationpageobjects.preAuthorizationDate.size() && i<preauthorizationpageobjects.preAuthorizationTime.size();i++)
		    {
		          String dateAndTime= preauthorizationpageobjects.preAuthorizationDate.get(i).getText()+" "+preauthorizationpageobjects.preAuthorizationTime.get(i).getText();
		          //System.out.println("Date And Time value is:"+dateAndTime);
		          preAuthorizationDateAndTime_Ascending.add(sdf.parse(dateAndTime));
		    }
		    Collections.sort(preAuthorizationDateAndTime_Ascending);
		    System.out.println("The duplicate Date and Time are:"+preAuthorizationDateAndTime_Ascending);
		    for(int i=0;i<=50;i++)
		    { wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Transaction_date_text()));}
		    if(!preAuthorizationDateAndTime.equals(preAuthorizationDateAndTime_Ascending))
		    {
		          Result="Passed "+"The preauth data is in Ascending order";
		    }
		    else
		    {
		          Result="Failed "+"The preauth data is in Descending order";
		    }
		}
	
	}
	return Result;
}
@Step	
public String Default_view_is_descending_order_in_transaction_view() throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		
		else
		{
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.trans_date_text.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.trans_date_text()));
				SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");
				
			    for(int i=0;i<preauthorizationpageobjects.preAuthorizationDate.size() && i<preauthorizationpageobjects.preAuthorizationTime.size();i++)
			    {
			          String dateAndTime= transactionpageobjects.transactionDate.get(i).getText()+" "+transactionpageobjects.transactionTime.get(i).getText();
			          System.out.println("Date And Time value is:"+dateAndTime);
			          TransactionDateAndTime.add(sdf.parse(dateAndTime));
			    }
			
			     System.out.println("The Date and Time are:"+TransactionDateAndTime);
				
			     ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
			     duplicateDateAndTime=(ArrayList<Date>) TransactionDateAndTime.clone();
			     Collections.sort(duplicateDateAndTime);
			     Collections.reverse(duplicateDateAndTime);
			
			     System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);
			     for(int i=0;i<=50;i++)
				 {
				 wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
				 checkPageIsReady();
				 }
			     if(TransactionDateAndTime.equals(duplicateDateAndTime))
			     {
			          Result="Passed "+"Default view of the data is in descending order";
			     }
			     else
			     {
			          Result="Failed "+"Default view of the data is in ascending order";
			     }
				}
			    
			}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		
		else
		{
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.trans_date_text.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.trans_date_text()));
				SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");
				
			    for(int i=0;i<preauthorizationpageobjects.preAuthorizationDate.size() && i<preauthorizationpageobjects.preAuthorizationTime.size();i++)
			    {
			          String dateAndTime= transactionpageobjects.transactionDate.get(i).getText()+" "+transactionpageobjects.transactionTime.get(i).getText();
			          System.out.println("Date And Time value is:"+dateAndTime);
			          TransactionDateAndTime.add(sdf.parse(dateAndTime));
			    }
			
			     System.out.println("The Date and Time are:"+TransactionDateAndTime);
				
			     ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
			     duplicateDateAndTime=(ArrayList<Date>) TransactionDateAndTime.clone();
			     Collections.sort(duplicateDateAndTime);
			     Collections.reverse(duplicateDateAndTime);
			
			     System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);
			     for(int i=0;i<=50;i++)
				 {
				 wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
				 checkPageIsReady();
				 }
			     if(TransactionDateAndTime.equals(duplicateDateAndTime))
			     {
			          Result="Passed "+"Default view of the data is in descending order";
			     }
			     else
			     {
			          Result="Failed "+"Default view of the data is in ascending order";
			     }
				}
			    
			}
	}
	return Result;
}
@Step	
public String sort_transaction_data_into_ascending_and_descending_order() throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	for(int i=0;i<=200;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	checkPageIsReady();
	}
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
		Result="Failed "+transactionpageobjects.search_error_message().getText();
	}
	
	else
	{
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.trans_date_text.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.trans_date_text()));
			SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");
			
		    for(int i=0;i<preauthorizationpageobjects.preAuthorizationDate.size() && i<preauthorizationpageobjects.preAuthorizationTime.size();i++)
		    {
		          String dateAndTime= transactionpageobjects.transactionDate.get(i).getText()+" "+transactionpageobjects.transactionTime.get(i).getText();
		          System.out.println("Date And Time value is:"+dateAndTime);
		          TransactionDateAndTime.add(sdf.parse(dateAndTime));
		    }
		
		    System.out.println("The Date and Time are:"+TransactionDateAndTime);
		    transactionpageobjects.down_arrow_transaction_date().click();
		    for(int i=0;i<=250;i++)
		    { wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.trans_date_text()));}
		    for(int i=0;i<transactionpageobjects.transactionDate.size() && i<transactionpageobjects.transactionTime.size();i++)
		    {
		          String dateAndTime= transactionpageobjects.transactionDate.get(i).getText()+" "+transactionpageobjects.transactionTime.get(i).getText();
		          System.out.println("Date And Time value is:"+dateAndTime);
		          TransactionDateAndTime_Ascending.add(sdf.parse(dateAndTime));
		    }
		    //Collections.sort(TransactionDateAndTime_Ascending);
		    System.out.println("The duplicate Date and Time are:"+TransactionDateAndTime_Ascending);
		    for(int i=0;i<=50;i++)
		    { wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.trans_date_text()));}
		    if(!TransactionDateAndTime.equals(TransactionDateAndTime_Ascending))
		    {
		          Result="Passed "+"The Transaction data is in Ascending order";
		    }
		    else
		    {
		          Result="Failed "+"The Transaction data is in Descending order";
		    }
		}
	
	}
	return Result;
}

@Step
public String Fee_information_in_the_transaction_detail_of_each_transaction() throws Throwable{
       
	driver=this.getDriver();
   	WebDriverWait wait = new WebDriverWait(driver, 100);
   	JavascriptExecutor executor = (JavascriptExecutor)driver;
   	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
	   	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	   	dasboardpageobjects.transaction_Link().click();
	   	for(int i=0;i<=150;i++)
	   	{
	   	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	   	checkPageIsReady();
	   	}
	
	       if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
	       {
	              for(int i=0;i<50;i++)
	              {
	                     wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown));
	              }
	              System.out.println(transactionpageobjects.transactionDate.size());
	              for(int i=0;i<100;i++)
	              {
	                     wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown));
	              }
	              for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
		          {
	            	  executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
		              wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.transactionDetails_GrossCharge()));
		              System.out.println("Number of funding fees is:"+transactionpageobjects.transactionDetails_Funding.size());
		              System.out.println("Number of EMS fees is:"+transactionpageobjects.transactionDetails_EMSFees.size());
		              wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.transactionDetails_GrossCharge()));
		              for(int i1=0;i1<transactionpageobjects.transactionDetails_Funding.size() ;i1++)
		              {
		
		                    Funding_fees_list.add(transactionpageobjects.transactionDetails_Funding.get(i1).getText());
		              }
		              for(int i2=0;i2< transactionpageobjects.transactionDetails_EMSFees.size();i2++)
		              {
		            	  Funding_fees_list.add(transactionpageobjects.transactionDetails_EMSFees.get(i2).getText());
		              }
		              Funding_fees_list.add(transactionpageobjects.transactionDetails_GrossCharge.getText());
		              executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
		              wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
		              System.out.println("the funding fees are:"+Funding_fees_list);
	              }
	              Result="Passed "+Funding_fees_list;
	       }
	
	       else
	       {
	              Result="Failed "+transactionpageobjects.search_error_message().getText();
	       }
	 }
   	else
   	{
   		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
   	   	dasboardpageobjects.transaction_Link().click();
   	   	for(int i=0;i<=150;i++)
   	   	{
   	   	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
   	   	checkPageIsReady();
   	   	}

   	       if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
   	       {
   	              for(int i=0;i<50;i++)
   	              {
   	                     wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown));
   	              }
   	              System.out.println(transactionpageobjects.transactionDate.size());
   	              for(int i=0;i<100;i++)
   	              {
   	                     wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown));
   	              }
   	              for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
   		          {
   	            	  executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
   		              wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.transactionDetails_GrossCharge()));
   		              System.out.println("Number of funding fees is:"+transactionpageobjects.transactionDetails_Funding.size());
   		              System.out.println("Number of EMS fees is:"+transactionpageobjects.transactionDetails_EMSFees.size());
   		              wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.transactionDetails_GrossCharge()));
   		              for(int i1=0;i1<transactionpageobjects.transactionDetails_Funding.size() ;i1++)
   		              {
   		
   		                    Funding_fees_list.add(transactionpageobjects.transactionDetails_Funding.get(i1).getText());
   		              }
   		              for(int i2=0;i2< transactionpageobjects.transactionDetails_EMSFees.size();i2++)
   		              {
   		            	  Funding_fees_list.add(transactionpageobjects.transactionDetails_EMSFees.get(i2).getText());
   		              }
   		              Funding_fees_list.add(transactionpageobjects.transactionDetails_GrossCharge.getText());
   		              executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
   		              wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
   		              System.out.println("the funding fees are:"+Funding_fees_list);
   	              }
   	              Result="Passed "+Funding_fees_list;
   	       }

   	       else
   	       {
   	              Result="Failed "+transactionpageobjects.search_error_message().getText();
   	       }
   	}
	return Result;
}

@Step
public String View_records_of_all_the_multiple_refunds_initiated() throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
				System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
				if(transactionpageobjects.refund_details_text.isCurrentlyVisible())
				{
					for(int i1=0;i1<transactionpageobjects.refund_detail_history.size();i1++)
					{String refundhistory_details=transactionpageobjects.refund_detail_history.get(i1).getText()+" "+
					transactionpageobjects.refund_currency.get(i1).getText()+" "+transactionpageobjects.refund_Amount.get(i1).getText();
					RefundHistoryDetails.add(refundhistory_details);}
				}
				else
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				}
			}
			
			Result="Passed "+RefundHistoryDetails;
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
				System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
				if(transactionpageobjects.refund_details_text.isCurrentlyVisible())
				{
					for(int i1=0;i1<transactionpageobjects.refund_detail_history.size();i1++)
					{String refundhistory_details=transactionpageobjects.refund_detail_history.get(i1).getText()+" "+
					transactionpageobjects.refund_currency.get(i1).getText()+" "+transactionpageobjects.refund_Amount.get(i1).getText();
					RefundHistoryDetails.add(refundhistory_details);}
				}
				else
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				}
			}
			
			Result="Passed "+RefundHistoryDetails;
		}
	}
	return Result;
}

@Step
public String Validate_refunding_amount_not_greater_than_remaining_refund_amount(String Transaction_ID,String Refund_amount) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text.sendKeys(Transaction_ID);
			transactionpageobjects.transactionId_select().click();
			transactionpageobjects.search_button().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
				executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button);
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.leftTorefund_text()));
				transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
				String amount_left_for_refund=transactionpageobjects.amount_left_refund().getText();
				transactionpageobjects.refund_button_inside_().click();
				if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.error_message_after_refund()));
					Result="Passed "+transactionpageobjects.error_message_after_refund().getText()+" "+"Refund left amount is "
					+amount_left_for_refund;
				}
				else
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.confirm_with_passcode_text()));
					if(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible() && transactionpageobjects.passcode_enter_text.isCurrentlyVisible())
					{Result="Failed "+"The amount "+Refund_amount+"is lesser than "+amount_left_for_refund;}
					
					
				}
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text.sendKeys(Transaction_ID);
			transactionpageobjects.transactionId_select().click();
			transactionpageobjects.search_button().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
				executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button);
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.leftTorefund_text()));
				transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
				String amount_left_for_refund=transactionpageobjects.amount_left_refund().getText();
				transactionpageobjects.refund_button_inside_().click();
				if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.error_message_after_refund()));
					Result="Passed "+transactionpageobjects.error_message_after_refund().getText()+" "+"Refund left amount is "
					+amount_left_for_refund;
				}
				else
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.confirm_with_passcode_text()));
					if(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible() && transactionpageobjects.passcode_enter_text.isCurrentlyVisible())
					{Result="Failed "+"The amount "+Refund_amount+"is lesser than "+amount_left_for_refund;}
					
					
				}
			}
		}
	}
	return Result;
}


@Step
public String Validate_Enter_correct_amount_for_refund(String From_date,String To_date,String Transaction_ID,String Refund_amount) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Transaction_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.transactionId_select());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button);
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.leftTorefund_text()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					String amount_left_for_refund=transactionpageobjects.amount_left_refund().getText();
					transactionpageobjects.refund_button_inside_().click();
					for(int i1=0;i1<=25;i1++)
					{
						checkPageIsReady();
					}
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.error_message_after_refund()));
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText()+" "+"Refund left amount is "
						+amount_left_for_refund;
					}
					else
					{
						System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
						for(int i1=0;i1<=50;i1++)
						{checkPageIsReady();
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						System.out.println(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible());
						System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
						if(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible() && transactionpageobjects.passcode_enter_text.isCurrentlyVisible())
						{Result="Passed "+"The amount "+Refund_amount+"is lesser than "+amount_left_for_refund;}
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.confirm_with_passcode_text()));
						System.out.println(transactionpageobjects.confirm_with_passcode_text.getText());
					}
				}
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Transaction_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.transactionId_select());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button);
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.leftTorefund_text()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					String amount_left_for_refund=transactionpageobjects.amount_left_refund().getText();
					transactionpageobjects.refund_button_inside_().click();
					for(int i1=0;i1<=25;i1++)
					{
						checkPageIsReady();
					}
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.error_message_after_refund()));
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText()+" "+"Refund left amount is "
						+amount_left_for_refund;
					}
					else
					{
						System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
						for(int i1=0;i1<=50;i1++)
						{checkPageIsReady();
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						System.out.println(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible());
						System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
						if(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible() && transactionpageobjects.passcode_enter_text.isCurrentlyVisible())
						{Result="Passed "+"The amount "+Refund_amount+"is lesser than "+amount_left_for_refund;}
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.confirm_with_passcode_text()));
						System.out.println(transactionpageobjects.confirm_with_passcode_text.getText());
					}
				}
			}
		}
	 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
			dasboardpageobjects.transaction_Link().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
				executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
				transactionpageobjects.fromdate().clear();
				transactionpageobjects.fromdate().sendKeys(From_date);
				transactionpageobjects.todate().clear();
				transactionpageobjects.todate().sendKeys(To_date);
				executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
				transactionpageobjects.searchField_Text().sendKeys(Transaction_ID);
				executor.executeScript("arguments[0].click()",transactionpageobjects.transactionId_select());
				executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
				for(int i=0;i<=100;i++)
				{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
				checkPageIsReady();
				}
				if(transactionpageobjects.search_error_message.isCurrentlyVisible())
				{
					Result="Failed "+transactionpageobjects.search_error_message().getText();
				}
				else
				{
					for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
					{
						executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button);
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.leftTorefund_text()));
						transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
						String amount_left_for_refund=transactionpageobjects.amount_left_refund().getText();
						transactionpageobjects.refund_button_inside_().click();
						for(int i1=0;i1<=25;i1++)
						{
							checkPageIsReady();
						}
						if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
						{
							wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.error_message_after_refund()));
							Result="Failed "+transactionpageobjects.error_message_after_refund().getText()+" "+"Refund left amount is "
							+amount_left_for_refund;
						}
						else
						{
							System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
							for(int i1=0;i1<=50;i1++)
							{checkPageIsReady();
							wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
							System.out.println(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible());
							System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
							if(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible() && transactionpageobjects.passcode_enter_text.isCurrentlyVisible())
							{Result="Passed "+"The amount "+Refund_amount+"is lesser than "+amount_left_for_refund;}
							wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.confirm_with_passcode_text()));
							System.out.println(transactionpageobjects.confirm_with_passcode_text.getText());
						}
					}
				}
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
				executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
				transactionpageobjects.fromdate().clear();
				transactionpageobjects.fromdate().sendKeys(From_date);
				transactionpageobjects.todate().clear();
				transactionpageobjects.todate().sendKeys(To_date);
				executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
				transactionpageobjects.searchField_Text().sendKeys(Transaction_ID);
				executor.executeScript("arguments[0].click()",transactionpageobjects.transactionId_select());
				executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
				for(int i=0;i<=100;i++)
				{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
				checkPageIsReady();
				}
				if(transactionpageobjects.search_error_message.isCurrentlyVisible())
				{
					Result="Failed "+transactionpageobjects.search_error_message().getText();
				}
				else
				{
					for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
					{
						executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button);
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.leftTorefund_text()));
						transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
						String amount_left_for_refund=transactionpageobjects.amount_left_refund().getText();
						transactionpageobjects.refund_button_inside_().click();
						for(int i1=0;i1<=25;i1++)
						{
							checkPageIsReady();
						}
						if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
						{
							wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.error_message_after_refund()));
							Result="Failed "+transactionpageobjects.error_message_after_refund().getText()+" "+"Refund left amount is "
							+amount_left_for_refund;
						}
						else
						{
							System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
							for(int i1=0;i1<=50;i1++)
							{checkPageIsReady();
							wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
							System.out.println(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible());
							System.out.println(transactionpageobjects.passcode_enter_text.isCurrentlyVisible());
							if(transactionpageobjects.confirm_with_passcode_text.isCurrentlyVisible() && transactionpageobjects.passcode_enter_text.isCurrentlyVisible())
							{Result="Passed "+"The amount "+Refund_amount+"is lesser than "+amount_left_for_refund;}
							wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.confirm_with_passcode_text()));
							System.out.println(transactionpageobjects.confirm_with_passcode_text.getText());
						}
					}
				}
			}
		}
	return Result;
}
@Step
public String user_access_right_for_refund_functionality() throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				for(int i1=0;i1<=25;i1++)
				{checkPageIsReady();wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
				if(transactionpageobjects.refund_button.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
					Result="Passed "+"This user account is related to Business owner or sub businessowner account";
				}
				else
				{
					Result="Failed "+"This user account is related to Business Assistance or sub businessAssistance account";
				}
				
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				for(int i1=0;i1<=25;i1++)
				{checkPageIsReady();wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
				if(transactionpageobjects.refund_button.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
					Result="Passed "+"This user account is related to Business owner or sub businessowner account";
				}
				else
				{
					Result="Failed "+"This user account is related to Business Assistance or sub businessAssistance account";
				}
				
			}
		}
	}
	return Result;	
}

@Step
public String Pre_auth_validity_duration_from_the_date_of_the_pre_auth_transaction(String Order_ID) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauthDate_mobile.get(i)));
			    	DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			    	System.out.println(preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Declined"));
			    	System.out.println(preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Completed"));
			    	if(!preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Declined") 
			    			&& !preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Completed"))
			    	{
				    	Date transaction_date=df.parse(preauthorizationpageobjects.preauthDate_mobile.get(i).getText());
				    	Date expiry_date=df.parse(preauthorizationpageobjects.complete_before_date.get(i).getText());
				    	DateTime dt=new DateTime(transaction_date);
				    	DateTime dt_exp=new DateTime(expiry_date);
				    	System.out.println(dt.plusDays(27).equals(dt_exp));
				    	if(dt.plusDays(27).equals(dt_exp))
				    	{
				    		Result="Passed "+preauthorizationpageobjects.complete_before_date.get(i).getText()+" after 27 days of "+preauthorizationpageobjects.preauthDate_mobile.get(i).getText();
				    	}
				    	else
				    	{
				    		Result="Failed "+preauthorizationpageobjects.complete_before_date.get(i).getText()+" before 27 days of "+preauthorizationpageobjects.preauthDate_mobile.get(i).getText();
				    	}
			    	}
			    	else
			    	{
			    		Result="Failed "+"The status is : "+preauthorizationpageobjects.complete_before_date.get(i).getText();
			    	}
			    }
			}
		}
	 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
			dasboardpageobjects.preauthorization_Link().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
				preauthorizationpageobjects.search_text().sendKeys(Order_ID);
				preauthorizationpageobjects.search_order_id().click();
				preauthorizationpageobjects.search_button().click();
				for(int i=0;i<=100;i++)
				{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
				checkPageIsReady();
				}
				if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
					Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
				}
				else
				{
					
				    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
				    {
				    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
				    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preAuthorizationDate.get(i)));
				    	DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				    	System.out.println(preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Declined"));
				    	System.out.println(preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Completed"));
				    	if(!preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Declined") 
				    			&& !preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Completed"))
				    	{
					    	Date transaction_date=df.parse(preauthorizationpageobjects.preAuthorizationDate.get(i).getText());
					    	Date expiry_date=df.parse(preauthorizationpageobjects.complete_before_date.get(i).getText());
					    	DateTime dt=new DateTime(transaction_date);
					    	DateTime dt_exp=new DateTime(expiry_date);
					    	System.out.println(dt.plusDays(27).equals(dt_exp));
					    	if(dt.plusDays(27).equals(dt_exp))
					    	{
					    		Result="Passed "+preauthorizationpageobjects.complete_before_date.get(i).getText()+" after 27 days of "+preauthorizationpageobjects.preAuthorizationDate.get(i).getText();
					    	}
					    	else
					    	{
					    		Result="Failed "+preauthorizationpageobjects.complete_before_date.get(i).getText()+" before 27 days of "+preauthorizationpageobjects.preAuthorizationDate.get(i).getText();
					    	}
				    	}
				    	else
				    	{
				    		Result="Failed "+"The status is : "+preauthorizationpageobjects.complete_before_date.get(i).getText();
				    	}
				    }
				}
			}
		}
	return Result;	
}

@Step
public String Rules_for_pre_auth_completion(String Order_ID) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		Result="Passed "+"The preauth complete button is visible ";
			    	}
			    	else
			    	{
			    		Result="Failed "+"The preauth completion button is not available";
			    	}
			    }
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		Result="Passed "+"The preauth complete button is visible ";
			    	}
			    	else
			    	{
			    		Result="Failed "+"The preauth completion button is not available";
			    	}
			    }
			}
		}
	}
	return Result;
}
@Step
public String preauth_completion_to_be_in_the_same_currency_as_the_preauth(String Order_ID, String sqlQuery) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		//String name=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
			    		preauthorizationpageobjects.confirm_button().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		if(before_preauthcompletion_amount.equals(after_preauthCompletion_amount))
			    		{
			    			Result="Passed "+preauthorizationpageobjects.preAuth_comfirm_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" Preauth completion button is not present ";
			    	}
			    }
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		//String name=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
			    		preauthorizationpageobjects.confirm_button().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		if(before_preauthcompletion_amount.equals(after_preauthCompletion_amount))
			    		{
			    			Result="Passed "+preauthorizationpageobjects.preAuth_comfirm_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" Preauth completion button is not present ";
			    	}
			    }
			}
		}
	}
	return Result;
}
@Step
public String return_to_the_preauth_view_from_the_auth_completion_confirmation_screen (String Order_ID) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.card_number()));
		    		String card_number_before_completion=preauthorizationpageobjects.card_number().getText();
		    		String preauth_amount_before_completion=preauthorizationpageobjects.preauth_amount().getText();
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		if(card_number_before_completion.equals(preauthorizationpageobjects.completion_page_card_number().getText())
			    		&& preauth_amount_before_completion.equals(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText()))
			    		{
			    			Result="Passed "+"We are completing the correct preauth transaction with the amount : "+preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		}
			    		else
			    		{
			    			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.cancel_button()));
			    			preauthorizationpageobjects.cancel_button().click();
			    			Result="Passed "+"We are not completing the correct preauth transaction ";
			    		}
			    	}
			    	else
			    	{
			    		Result="Failed "+"Preauth completion button is not available to complete the pre authorization ";
			    	}
			    }
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.card_number()));
		    		String card_number_before_completion=preauthorizationpageobjects.card_number().getText();
		    		String preauth_amount_before_completion=preauthorizationpageobjects.preauth_amount().getText();
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		if(card_number_before_completion.equals(preauthorizationpageobjects.completion_page_card_number().getText())
			    		&& preauth_amount_before_completion.equals(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText()))
			    		{
			    			Result="Passed "+"We are completing the correct preauth transaction with the amount : "+preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		}
			    		else
			    		{
			    			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.cancel_button()));
			    			preauthorizationpageobjects.cancel_button().click();
			    			Result="Passed "+"We are not completing the correct preauth transaction ";
			    		}
			    	}
			    	else
			    	{
			    		Result="Failed "+"Preauth completion button is not available to complete the pre authorization ";
			    	}
			    }
			}
		}
	}
	return Result;
}
@Step
public String request_resending_of_the_passcode_in_pre_auth_completion(String Order_ID,String sqlQuery) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		preauthorizationpageobjects.send_passcode_again_link().click();
			    		if(preauthorizationpageobjects.resend_passcode_text.isCurrentlyVisible())
			    		{
			    			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.resend_passcode_text()));
			    			String passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    			//String passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
			    			Result="Passed "+preauthorizationpageobjects.resend_passcode_text.getText()+"The pass code is  : "+passcode;
			    		}
			    		
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";  	
			    		}
			    	}
			    	else
			    	{
			    		Result="Failed "+"Preauth completion button is not present ";
			    	}
			    }
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		preauthorizationpageobjects.send_passcode_again_link().click();
			    		if(preauthorizationpageobjects.resend_passcode_text.isCurrentlyVisible())
			    		{
			    			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.resend_passcode_text()));
			    			String passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    			//String passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
			    			Result="Passed "+preauthorizationpageobjects.resend_passcode_text.getText()+"The pass code is  : "+passcode;
			    		}
			    		
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";  	
			    		}
			    	}
			    	else
			    	{
			    		Result="Failed "+"Preauth completion button is not present ";
			    	}
			    }
			}
		}
	}
	return Result;
}

@Step
public String Initiating_preauth_completion_after_the_validity_has_expired(String From_date,String To_date,String Order_ID) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", preauthorizationpageobjects.date_dropdown());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.FromDate()));
			preauthorizationpageobjects.FromDate().clear();
			preauthorizationpageobjects.FromDate().sendKeys(From_date);
			preauthorizationpageobjects.ToDate().clear();
			preauthorizationpageobjects.ToDate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", preauthorizationpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			executor.executeScript("arguments[0].click()", preauthorizationpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.card_number()));
			    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
			    	if(preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Expired"))
			    	{
			    		if(!preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
				    	{
			    			Result="Passed "+"The pre auth completion validity has been "+preauthorizationpageobjects.complete_before_date.get(i).getText();
				    	}
			    		else
			    		{
			    			Result="Failed "+"The pre auth completion validity has been "+preauthorizationpageobjects.complete_before_date.get(i).getText();
			    		}
			    	}
			    	else
			    	{
			    		Result="Failed "+"The pre auth completion validity has been "+preauthorizationpageobjects.complete_before_date.get(i).getText();
			    	}
			    }
			}
		}
	 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
			dasboardpageobjects.preauthorization_Link().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
				executor.executeScript("arguments[0].click()", preauthorizationpageobjects.date_dropdown());
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.FromDate()));
				preauthorizationpageobjects.FromDate().clear();
				preauthorizationpageobjects.FromDate().sendKeys(From_date);
				preauthorizationpageobjects.ToDate().clear();
				preauthorizationpageobjects.ToDate().sendKeys(To_date);
				executor.executeScript("arguments[0].click()", preauthorizationpageobjects.apply_button());
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
				preauthorizationpageobjects.search_text().sendKeys(Order_ID);
				preauthorizationpageobjects.search_order_id().click();
				executor.executeScript("arguments[0].click()", preauthorizationpageobjects.search_button());
				for(int i=0;i<=100;i++)
				{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
				checkPageIsReady();
				}
				if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
					Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
				}
				else
				{	
				    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
				    {
				    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
				    	for(int i1=0;i1<=100;i1++)
						{
						wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
						checkPageIsReady();
						}
				    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.card_number()));
				    	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
				    	if(preauthorizationpageobjects.complete_before_date.get(i).getText().equals("Expired"))
				    	{
				    		if(!preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
					    	{
				    			Result="Passed "+"The pre auth completion validity has been "+preauthorizationpageobjects.complete_before_date.get(i).getText();
					    	}
				    		else
				    		{
				    			Result="Failed "+"The pre auth completion validity has been "+preauthorizationpageobjects.complete_before_date.get(i).getText();
				    		}
				    	}
				    	else
				    	{
				    		Result="Failed "+"The pre auth completion validity has been "+preauthorizationpageobjects.complete_before_date.get(i).getText();
				    	}
				    }
				}
			}
		}
	return Result;
}
	
@Step
public String view_the_available_preauth_completion_amount_when_an_auth_completion_is_initiated(String Order_ID,String sqlQuery) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
			    		preauthorizationpageobjects.confirm_button().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		if(before_preauthcompletion_amount.equals(after_preauthCompletion_amount))
			    		{
			    			Result="Passed "+preauthorizationpageobjects.preAuth_comfirm_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" Preauth completion button is not present ";
			    	}
			    }
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
			    		preauthorizationpageobjects.confirm_button().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		if(before_preauthcompletion_amount.equals(after_preauthCompletion_amount))
			    		{
			    			Result="Passed "+preauthorizationpageobjects.preAuth_comfirm_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" Preauth completion button is not present ";
			    	}
			    }
			}
		}
	}
	return Result;
}

@Step
public String Full_preauth_completion_on_preauthorisation(String Order_ID,String sqlQuery) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		//String name=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
			    		preauthorizationpageobjects.confirm_button().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		if(before_preauthcompletion_amount.equals(after_preauthCompletion_amount))
			    		{
			    			Result="Passed "+preauthorizationpageobjects.preAuth_comfirm_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" Preauth completion button is not present ";
			    	}
			    }
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
			    		String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		//String name=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
			    		preauthorizationpageobjects.confirm_button().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
			    		if(before_preauthcompletion_amount.equals(after_preauthCompletion_amount))
			    		{
			    			Result="Passed "+preauthorizationpageobjects.preAuth_comfirm_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The amount is not same as preauth completion amount ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" Preauth completion button is not present ";
			    	}
			    }
			}
		}
	}
	return Result;
}

@Step
public String  Identifying_refundable_transaction() throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				for(int i1=0;i1<=25;i1++)
				{checkPageIsReady();wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
				if(transactionpageobjects.refund_button.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
					Result="Passed "+"The transaction is made available for refund operation";
				}
				else
				{
					Result="Failed "+"The transaction is not having any refund operation ";
				}
				
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				for(int i1=0;i1<=25;i1++)
				{checkPageIsReady();wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
				if(transactionpageobjects.refund_button.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_button()));
					Result="Passed "+"The transaction is made available for refund operation";
				}
				else
				{
					Result="Failed "+"The transaction is not having any refund operation ";
				}
				
			}
		}
	}
	return Result;	
}

@Step
public String Remaining_refund_amount_for_every_refundable_transaction(String From_date,String To_date,String Order_ID) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			transactionpageobjects.Order_id_search().click();
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					if(transactionpageobjects.refund_details_text.isCurrentlyVisible())
					{
						
						for(int i1=0;i1<transactionpageobjects.refund_detail_history.size();i1++)
						{String refundhistory_details=transactionpageobjects.refund_detail_history.get(i1).getText()+" "+
						transactionpageobjects.refund_currency.get(i1).getText()+" "+transactionpageobjects.refund_Amount.get(i1).getText();
						RefundHistoryDetails.add(refundhistory_details);}
					}
					else
					{
						executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					}
				}
				
				Result="Passed "+RefundHistoryDetails;
			 }
			
			}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			transactionpageobjects.Order_id_search().click();
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			transactionpageobjects.Order_id_search().click();
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					if(transactionpageobjects.refund_details_text.isCurrentlyVisible())
					{
						
						for(int i1=0;i1<transactionpageobjects.refund_detail_history.size();i1++)
						{String refundhistory_details=transactionpageobjects.refund_detail_history.get(i1).getText()+" "+
						transactionpageobjects.refund_currency.get(i1).getText()+" "+transactionpageobjects.refund_Amount.get(i1).getText();
						RefundHistoryDetails.add(refundhistory_details);}
					}
					else
					{
						executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					}
				}
				
				Result="Passed "+RefundHistoryDetails;
			 }
			
			}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			transactionpageobjects.Order_id_search().click();
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
		}
	}
	return Result;
}

@Step
public String Adjusting_unsuccessful_refund_amount_back_to_remaining_refund_amount(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	for(int i=0;i<=200;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	checkPageIsReady();
	}
	if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
		transactionpageobjects.fromdate().clear();
		transactionpageobjects.fromdate().sendKeys(From_date);
		transactionpageobjects.todate().clear();
		transactionpageobjects.todate().sendKeys(To_date);
		executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
		transactionpageobjects.searchField_Text().sendKeys(Order_ID);
		transactionpageobjects.Order_id_search().click();
		executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
		for(int i=0;i<=100;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
			{
				executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
				System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
				for(int i2=0;i2<=50;i2++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					String available_amount_before=transactionpageobjects.available_refund_Amount.getText();
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						System.out.println(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())));
						if(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())).contains(Refund_amount))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							transactionpageobjects.passcode_enter_text().sendKeys(Passcode);
							executor.executeScript("arguments[0].click()",transactionpageobjects.confirm_button);
							for(int i2=0;i2<=50;i2++){wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));}
							System.out.println(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible());
							if(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible())
							{
								wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));
								executor.executeScript("arguments[0].click()",transactionpageobjects.close_button);
								wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_details_text));
								if(available_amount_before.equals(transactionpageobjects.available_refund_Amount.getText()))
								{ 
									Result="Passed "+"After unsuccessful transaction we got the available amount as : "+transactionpageobjects.available_refund_Amount.getText();
								}
								else
								{
									Result="Failed "+"After unsuccessful transaction we got the available amount as : "+transactionpageobjects.available_refund_Amount.getText();
								}
							}
						}
						else
						{
							Result="Failed "+"Refund amount is not same as the confirmation refund amount ";
						}
					}
				}
			}
		}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
		transactionpageobjects.fromdate().clear();
		transactionpageobjects.fromdate().sendKeys(From_date);
		transactionpageobjects.todate().clear();
		transactionpageobjects.todate().sendKeys(To_date);
		executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
		transactionpageobjects.searchField_Text().sendKeys(Order_ID);
		transactionpageobjects.Order_id_search().click();
		executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.search_error_message().getText();
		}
	}
	return Result;
}


@Step
public String View_successful_refunded_amount(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery) throws Throwable{
	driver = this.getDriver();
	//int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
						String available_amount_before=transactionpageobjects.available_refund_Amount.getText();
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
						transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
						if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
						{
							Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
						}
						else
						{
							
							for(int i2=0;i2<=50;i2++)
							{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
							System.out.println(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())));
							if(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())).contains(Refund_amount))
							{
								String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
					    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
								transactionpageobjects.passcode_enter_text().sendKeys(Passcode);
								executor.executeScript("arguments[0].click()",transactionpageobjects.confirm_button);
								for(int i2=0;i2<=50;i2++){wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));}
								System.out.println(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible());
								if(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible())
								{
									wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));
									executor.executeScript("arguments[0].click()",transactionpageobjects.close_button);
									wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_details_text));
									Result="Failed "+"Refund operation has failed ";
								}
								else
								{
									Result="Passed "+"Suceesfully refund operation has happened ";
								}
							}
							else
							{
								Result="Failed "+"Refund amount is not same as the confirmation refund amount ";
							}
						}
					}
				}
			}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
						String available_amount_before=transactionpageobjects.available_refund_Amount.getText();
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
						transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
						if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
						{
							Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
						}
						else
						{
							
							for(int i2=0;i2<=50;i2++)
							{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
							System.out.println(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())));
							if(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())).contains(Refund_amount))
							{
								String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
					    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
								transactionpageobjects.passcode_enter_text().sendKeys(Passcode);
								executor.executeScript("arguments[0].click()",transactionpageobjects.confirm_button);
								for(int i2=0;i2<=50;i2++){wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));}
								System.out.println(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible());
								if(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible())
								{
									wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));
									executor.executeScript("arguments[0].click()",transactionpageobjects.close_button);
									for(int i2=0;i2<=50;i2++){wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_details_text));}
									Result="Failed "+"refund operation has failed ";
								}
								else
								{
									Result="Passed "+"Suceesfully refund operation has happened ";
								}
							}
							else
							{
								Result="Failed "+"Refund amount is not same as the confirmation refund amount ";
							}
						}
					}
				}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
						String available_amount_before=transactionpageobjects.available_refund_Amount.getText();
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
						transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
						if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
						{
							Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
						}
						else
						{
							
							for(int i2=0;i2<=50;i2++)
							{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
							System.out.println(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())));
							if(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())).contains(Refund_amount))
							{
								String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
					    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
								transactionpageobjects.passcode_enter_text().sendKeys(Passcode);
								executor.executeScript("arguments[0].click()",transactionpageobjects.confirm_button);
								for(int i2=0;i2<=50;i2++){wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));}
								System.out.println(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible());
								if(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible())
								{
									wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));
									executor.executeScript("arguments[0].click()",transactionpageobjects.close_button);
									wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_details_text));
									Result="Failed "+"Refund operation has failed ";
								}
								else
								{
									Result="Passed "+"Suceesfully refund operation has happened ";
								}
							}
							else
							{
								Result="Failed "+"Refund amount is not same as the confirmation refund amount ";
							}
						}
					}
				}
			}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
						String available_amount_before=transactionpageobjects.available_refund_Amount.getText();
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
						transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
						executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
						if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
						{
							Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
						}
						else
						{
							
							for(int i2=0;i2<=50;i2++)
							{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
							System.out.println(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())));
							if(transactionpageobjects.refund_amount_for_refund.getText().substring(1,(transactionpageobjects.refund_amount_for_refund.getText().length())).contains(Refund_amount))
							{
								String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
					    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
								transactionpageobjects.passcode_enter_text().sendKeys(Passcode);
								executor.executeScript("arguments[0].click()",transactionpageobjects.confirm_button);
								for(int i2=0;i2<=50;i2++){wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));}
								System.out.println(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible());
								if(transactionpageobjects.refund_Failed_error_message.isCurrentlyVisible())
								{
									wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.close_button));
									executor.executeScript("arguments[0].click()",transactionpageobjects.close_button);
									for(int i2=0;i2<=50;i2++){wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.refund_details_text));}
									Result="Failed "+"refund operation has failed ";
								}
								else
								{
									Result="Passed "+"Suceesfully refund operation has happened ";
								}
							}
							else
							{
								Result="Failed "+"Refund amount is not same as the confirmation refund amount ";
							}
						}
					}
				}
		}
	}
	return Result;
}

@Step
public String validation_of_user_mobile_number_perfoming_preauth_completion(String Order_ID, String sqlQuery)throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.more_option()));
		dasboardpageobjects.more_option().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.settings()));
		dasboardpageobjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingsuserpageobjects.mobile_number()));
		String mobile_number=settingsuserpageobjects.mobile_number().getText();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link.click();
		for(int i=0;i<=100;i++){wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));checkPageIsReady();}
		if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.search_order_id());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.search_button());
			for(int i=0;i<=80;i++){wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));checkPageIsReady();}
			if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()",preauthorizationpageobjects.plus_icon.get(i));
					for(int i1=0;i1<=25;i1++){wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.plus_icon.get(i)));}
					
					if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
					{
						executor.executeScript("arguments[0].click()",preauthorizationpageobjects.preAuth_complete_button);
						wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
						executor.executeScript("arguments[0].click()",preauthorizationpageobjects.complete_preAuth_buton());
						for(int i1=0;i1<=50;i1++){wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.mobile_number_text));}
						String verify_mobile_no=preauthorizationpageobjects.mobile_number_text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
							//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : ");
							Result="Passed "+preauthorizationpageobjects.verfication_text.getText();
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
					else
					{
						Result="Failed "+"The preauth completion has been happened, there is no preauth complete button available here ";
					}
				}
			}
			else
			{
				Result="Failed "+preauthorizationpageobjects.search_error_message.getText();
			}
		}
		else
		{
			Result="Failed "+preauthorizationpageobjects.search_error_message.getText();
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.more_option()));
		dasboardpageobjects.more_option().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.settings()));
		dasboardpageobjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingsuserpageobjects.mobile_number()));
		String mobile_number=settingsuserpageobjects.mobile_number().getText();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link.click();
		for(int i=0;i<=100;i++){wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));checkPageIsReady();}
		if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.search_order_id());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.search_button());
			for(int i=0;i<=80;i++){wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));checkPageIsReady();}
			if(!preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()",preauthorizationpageobjects.plus_icon.get(i));
					for(int i1=0;i1<=25;i1++){wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.plus_icon.get(i)));}
					
					if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
					{
						executor.executeScript("arguments[0].click()",preauthorizationpageobjects.preAuth_complete_button);
						wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
						executor.executeScript("arguments[0].click()",preauthorizationpageobjects.complete_preAuth_buton());
						for(int i1=0;i1<=50;i1++){wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.mobile_number_text));}
						String verify_mobile_no=preauthorizationpageobjects.mobile_number_text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
							//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : ");
							Result="Passed "+preauthorizationpageobjects.verfication_text.getText();
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
					else
					{
						Result="Failed "+"The preauth completion has been happened, there is no preauth complete button available here ";
					}
				}
			}
			else
			{
				Result="Failed "+preauthorizationpageobjects.search_error_message.getText();
			}
		}
		else
		{
			Result="Failed "+preauthorizationpageobjects.search_error_message.getText();
		}
		
	}
	return Result;	
}
@Step
public String validation_of_user_mobile_number_perfoming_refund(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery )throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.more_option()));
		dasboardpageobjects.more_option().click();
		dasboardpageobjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingsuserpageobjects.mobile_number()));
		String mobile_number=settingsuserpageobjects.mobile_number().getText();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							Result="Passed "+transactionpageobjects.verification_Text.getText();
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							Result="Passed "+transactionpageobjects.verification_Text.getText();
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.more_option()));
		dasboardpageobjects.more_option().click();
		dasboardpageobjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingsuserpageobjects.mobile_number()));
		String mobile_number=settingsuserpageobjects.mobile_number().getText();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							Result="Passed "+transactionpageobjects.verification_Text.getText();
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							Result="Passed "+transactionpageobjects.verification_Text.getText();
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
	}
	return Result;
}

@Step
public String Option_to_enter_passcode_received_for_performing_refund(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery )throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.more_option()));
		dasboardpageobjects.more_option().click();
		dasboardpageobjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingsuserpageobjects.mobile_number()));
		String mobile_number=settingsuserpageobjects.mobile_number().getText();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							if(Passcode.length()==6)
							{Result="Passed "+transactionpageobjects.verification_Text.getText();}
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : ");
				    		if(Passcode.length()==6)
							{
							Result="Passed "+transactionpageobjects.verification_Text.getText();}
				    		else
				    		{
				    			Result="Failed "+"The passcode is not of 6 digit "+Passcode;
				    		}
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.more_option()));
		dasboardpageobjects.more_option().click();
		dasboardpageobjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingsuserpageobjects.mobile_number()));
		String mobile_number=settingsuserpageobjects.mobile_number().getText();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							if(Passcode.length()==6)
							{Result="Passed "+transactionpageobjects.verification_Text.getText();}
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String verify_mobile_no=transactionpageobjects.mobile_number_Text.getText().replaceAll("\\s", "");
						System.out.println(verify_mobile_no);
						if(mobile_number.equals(verify_mobile_no))
						{
							//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : ");
				    		if(Passcode.length()==6)
							{
							Result="Passed "+transactionpageobjects.verification_Text.getText();}
				    		else
				    		{
				    			Result="Failed "+"The passcode is not of 6 digit "+Passcode;
				    		}
						}
						else
						{
							Result="Failed "+"The mobile number of the user are not same.This is not the registered number ";
						}
					}
				}
			}
		}
	}
	return Result;
}
@Step
public String Request_resending_of_passcode_for_performing_refund(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery )throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String mobile_number=transactionpageobjects.verification_Text.getText();
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.send_passcode_again_link));
						executor.executeScript("arguments[0].click()", transactionpageobjects.send_passcode_again_link);
						if(!transactionpageobjects.resend_verification_text.getText().contains(mobile_number))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							if(Passcode.length()==6)
							{Result="Passed "+transactionpageobjects.resend_verification_text.getText();}
							else
				    		{
				    			Result="Failed "+"The passcode is not of 6 digit "+Passcode;
				    		}
						}
						
						else
						{
							Result="Failed "+transactionpageobjects.resend_verification_text.getText();
						}
					}
				}
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String mobile_number=transactionpageobjects.verification_Text.getText();
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.send_passcode_again_link));
						executor.executeScript("arguments[0].click()", transactionpageobjects.send_passcode_again_link);
						if(!transactionpageobjects.resend_verification_text.getText().contains(mobile_number))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							if(Passcode.length()==6)
							{Result="Passed "+transactionpageobjects.resend_verification_text.getText();}
							else
				    		{
				    			Result="Failed "+"The passcode is not of 6 digit "+Passcode;
				    		}
						}
						
						else
						{
							Result="Failed "+transactionpageobjects.resend_verification_text.getText();
						}
					}
				}
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
		dasboardpageobjects.transaction_Link().click();
		for(int i=0;i<=200;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
		checkPageIsReady();
		}
		if(!transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String mobile_number=transactionpageobjects.verification_Text.getText();
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.send_passcode_again_link));
						executor.executeScript("arguments[0].click()", transactionpageobjects.send_passcode_again_link);
						if(!transactionpageobjects.resend_verification_text.getText().contains(mobile_number))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							if(Passcode.length()==6)
							{Result="Passed "+transactionpageobjects.resend_verification_text.getText();}
							else
				    		{
				    			Result="Failed "+"The passcode is not of 6 digit "+Passcode;
				    		}
						}
						
						else
						{
							Result="Failed "+transactionpageobjects.resend_verification_text.getText();
						}
					}
				}
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
			executor.executeScript("arguments[0].click()", transactionpageobjects.date_dropdown());
			transactionpageobjects.fromdate().clear();
			transactionpageobjects.fromdate().sendKeys(From_date);
			transactionpageobjects.todate().clear();
			transactionpageobjects.todate().sendKeys(To_date);
			executor.executeScript("arguments[0].click()", transactionpageobjects.apply_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
			transactionpageobjects.searchField_Text().sendKeys(Order_ID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Order_id_search()));
			executor.executeScript("arguments[0].click()",transactionpageobjects.Order_id_search());
			executor.executeScript("arguments[0].click()", transactionpageobjects.search_button());
			for(int i2=0;i2<=80;i2++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				Result="Failed "+transactionpageobjects.search_error_message().getText();
			}
			else
			{
				for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
				{
					executor.executeScript("arguments[0].click()", transactionpageobjects.plus_icon.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));
					System.out.println(transactionpageobjects.refund_details_text.isCurrentlyVisible());
					for(int i2=0;i2<=50;i2++)
					{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.plus_icon.get(i)));checkPageIsReady();}
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.current_Refund_amount()));
					transactionpageobjects.current_Refund_amount().sendKeys(Refund_amount);
					executor.executeScript("arguments[0].click()", transactionpageobjects.refund_button_inside_());
					if(transactionpageobjects.error_message_after_refund.isCurrentlyVisible())
					{
						Result="Failed "+transactionpageobjects.error_message_after_refund().getText();
					}
					else
					{
						
						for(int i2=0;i2<=50;i2++)
						{wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.passcode_enter_text()));}
						String mobile_number=transactionpageobjects.verification_Text.getText();
						wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.send_passcode_again_link));
						executor.executeScript("arguments[0].click()", transactionpageobjects.send_passcode_again_link);
						if(!transactionpageobjects.resend_verification_text.getText().contains(mobile_number))
						{
							String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
				    		//String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
							if(Passcode.length()==6)
							{Result="Passed "+transactionpageobjects.resend_verification_text.getText();}
							else
				    		{
				    			Result="Failed "+"The passcode is not of 6 digit "+Passcode;
				    		}
						}
						
						else
						{
							Result="Failed "+transactionpageobjects.resend_verification_text.getText();
						}
					}
				}
			}
		}
	}
	return Result;
}

@Step
public String Void_preauthorisation_Transactions(String Order_ID, String sqlQuery) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.Void_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.Void_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.amount_for_voiding_transaction));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.amount_for_voiding_transaction.getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.void_preauth_button()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.void_preauth_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.amount_for_voiding_transaction));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_void()));
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_void().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button_for_void()));
			    		preauthorizationpageobjects.confirm_button_for_void().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.error_message_after_passcode_for_void.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.error_message_after_passcode_for_void.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.amount_for_voiding_transaction));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.amount_for_voiding_transaction.getText();
			    		if(preauthorizationpageobjects.voiding_confirm_validation_text.isCurrentlyVisible())
			    		{
			    			Result="Passed "+preauthorizationpageobjects.voiding_confirm_validation_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The void transaction operation got failed ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" void button is not present ";
			    	}
			    }
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    	if(preauthorizationpageobjects.Void_button.isCurrentlyVisible())
			    	{
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.Void_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.amount_for_voiding_transaction));
			    		String before_preauthcompletion_amount=preauthorizationpageobjects.amount_for_voiding_transaction.getText();
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.void_preauth_button()));
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.void_preauth_button);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.amount_for_voiding_transaction));
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_void()));
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
			    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
			    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
			    		preauthorizationpageobjects.one_time_passcode_void().sendKeys(Passcode);
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button_for_void()));
			    		preauthorizationpageobjects.confirm_button_for_void().click();
			    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
			    		if(preauthorizationpageobjects.error_message_after_passcode_for_void.isCurrentlyVisible())
			    		{
			    			Result="Failed "+preauthorizationpageobjects.error_message_after_passcode_for_void.getText();
			    		}
			    		else{
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.amount_for_voiding_transaction));
			    		String after_preauthCompletion_amount=preauthorizationpageobjects.amount_for_voiding_transaction.getText();
			    		if(preauthorizationpageobjects.voiding_confirm_validation_text.isCurrentlyVisible())
			    		{
			    			Result="Passed "+preauthorizationpageobjects.voiding_confirm_validation_text.getText();
			    		}
			    		else
			    		{
			    			Result="Failed "+" The void transaction operation got failed ";
			    		}}
			    	}
			    	else
			    	{
			    		Result="Failed "+" void button is not present ";
			    	}
			    }
			}
		}
	}
	return Result;
}


@Step
public String View_status_of_the_preauth_completion_transaction_in_the_preauth(String Order_ID, String sqlQuery) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	//clickJS(preauthorizationpageobjects.plus_icon.get(i));
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    }
		    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
		    	{
		    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
		    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
		    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
		    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
		    		//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
		    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
		    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
		    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
		    		preauthorizationpageobjects.confirm_button().click();
		    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
		    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
		    		{
		    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
		    		}
		 
			    	else
			    	{
			    		//clickJS(preauthorizationpageobjects.close_button());
			    		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.close_button());
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			    		preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.search_button());
			    		//clickJS(preauthorizationpageobjects.search_button());
			    		for(int i=0;i<=100;i++)
			    		{
			    		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			    		checkPageIsReady();
			    		}
			    		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			    		{
			    			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			    			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			    		}
			    		else
			    		{	
			    		    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    		    {
			    		    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    		    	for(int i1=0;i1<=100;i1++)
			    				{
			    				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
			    				checkPageIsReady();
			    				}
			    		    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    		    	{
			    		    		Result="Failed "+"The preauth completion has not been done ";
			    		    	}
					    		else
					    		{
					    			Result="Passed "+preauthorizationpageobjects.preauth_history.getText();
					    		}
			    		    } 
		    		     }
			    	}
		    	}
		    	else
		    	{
		    		Result="Failed "+" Preauth completion button is not present ";
		    	}
			  }
			}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
		dasboardpageobjects.preauthorization_Link().click();
		for(int i=0;i<=150;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
		checkPageIsReady();
		}
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			preauthorizationpageobjects.search_order_id().click();
			preauthorizationpageobjects.search_button().click();
			for(int i=0;i<=100;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			checkPageIsReady();
			}
			if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
				Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			}
			else
			{	
			    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    {
			    	//clickJS(preauthorizationpageobjects.plus_icon.get(i));
			    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    	for(int i1=0;i1<=100;i1++)
					{
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
					checkPageIsReady();
					}
			    }
		    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
		    	{
		    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.preAuth_complete_button);
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
		    		String before_preauthcompletion_amount=preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation().getText();
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_preAuth_buton()));
		    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.complete_preAuth_buton);
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauth_completion_currency_after__befor_confirmation()));
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.one_time_passcode_textbox()));
		    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
		    		//String Passcode=JDBCConnection.GetTheDbqueryValue(sqlQuery);
		    		String Passcode=JOptionPane.showInputDialog("Enter Passcode : "); 
		    		for(int i1=0;i1<=100;i1++){checkPageIsReady();}
		    		preauthorizationpageobjects.one_time_passcode_textbox().sendKeys(Passcode);
		    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.confirm_button()));
		    		preauthorizationpageobjects.confirm_button().click();
		    		for(int i1=0;i1<=80;i1++){checkPageIsReady();}
		    		if(preauthorizationpageobjects.invalid_passcode_error_message.isCurrentlyVisible())
		    		{
		    			Result="Failed "+preauthorizationpageobjects.invalid_passcode_error_message.getText();
		    		}
		 
			    	else
			    	{
			    		//clickJS(preauthorizationpageobjects.close_button());
			    		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.close_button());
			    		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_text()));
			    		preauthorizationpageobjects.search_text().sendKeys(Order_ID);
			    		executor.executeScript("arguments[0].click()", preauthorizationpageobjects.search_button());
			    		//clickJS(preauthorizationpageobjects.search_button());
			    		for(int i=0;i<=100;i++)
			    		{
			    		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_text()));
			    		checkPageIsReady();
			    		}
			    		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
			    		{
			    			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.search_error_message()));
			    			Result="Failed "+preauthorizationpageobjects.search_error_message().getText();
			    		}
			    		else
			    		{	
			    		    for(int i=0;i<preauthorizationpageobjects.plus_icon.size();i++)
			    		    {
			    		    	executor.executeScript("arguments[0].click()", preauthorizationpageobjects.plus_icon.get(i));
			    		    	for(int i1=0;i1<=100;i1++)
			    				{
			    				wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.complete_before_date.get(i)));
			    				checkPageIsReady();
			    				}
			    		    	if(preauthorizationpageobjects.preAuth_complete_button.isCurrentlyVisible())
			    		    	{
			    		    		Result="Failed "+"The preauth completion has not been done ";
			    		    	}
					    		else
					    		{
					    			Result="Passed "+preauthorizationpageobjects.preauth_history.getText();
					    		}
			    		    } 
		    		     }
			    	}
		    	}
		    	else
		    	{
		    		Result="Failed "+" Preauth completion button is not present ";
		    	}
			  }
			}
	}
	return Result;
}

@Step
public String validatePreAuthorizationsDetails()
{
       if(dasboardpageobjects.preAuthorizationsGraph.isCurrentlyVisible())
       {
              if(dasboardpageobjects.noExpiringPreAuthorizations.size() > 0)
              {
                    Result=dasboardpageobjects.noExpiringPreAuthorizations.get(0).getText();
              }
              else
              {
                    Result="PreAuthorization details are displayed";
              }
       }
       else
       {
              Result="No PreAuthorization details displayed";
       }

       return Result;
}
//////////////////////////////////////////////////////////////////Janani/////////////////////////////////////////////////////////////////////////////////////

@Step
public String Navigate_to_Authorization()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Authorizations_Link()));
	if(authorizationpageobjects.Authorizations_Link.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Authorizations_Link()));
		//Preauthorizationpageobjects.preauthorization_link().click();
		executor.executeScript("arguments[0].click()",authorizationpageobjects.Authorizations_Link());
		for(int i=0; i < 200; i++)
		{
		waitFor(usermanagementpageobject.Search_Textbox());
		wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
		}
		wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
		if(usermanagementpageobject.Search_Textbox.isCurrentlyVisible())
		{
		Result="Passed"+"::"+"Successfuly navigated to Authorization";
		}
		else
		{
		Result="Failed"+"::"+"Unable to navigate to Authorization";
		}
	}
	else
	{
		Result="Failed"+"::"+"Authorization Link not found";
	}
	return Result;
}
@Step
public String save_column_preference_in_Authorization()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null;
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(authorizationpageobjects.Auth_NoResult.isCurrentlyVisible())
	{
		Result="Failed"+"::"+authorizationpageobjects.Auth_NoResult.getText();
	}	
	else
	{
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Show_More()));
		if(transactionpageobjects.AddColumn_CardNo_Header.isCurrentlyVisible() && transactionpageobjects.AddColumn_CardNo_Header.getText().contains("Card number") )
		{
			Result="Passed"+"::"+"Column "+"'"+transactionpageobjects.AddColumn_CardNo_Header.getText()+"'"+" is already added to column preference";
		}
		else
		{
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Show_More()));
		transactionpageobjects.Show_More.click();
		executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.AddColumn_CardNo()));
		Result1=transactionpageobjects.AddColumn_CardNo.getText();
		transactionpageobjects.AddColumn_CardNo.click();
		executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Apply_Button()));
		authorizationpageobjects.Auth_Apply_Button.click();
		Result="Passed"+"::"+"Column "+"'"+Result1+"'"+" is added to view and successfully saved the column preference";	
		}
    }
	return Result;
}
@Step
public String user_should_able_to_view_Choosen_column_in_Authorization()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(authorizationpageobjects.Auth_NoResult.isCurrentlyVisible())
	{
		Result="Failed"+"::"+authorizationpageobjects.Auth_NoResult.getText();
	}	
	else
	{
		if(transactionpageobjects.AddColumn_CardNo_Header.isCurrentlyVisible() && transactionpageobjects.AddColumn_CardNo_Header.getText().contains("Card number") )
		{
			Result="Passed"+"::"+"Column "+"'"+transactionpageobjects.AddColumn_CardNo_Header.getText()+"'"+" is added to column preference and is displayed";
		}
		else
		{
		Result="Failed"+"::"+"Column 'Cardnumber' is not displayed in column preference";	
		}
    }
	return Result;
}

@Step
public String validate_auth_confirmation_screen_for_OrderID(String OrderID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Card_Number=null, Date=null, Amount=null;
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_homepage_text()));
	for(int i=0;i<50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
	}
	authorizationpageobjects.Search_Textbox().clear();
	authorizationpageobjects.Search_Textbox().sendKeys(OrderID);
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_autofill_OrderID()));
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_OrderID()));
	authorizationpageobjects.auth_Search_autofill_OrderID().click();
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
	authorizationpageobjects.auth_Search_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
	waitFor(authorizationpageobjects.Search_Textbox());
	if(authorizationpageobjects.Auth_NoResult.isVisible())
	{
		Result="Failed"+"::"+authorizationpageobjects.Auth_NoResult.getText();
	}	
	else
	{
	    for(int i=0; i<50; i++)
	    {
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
	    }
	    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
	    //executor.executeScript("arguments[0].click()",authorizationpageobjects.Auth_Search_Expand());
	    authorizationpageobjects.Auth_Search_Expand.click();
	    while(!authorizationpageobjects.auth_Cardno.isVisible())
	    {
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Cardno()));
	    }
		if(authorizationpageobjects.Void_button.isCurrentlyVisible())
		{
			Card_Number=authorizationpageobjects.auth_Cardno.getText().replaceAll("\\s", "");
			Date=authorizationpageobjects.auth_Date.getText();
			Amount=authorizationpageobjects.auth_amount.getText();
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Void_button()));
			authorizationpageobjects.Void_button.click();
		    //Void authorization screen -> Step 1
		    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_void_authorization()));
		    executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_void_authorization());
		    //Preauthorizationpageobjects.auth_void_authorization.click();
		    //Void confirmation screen -> Step 2
		    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_vc_Back()));
		    wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_vc_Cardno()));
		    wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_vc_Date()));
		    wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_vc_Amount()));
		    if(Card_Number.contains(authorizationpageobjects.auth_vc_Cardno.getText()) && Date.equals(authorizationpageobjects.auth_vc_Date.getText()) && Amount.equals(authorizationpageobjects.auth_vc_Amount.getText()))
		    {
			Result="Passed"+"::"+"'"+authorizationpageobjects.auth_vc_header.getText()+"'"+";"+authorizationpageobjects.auth_vc_heading_Cardno.getText()+"-->"+authorizationpageobjects.auth_vc_Cardno.getText()+"; Date -->"+authorizationpageobjects.auth_vc_Date.getText()+"; Amount -->"+authorizationpageobjects.auth_vc_Amount.getText();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_vc_Back());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_void_S1_Cancel()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_void_S1_Cancel());
		    }
		    else
		    {
		    Result="Failed"+"::"+"Information in Void Confirmation screen doesn't match with the data in Authorization view";
		    }
		}
		else
		{
			Result="Failed"+"::"+"Void button is not present for this Order ID";
		}
    }
	return Result;
}

@Step
public String Return_from_void_confirmation_back_to_authorization_view_for_OrderID(String OrderID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null;
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_homepage_text()));
	for(int i=0;i<50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
	}
	authorizationpageobjects.Search_Textbox().clear();
	authorizationpageobjects.Search_Textbox().sendKeys(OrderID);
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_autofill_OrderID()));
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_OrderID()));
	authorizationpageobjects.auth_Search_autofill_OrderID().click();
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
	authorizationpageobjects.auth_Search_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
	waitFor(authorizationpageobjects.Search_Textbox());
	if(authorizationpageobjects.Auth_NoResult.isVisible())
	{
		Result="Failed"+"::"+authorizationpageobjects.Auth_NoResult.getText();
	}	
	else
	{
	    for(int i=0; i<50; i++)
	    {
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
	    }
	    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
	    //executor.executeScript("arguments[0].click()",authorizationpageobjects.Auth_Search_Expand());
	    authorizationpageobjects.Auth_Search_Expand.click();
	    while(!authorizationpageobjects.auth_Cardno.isVisible())
	    {
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Cardno()));
	    }
		if(authorizationpageobjects.Void_button.isCurrentlyVisible())
		{
			
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Void_button()));
			authorizationpageobjects.Void_button.click();
		    //Void authorization screen -> Step 1
		    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_void_authorization()));
		    executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_void_authorization());
		    //Preauthorizationpageobjects.auth_void_authorization.click();
		    //Void confirmation screen -> Step 2
		    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_vc_Back()));
		    wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_vc_Cardno()));
		    wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_vc_Date()));
		    wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_vc_Amount()));
		    
			Result1="'"+authorizationpageobjects.auth_vc_header.getText()+"'"+";"+authorizationpageobjects.auth_vc_heading_Cardno.getText()+"-->"+authorizationpageobjects.auth_vc_Cardno.getText()+"; Date -->"+authorizationpageobjects.auth_vc_Date.getText()+"; Amount -->"+authorizationpageobjects.auth_vc_Amount.getText();
			//Navigate to Step1 
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_vc_Back()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_vc_Back());
			//Navigate to Authorization screen
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_void_S1_Cancel()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_void_S1_Cancel());
			//Validate successful navigation to Authorization screen
			if(authorizationpageobjects.auth_homepage_text.isVisible())
			{
				Result="Passed"+"::"+Result1+"; Successfully navigated to Authorization screen from void confirmation screen";
		    }
			else
			{
				Result="Failed"+"::"+"Unable to navigate to Authorization screen from void confirmation screen";
			}
		}
		else
		{
			Result="Failed"+"::"+"Void button is not present for this Order ID";
		}
    }
	return Result;
}

@Step
public String verify_void_on_transaction_past_today_in_authorization_view_for_OrderID(String OrderID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null;
	Date CurrentDate = new Date();
	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	String Currdate_Format,Txndate_Format;
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_homepage_text()));
	for(int i=0;i<20;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
	}
	//Change Date filter to view Last 7 days transaction
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Filter_Date_Dropdown()));
	authorizationpageobjects.Filter_Date_Dropdown().click();
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Last7days_Dropdown()));
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Last7days_Dropdown()));
	executor.executeScript("arguments[0].click()",authorizationpageobjects.Last7days_Dropdown());
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Filter_Date_Apply()));
	executor.executeScript("arguments[0].click()",authorizationpageobjects.Filter_Date_Apply());
	//Search with Order ID
	authorizationpageobjects.Search_Textbox().clear();
	authorizationpageobjects.Search_Textbox().sendKeys(OrderID);
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_autofill_OrderID()));
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_OrderID()));
	//authorizationpageobjects.auth_Search_autofill_OrderID().click();
	executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_autofill_OrderID());
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
	authorizationpageobjects.auth_Search_button().click();
	//executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
	waitFor(authorizationpageobjects.Search_Textbox());
	if(authorizationpageobjects.Auth_NoResult.isVisible())
	{
		Result="Failed"+"::"+authorizationpageobjects.Auth_NoResult.getText();
	}	
	else
	{
	    for(int i=0; i<50; i++)
	    {
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
	    }
	    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
	    authorizationpageobjects.Auth_Search_Expand.click();
	    while(!authorizationpageobjects.auth_Cardno.isVisible())
	    {
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Cardno()));
	    }
	    //Convert Curernt Date to Format DD/MM/YYYY
	    Currdate_Format=dateFormat.format(CurrentDate);
	    System.out.println("Current Date: "+Currdate_Format);
	    System.out.println("Txn Date: "+authorizationpageobjects.auth_Date.getText());
	    //Validation
	    if(Currdate_Format.equals(authorizationpageobjects.auth_Date.getText()))
	    {
	    	if(authorizationpageobjects.Void_button.isVisible())
	    	{
	    		Result="Passed"+"::"+"Transaction Date: "+authorizationpageobjects.auth_Date.getText()+"; Void button is visible for Today's transaction";
	    	}
	    	else if(!authorizationpageobjects.Void_button.isVisible())
	    	{
	    		Result="Passed"+"::"+"Transaction Date: "+authorizationpageobjects.auth_Date.getText()+"; Void button is not visible for Today's transaction";
	    	}
	    }
	    else
	    {
	    	if(authorizationpageobjects.Void_button.isVisible())
	    	{
	    		Result="Failed"+"::"+"Transaction Date: "+authorizationpageobjects.auth_Date.getText()+"; Void button is visible for Past Transaction";
	    	}
	    	else if(!authorizationpageobjects.Void_button.isVisible())
	    	{
	    		Result="Passed"+"::"+"Transaction Date: "+authorizationpageobjects.auth_Date.getText()+"; Void button is not visible for Past Transaction";
	    	}
	    }
    }
	return Result;
}

@Step
public String validate_presence_of_void_button_in_auth_view_for_OrderID(String OrderID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_homepage_text()));
	for(int i=0;i<50;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
	}
	if(authorizationpageobjects.Auth_NoResult.isVisible())
	{
		Result="Failed"+"::"+authorizationpageobjects.Auth_NoResult.getText();
	}
	else
	{
		authorizationpageobjects.Search_Textbox().clear();
		authorizationpageobjects.Search_Textbox().sendKeys(OrderID);
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_autofill_OrderID()));
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_OrderID()));
		authorizationpageobjects.auth_Search_autofill_OrderID().click();
		wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
		authorizationpageobjects.auth_Search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
		waitFor(authorizationpageobjects.Search_Textbox());
		if(authorizationpageobjects.Auth_NoResult.isVisible())
		{
			Result="Failed"+"::"+"Search with Order ID: "+OrderID+"-->"+authorizationpageobjects.Auth_NoResult.getText();
		}	
		else
		{
		    for(int i=0; i<50; i++)
		    {
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
		    }
		    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
		    //executor.executeScript("arguments[0].click()",authorizationpageobjects.Auth_Search_Expand());
		    authorizationpageobjects.Auth_Search_Expand.click();
		    while(!authorizationpageobjects.auth_Cardno.isVisible())
		    {
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Cardno()));
		    }
			if(authorizationpageobjects.Void_button.isCurrentlyVisible())
			{
				Result="Passed"+"::"+"Search with Order ID: "+OrderID+"-->"+"Void button is present";
			}
			else
			{
				Result="Failed"+"::"+"Search with Order ID: "+OrderID+"-->"+"Void button is not present";
			}
	    }
	}
	return Result;
}

@Step
public String user_should_be_able_to_filter_transaction_in_Authorisation_view(String OrderID, String MerchantID, String StoreID, String Authcode, String CardNumber, String ChannelType, String Authtype, String AmtFrom, String AmtTo)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null, Result2=null, Result3=null, Result4=null, Result5=null, Result6=null, Result7=null, Result8=null, SearchResult_CardNumber, Amount=null;
	WebElement SearchResult_OrderID, SearchResult_MerchantID, SearchResult_StoreID, SearchResult_Authcode, SearchResult_AuthType, SearchResult_Amt;
	wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Search_Textbox()));
	if(authorizationpageobjects.Auth_NoResult.isVisible())
	{
		Result="Failed"+"::"+authorizationpageobjects.Auth_NoResult.getText();
	}	
	else
	{
		//Search with OrderID
			authorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Search_Textbox()));
			authorizationpageobjects.Search_Textbox.sendKeys(OrderID);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_OrderID()));
			authorizationpageobjects.auth_Search_autofill_OrderID().click();
			//executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_autofill_OrderID());
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
			authorizationpageobjects.auth_Search_button().click();
			//executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
			waitFor(authorizationpageobjects.Search_Textbox());
			if(authorizationpageobjects.Auth_NoResult.isVisible())
			{
				Result1="Failed"+"=>"+"Search with Order ID: "+OrderID+"->"+authorizationpageobjects.Auth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.SearchResult_OrderID.get(1)));
			    SearchResult_OrderID=authorizationpageobjects.SearchResult_OrderID.get(1);
			    System.out.println("Order ID: "+SearchResult_OrderID.getText());
				if(SearchResult_OrderID.getText().contains(OrderID))
				{
				Result1="Passed"+"=>"+"Search with Order ID: "+SearchResult_OrderID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result1="Failed"+"=>"+"Search with Order ID: "+SearchResult_OrderID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//authorizationpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.Search_Textbox_Close_icon());
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
		//Search with MerchantID
			authorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Search_Textbox()));
			authorizationpageobjects.Search_Textbox.sendKeys(MerchantID);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_MerchantID()));
			//authorizationpageobjects.auth_Search_autofill_MerchantID().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_autofill_MerchantID());
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
			waitFor(authorizationpageobjects.Search_Textbox());
			if(authorizationpageobjects.Auth_NoResult.isVisible())
			{
				Result2="Failed"+"=>"+"Search with MerchantID: "+MerchantID+"->"+authorizationpageobjects.Auth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<30; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.SearchResult_MerchantID.get(1)));
			    SearchResult_MerchantID=authorizationpageobjects.SearchResult_MerchantID.get(1);
			    System.out.println("Merchant ID: "+SearchResult_MerchantID.getText());
				if(SearchResult_MerchantID.getText().contains(MerchantID))
				{
				Result2="Passed"+"=>"+"Search with MerchantID: "+SearchResult_MerchantID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result2="Failed"+"=>"+"Search with MerchantID: "+SearchResult_MerchantID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//authorizationpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.Search_Textbox_Close_icon());
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
		//Search with StoreID
			authorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Search_Textbox()));
			authorizationpageobjects.Search_Textbox.sendKeys(StoreID);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_StoreID()));
			//authorizationpageobjects.auth_Search_autofill_StoreID().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_autofill_StoreID());
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
			waitFor(authorizationpageobjects.Search_Textbox());
			if(authorizationpageobjects.Auth_NoResult.isVisible())
			{
				Result3="Failed"+"=>"+"Search with StoreID: "+StoreID+"->"+authorizationpageobjects.Auth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.SearchResult_StoreID.get(1)));
			    SearchResult_StoreID=authorizationpageobjects.SearchResult_StoreID.get(1);
			    System.out.println("Store ID: "+SearchResult_StoreID.getText());
				if(SearchResult_StoreID.getText().contains(StoreID))
				{
				Result3="Passed"+"=>"+"Search with StoreID: "+SearchResult_StoreID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result3="Failed"+"=>"+"Search with StoreID: "+SearchResult_StoreID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//authorizationpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.Search_Textbox_Close_icon());
			//authorizationpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
		//Search with Authcode
			authorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Search_Textbox()));
			authorizationpageobjects.Search_Textbox.sendKeys(Authcode);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_Authcode()));
			//authorizationpageobjects.auth_Search_autofill_Authcode().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_autofill_Authcode());
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
			waitFor(authorizationpageobjects.Search_Textbox());
			if(authorizationpageobjects.Auth_NoResult.isVisible())
			{
				Result4="Failed"+"=>"+"Search with Authcode: "+Authcode+"->"+authorizationpageobjects.Auth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.SearchResult_Authcode.get(1)));
			    SearchResult_Authcode=authorizationpageobjects.SearchResult_Authcode.get(1);
			    System.out.println("Authcode ID: "+SearchResult_Authcode.getText());
				if(SearchResult_Authcode.getText().contains(Authcode))
				{
				Result4="Passed"+"=>"+"Search with Authcode: "+SearchResult_Authcode.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result4="Failed"+"=>"+"Search with Authcode: "+SearchResult_Authcode.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//authorizationpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.Search_Textbox_Close_icon());
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
		//Search with CardNumber
			authorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Search_Textbox()));
			authorizationpageobjects.Search_Textbox.sendKeys(CardNumber);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_Search_autofill_CardNumber()));
			//authorizationpageobjects.auth_Search_autofill_CardNumber().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_autofill_CardNumber());
			wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.auth_Search_button()));
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
			waitFor(authorizationpageobjects.Search_Textbox());
			if(authorizationpageobjects.Auth_NoResult.isVisible())
			{
				Result5="Failed"+"=>"+"Search with txnID: "+CardNumber+"->"+authorizationpageobjects.Auth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
			    //authorizationpageobjects.Auth_Search_Expand.click();
			    executor.executeScript("arguments[0].click()",authorizationpageobjects.Auth_Search_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.SearchResult_CardNumber()));
			    SearchResult_CardNumber=authorizationpageobjects.SearchResult_CardNumber.getText().replaceAll("\\s", "");
			    System.out.println("Card Number:"+SearchResult_CardNumber);
				if(SearchResult_CardNumber.contains(CardNumber))
				{
				Result5="Passed"+"=>"+"Search with CardNumber: "+CardNumber+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result5="Failed"+"=>"+"Search with CardNumber: "+CardNumber+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//authorizationpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.Search_Textbox_Close_icon());
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());	
		//Search with ChannelType
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.More_Filter()));
			//authorizationpageobjects.More_Filter().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.More_Filter());
			//authorizationpageobjects.ChannelType_dropdown().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.ChannelType_dropdown());
			//Channel Type -> E-commerce
				if(ChannelType.equals("E-commerce"))
				{
					//authorizationpageobjects.ChannelType_Ecommerce().click();
					executor.executeScript("arguments[0].click()",authorizationpageobjects.ChannelType_Ecommerce());
					wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
					waitFor(authorizationpageobjects.Search_Textbox());
					if(authorizationpageobjects.Auth_NoResult.isVisible())
					{
						Result6="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"->"+authorizationpageobjects.Auth_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));		
						if(authorizationpageobjects.SearchResult_ChannelType_Ecomm.isVisible())
						{
						Result6="Passed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result matches the filter criteria";
						}
						else
						{
						Result6="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Channel Type -> Pos
				else if(ChannelType.equals("POS"))
				{
					//authorizationpageobjects.ChannelType_pos().click();
					executor.executeScript("arguments[0].click()",authorizationpageobjects.ChannelType_pos());
					wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
					waitFor(authorizationpageobjects.Search_Textbox());
					if(authorizationpageobjects.Auth_NoResult.isVisible())
					{
						Result6="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"->"+authorizationpageobjects.Auth_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));		
						if(authorizationpageobjects.SearchResult_ChannelType_Pos.isVisible())
						{
						Result6="Passed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result matches the filter criteria";
						}
						else
						{
						Result6="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Channel Type -> Other than Ecommerce / POS	
				else
				{
				Result6="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Channel Type doesn't match with drop down list available";	
				}
		//Reset Filter & clear previous search
			executor.executeScript("arguments[0].click()",authorizationpageobjects.ResetFilter_button());
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
		//Search with Authtype
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.More_Filter()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.AuthType_dropdown());
			//authorizationpageobjects.PaymentType_dropdown().click();
			//Auth Type -> Purchase
			if(Authtype.equals("Purchase"))
			{
				//authorizationpageobjects.AuthType_Purchase().click();
				executor.executeScript("arguments[0].click()",authorizationpageobjects.AuthType_Purchase());
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
				waitFor(authorizationpageobjects.Search_Textbox());
				if(authorizationpageobjects.Auth_NoResult.isVisible())
				{
					Result7="Failed"+"=>"+"Search with Authtype: "+Authtype+"->"+authorizationpageobjects.Auth_NoResult.getText();
				}
				else
				{
					for(int i=0; i<20; i++)
				    {
					wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
				    }
				    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));	
				    SearchResult_AuthType=authorizationpageobjects.SearchResult_AuthType.get(1);
				    System.out.println(SearchResult_AuthType.getText());
					if(Authtype.equals(SearchResult_AuthType.getText()))
					{
					Result7="Passed"+"=>"+"Search with Authtype: "+Authtype+"-> Search Result matches the filter criteria";
					}
					else
					{
					Result7="Failed"+"=>"+"Search with Authtype: "+Authtype+"-> Search Result doesn't match with the filter criteria";	
					}
				}
			}
			//Payment Type -> Payment
			else if(Authtype.equals("Payment"))
			{
				//authorizationpageobjects.AuthType_Payment().click();
				executor.executeScript("arguments[0].click()",authorizationpageobjects.AuthType_Payment());
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
				waitFor(authorizationpageobjects.Search_Textbox());
				if(authorizationpageobjects.Auth_NoResult.isVisible())
				{
					Result7="Failed"+"=>"+"Search with Authtype: "+Authtype+"->"+authorizationpageobjects.Auth_NoResult.getText();
				}
				else
				{
					for(int i=0; i<20; i++)
				    {
					wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
				    }
				    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));	
				    SearchResult_AuthType=authorizationpageobjects.SearchResult_AuthType.get(1);
				    System.out.println(SearchResult_AuthType.getText());
					if(Authtype.equals(SearchResult_AuthType))
					{
					Result7="Passed"+"=>"+"Search with Authtype: "+Authtype+"-> Search Result matches the filter criteria";
					}
					else
					{
					Result7="Failed"+"=>"+"Search with Authtype: "+Authtype+"-> Search Result doesn't match with the filter criteria";	
					}
				}
			}
			//Payment Type -> Refund
			else if(Authtype.equals("Refund"))
			{
				//authorizationpageobjects.AuthType_Refund().click();
				executor.executeScript("arguments[0].click()",authorizationpageobjects.AuthType_Refund());
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
				waitFor(authorizationpageobjects.Search_Textbox());
				if(authorizationpageobjects.Auth_NoResult.isVisible())
				{
					Result7="Failed"+"=>"+"Search with Authtype: "+Authtype+"->"+authorizationpageobjects.Auth_NoResult.getText();
				}
				else
				{
					for(int i=0; i<20; i++)
				    {
					wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
				    }
				    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));	
				    SearchResult_AuthType=authorizationpageobjects.SearchResult_AuthType.get(1);
				    System.out.println(SearchResult_AuthType.getText());
					if(Authtype.equals(SearchResult_AuthType))
					{
					Result7="Passed"+"=>"+"Search with Authtype: "+Authtype+"-> Search Result matches the filter criteria";
					}
					else
					{
					Result7="Failed"+"=>"+"Search with Authtype: "+Authtype+"-> Search Result doesn't match with the filter criteria";	
					}
				}
			}
			else
			{
			Result7="Failed"+"=>"+"Search with Txntype: "+Authtype+"-> Transaction Type doesn't match with drop down list available";	
			}
		//Reset Filter & clear previous search
			executor.executeScript("arguments[0].click()",authorizationpageobjects.ResetFilter_button());
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
		//Search with Amount
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.More_Filter()));
			authorizationpageobjects.AmtFrom.sendKeys(AmtFrom);
			authorizationpageobjects.AmtTo.sendKeys(AmtTo);
			//authorizationpageobjects.auth_Search_button().click();
			executor.executeScript("arguments[0].click()",authorizationpageobjects.auth_Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Search_Textbox()));
			if(authorizationpageobjects.Auth_NoResult.isVisible())
			{
				Result8="Failed"+"=>"+"Search with Amount, From: "+AmtFrom+" To: "+AmtTo+"->"+authorizationpageobjects.Auth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(authorizationpageobjects.Auth_Search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.Auth_Search_Expand()));
			    SearchResult_Amt=authorizationpageobjects.SearchResult_Amt.get(0);
			    Double iAmtFrom = Double.parseDouble(AmtFrom);
			    Double iAmtTo = Double.parseDouble(AmtTo);
			    if(SearchResult_Amt.getText().startsWith("� "))
			    {
			    Amount =SearchResult_Amt.getText().replaceAll("� ", "");
			    }
			    else if(SearchResult_Amt.getText().startsWith("- � "))
			    {
			    Amount =SearchResult_Amt.getText().replaceAll("- � ", "");
			    }
			    System.out.println("Triming �: "+Amount);
			    Double iSearchResult_Amt = Double.parseDouble(Amount);
			    System.out.println("From: "+iAmtFrom);
			    System.out.println("To: "+iAmtTo);
			    System.out.println("Result: "+iSearchResult_Amt);
				if(iSearchResult_Amt>=iAmtFrom && iSearchResult_Amt<=iAmtTo)
				{
				Result8="Passed"+"=>"+"Search with Amount, From: "+AmtFrom+" To: "+AmtTo+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result8="Failed"+"=>"+"Search with Amount, From: "+AmtFrom+" To: "+AmtTo+"-> Search Result doesn't match with the filter criteria";	
				}
			}
			
		Result="1."+Result1+";----;"+"2."+Result2+";----;"+"3."+Result3+";----;"+"4."+Result4+";----;"+"5."+Result5+";----;"+"6."+Result6+";----;"+"7."+Result7+";----;"+"8."+Result8;
    }
	return Result;
}

@Step
public String Navigate_to_Transactions()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Transactions_Link()));
	if(transactionpageobjects.Transactions_Link.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Transactions_Link()));
		//preauthorizationpageobjects.preauthorization_link().click();
		executor.executeScript("arguments[0].click()",transactionpageobjects.Transactions_Link());
		for (int i=0; i <50; i++)
		{
		waitFor(usermanagementpageobject.Search_Textbox());
		}
		//waitFor(usermanagementpageobject.Search_Textbox());
		wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
		if(usermanagementpageobject.Search_Textbox.isCurrentlyVisible())
		{
		Result="Passed"+"::"+"Successfuly navigated to Transactions";
		}
		else
		{
		Result="Failed"+"::"+"Unable to navigate to Transactions";
		}
	}
	else
	{
		Result="Failed"+"::"+"Transaction Link not found";
	}
	return Result;
}
@Step
public String user_should_be_able_to_navigate_to_top_and_bottom_of_transaction_list()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(transactionpageobjects.Txn_NoResult.isCurrentlyVisible())
	{
		Result="Failed"+"::"+transactionpageobjects.Txn_NoResult.getText();
	}	
	else
	{
		executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Result="Passed"+"::"+"Successfuly navigated to Top & bottom of transaction list";
    }
	return Result;
}

@Step
public String save_column_preference_in_Transactions()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null;
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(transactionpageobjects.Txn_NoResult.isCurrentlyVisible())
	{
		Result="Failed"+"::"+transactionpageobjects.Txn_NoResult.getText();
	}	
	else
	{
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Show_More()));
		if(transactionpageobjects.AddColumn_CardNo_Header.isCurrentlyVisible() && transactionpageobjects.AddColumn_CardNo_Header.getText().contains("Card number") )
		{
			Result="Passed"+"::"+"Column "+"'"+transactionpageobjects.AddColumn_CardNo_Header.getText()+"'"+" is already added to column preference";
		}
		else
		{
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Show_More()));
		transactionpageobjects.Show_More.click();
		executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.AddColumn_CardNo()));
		Result1=transactionpageobjects.AddColumn_CardNo.getText();
		transactionpageobjects.AddColumn_CardNo.click();
		executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		//executor.executeScript("arguments[0].scrollIntoView();",transactionpageobjects.Apply_Button());
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Txn_Apply_Button()));
		transactionpageobjects.Txn_Apply_Button.click();
		Result="Passed"+"::"+"Column "+"'"+Result1+"'"+" is added to view and successfully saved the column preference";	
		}
    }
	return Result;
}

@Step
public String user_should_able_to_view_Choosen_column_in_Transactions()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(transactionpageobjects.Txn_NoResult.isCurrentlyVisible())
	{
		Result="Failed"+"::"+transactionpageobjects.Txn_NoResult.getText();
	}	
	else
	{
		if(transactionpageobjects.AddColumn_CardNo_Header.isCurrentlyVisible() && transactionpageobjects.AddColumn_CardNo_Header.getText().contains("Card number") )
		{
			Result="Passed"+"::"+"Column "+"'"+transactionpageobjects.AddColumn_CardNo_Header.getText()+"'"+" is added to column preference and is displayed";
		}
		else
		{
		Result="Failed"+"::"+"Column 'Cardnumber' is not displayed in column preference";	
		}
    }
	return Result;
}

@Step
public String user_should_be_able_to_filter_transaction_in_transaction_view(String OrderID, String MerchantID, String StoreID, String Authcode, String txnID, String CardNumber, String ChannelType, String Txntype, String AmtFrom, String AmtTo)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null, Result2=null, Result3=null, Result4=null, Result5=null, Result6=null, Result7=null, Result8=null, Result9=null,SearchResult_CardNumber, Amount=null;
	WebElement SearchResult_OrderID, SearchResult_MerchantID, SearchResult_StoreID, SearchResult_PaymentType, SearchResult_Amt;
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(transactionpageobjects.Txn_NoResult.isVisible())
	{
		Result="Failed"+"::"+transactionpageobjects.Txn_NoResult.getText();
	}	
	else
	{
		//Search with OrderID
			transactionpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
			transactionpageobjects.Search_Textbox.sendKeys(OrderID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_OrderID()));
			transactionpageobjects.Search_Autofill_OrderID().click();
			//executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_OrderID());
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
			transactionpageobjects.Search_button().click();
			//executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
			waitFor(transactionpageobjects.Search_Textbox());
			if(transactionpageobjects.Txn_NoResult.isVisible())
			{
				Result1="Failed"+"=>"+"Search with Order ID: "+OrderID+"->"+transactionpageobjects.Txn_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
			    //transactionpageobjects.Search_Result_Expand.click();
			    executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
			    SearchResult_OrderID=transactionpageobjects.SearchResult_OrderID.get(1);
			    System.out.println(SearchResult_OrderID.getText());
				if(SearchResult_OrderID.getText().contains(OrderID))
				{
				Result1="Passed"+"=>"+"Search with Order ID: "+SearchResult_OrderID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result1="Failed"+"=>"+"Search with Order ID: "+SearchResult_OrderID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//transactionpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Textbox_Close_icon());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		//Search with MerchantID
			transactionpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
			transactionpageobjects.Search_Textbox.sendKeys(MerchantID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_MerchantID()));
			//transactionpageobjects.Search_Autofill_MerchantID().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_MerchantID());
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
			waitFor(transactionpageobjects.Search_Textbox());
			if(transactionpageobjects.Txn_NoResult.isVisible())
			{
				Result2="Failed"+"=>"+"Search with MerchantID: "+MerchantID+"->"+transactionpageobjects.Txn_NoResult.getText();
			}
			else
			{
				for(int i=0; i<30; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
			    //transactionpageobjects.Search_Result_Expand.click();
			    executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.SearchResult_MerchantID.get(1)));
			    SearchResult_MerchantID=transactionpageobjects.SearchResult_MerchantID.get(1);
			    System.out.println(SearchResult_MerchantID.getText());
				if(SearchResult_MerchantID.getText().contains(MerchantID))
				{
				Result2="Passed"+"=>"+"Search with MerchantID: "+SearchResult_MerchantID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result2="Failed"+"=>"+"Search with MerchantID: "+SearchResult_MerchantID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//transactionpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Textbox_Close_icon());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		//Search with StoreID
			transactionpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
			transactionpageobjects.Search_Textbox.sendKeys(StoreID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_StoreID()));
			//transactionpageobjects.Search_Autofill_StoreID().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_StoreID());
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
			waitFor(transactionpageobjects.Search_Textbox());
			if(transactionpageobjects.Txn_NoResult.isVisible())
			{
				Result3="Failed"+"=>"+"Search with StoreID: "+StoreID+"->"+transactionpageobjects.Txn_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
			    //transactionpageobjects.Search_Result_Expand.click();
			    executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.SearchResult_StoreID.get(1)));
			    SearchResult_StoreID=transactionpageobjects.SearchResult_StoreID.get(1);
			    System.out.println(SearchResult_StoreID.getText());
				if(SearchResult_StoreID.getText().contains(StoreID))
				{
				Result3="Passed"+"=>"+"Search with StoreID: "+SearchResult_StoreID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result3="Failed"+"=>"+"Search with StoreID: "+SearchResult_StoreID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//transactionpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Textbox_Close_icon());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		//Search with Authcode
			transactionpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
			transactionpageobjects.Search_Textbox.sendKeys(Authcode);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_Authcode()));
			//transactionpageobjects.Search_Autofill_Authcode().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_Authcode());
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
			waitFor(transactionpageobjects.Search_Textbox());
			if(transactionpageobjects.Txn_NoResult.isVisible())
			{
				Result4="Failed"+"=>"+"Search with Authcode: "+Authcode+"->"+transactionpageobjects.Txn_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
			    //transactionpageobjects.Search_Result_Expand.click();
			    executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.SearchResult_Authcode()));
			    System.out.println(transactionpageobjects.SearchResult_Authcode.getText());
				if(transactionpageobjects.SearchResult_Authcode.getText().contains(Authcode))
				{
				Result4="Passed"+"=>"+"Search with Authcode: "+transactionpageobjects.SearchResult_Authcode.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result4="Failed"+"=>"+"Search with Authcode: "+transactionpageobjects.SearchResult_Authcode.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//transactionpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Textbox_Close_icon());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		//Search with txnID
			transactionpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
			transactionpageobjects.Search_Textbox.sendKeys(txnID);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_txnID()));
			//transactionpageobjects.Search_Autofill_txnID().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_txnID());
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
			waitFor(transactionpageobjects.Search_Textbox());
			if(transactionpageobjects.Txn_NoResult.isVisible())
			{
				Result5="Failed"+"=>"+"Search with txnID: "+txnID+"->"+transactionpageobjects.Txn_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
			    //transactionpageobjects.Search_Result_Expand.click();
			    executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.SearchResult_txnID()));
			    System.out.println(transactionpageobjects.SearchResult_txnID.getText());
				if(transactionpageobjects.SearchResult_txnID.getText().contains(txnID))
				{
				Result5="Passed"+"=>"+"Search with txnID: "+transactionpageobjects.SearchResult_txnID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result5="Failed"+"=>"+"Search with txnID: "+transactionpageobjects.SearchResult_txnID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//transactionpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Textbox_Close_icon());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		//Search with CardNumber
			transactionpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
			transactionpageobjects.Search_Textbox.sendKeys(CardNumber);
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_CardNumber()));
			//transactionpageobjects.Search_Autofill_CardNumber().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_CardNumber());
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
			waitFor(transactionpageobjects.Search_Textbox());
			if(transactionpageobjects.Txn_NoResult.isVisible())
			{
				Result6="Failed"+"=>"+"Search with txnID: "+CardNumber+"->"+transactionpageobjects.Txn_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
			    //transactionpageobjects.Search_Result_Expand.click();
			    executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.SearchResult_CardNumber()));
			    System.out.println(transactionpageobjects.SearchResult_CardNumber.getText());
			    SearchResult_CardNumber=transactionpageobjects.SearchResult_CardNumber.getText().replaceAll("\\s", "");
				if(SearchResult_CardNumber.contains(CardNumber))
				{
				Result6="Passed"+"=>"+"Search with CardNumber: "+CardNumber+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result6="Failed"+"=>"+"Search with CardNumber: "+CardNumber+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			//transactionpageobjects.Search_Textbox_Close_icon.click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Textbox_Close_icon());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());	
		//Search with ChannelType
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.More_Filter()));
			//transactionpageobjects.More_Filter().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.More_Filter());
			//transactionpageobjects.ChannelType_dropdown().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.ChannelType_dropdown());
			//Channel Type -> E-commerce
				if(ChannelType.equals("E-commerce"))
				{
					//transactionpageobjects.ChannelType_Ecommerce().click();
					executor.executeScript("arguments[0].click()",transactionpageobjects.ChannelType_Ecommerce());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
					waitFor(transactionpageobjects.Search_Textbox());
					if(transactionpageobjects.Txn_NoResult.isVisible())
					{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"->"+transactionpageobjects.Txn_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));		
						if(transactionpageobjects.SearchResult_ChannelType_Ecomm.isVisible())
						{
						Result7="Passed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result matches the filter criteria";
						}
						else
						{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Channel Type -> Pos
				else if(ChannelType.equals("POS"))
				{
					//transactionpageobjects.ChannelType_pos().click();
					executor.executeScript("arguments[0].click()",transactionpageobjects.ChannelType_pos());
					wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
					waitFor(transactionpageobjects.Search_Textbox());
					if(transactionpageobjects.Txn_NoResult.isVisible())
					{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"->"+transactionpageobjects.Txn_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));		
						if(transactionpageobjects.SearchResult_ChannelType_Pos.isVisible())
						{
						Result7="Passed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result matches the filter criteria";
						}
						else
						{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Channel Type -> Other than Ecommerce / POS	
				else
				{
				Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Channel Type doesn't match with drop down list available";	
				}
		//Reset Filter & clear previous search
			executor.executeScript("arguments[0].click()",transactionpageobjects.ResetFilter_button());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		//Search with Txntype
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.More_Filter()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.PaymentType_dropdown());
		//transactionpageobjects.PaymentType_dropdown().click();
		//Payment Type -> Purchase
			if(Txntype.equals("Purchase"))
			{
				//transactionpageobjects.PaymentType_Purchase().click();
				executor.executeScript("arguments[0].click()",transactionpageobjects.PaymentType_Purchase());
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
				waitFor(transactionpageobjects.Search_Textbox());
				if(transactionpageobjects.Txn_NoResult.isVisible())
				{
					Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"->"+transactionpageobjects.Txn_NoResult.getText();
				}
				else
				{
					for(int i=0; i<20; i++)
				    {
					wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
				    }
				    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));	
				    SearchResult_PaymentType=transactionpageobjects.SearchResult_PaymentType.get(1);
				    System.out.println(SearchResult_PaymentType.getText());
					if(Txntype.equals(SearchResult_PaymentType.getText()))
					{
					Result8="Passed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result matches the filter criteria";
					}
					else
					{
					Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result doesn't match with the filter criteria";	
					}
				}
			}
			//Payment Type -> Payment
			else if(Txntype.equals("Payment"))
			{
				//transactionpageobjects.PaymentType_Payment().click();
				executor.executeScript("arguments[0].click()",transactionpageobjects.PaymentType_Payment());
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
				waitFor(transactionpageobjects.Search_Textbox());
				if(transactionpageobjects.Txn_NoResult.isVisible())
				{
					Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"->"+transactionpageobjects.Txn_NoResult.getText();
				}
				else
				{
					for(int i=0; i<20; i++)
				    {
					wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
				    }
				    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));	
				    SearchResult_PaymentType=transactionpageobjects.SearchResult_PaymentType.get(1);
				    System.out.println(SearchResult_PaymentType.getText());
					if(Txntype.equals(SearchResult_PaymentType))
					{
					Result8="Passed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result matches the filter criteria";
					}
					else
					{
					Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result doesn't match with the filter criteria";	
					}
				}
			}
			//Payment Type -> Refund
			else if(Txntype.equals("Refund"))
			{
				//transactionpageobjects.PaymentType_Refund().click();
				executor.executeScript("arguments[0].click()",transactionpageobjects.PaymentType_Refund());
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
				waitFor(transactionpageobjects.Search_Textbox());
				if(transactionpageobjects.Txn_NoResult.isVisible())
				{
					Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"->"+transactionpageobjects.Txn_NoResult.getText();
				}
				else
				{
					for(int i=0; i<20; i++)
				    {
					wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
				    }
				    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));	
				    SearchResult_PaymentType=transactionpageobjects.SearchResult_PaymentType.get(1);
				    System.out.println(SearchResult_PaymentType.getText());
					if(Txntype.equals(SearchResult_PaymentType))
					{
					Result8="Passed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result matches the filter criteria";
					}
					else
					{
					Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result doesn't match with the filter criteria";	
					}
				}
			}
			else
			{
			Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Transaction Type doesn't match with drop down list available";	
			}
		//Reset Filter & clear previous search
			executor.executeScript("arguments[0].click()",transactionpageobjects.ResetFilter_button());
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		//Search with Amount
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.More_Filter()));
			transactionpageobjects.AmtFrom.sendKeys(AmtFrom);
			transactionpageobjects.AmtTo.sendKeys(AmtTo);
			//transactionpageobjects.Search_button().click();
			executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
			if(transactionpageobjects.Txn_NoResult.isVisible())
			{
				Result9="Failed"+"=>"+"Search with Amount, From: "+AmtFrom+"To: "+AmtTo+"->"+transactionpageobjects.Txn_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
			    SearchResult_Amt=transactionpageobjects.SearchResult_Amt.get(0);
			    Double iAmtFrom = Double.parseDouble(AmtFrom);
			    Double iAmtTo = Double.parseDouble(AmtTo);
			    if(SearchResult_Amt.getText().startsWith("� "))
			    {
			    Amount =SearchResult_Amt.getText().replaceAll("� ", "");
			    }
			    else if(SearchResult_Amt.getText().startsWith("- � "))
			    {
			    Amount =SearchResult_Amt.getText().replaceAll("- � ", "");
			    }
			    System.out.println("Triming �: "+Amount);
			    Double iSearchResult_Amt = Double.parseDouble(Amount);
			    System.out.println("From: "+iAmtFrom);
			    System.out.println("To: "+iAmtTo);
			    System.out.println("Result: "+iSearchResult_Amt);
				if(iSearchResult_Amt>=iAmtFrom && iSearchResult_Amt<=iAmtTo)
				{
				Result9="Passed"+"=>"+"Search with Amount, From: "+AmtFrom+"To: "+AmtTo+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result9="Failed"+"=>"+"Search with Amount, From: "+AmtFrom+"To: "+AmtTo+"-> Search Result doesn't match with the filter criteria";	
				}
			}
			
		Result="1."+Result1+";----;"+"2."+Result2+";----;"+"3."+Result3+";----;"+"4."+Result4+";----;"+"5."+Result5+";----;"+"6."+Result6+";----;"+"7."+Result7+";----;"+"8."+Result8+";----;"+"9."+Result9;
    }
	return Result;
}

@Step
public String user_should_be_able_to_view_refund_button_in_transaction_view(String txnID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(transactionpageobjects.Txn_NoResult.isVisible())
	{
		Result="Failed"+"::"+transactionpageobjects.Txn_NoResult.getText();
	}	
	else
	{
		//Search with txnID
		transactionpageobjects.Search_Textbox.clear();
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
		transactionpageobjects.Search_Textbox.sendKeys(txnID);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_txnID()));
		transactionpageobjects.Search_Autofill_txnID().click();
		//executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_txnID());
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
		//transactionpageobjects.Search_button().click();
		executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Textbox()));
		waitFor(transactionpageobjects.Search_Textbox());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.More_Filter()));
		if(transactionpageobjects.Txn_NoResult.isVisible())
		{
			Result="Failed"+"=>"+"Search with txnID: "+txnID+"->"+transactionpageobjects.Txn_NoResult.getText();
		}
		else
		{
			for(int i=0; i<10; i++)
		    {
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
		    }
		    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
		    transactionpageobjects.Search_Result_Expand.click();
		    //executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
		    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.SearchResult_txnID()));
			if(transactionpageobjects.Refund_button.isVisible())
			{
				Result="Passed"+"=>"+"Search with txnID: "+transactionpageobjects.SearchResult_txnID.getText()+"-> Refund button is visible";
			}
			else
			{
				Result="Failed"+"=>"+"Search with txnID: "+transactionpageobjects.SearchResult_txnID.getText()+"-> Refund button is not visible";	
			}
		}
		
	}
	return Result;
}

@Step
public String user_should_see_Portal_transaction_data_in_corresponding_language(String PortalLanguage) throws InterruptedException{
       driver = this.getDriver(); 
       WebDriverWait wait = new WebDriverWait(driver, 60);
       wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	   	if(transactionpageobjects.Txn_NoResult.isVisible())
	   	{
	   		Result="Failed"+"::"+transactionpageobjects.Txn_NoResult.getText();
	   	}
	   	else
	   	{
	   		for(int i=0; i<10; i++)
		    {
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
		    }
	   		if(PortalLanguage.equals("Dutch") || PortalLanguage.equals("Nederlands") || PortalLanguage.equals("N�erlandais") || PortalLanguage.equals("Niederl�ndisch"))
	        {
	   			boolean flag=true;
	   			System.out.println("Flag value is:"+flag);
	   			System.out.println("Size of the transaction objects:"+transactionpageobjects.Posting_Txn_date.size());
	   			for(int i=0 ;i<transactionpageobjects.Posting_Txn_date.size() && flag==true;i++)
	   			{
	               if(transactionpageobjects.Posting_Txn_date.get(i).getText().contains("-"))
	               {
	            	   Result="Passed "+"::"+"Transaction Data is displayed in "+PortalLanguage+" language";
	               }
	               else
	               {
	                   flag=false;   
	            	   Result="Failed "+"::"+"Transaction Data is not displayed in "+PortalLanguage+" language";
	               }
	   			}
	        }
	   		else if(PortalLanguage.equals("English") || PortalLanguage.equals("Engels") || PortalLanguage.equals("Englisch") || PortalLanguage.equals("Anglais"))
	        {
	   			boolean flag=true;
	   			System.out.println("Flag value is:"+flag);
	   			System.out.println("Size of the transaction objects:"+transactionpageobjects.Posting_Txn_date.size());
	   			for(int i=0 ;i<transactionpageobjects.Posting_Txn_date.size() && flag==true;i++)
	   			{
	               if(transactionpageobjects.Posting_Txn_date.get(i).getText().contains("/"))
	               {
	            	   Result="Passed "+"::"+"Transaction Data is displayed in "+PortalLanguage+" language";
	               }
	               else
	               {
	                   flag=false;   
	            	   Result="Failed "+"::"+"Transaction Data is not displayed in "+PortalLanguage+" language";
	               }
	   			}
	        }
	   		else if(PortalLanguage.equals("French") || PortalLanguage.equals("Frans") || PortalLanguage.equals("Fran�ais") || PortalLanguage.equals("Franz�sisch"))
	        {
	   			boolean flag=true;
	   			System.out.println("Flag value is:"+flag);
	   			System.out.println("Size of the transaction objects:"+transactionpageobjects.Posting_Txn_date.size());
	   			for(int i=0 ;i<transactionpageobjects.Posting_Txn_date.size() && flag==true;i++)
	   			{
	               if(transactionpageobjects.Posting_Txn_date.get(i).getText().contains("/"))
	               {
	            	   Result="Passed "+"::"+"Transaction Data is displayed in "+PortalLanguage+" language";
	               }
	               else
	               {
	                   flag=false;   
	            	   Result="Failed "+"::"+"Transaction Data is not displayed in "+PortalLanguage+" language";
	               }
	   			}
	        }
	   		else if(PortalLanguage.equals("German") || PortalLanguage.equals("Duits") || PortalLanguage.equals("Allemand") || PortalLanguage.equals("Deutsch"))
	        {
	   			boolean flag=true;
	   			System.out.println("Flag value is:"+flag);
	   			System.out.println("Size of the transaction objects:"+transactionpageobjects.Posting_Txn_date.size());
	   			for(int i=0 ;i<transactionpageobjects.Posting_Txn_date.size() && flag==true;i++)
	   			{
	               if(transactionpageobjects.Posting_Txn_date.get(i).getText().contains("."))
	               {
	            	   Result="Passed "+"::"+"Transaction Data is displayed in "+PortalLanguage+" language";
	               }
	               else
	               {
	                   flag=false;   
	            	   Result="Failed "+"::"+"Transaction Data is not displayed in "+PortalLanguage+" language";
	               }
	   			}
	        }
	   		else
            {  
         	   Result="Failed "+"::"+"Portal language doesn't match with the available language";
            }
	   	}
	   	
	   	System.out.println("The Result is:"+Result);
       return Result;
}

@Step
public String view_Fees_displayed_in_3_decimal_format_in_Transaction_view(String FromDate, String ToDate, String TxnID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
	//Change From / To Date
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Date_dropdown()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.Date_dropdown());
		transactionpageobjects.FromDate.clear();
		transactionpageobjects.FromDate.sendKeys(FromDate);
		transactionpageobjects.ToDate.clear();
		transactionpageobjects.ToDate.sendKeys(ToDate);
		executor.executeScript("arguments[0].click()",transactionpageobjects.DatePicker_Apply());
		for(int i=0; i<20; i++)
		{
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_button()));
		}
	//Search with txnID
		transactionpageobjects.Search_Textbox.clear();
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Textbox()));
		transactionpageobjects.Search_Textbox.sendKeys(TxnID);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Autofill_txnID()));
		//transactionpageobjects.Search_Autofill_txnID().click();
		executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Autofill_txnID());
		wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_button()));
		//transactionpageobjects.Search_button().click();
		executor.executeScript("arguments[0].click()",transactionpageobjects.Search_button());
		for(int i=0; i<20; i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Date_dropdown()));
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.More_Filter()));
		}
		if(transactionpageobjects.Txn_NoResult.isVisible())
		{
			Result="Failed"+"=>"+"Search with txnID: "+TxnID+"->"+transactionpageobjects.Txn_NoResult.getText();
		}
		else
		{
			for(int i=0; i<10; i++)
		    {
			wait.until(ExpectedConditions.visibilityOf(transactionpageobjects.Search_Result_Expand()));
		    }
		    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Search_Result_Expand()));
		    //transactionpageobjects.Search_Result_Expand.click();
		    executor.executeScript("arguments[0].click()",transactionpageobjects.Search_Result_Expand());
		    for(int i=0; i<30; i++)
		    {
		    wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.SearchResult_txnID()));
		    }
		    while(!transactionpageobjects.Brand.isVisible())
		    {
		    	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Brand()));
		    }
		    System.out.println(transactionpageobjects.Brand.getText());
			if(transactionpageobjects.Brand.getText().equals("Visa")||transactionpageobjects.Brand.getText().equals("Maestro"))
			{
				boolean flag=true;
				String EMS_fees=null;
				for(int i=0 ;i<transactionpageobjects.EMS_fees.size() && flag==true;i++)
	   			{
					if(transactionpageobjects.EMS_fees.get(i).getText().startsWith("� "))
				    {
						EMS_fees =transactionpageobjects.EMS_fees.get(i).getText().replaceAll("� ", "");
				    }
				    else if(transactionpageobjects.EMS_fees.get(i).getText().startsWith("- � "))
				    {
				    	EMS_fees =transactionpageobjects.EMS_fees.get(i).getText().replaceAll("- � ", "");
				    }
					String[] Split_Amount=EMS_fees.split("\\.");
					if(Split_Amount[1].length()==3)
					{
						Result="Passed "+"::"+"Search with txnID-> "+transactionpageobjects.SearchResult_txnID.getText()+"; Txn is of Brand-> "+transactionpageobjects.Brand.getText()+"; EMS Fees is displayed with "+Split_Amount[1].length()+" decimals";
					}
					else
					{
						flag=false;   
						Result="Failed "+"::"+"Search with txnID-> "+transactionpageobjects.SearchResult_txnID.getText()+"; Txn is of Brand-> "+transactionpageobjects.Brand.getText()+"; EMS Fees is displayed with "+Split_Amount[1].length()+" decimals";
					}
	   			}
			}
			else
			{
				Result="Failed"+"=>"+"Search with txnID-> "+transactionpageobjects.SearchResult_txnID.getText()+"; Txn is of Brand-> "+transactionpageobjects.Brand.getText();	
			}
		}
	return Result;
}

@Step
public String agent_enter_merchant_user_name(String BOusername)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.impersonationLogin()));
	if(preauthorizationpageobjects.impersonationLogin.isCurrentlyVisible())
	{
		preauthorizationpageobjects.impersonationUserName.sendKeys(BOusername);
		preauthorizationpageobjects.impersonationLogin().click();
		if(preauthorizationpageobjects.impersonatedUserNameText.containsText(BOusername))
		{
			Result="Passed"+"::"+"Welcome Text: "+preauthorizationpageobjects.impersonatedUserNameText.getText();
		}
		else
		{
			Result="Failed"+"::"+"Error: "+preauthorizationpageobjects.impersonationErrorMessage.getText();
		}
	}
	else
	{
		Result="Failed"+"::"+"Issue in Login as impersonation";
	}
	return Result;
}
@Step
public String Navigate_to_Preauthorization()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.preauthorization_link()));
	if(preauthorizationpageobjects.preauthorization_link.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.preauthorization_link()));
		//preauthorizationpageobjects.preauthorization_link().click();
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.preauthorization_link());
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
}
@Step
public String user_should_not_be_able_to_view_Complete_preauthorization_and_Void_button()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobject.Search_Textbox()));
	if(preauthorizationpageobjects.Preauth_NoResult.isCurrentlyVisible())
	{
		Result="Failed"+"::"+preauthorizationpageobjects.Preauth_NoResult.getText();
	}	
	else
	{
		int x=0;
		boolean flag = true;
	    while (x < preauthorizationpageobjects.Preauth_SearchResult.size() && flag==true)
	    {
	    WebElement element = preauthorizationpageobjects.Preauth_SearchResult.get(x);
	    executor.executeScript("arguments[0].click()",element);
	    //element.click();
	    wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_SearchResult.get(x)));
		if(preauthorizationpageobjects.Complete_preauthorization_button.isCurrentlyEnabled()||preauthorizationpageobjects.Void_button.isCurrentlyEnabled())
		{
			Result="Failed"+"::"+"Complete pre-authorization & Void button is Present";
			flag=false;
		}
		else
		{
		Result="Passed";
		}
		x++;
	    }
    }
	return Result;
}

@Step
public String validate_Preauth_confirmation_screen_for_OrderID(String Order_ID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Card_Number=null, Date=null, Amount=null;
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.preauth_homepage_text()));
	for(int i=0;i<200;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
	}
	preauthorizationpageobjects.Search_Textbox().clear();
	preauthorizationpageobjects.Search_Textbox().sendKeys(Order_ID);
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_Search_autofill_OrderID()));
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_OrderID()));
	preauthorizationpageobjects.Preauth_Search_autofill_OrderID().click();
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
	preauthorizationpageobjects.Search_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
	waitFor(preauthorizationpageobjects.Search_Textbox());
	if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
	{
		Result="Failed"+"::"+preauthorizationpageobjects.Preauth_NoResult.getText();
	}	
	else
	{
		for(int i=0; i<50; i++)
	    {
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
	    }
	    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
	    //executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_search_Expand());
	    preauthorizationpageobjects.Preauth_search_Expand.click();
	    while(!preauthorizationpageobjects.Preauth_Cardno.isVisible())
	    {
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_Cardno()));
	    }
		if(preauthorizationpageobjects.Void_button.isVisible())
		{
			Card_Number=preauthorizationpageobjects.Preauth_Cardno.getText();
			Date=preauthorizationpageobjects.Preauth_Date.getText();
			Amount=preauthorizationpageobjects.Preauth_Amount.getText();
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Void_button()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Void_button());
			//preauthorizationpageobjects.Void_button.click();
		    //Void authorization screen -> Step 1
		    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_void_authorization()));
		    executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_void_authorization());
		    //preauthorizationpageobjects.Preauth_void_authorization.click();
		    //Void confirmation screen -> Step 2
		    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_vc_Back()));
		    wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_vc_Cardno()));
		    wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_vc_Date()));
		    wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_vc_Amount()));
		    if(Card_Number.equals(preauthorizationpageobjects.Preauth_vc_Cardno.getText()) && Date.equals(preauthorizationpageobjects.Preauth_vc_Date.getText()) && Amount.equals(preauthorizationpageobjects.Preauth_vc_Amount.getText()))
		    {
			Result="Passed"+"::"+"'"+preauthorizationpageobjects.Preauth_vc_header.getText()+"'"+";"+preauthorizationpageobjects.Preauth_vc_heading_Cardno.getText()+"-->"+preauthorizationpageobjects.Preauth_vc_Cardno.getText()+"; Date -->"+preauthorizationpageobjects.Preauth_vc_Date.getText()+"; Amount -->"+preauthorizationpageobjects.Preauth_vc_Amount.getText();
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_vc_Back());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_void_S1_Cancel()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_void_S1_Cancel());
		    }
		    else
		    {
		    Result="Failed"+"::"+"Information in Void Confirmation screen doesn't match with the data in Pre-authorization view";
		    }
		}
		else
		{
			Result="Failed"+"::"+"Void button is not present for this Order ID";
		}
    }
	return Result;
}

@Step
public String Return_from_void_confirmation_back_to_preauth_view_for_OrderID(String Order_ID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null;
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.preauth_homepage_text()));
	//for(int i=0;i<1000;i++)
	while(!preauthorizationpageobjects.Search_Textbox.isVisible())
	{
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
	}
	preauthorizationpageobjects.Search_Textbox().clear();
	preauthorizationpageobjects.Search_Textbox().sendKeys(Order_ID);
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_Search_autofill_OrderID()));
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_OrderID()));
	preauthorizationpageobjects.Preauth_Search_autofill_OrderID().click();
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
	preauthorizationpageobjects.Search_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
	waitFor(preauthorizationpageobjects.Search_Textbox());
	if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
	{
		Result="Failed"+"::"+preauthorizationpageobjects.Preauth_NoResult.getText();
	}	
	else
	{
		for(int i=0; i<50; i++)
	    {
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
	    }
	    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
	    //executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_search_Expand());
	    preauthorizationpageobjects.Preauth_search_Expand.click();
	    while(!preauthorizationpageobjects.Preauth_Cardno.isVisible())
	    {
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_Cardno()));
	    }
		if(preauthorizationpageobjects.Void_button.isVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Void_button()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Void_button());
		    //preauthorizationpageobjects.Void_button.click();
		    //Void authorization screen -> Step 1
		    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_void_authorization()));
		    executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_void_authorization());
		    //preauthorizationpageobjects.Preauth_void_authorization.click();
		    //Void confirmation screen -> Step 2
		    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_vc_Back()));
		    wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_vc_Cardno()));
		    wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_vc_Date()));
		    wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_vc_Amount()));
		    
			Result1="'"+preauthorizationpageobjects.Preauth_vc_header.getText()+"'"+";"+preauthorizationpageobjects.Preauth_vc_heading_Cardno.getText()+"-->"+preauthorizationpageobjects.Preauth_vc_Cardno.getText()+"; Date -->"+preauthorizationpageobjects.Preauth_vc_Date.getText()+"; Amount -->"+preauthorizationpageobjects.Preauth_vc_Amount.getText();
			//Navigate to Step1
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_vc_Back()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_vc_Back());
			//Navigate to Preauth screen
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_void_S1_Cancel()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_void_S1_Cancel());
			//Validate successful navigation to Preauth screen
			if(preauthorizationpageobjects.preauth_homepage_text.isVisible())
			{
				Result="Passed"+"::"+Result1+"; Successfully navigated to Preauth screen from void confirmation screen";
		    }
			else
			{
				Result="Failed"+"::"+"Unable to navigate to Preauth screen from void confirmation screen";
			}
		}
		else
		{
			Result="Failed"+"::"+"Void button is not present for this Order ID";
		}
    }
	return Result;
}

@Step
public String validate_presence_of_void_button_in_Preauth_view_for_OrderID(String Order_ID)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.preauth_homepage_text()));
	for(int i=0;i<100;i++)
	{
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
	}
	if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
	{
		Result="Failed"+"::"+preauthorizationpageobjects.Preauth_NoResult.getText();
	}
	else
	{
		preauthorizationpageobjects.Search_Textbox().clear();
		preauthorizationpageobjects.Search_Textbox().sendKeys(Order_ID);
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_Search_autofill_OrderID()));
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_OrderID()));
		preauthorizationpageobjects.Preauth_Search_autofill_OrderID().click();
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
		preauthorizationpageobjects.Search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
		waitFor(preauthorizationpageobjects.Search_Textbox());
		if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
		{
			Result="Failed"+"::"+"Search with Order ID: "+Order_ID+"-->"+preauthorizationpageobjects.Preauth_NoResult.getText();
		}	
		else
		{
			for(int i=0; i<50; i++)
		    {
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
		    }
		    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
		    executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_search_Expand());
		    //preauthorizationpageobjects.Preauth_search_Expand.click();
		    while(!preauthorizationpageobjects.Preauth_Cardno.isVisible())
		    {
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_Cardno()));
		    }
			if(preauthorizationpageobjects.Void_button.isVisible())
			{
				
				Result="Passed"+"::"+"Search with Order ID: "+Order_ID+"-->"+"Void button is present";
			}
			else
			{
				Result="Failed"+"::"+"Search with Order ID: "+Order_ID+"-->"+"Void button is not present";
			}
	    }
	}
	return Result;
}

@Step
public String user_should_be_able_to_filter_transaction_in_Preauthorisation_view(String OrderID, String MerchantID, String StoreID, String Preauthcode, String Reservationno, String CardNumber, String ChannelType, String Txntype, String AmtFrom, String AmtTo)  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null, Result2=null, Result3=null, Result4=null, Result5=null, Result6=null, Result7=null, Result8=null, Result9=null, SearchResult_CardNumber, Amount = null;
	WebElement SearchResult_OrderID, SearchResult_MerchantID, SearchResult_StoreID, SearchResult_Reservationno, SearchResult_Amt;
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
	if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
	{
		Result="Failed"+"::"+preauthorizationpageobjects.Preauth_NoResult.getText();
	}	
	else
	{
		//Search with OrderID
			preauthorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
			preauthorizationpageobjects.Search_Textbox.sendKeys(OrderID);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_OrderID()));
			preauthorizationpageobjects.Preauth_Search_autofill_OrderID().click();
			//executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_Search_autofill_OrderID());
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
			preauthorizationpageobjects.Search_button().click();
			//executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
			waitFor(preauthorizationpageobjects.Search_Textbox());
			if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
			{
				Result1="Failed"+"=>"+"Search with Order ID: "+OrderID+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.SearchResult_OrderID.get(1)));
			    SearchResult_OrderID=preauthorizationpageobjects.SearchResult_OrderID.get(1);
			    System.out.println("Order ID: "+SearchResult_OrderID.getText());
				if(SearchResult_OrderID.getText().contains(OrderID))
				{
				Result1="Passed"+"=>"+"Search with Order ID: "+SearchResult_OrderID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result1="Failed"+"=>"+"Search with Order ID: "+SearchResult_OrderID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_Textbox_Close_icon());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
		//Search with MerchantID
			preauthorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
			preauthorizationpageobjects.Search_Textbox.sendKeys(MerchantID);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_MerchantID()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_Search_autofill_MerchantID());
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
			waitFor(preauthorizationpageobjects.Search_Textbox());
			if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
			{
				Result2="Failed"+"=>"+"Search with MerchantID: "+MerchantID+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<30; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.SearchResult_MerchantID.get(1)));
			    SearchResult_MerchantID=preauthorizationpageobjects.SearchResult_MerchantID.get(1);
			    System.out.println("Merchant ID: "+SearchResult_MerchantID.getText());
				if(SearchResult_MerchantID.getText().contains(MerchantID))
				{
				Result2="Passed"+"=>"+"Search with MerchantID: "+SearchResult_MerchantID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result2="Failed"+"=>"+"Search with MerchantID: "+SearchResult_MerchantID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_Textbox_Close_icon());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
		//Search with StoreID
			preauthorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
			preauthorizationpageobjects.Search_Textbox.sendKeys(StoreID);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_StoreID()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_Search_autofill_StoreID());
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
			waitFor(preauthorizationpageobjects.Search_Textbox());
			if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
			{
				Result3="Failed"+"=>"+"Search with StoreID: "+StoreID+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.SearchResult_StoreID.get(1)));
			    SearchResult_StoreID=preauthorizationpageobjects.SearchResult_StoreID.get(1);
			    System.out.println("Store ID: "+SearchResult_StoreID.getText());
				if(SearchResult_StoreID.getText().contains(StoreID))
				{
				Result3="Passed"+"=>"+"Search with StoreID: "+SearchResult_StoreID.getText()+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result3="Failed"+"=>"+"Search with StoreID: "+SearchResult_StoreID.getText()+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_Textbox_Close_icon());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
		//Search with Preauthcode
			preauthorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
			preauthorizationpageobjects.Search_Textbox.sendKeys(Preauthcode);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_Preauthcode()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_Search_autofill_Preauthcode());
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
			waitFor(preauthorizationpageobjects.Search_Textbox());
			if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
			{
				Result4="Failed"+"=>"+"Search with Preauthcode: "+Preauthcode+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
			    //preauthorizationpageobjects.Preauth_search_Expand.click();
			    executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_search_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.SearchResult_Preauthcode()));
			    System.out.println("Authcode ID: "+preauthorizationpageobjects.SearchResult_Preauthcode.getText());
				if(preauthorizationpageobjects.SearchResult_Preauthcode.getText().contains(Preauthcode))
				{
				Result4="Passed"+"=>"+"Search with Preauthcode: "+Preauthcode+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result4="Failed"+"=>"+"Search with Preauthcode: "+Preauthcode+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_Textbox_Close_icon());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
		//Search with Reservationno
			preauthorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
			preauthorizationpageobjects.Search_Textbox.sendKeys(Reservationno);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_Reservationno()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_Search_autofill_Reservationno());
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
			waitFor(preauthorizationpageobjects.Search_Textbox());
			if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
			{
				Result5="Failed"+"=>"+"Search with Reservation Number: "+Reservationno+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.SearchResult_Reservationno.get(1)));
			    SearchResult_Reservationno=preauthorizationpageobjects.SearchResult_Reservationno.get(1);
			    System.out.println("Reservation Number: "+SearchResult_Reservationno.getText());
				if(SearchResult_Reservationno.getText().contains(Reservationno))
				{
				Result5="Passed"+"=>"+"Search with Reservation Number: "+Reservationno+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result5="Failed"+"=>"+"Search with Reservation Number: "+Reservationno+"-> Search Result doesn't match with the filter criteria";	
				}
			}	
		//Clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_Textbox_Close_icon());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
		//Search with CardNumber
			preauthorizationpageobjects.Search_Textbox.clear();
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
			preauthorizationpageobjects.Search_Textbox.sendKeys(CardNumber);
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Search_autofill_CardNumber()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_Search_autofill_CardNumber());
			wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_button()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
			waitFor(preauthorizationpageobjects.Search_Textbox());
			if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
			{
				Result6="Failed"+"=>"+"Search with txnID: "+CardNumber+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
			    //preauthorizationpageobjects.Preauth_search_Expand.click();
			    executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_search_Expand());
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_Cardno()));
			    SearchResult_CardNumber=preauthorizationpageobjects.Preauth_Cardno.getText().replaceAll("\\s", "");
			    System.out.println("Card Number:"+SearchResult_CardNumber);
				if(SearchResult_CardNumber.contains(CardNumber))
				{
				Result6="Passed"+"=>"+"Search with CardNumber: "+CardNumber+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result6="Failed"+"=>"+"Search with CardNumber: "+CardNumber+"-> Search Result doesn't match with the filter criteria";	
				}
			}
		//Clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_Textbox_Close_icon());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());	
		//Search with ChannelType
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.More_Filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.More_Filter());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.ChannelType_dropdown());
			//Channel Type -> E-commerce
				if(ChannelType.equals("E-commerce"))
				{
					//preauthorizationpageobjects.ChannelType_Ecommerce().click();
					executor.executeScript("arguments[0].click()",preauthorizationpageobjects.ChannelType_Ecommerce());
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
					waitFor(preauthorizationpageobjects.Search_Textbox());
					if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
					{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));		
						if(preauthorizationpageobjects.SearchResult_ChannelType_Ecomm.isVisible())
						{
						Result7="Passed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result matches the filter criteria";
						}
						else
						{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Channel Type -> Pos
				else if(ChannelType.equals("POS"))
				{
					executor.executeScript("arguments[0].click()",preauthorizationpageobjects.ChannelType_pos());
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
					waitFor(preauthorizationpageobjects.Search_Textbox());
					if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
					{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));		
						if(preauthorizationpageobjects.SearchResult_ChannelType_Pos.isVisible())
						{
						Result7="Passed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result matches the filter criteria";
						}
						else
						{
						Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Channel Type -> Other than Ecommerce / POS	
				else
				{
				Result7="Failed"+"=>"+"Search with ChannelType: "+ChannelType+"-> Channel Type doesn't match with drop down list available";	
				}
		//Reset Filter & clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.ResetFilter_button());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
		//Search with Txntype
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.More_Filter()));
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Txntype_dropdown());
			//Txntype -> Purchase
				if(Txntype.equals("Purchase"))
				{
					executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Txntype_Purchase());
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
					waitFor(preauthorizationpageobjects.Search_Textbox());
					if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
					{
						Result8="Failed"+"=>"+"Search with Authtype: "+Txntype+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));	
						if(preauthorizationpageobjects.Preauth_search_Expand.isVisible())
						{
						Result8="Passed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result matches the filter criteria. No of records obatined: "+preauthorizationpageobjects.Preauth_SearchResult.size();
						}
						else
						{
						Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Payment Type -> Payment
				else if(Txntype.equals("Payment"))
				{
					executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Txntype_Payment());
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
					waitFor(preauthorizationpageobjects.Search_Textbox());
					if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
					{
						Result8="Failed"+"=>"+"Search with Authtype: "+Txntype+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));	
						if(preauthorizationpageobjects.Preauth_search_Expand.isVisible())
						{
						Result8="Passed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result matches the filter criteria. No of records obatined: "+preauthorizationpageobjects.Preauth_SearchResult.size();
						}
						else
						{
						Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Payment Type -> Refund
				else if(Txntype.equals("Refund"))
				{
					executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Txntype_Refund());
					wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
					waitFor(preauthorizationpageobjects.Search_Textbox());
					if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
					{
						Result8="Failed"+"=>"+"Search with Authtype: "+Txntype+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
					}
					else
					{
						for(int i=0; i<20; i++)
					    {
						wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
					    }
					    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));	
						if(preauthorizationpageobjects.Preauth_search_Expand.isVisible())
						{
						Result8="Passed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result matches the filter criteria. No of records obatined: "+preauthorizationpageobjects.Preauth_SearchResult.size();
						}
						else
						{
						Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Search Result doesn't match with the filter criteria";	
						}
					}
				}
			//Payment Type - > Other than Purchase , Payment, Refund
				else
				{
				Result8="Failed"+"=>"+"Search with Txntype: "+Txntype+"-> Transaction Type doesn't match with drop down list available";	
				}
		//Reset Filter & clear previous search
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.ResetFilter_button());
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
		//Search with Amount
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.More_Filter()));
			preauthorizationpageobjects.AmtFrom.sendKeys(AmtFrom);
			preauthorizationpageobjects.AmtTo.sendKeys(AmtTo);
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Search_button());
			wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Search_Textbox()));
			if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
			{
				Result9="Failed"+"=>"+"Search with Amount, From: "+AmtFrom+" To: "+AmtTo+"->"+preauthorizationpageobjects.Preauth_NoResult.getText();
			}
			else
			{
				for(int i=0; i<20; i++)
			    {
				wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
			    }
			    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
			    SearchResult_Amt=preauthorizationpageobjects.SearchResult_Amt.get(0);
			    Double iAmtFrom = Double.parseDouble(AmtFrom);
			    Double iAmtTo = Double.parseDouble(AmtTo);
			    if(SearchResult_Amt.getText().startsWith("� "))
			    {
			    Amount =SearchResult_Amt.getText().replaceAll("� ", "");
			    }
			    else if(SearchResult_Amt.getText().startsWith("- � "))
			    {
			    Amount =SearchResult_Amt.getText().replaceAll("- � ", "");
			    }
			    System.out.println("Amount Search Result: "+SearchResult_Amt.getText());
			    System.out.println("Triming �: "+Amount);
			    Double iSearchResult_Amt = Double.parseDouble(Amount);
			    System.out.println("From: "+iAmtFrom);
			    System.out.println("To: "+iAmtTo);
			    System.out.println("Converting to Double: "+iSearchResult_Amt);
				if(iSearchResult_Amt>=iAmtFrom && iSearchResult_Amt<=iAmtTo)
				{
				Result9="Passed"+"=>"+"Search with Amount, From: "+AmtFrom+" To: "+AmtTo+"-> Search Result matches the filter criteria";
				}
				else
				{
				Result9="Failed"+"=>"+"Search with Amount, From: "+AmtFrom+" To: "+AmtTo+"-> Search Result doesn't match with the filter criteria";	
				}
			}
			
		Result="1."+Result1+";----;"+"2."+Result2+";----;"+"3."+Result3+";----;"+"4."+Result4+";----;"+"5."+Result5+";----;"+"6."+Result6+";----;"+"7."+Result7+";----;"+"8."+Result8+";----;"+"9."+Result9;
    }
	return Result;
}

public String user_should_be_able_to_view_Preauthorisations_in_Preauth_view()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String Result1=null;
	wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Search_Textbox()));
	if(preauthorizationpageobjects.Preauth_NoResult.isVisible())
	{
		Result="Failed"+"::"+preauthorizationpageobjects.Preauth_NoResult.getText();
	}
	else
	{
		for(int i=0; i<20; i++)
	    {
		wait.until(ExpectedConditions.visibilityOf(preauthorizationpageobjects.Preauth_search_Expand()));
	    }
	    wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Preauth_search_Expand()));
	   
		for(int i=0;i<preauthorizationpageobjects.Preauth_SearchResult.size();i++)
		{
			
			executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Preauth_SearchResult.get(i));
			waitFor(preauthorizationpageobjects.Preauth_Cardno());
			while(preauthorizationpageobjects.Preauth_Details.size()==0)
			{
				waitFor(preauthorizationpageobjects.Preauth_Cardno());
			}
			
			System.out.println("The size of the preauth objects are:"+preauthorizationpageobjects.Preauth_Details.size());
			for(int j=0;j<10;j++)
			{
			wait.until(ExpectedConditions.not(ExpectedConditions.stalenessOf(preauthorizationpageobjects.Preauth_Details.get(i))));
			}
			TempResult.add("Preauth transaction "+i+"==>"+preauthorizationpageobjects.Preauth_Details.get(i).getText()+";");
			System.out.println(TempResult);
			Result="Passed";
		}
	}
	return Result;
}
public static boolean isDateValidforFromDate_Todate(String date) 
{
    try {
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
        df.setLenient(false);
        df.parse(date);
        return true;
    } catch (ParseException e) {
        return false;
    }
}
public static boolean isDateValid(String date) 
{
    try {
        DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        df.setLenient(false);
        df.parse(date);
        return true;
    } catch (ParseException e) {
        return false;
    }
}
public boolean isFileDownloaded(String downloadPath, String fileName) throws InterruptedException {
	boolean flag = false;
	File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }
	 
    return flag;
}
private File getLatestFilefromDir(String dirPath){
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}

public void checkPageIsReady() throws InterruptedException {

	  JavascriptExecutor js = (JavascriptExecutor)driver;


	  //Initially bellow given if condition will check ready state of page.
	/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
	
	   return; 
	  } 
*/
	  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
	  //You can replace your value with 25 If you wants to Increase or decrease wait time.
	  for (int i=0; i<100; i++){ 
	   //To check page ready state.
	   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   
	    break; 
	   }
	   System.out.println("Page Is loaded.");
	  }
	 }

/*public void clickJS(WebElement webElement){
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 200);
	wait.until(ExpectedConditions.elementToBeClickable(webElement));
	executor.executeScript("arguments[0].click()", webElement);
}*/
}
