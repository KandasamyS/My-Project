package ui.Signon;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.thoughtworks.selenium.webdriven.JavascriptLibrary;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.DocumentAdminPage_object;
import ui.pageobjects.Signon.DocumentPage_object;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SignonPage_objects;

public class Document_Management extends PageObject{
	WebDriver driver =null;
	String Result=null;
	boolean Status=false;
	MessagePage_object messagepageObjects;
	AdminPage_object adminpageObjects;
	DocumentAdminPage_object documentAdminpageobjects;
	DashboardPage_objects dasboardpageobjects;
	SignonPage_objects signonObjects;
	DocumentPage_object documentpageobjects;
	String document_link=null;

@Step
public String permanent_link_Retrive(String userID_LBC,String password_LBC,String downloaded_Path) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,50);
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
	documentAdminpageobjects.document_link.click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.search_Textbox()));
	/*documentAdminpageobjects.search_Textbox().sendKeys(Document_Title);
	documentAdminpageobjects.search_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.search_Textbox()));*/
	//wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_text()));
	System.out.println(documentAdminpageobjects.selected_text.isCurrentlyVisible());
	String Document_title=documentAdminpageobjects.selected_text().getText();
	if(documentAdminpageobjects.selected_text.isCurrentlyVisible())
	{
		System.out.println(documentAdminpageobjects.selected_text().getText());
		documentAdminpageobjects.selected_text().click();
		if(documentAdminpageobjects.document_link_of_each_document.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link_of_each_document()));
			document_link=documentAdminpageobjects.document_link_of_each_document().getText();
			driver.get(document_link);
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.userId_LBC()));
			signonObjects.userId_LBC().sendKeys(userID_LBC);
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.password_LBC()));
			signonObjects.password_LBC().sendKeys(password_LBC);
			signonObjects.submit_lbc().click();
			wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.dashboard_text_LBC()));
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		   
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) || filedetails[0].contains(Document_title))
		    	{
		    		Result="Passed "+fileName+" The document can be downloaded from outside";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
		}
		else
		{
			Result="Failed "+"The document link is not found";
		}
	}
	return Result;
}
@Step
public String Add_a_new_document(String document_Name,String Alliance_name,String Language,String Upload_file,String attachmentPath,String Description_DocumentText) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,100);
	if(!documentAdminpageobjects.document_link.isCurrentlyVisible())
	{adminpageObjects.hidden_button.click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
	documentAdminpageobjects.document_link().click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.add_button()));
	documentAdminpageobjects.add_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.documentName()));
	documentAdminpageobjects.documentName().sendKeys(document_Name);
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.alliance_code()));
	documentAdminpageobjects.alliance_code().sendKeys(Alliance_name);
	checkPageIsReady();
	for(int i=0;i<=30;i++)
	{waitFor(documentAdminpageobjects.language());
	checkPageIsReady();}
	documentAdminpageobjects.language().sendKeys(Language);
	for(int i=0;i<=30;i++)
	{checkPageIsReady();
	waitFor(documentAdminpageobjects.attachmentPath());}
	documentAdminpageobjects.attachmentPath().sendKeys(attachmentPath);
	documentAdminpageobjects.description().sendKeys(Description_DocumentText);
	for(int i=0;i<=30;i++)
	{waitFor(documentAdminpageobjects.documentPath());}
	documentAdminpageobjects.documentPath().sendKeys(Upload_file);
	for(int i=0;i<=30;i++)
	{waitFor(documentAdminpageobjects.uploadeButton());}
	documentAdminpageobjects.uploadeButton().click();
	File f = new File(Upload_file);
	System.out.println(f.getName());
	String filename=f.getName();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));
	if(documentAdminpageobjects.message_top_panel().getText().contains('"'+filename+'"'+" was uploaded. Please save to continue"))
	{
		if(!documentAdminpageobjects.error_message.isCurrentlyVisible())
		{
			documentAdminpageobjects.submit_button().click();
			for(int i=0;i<=10;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));}
			if(documentAdminpageobjects.message_top_panel().getText().contains("Document has been added successfully."))
			{
				Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
			}
			else
			{
				Result="Failed "+"Document has not been added properly.";
			}
		}
		else
		{
			Result="Failed "+"Document needs more input.";
		}
	}
	else
	{
		Result="Failed "+"Failed to attach the file";
	}
	}
	return Result;
}
@Step
public String Rename_a_document(String Rename_document,String Upload_file) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,50);
//	if(!documentAdminpageobjects.document_link.isCurrentlyVisible())
//	{adminpageObjects.hidden_button.click();
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.home_link_admin));
	adminpageObjects.home_link_admin.click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
	documentAdminpageobjects.document_link.click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_firstRow()));
	File f = new File(Upload_file);
	System.out.println(f.getName());
	String filename=f.getName();
	
	for(int i=0;i<documentAdminpageobjects.Document_Table_list.size();i++)	
	{
		if(documentAdminpageobjects.Document_Table_list.get(i).getText().contains(filename))
		{
			documentAdminpageobjects.selected_firstRow().click();
			waitFor(documentAdminpageobjects.documentName());
			documentAdminpageobjects.documentName().clear();
			documentAdminpageobjects.documentName().sendKeys(Rename_document);
			for(int i1=0;i<=10;i++)
			{waitFor(documentAdminpageobjects.submit_button());}
			documentAdminpageobjects.submit_button().click();
			for(int i1=0;i<=10;i++)
			{waitFor(documentAdminpageobjects.message_top_panel());}
			if(documentAdminpageobjects.message_top_panel().getText().contains("Document has been added successfully."))
			{
				Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
			}
			else
			{
				Result="Failed "+"Document has not been added properly.";
			}
		}
		else
		{
			Result="Failed "+"No Document are there for now";
		}
	}

	return Result;
}
@Step
public String Remove_a_document(String Upload_file) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,50);
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.home_link_admin));
	adminpageObjects.home_link_admin.click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
	documentAdminpageobjects.document_link().click();
	File f = new File(Upload_file);
	System.out.println(f.getName());
	String filename=f.getName();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_firstRow()));
	for(int i=0;i<documentAdminpageobjects.Document_Table_list.size();i++)	
	{
		if(documentAdminpageobjects.Document_Table_list.get(i).getText().contains(filename))
		{
			for(int i1=0;i1<=10;i1++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.delete_button()));
				checkPageIsReady();
			}
			documentAdminpageobjects.delete_button().click();
			for(int i1=0;i1<=80;i1++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));
				checkPageIsReady();
			}
			if(documentAdminpageobjects.message_top_panel().getText().contains("Documents "+'"'+filename+'"'+" was deleted."))
			{
				Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
			}
			else
			{
				Result="Failed "+"The document is not deleted.";
			}
			//"Documents "pdf-sample.pdf" was deleted."
		}
		else
		{
			Result="Failed "+"No Document are there for now";
		}
	}
	
	return Result;
	
}
@Step
public String marked_unread_document(/*String folderName*/) throws Throwable{
	driver = this.getDriver();
	int count1=0;
	String Result1=null;
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
		dasboardpageobjects.documents_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
		int count=documentpageobjects.folderslist.size();
	    System.out.println("Number of folders is:"+count);
	    for(int i=0;i<documentpageobjects.folderslist.size();i++)
	    {
	    	System.out.println(documentpageobjects.folderslist.get(i).getText());
	    	waitFor(documentpageobjects.folderslist.get(i)).click();
	    	for(int i1=0;i1<documentpageobjects.DocumentList.size();i1++)
	    	{
	    		waitFor(documentpageobjects.DocumentList.get(i1));
	    		String unread_status=documentpageobjects.DocumentList.get(i1).getAttribute("class");
	    				if(unread_status.equals("ng-binding"))
	    				{
	    					Result1="Passed "+"For Now no unread documents are present";
	    				}
	                    
	    				else
	    				{
	    					
	    					count1 =count1+1;
	    					Result1="Passed "+"Unread count is : "+count1;
	    				}
	    	}    
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
			dasboardpageobjects.documents_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
	    }
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
		dasboardpageobjects.documents_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
		int count=documentpageobjects.folderslist.size();
	    System.out.println("Number of folders is:"+count);
	    for(int i=0;i<documentpageobjects.folderslist.size();i++)
	    {
	    	System.out.println(documentpageobjects.folderslist.get(i).getText());
	    	waitFor(documentpageobjects.folderslist.get(i)).click();
	    	for(int i1=0;i1<documentpageobjects.DocumentList.size();i1++)
	    	{
	    		waitFor(documentpageobjects.DocumentList.get(i1));
	    		String unread_status=documentpageobjects.DocumentList.get(i1).getAttribute("class");
	    				if(unread_status.equals("ng-binding"))
	    				{
	    					Result1="Passed "+"For Now no unread documents are present";
	    				}
	                    
	    				else
	    				{
	    					
	    					count1 =count1+1;
	    					Result1="Passed "+"Unread count is : "+count1;
	    				}
	    	}    
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
			dasboardpageobjects.documents_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
	    }
	}
    Result=Result1;
    
	return Result;
}

@Step
public String Download_document_from_document_library(String downloaded_Path,String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptLibrary jsLib = new JavascriptLibrary();
	int count1=0;
	String Result1=null;
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
		dasboardpageobjects.documents_Link().click();
		for(int i=0;i<=50;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
		checkPageIsReady();}
		for(int i=0;i<documentpageobjects.AllDocumentListView.size();i++)
		{
			if(documentpageobjects.AllDocumentListView.get(i).isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",documentpageobjects.AllDocumentListView.get(i));
				for(int i1=0;i1<=50;i1++)
				{checkPageIsReady();}
				if(documentpageobjects.no_files_text.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
					documentpageobjects.all_document_link().click();
				}
				else
				{
					wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.listwiseView()));
					documentpageobjects.listwiseView().click();
					for(int i1=0;i1<=50;i1++)
					{checkPageIsReady();}
					List<WebElement> allcheckbox_css=driver.findElements(By.cssSelector("input[id='cleckbox-all']"));
					System.out.println(allcheckbox_css);
					String id=allcheckbox_css.get(0).getAttribute("id");
		            System.out.println(id);
		            jsLib.executeScript(driver,"document.getElementById('"+id+"').click()");
		            String[]no_of_documents=documentpageobjects.no_of_document.getText().split("-");
		            int no_documents=Integer.parseInt(no_of_documents[1]);
		            if(no_documents>1)
		            { 
		            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));
			            documentpageobjects.download_selected().click();
			            for(int i1=0;i1<=150;i1++)
						{checkPageIsReady();
						wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));}
			            File getLatestFile = getLatestFilefromDir(downloaded_Path);
			    	    String fileName = getLatestFile.getName();
			    	    String []filedetails=fileName.split("_");
			    	    long length = getLatestFile.length();
			    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
			    	    		&& isDateValid(filedetails[1]) && fileName.endsWith(".zip"))
			    	    {
			    	    	Result="Passed "+fileName+" File got downloaded successfully";
			    	    }
			    	    else
			    	    {
			    	    	Result="Failed "+"File is not there in the folder";
			    	    }
			         }
		            else if(no_documents==1)
		            {
		            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_button()));
		            	documentpageobjects.download_button().click();
			            File getLatestFile = getLatestFilefromDir(downloaded_Path);
			    	    String fileName = getLatestFile.getName();
			    	    String []filedetails=fileName.split("_");
			    	    long length = getLatestFile.length();
			    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
			    	    {
			    	    	Result="Passed "+fileName+" File got downloaded successfully";
			    	    }
			    	    else
			    	    {
			    	    	Result="Failed "+"File is not there in the folder";
			    	    }
		            }
		    	    wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
					documentpageobjects.all_document_link().click();
				}
			}
			else
			{
				Result="Failed "+"No document folders are present right now";
			}
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
		dasboardpageobjects.documents_Link().click();
		for(int i=0;i<=50;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
		checkPageIsReady();}
		for(int i=0;i<documentpageobjects.AllDocumentListView.size();i++)
		{
			if(documentpageobjects.AllDocumentListView.get(i).isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",documentpageobjects.AllDocumentListView.get(i));
				for(int i1=0;i1<=50;i1++)
				{checkPageIsReady();}
				if(documentpageobjects.no_files_text.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
					documentpageobjects.all_document_link().click();
				}
				else
				{
					wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.listwiseView()));
					documentpageobjects.listwiseView().click();
					for(int i1=0;i1<=50;i1++)
					{checkPageIsReady();}
					List<WebElement> allcheckbox_css=driver.findElements(By.cssSelector("input[id='cleckbox-all']"));
					System.out.println(allcheckbox_css);
					String id=allcheckbox_css.get(0).getAttribute("id");
		            System.out.println(id);
		            jsLib.executeScript(driver,"document.getElementById('"+id+"').click()");
		            String[]no_of_documents=documentpageobjects.no_of_document.getText().split("-");
		            int no_documents=Integer.parseInt(no_of_documents[1]);
		            if(no_documents>1)
		            { 
		            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));
			            documentpageobjects.download_selected().click();
			            for(int i1=0;i1<=150;i1++)
						{checkPageIsReady();
						wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));}
			            File getLatestFile = getLatestFilefromDir(downloaded_Path);
			    	    String fileName = getLatestFile.getName();
			    	    String []filedetails=fileName.split("_");
			    	    long length = getLatestFile.length();
			    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
			    	    		&& isDateValid(filedetails[1]) && fileName.endsWith(".zip"))
			    	    {
			    	    	Result="Passed "+fileName+" File got downloaded successfully";
			    	    }
			    	    else
			    	    {
			    	    	Result="Failed "+"File is not there in the folder";
			    	    }
			         }
		            else if(no_documents==1)
		            {
		            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_button()));
		            	documentpageobjects.download_button().click();
			            File getLatestFile = getLatestFilefromDir(downloaded_Path);
			    	    String fileName = getLatestFile.getName();
			    	    String []filedetails=fileName.split("_");
			    	    long length = getLatestFile.length();
			    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
			    	    {
			    	    	Result="Passed "+fileName+" File got downloaded successfully";
			    	    }
			    	    else
			    	    {
			    	    	Result="Failed "+"File is not there in the folder";
			    	    }
		            }
		    	    wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
					documentpageobjects.all_document_link().click();
				}
			}
			else
			{
				Result="Failed "+"No document folders are present right now";
			}
		}
	}
		
	return Result;
	
}
public static boolean isDateValid(String date) 
{
    try {
        DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        df.setLenient(false);
        df.parse(date);
        return true;
    } catch (ParseException e) {
        return false;
    }
}
public boolean isFileDownloaded(String downloadPath, String fileName) throws InterruptedException {
	boolean flag = false;
	File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }
	 
    return flag;
}
private File getLatestFilefromDir(String dirPath) throws InterruptedException{
	for(int i1=0;i1<=80;i1++)
	{checkPageIsReady();}
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}
public void checkPageIsReady() throws InterruptedException {

	  JavascriptExecutor js = (JavascriptExecutor)driver;


	  //Initially bellow given if condition will check ready state of page.
	/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
	
	   return; 
	  } 
*/
	  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
	  //You can replace your value with 25 If you wants to Increase or decrease wait time.
	  for (int i=0; i<100; i++){ 
	   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   
	    break; 
	   }
	   System.out.println("Page Is loaded.");
	  }
	 }


}

