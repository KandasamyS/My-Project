package ui.Signon;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.websocket.common.message.MessageInputStream;
import org.jruby.ast.DAsgnNode;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.thoughtworks.selenium.webdriven.commands.Check;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SignonPage_objects;

public class MessagePage extends PageObject{
	WebDriver driver =null;
	String Result=null;
	boolean Status=false;
	MessagePage_object messagepageObjects;
	AdminPage_object adminpageObjects;
	DashboardPage_objects dasboardpageobjects;
	SignonPage_objects signonObjects;
	String message_link=null;
		
@Step	
public String Print_option_Message(String Message_text){
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	messagepageObjects.messages_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.messages_text()));
	if(messagepageObjects.messages_text().getText().equals(Message_text))
	{
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.print_option()));
		messagepageObjects.print_option().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
	}
@Step	
public String Create_message(String Alliance_Name, String language, String type, String title, String sub_title, String date_received, String Validity_type, String In_days_Validity_days, String message_body) throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,100);
		/*if(!adminpageObjects.GUI_Message.isCurrentlyVisible())
		{adminpageObjects.hidden_button.click();*/
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
		adminpageObjects.GUI_Message().click();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Add_button()));
		adminpageObjects.Add_button().click();
		for(int i=0;i<=80;i++)
		{checkPageIsReady();waitForWithRefresh();		
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.allianceCode_dropdown()));}
		adminpageObjects.allianceCode_dropdown().sendKeys(Alliance_Name);
		System.out.println(Alliance_Name+"Donef0");
		waitForWithRefresh();
		for(int i=0;i<=100;i++)
		{checkPageIsReady();waitForWithRefresh();		
		waitFor(adminpageObjects.Language_msg_dropdown());}
		//new Select(adminpageObjects.Language_msg_dropdown()).selectByVisibleText(language);
		adminpageObjects.Language_msg_dropdown().sendKeys(language);
		adminpageObjects.type_dropdown().sendKeys(type);
		adminpageObjects.message_title().sendKeys(title);
		adminpageObjects.message_subTitle().sendKeys(sub_title);
		adminpageObjects.date_picker().sendKeys(date_received);
		adminpageObjects.Flag_notification().click();
		if(Validity_type.equals("In days"))
		{
			adminpageObjects.Indays_validity().click();
			adminpageObjects.Indays_validity_days().sendKeys(In_days_Validity_days);
		}
		else if(Validity_type.equals("Unlimited"))
		{
			adminpageObjects.unlimited_validity().click();
		}
		adminpageObjects.messagebody().sendKeys(message_body);
		adminpageObjects.save_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
		System.out.println(adminpageObjects.Created_successfully_text().getText());
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		if(adminpageObjects.Created_successfully_text().getText().contains("Message "+'"'+title+'"'+" has been added successfully."))
		{
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
			Result="Passed "+adminpageObjects.Created_successfully_text().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
			Result="Failed"+adminpageObjects.Created_successfully_text().getText();
		}

	return Result;
}
@Step
public String Download_attachment_from_message(String message_Title) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.messages_Link));
		dasboardpageobjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.searchbox_message()));
		messagepageObjects.searchbox_message().sendKeys(message_Title);
		executor.executeScript("arguments[0].click()",messagepageObjects.search_Button());
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
		if(messagepageObjects.Message_Title().getText().equals(message_Title))
		{
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			if(messagepageObjects.Download_all_attachment.isCurrentlyVisible())
			{
				
				wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Download_all_attachment()));
				executor.executeScript("arguments[0].click()", messagepageObjects.Download_all_attachment());
				for(int i=0;i<=100;i++)
				{
					checkPageIsReady();
				}
				Result = "Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="Failed";
		}
	}
	else
	{
		dasboardpageobjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.searchbox_message()));
		messagepageObjects.searchbox_message().sendKeys(message_Title);
		messagepageObjects.search_Button().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
		if(messagepageObjects.Message_Title().getText().equals(message_Title))
		{
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			if(messagepageObjects.Download_all_attachment.isCurrentlyVisible())
			{
				
				wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Download_all_attachment()));
				executor.executeScript("arguments[0].click()", messagepageObjects.Download_all_attachment());
				Result = "Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="Failed";
		}
	}
	return Result;
}
@Step
public String validation_of_message_template(String message_Title) throws Throwable{
	driver = this.getDriver();	
	String message_type=null;
	WebDriverWait wait = new WebDriverWait(driver,20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.messages_Link()));
		messagepageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.searchbox_message()));
		messagepageObjects.searchbox_message().sendKeys(message_Title);
		executor.executeScript("arguments[0].click()",messagepageObjects.search_Button());
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
		if(messagepageObjects.Message_Title().getText().equals(message_Title))
		{
					
					if(messagepageObjects.message_subTitle.isCurrentlyVisible() && messagepageObjects.date_time.isCurrentlyVisible())
					{
						//System.out.println(messagepageObjects.message_bodyText().getText());
						
						driver.switchTo().frame("message-content-object");
						System.out.println(messagepageObjects.message_bodyText().getText());
						System.out.println(messagepageObjects.Download_all_attachment.isCurrentlyVisible());
						if(messagepageObjects.message_bodyText().getText()!=null && messagepageObjects.Download_all_attachment.isCurrentlyVisible()){
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							Result="Passed"+":"+message_type+","+"Attachement and message body text is available";
						}
						else if (messagepageObjects.message_bodyText().getText()!=null || messagepageObjects.Download_all_attachment.isCurrentlyVisible())
						{
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							Result="Passed"+":"+message_type+","+"Attachement or message body text is available";
						}
						else
						{
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							Result="Passed"+" "+"Both are not available";
						}
					}	
			}
	
				
			else
			{
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				Result="Failed"+" "+"No message found";
			}
	}
	else
	{
		messagepageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.searchbox_message()));
		messagepageObjects.searchbox_message().sendKeys(message_Title);
		messagepageObjects.search_Button().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
		if(messagepageObjects.Message_Title().getText().equals(message_Title))
		{
			if(messagepageObjects.notification_flag_type.isCurrentlyVisible() && messagepageObjects.notification_flag_type().getAttribute("class").equals("fa  fa-bullhorn"))
			{
					message_type="Notification";
					String status[]=messagepageObjects.message_status_readunread().getAttribute("class").split(" ");
					if(messagepageObjects.message_subTitle.isCurrentlyVisible() && messagepageObjects.date_time.isCurrentlyVisible() && messagepageObjects.archieve_button.isCurrentlyEnabled())
					{
						//System.out.println(messagepageObjects.message_bodyText().getText());
						
						driver.switchTo().frame("message-content-object");
						System.out.println(messagepageObjects.message_bodyText().getText());
						System.out.println(messagepageObjects.Download_all_attachment.isCurrentlyVisible());
						if(messagepageObjects.message_bodyText().getText()!=null && messagepageObjects.Download_all_attachment.isCurrentlyVisible()){
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							Result="Passed"+":"+message_type+","+status[1]+"Attachement and message body text is available";
						}
						else if (messagepageObjects.message_bodyText().getText()!=null || messagepageObjects.Download_all_attachment.isCurrentlyVisible())
						{
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							Result="Passed"+":"+message_type+","+status[1]+"Attachement or message body text is available";
						}
						else
						{
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							Result="Passed"+" "+"Both are not available";
						}
					}	
			}
			else if(messagepageObjects.alert_flag_type.isCurrentlyVisible() && messagepageObjects.alert_flag_type().getAttribute("class").equals("fa  fa-info-circle"))
			{
				message_type="Alert";
				String status[]=messagepageObjects.message_status_readunread().getAttribute("class").split(" ");
				if(messagepageObjects.message_subTitle.isCurrentlyVisible() && messagepageObjects.date_time.isCurrentlyVisible() && messagepageObjects.archieve_button.isCurrentlyEnabled())
				{
					if(messagepageObjects.message_bodyText().getText()!=null && messagepageObjects.Download_all_attachment.isCurrentlyVisible()){
						driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
						Result="Passed"+":"+message_type+","+status[1]+"Attachement and message body text is available";
					}
					else if (messagepageObjects.message_bodyText().getText()!=null || messagepageObjects.Download_all_attachment.isCurrentlyVisible())
					{
						driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
						Result="Passed"+":"+message_type+","+status[1]+"Attachement or message body text is available";
					}
					else
					{
						driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
						Result="Passed"+" "+"Both are not available";
					}
				}
			}
			
			
		}
		
			else
			{
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				Result="Failed"+" "+"No message found";
			}
	}
	
	return Result;
	
}
@Step
public String permanent_link_Retrive(String userID_LBC,String password_LBC,String message_Title) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,120);
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
	adminpageObjects.GUI_Message().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_box));
	adminpageObjects.search_box().sendKeys(message_Title);
	adminpageObjects.search_button().click();
	for(int i=0;i<=50;i++)
	{checkPageIsReady();}
	if(adminpageObjects.selected_message().getText().equals(message_Title))
	{
		System.out.println(adminpageObjects.selected_message().getText());
		adminpageObjects.selected_message().click();
		if(adminpageObjects.message_link.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.message_link()));
			message_link=adminpageObjects.message_link().getText();
			driver.get(message_link);
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
			signonObjects.UserName().sendKeys(userID_LBC);
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Password()));
			signonObjects.Password().sendKeys(password_LBC);
			signonObjects.Submit().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
			if(messagepageObjects.Message_Title().getText().equals(message_Title))
			{
				Result="Passed"+message_Title;
			}
			else{
				Result="Failed";
			}	
		}
		else{
			Result="Failed";
		}
	}
	else
	{
		Result="Failed"+" "+"No message found";
	}
	
	return Result;
}
@Step
public String pagination_of_message() throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.messages_Link()));
		messagepageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.inbox_link));
		executor.executeScript("arguments[0].click()",messagepageObjects.inbox_link);
		for(int i=0;i<=25;i++){checkPageIsReady();}
		if(messagepageObjects.more_message_pagination.isCurrentlyVisible())
		{
			
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.more_message_pagination()));
			executor.executeScript("arguments[0].click()", messagepageObjects.more_message_pagination());
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			Result="Passed " ;
			
		 }
		else
		{
			Result="Failed "+ "no paging is available";
		}
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.messages_Link()));
		messagepageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.inbox_message_count()));
		String convertmessagecount=messagepageObjects.inbox_message_count().getText().toString();
		System.out.println(messagepageObjects.inbox_message_count().getText());
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.inbox_message_count()));
		//System.out.println(messagepageObjects.inbox_message_count().getText().toString());
		int read_message_count=Integer.parseInt(convertmessagecount);
		System.out.println(read_message_count);
		if(messagepageObjects.more_message_pagination.isCurrentlyVisible())
		{
			for(int i=0; i<=read_message_count/10; i++)
		 {
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.more_message_pagination()));
			executor.executeScript("arguments[0].click()", messagepageObjects.more_message_pagination());
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
		 }
			Result="Passed "+ read_message_count ;
		}
		else
		{
			Result="Failed "+ "no paging is available";
		}
	}
	return Result;
}

@Step
public String display_message_in_descending_order() throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.messages_Link()));
		messagepageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.inbox_link));
		executor.executeScript("arguments[0].click()",messagepageObjects.inbox_link);
		for(int i=0;i<=25;i++){checkPageIsReady();}
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.message_start_date_list));
		String current_date_of_message=messagepageObjects.message_start_date_list.getText();
		if(messagepageObjects.more_message_pagination.isCurrentlyVisible())
		{
			
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.more_message_pagination()));
			executor.executeScript("arguments[0].click()", messagepageObjects.more_message_pagination());
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.message_end_date_list()));
			String Last_date_of_message=messagepageObjects.message_end_date_list().getText();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	        Date date1 = sdf.parse(current_date_of_message);
	        Date date2 = sdf.parse(Last_date_of_message);
	
	        System.out.println("Date1"+sdf.format(date1));
	        System.out.println("Date2"+sdf.format(date2));
	        if(date1.after(date2)){
	            System.out.println("Date1 is after Date2");
	            Result="Passed "+" The display order is in descending mode ";
	        }
	        // before() will return true if and only if date1 is before date2
	        else if(date1.before(date2)){
	            System.out.println("Date1 is before Date2");
	            Result="Failed "+" The display order is in Ascending mode ";
	        }
	
	        //equals() returns true if both the dates are equal
	        else if(date1.equals(date2)){
	            System.out.println("Date1 is equal Date2");
	            Result="Failed "+" Both the messages are created in same time. ";
	            
	        }
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.message_end_date_list()));
			String Last_date_of_message=messagepageObjects.message_end_date_list().getText();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	        Date date1 = sdf.parse(current_date_of_message);
	        Date date2 = sdf.parse(Last_date_of_message);
	
	        System.out.println("Date1"+sdf.format(date1));
	        System.out.println("Date2"+sdf.format(date2));
	        if(date1.after(date2)){
	            System.out.println("Date1 is after Date2");
	            Result="Passed "+" The display order is in descending mode ";
	        }
	        // before() will return true if and only if date1 is before date2
	        else if(date1.before(date2)){
	            System.out.println("Date1 is before Date2");
	            Result="Failed "+" The display order is in Ascending mode ";
	        }
	
	        //equals() returns true if both the dates are equal
	        else if(date1.equals(date2)){
	            System.out.println("Date1 is equal Date2");
	            Result="Failed "+" Both the messages are created in same time. ";
	        }
		}
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.messages_Link()));
		messagepageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.inbox_message_count()));
		String messagecount=messagepageObjects.inbox_message_count().getText();
		System.out.println("messagecount "+messagepageObjects.inbox_message_count().getText());
		int read_message_count=Integer.valueOf(messagecount);
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.message_start_date_list));
		String current_date_of_message=messagepageObjects.message_start_date_list.getText();
		if(messagepageObjects.more_message_pagination.isCurrentlyVisible())
		{
			for(int i=0; i<=read_message_count/10; i++)
		 {
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.more_message_pagination()));
			executor.executeScript("arguments[0].click()", messagepageObjects.more_message_pagination());
		 }	
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.message_end_date_list()));
			String Last_date_of_message=messagepageObjects.message_end_date_list().getText();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	        Date date1 = sdf.parse(current_date_of_message);
	        Date date2 = sdf.parse(Last_date_of_message);
	
	        System.out.println("Date1"+sdf.format(date1));
	        System.out.println("Date2"+sdf.format(date2));
	        if(date1.after(date2)){
	            System.out.println("Date1 is after Date2");
	            Result="Passed "+" The display order is in descending mode ";
	        }
	        // before() will return true if and only if date1 is before date2
	        else if(date1.before(date2)){
	            System.out.println("Date1 is before Date2");
	            Result="Failed "+" The display order is in Ascending mode ";
	        }
	
	        //equals() returns true if both the dates are equal
	        else if(date1.equals(date2)){
	            System.out.println("Date1 is equal Date2");
	            Result="Failed "+" Both the messages are created in same time. ";
	            
	        }
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.message_end_date_list()));
			String Last_date_of_message=messagepageObjects.message_end_date_list().getText();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	        Date date1 = sdf.parse(current_date_of_message);
	        Date date2 = sdf.parse(Last_date_of_message);
	
	        System.out.println("Date1"+sdf.format(date1));
	        System.out.println("Date2"+sdf.format(date2));
	        if(date1.after(date2)){
	            System.out.println("Date1 is after Date2");
	            Result="Passed "+" The display order is in descending mode ";
	        }
	        // before() will return true if and only if date1 is before date2
	        else if(date1.before(date2)){
	            System.out.println("Date1 is before Date2");
	            Result="Failed "+" The display order is in Ascending mode ";
	        }
	
	        //equals() returns true if both the dates are equal
	        else if(date1.equals(date2)){
	            System.out.println("Date1 is equal Date2");
	            Result="Failed "+" Both the messages are created in same time. ";
	        }
		}
	}
	
	return Result;
	
}
@Step
public String modify_the_Message(String Message_title,String Sub_title,String message_body,String Upload_file) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,150);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
	adminpageObjects.GUI_Message().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_box()));
	adminpageObjects.search_box().sendKeys(Message_title);
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_button()));
	adminpageObjects.search_button().click();
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.message_title_selected()));
	System.out.println(adminpageObjects.message_title_selected.isCurrentlyVisible());
	if(!adminpageObjects.no_records_found.isCurrentlyVisible())
	{
		waitForWithRefresh();
		//System.out.println(adminpageObjects.selected_message().getText());
		waitFor(adminpageObjects.message_title_selected());
		if(adminpageObjects.message_title_selected().getText().equals(Message_title))
		{
			adminpageObjects.selected_message().click();
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.message_title()));
			adminpageObjects.message_subTitle.clear();
			adminpageObjects.message_subTitle().sendKeys(Sub_title);
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.messagebody()));
			//adminpageObjects.messagebody().clear();
			adminpageObjects.messagebody.sendKeys(message_body);
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.AttachmentLink()));
			File f = new File(Upload_file);
			System.out.println(f.getName());
			String filename=f.getName();
			
			if(f.getName().endsWith(".pdf"))
			{
				adminpageObjects.AttachmentLink().sendKeys(Upload_file);
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.upload_button()));
				adminpageObjects.upload_button().click();
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
				System.out.println(adminpageObjects.Created_successfully_text().getText()+filename);
				if(adminpageObjects.Created_successfully_text().getText().contains('"'+filename+'"'+" was uploaded. Please save to continue"))
				{
					//wait.until(ExpectedConditions.elementToBeSelected(adminpageObjects.save_button()));
					adminpageObjects.save_button().click();
					wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
					//wait.until((ExpectedConditions.elementToBeSelected(adminpageObjects.search_button())));
					Result="Passed "+adminpageObjects.Created_successfully_text().getText();
				}
				else
				{
					Result="Failed "+"File cannot be uploaded";
					wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.cancel_button()));
					adminpageObjects.cancel_button().click();
				}
			}
			else
			{
				Result="Failed "+"File extensions is not applicable only require .pdf";
			}
		}
		else
		{
			Result="Failed "+"No Message is there..failed to fetch the message";
		}	
	}
	else
	{
		Result="Failed "+adminpageObjects.no_records_found().getText();
	}
	return Result;
}
@Step
public String delete_the_Message(String Message_title) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.home_link_admin));
	adminpageObjects.home_link_admin.click();
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
	adminpageObjects.GUI_Message().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_box()));
	adminpageObjects.search_box().sendKeys(Message_title);
	wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_button()));
	executor.executeScript("arguments[0].click()",adminpageObjects.search_button());
	for(int i=0;i<=60;i++){wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.selected_message()));}
	if(!adminpageObjects.no_records_found.isCurrentlyVisible())
	{
		for(int i=0;i<=50;i++)
		{waitFor(adminpageObjects.selected_message());}
		if(adminpageObjects.selected_message.getText().equals(Message_title))
		{	
			for(int i=0;i<=50;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.deletebutton()));}
			adminpageObjects.deletebutton().click();
			for(int i=0;i<=50;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));}
			System.out.println(adminpageObjects.Created_successfully_text().getText());
			if(adminpageObjects.Created_successfully_text().getText().contains("Message "+'"'+Message_title+'"'+" was deleted."))
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
				Result="Passed "+adminpageObjects.Created_successfully_text().getText();
			}
			else
			{
				Result="Failed "+"Message was not deleted";
			}
		}
		else
		{
		Result="Failed "+"No Message is there..failed to fetch the message";
		}
	}	

	else
	{
		Result="Failed "+adminpageObjects.no_records_found().getText();
	}
	return Result;
	}
public void checkPageIsReady() throws InterruptedException {

	  JavascriptExecutor js = (JavascriptExecutor)driver;


	  //Initially bellow given if condition will check ready state of page.
	/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
	
	   return; 
	  } 
*/
	  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
	  //You can replace your value with 25 If you wants to Increase or decrease wait time.
	  for (int i=0; i<100; i++){ 
	   //To check page ready state.
	   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   
	    break; 
	   }
	   System.out.println("Page Is loaded.");
	  }
	 }
}
