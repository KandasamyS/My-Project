package ui.Signon;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SettingsuserPage_object;
import ui.pageobjects.Signon.SignonPage_objects;
import ui.pageobjects.Signon.UserManagementPage_objects;

public class Impersonation extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonPage_objects signonObjects;
	DashboardPage_objects dasboardpageObjects;
	//MessagePage_Objects messagepageobjects;
	MessagePage_object messagepageObjects;
	SettingsuserPage_object settingspageobjects;
	UserManagementPage_objects usermanagementpageobjects;
	
@Step
public String user_clicks_submit_and_should_be_logged_in_as_call_center_agent() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	signonObjects.Submit().click();
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(dasboardpageObjects.Impersonation_Welcome_Text()),ExpectedConditions.visibilityOf(signonObjects.Login_error())));
	if(dasboardpageObjects.Impersonation_Welcome_Text.isCurrentlyVisible())
	{
		Result="Passed"+"::"+"Successful Login; Welcome Text:"+dasboardpageObjects.Impersonation_Welcome_Text.getText();
	}
	else if(signonObjects.Login_error.isDisplayed())
	{
		Result="Failed"+"::"+signonObjects.Login_error.getText();
	}
	else 
	{
		Result="Failed";	
	}
	return Result;
}
}
