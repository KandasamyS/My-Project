package ui.Signon;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.xalan.templates.ElemApplyImport;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.gl.E;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.pages.WebElementState;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SettingsuserPage_object;
import ui.pageobjects.Signon.SignonPage_objects;
import ui.pageobjects.Signon.UserManagementPage_objects;
public class Dashboard_Navigation extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonPage_objects signonObjects;
	DashboardPage_objects dasboardpageObjects;
	//MessagePage_Objects messagepageobjects;
	MessagePage_object messagepageObjects;
	SettingsuserPage_object settingspageobjects;
	UserManagementPage_objects usermanagementpageobjects;
	
@Step
public String Dashboard_cookie_information_link(String Device) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if(Device.equalsIgnoreCase("desktop"))
	{
		if(dasboardpageObjects.Portal_cookie_message.getText().equals("By using our website, you agree to EMS� use of cookies."))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.portal_cookie_details()));
			dasboardpageObjects.portal_cookie_details().click();
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.cookie_page()));
			if(dasboardpageObjects.cookie_page().getText().equals("Privacy & Cookie Policy"))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
			driver.close();
			driver.switchTo().window(tabs2.get(0));
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		if(dasboardpageObjects.Portal_cookie_message.getText().equals("By using our website, you agree to EMS� use of cookies."))
		{String cookie_message=dasboardpageObjects.Portal_cookie_message.getText();
			if(dasboardpageObjects.understood_cookie_policy.isCurrentlyVisible())
			{
				dasboardpageObjects.understood_cookie_policy.click();
				if(!dasboardpageObjects.understood_cookie_policy.isCurrentlyVisible())
				{Result="Passed "+ cookie_message;}
				else
				{
					Result="Failed ";
				}
			}
			Result="Failed ";
			
		}
		else
		{
			Result="Failed "+"The cookie policy message is not availble in this view ";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		if(dasboardpageObjects.Portal_cookie_message.getText().equals("By using our website, you agree to EMS� use of cookies."))
		{String cookie_message=dasboardpageObjects.Portal_cookie_message.getText();
			if(dasboardpageObjects.understood_cookie_policy.isCurrentlyVisible())
			{
				dasboardpageObjects.understood_cookie_policy.click();
				if(!dasboardpageObjects.understood_cookie_policy.isCurrentlyVisible())
				{Result="Passed "+cookie_message;}
				else
				{
					Result="Failed ";
				}
			}
			Result="Failed ";
			
		}
		else
		{
			Result="Failed "+"The cookie policy message is not availble in this view ";
		}
	}
	return Result;	
}
@Step
public String Unread_message_count(String Device) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
			
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			if(dasboardpageObjects.message_indicator_count().getText()!=null)
			{
				Result="Passed"+":"+dasboardpageObjects.message_indicator_count().getText();
			}
			
		}
		
		else
		{
			Result="Passed"+":"+"No unread message are there for now";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
			
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			if(dasboardpageObjects.message_indicator_count().getText()!=null)
			{
				Result="Passed"+":"+dasboardpageObjects.message_indicator_count().getText();
			}
			
		}
		
		else
		{
			Result="Passed"+":"+"No unread message are there for now";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
			
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			if(dasboardpageObjects.message_indicator_count().getText()!=null)
			{
				Result="Passed"+":"+dasboardpageObjects.message_indicator_count().getText();
				executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
			}
			
		}
		
		else
		{
			Result="Passed"+":"+"No unread message are there for now";
			executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		}
	}
	return Result;
}
@Step
public String Unread_Document_count(String Device) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		if(dasboardpageObjects.document_indicator_count.isCurrentlyVisible())	
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			if(dasboardpageObjects.document_indicator_count().getText()!=null)
			{
				Result="Passed"+":"+dasboardpageObjects.document_indicator_count().getText();
			}
		}
		else
		{
			Result="Failed"+":"+dasboardpageObjects.document_indicator_count().getText()+":"+"No unread Document are there for now";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		if(dasboardpageObjects.document_indicator_count.isCurrentlyVisible())	
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			if(dasboardpageObjects.document_indicator_count().getText()!=null)
			{
				Result="Passed"+":"+dasboardpageObjects.document_indicator_count().getText();
			}
		}
		else
		{
			Result="Failed"+":"+dasboardpageObjects.document_indicator_count().getText()+":"+"No unread Document are there for now";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		if(dasboardpageObjects.document_indicator_count.isCurrentlyVisible())	
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
		if(dasboardpageObjects.document_indicator_count().getText()!=null)
		{
			Result="Passed"+":"+dasboardpageObjects.document_indicator_count().getText();
			executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		}
		}
		else
		{
			Result="Failed"+":"+dasboardpageObjects.document_indicator_count().getText()+":"+"No unread Document are there for now";
			executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		}
		
		
	}
	return Result;
}
@Step
public String Verify_dashboard_panel_Navigation(String Pre_authorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Messages_Text, String Documents_Text,String Device) {
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 30);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		executor.executeScript("arguments[0].click()", dasboardpageObjects.preauthorization_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
		if(dasboardpageObjects.preauthorization_text().getText().equals(Pre_authorizations_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link()));
		//new Actions(driver).moveToElement(dasboardpageObjects.Authorizations_Link).perform();  
		executor.executeScript("arguments[0].click()", dasboardpageObjects.Authorizations_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_text()));
		if(dasboardpageObjects.Authorizations_text().getText().equals(Authorizations_Text))
		{
		
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.transaction_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_text()));
		if(dasboardpageObjects.transaction_text().getText().equals(Transactions_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.funding_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
		if(dasboardpageObjects.funding_text().getText().equals(Funding_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.messages_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
		if(dasboardpageObjects.messages_text().getText().equals(Messages_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.documents_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
		if(dasboardpageObjects.documents_text().getText().equals(Documents_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		/*wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.more_option());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_option()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.help_option());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_text()));
		if(dasboardpageObjects.help_text().getText().equals(Help_Text))
		{
			Status = true;
		}
		else{
			Status=false;
			
		}*/
		if (Status==true)
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		executor.executeScript("arguments[0].click()", dasboardpageObjects.preauthorization_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
		if(dasboardpageObjects.preauthorization_text().getText().equals(Pre_authorizations_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link()));
		//new Actions(driver).moveToElement(dasboardpageObjects.Authorizations_Link).perform();  
		executor.executeScript("arguments[0].click()", dasboardpageObjects.Authorizations_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_text()));
		if(dasboardpageObjects.Authorizations_text().getText().equals(Authorizations_Text))
		{
		
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.transaction_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_text()));
		if(dasboardpageObjects.transaction_text().getText().equals(Transactions_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.funding_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
		if(dasboardpageObjects.funding_text().getText().equals(Funding_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.messages_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
		if(dasboardpageObjects.messages_text().getText().equals(Messages_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.documents_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
		if(dasboardpageObjects.documents_text().getText().equals(Documents_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		/*wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.more_option());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_option()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.help_option());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_text()));
		if(dasboardpageObjects.help_text().getText().equals(Help_Text))
		{
			Status = true;
		}
		else{
			Status=false;
			
		}*/
		if (Status==true)
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.preauthorization_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
		if(dasboardpageObjects.preauthorization_text().getText().equals(Pre_authorizations_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link()));
		//new Actions(driver).moveToElement(dasboardpageObjects.Authorizations_Link).perform();  
		executor.executeScript("arguments[0].click()", dasboardpageObjects.Authorizations_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_text()));
		if(dasboardpageObjects.Authorizations_text().getText().equals(Authorizations_Text))
		{
		
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.transaction_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_text()));
		if(dasboardpageObjects.transaction_text().getText().equals(Transactions_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.funding_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
		if(dasboardpageObjects.funding_text().getText().equals(Funding_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.messages_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
		if(dasboardpageObjects.messages_text().getText().equals(Messages_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.documents_Link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
		if(dasboardpageObjects.documents_text().getText().equals(Documents_Text))
		{
			Status = true;
		}
		else
		{
			Status=false;
		}
		/*wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.more_option());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_option()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.help_option());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_text()));
		if(dasboardpageObjects.help_text().getText().equals(Help_Text))
		{
			Status = true;
		}
		else{
			Status=false;
			
		}*/
		if (Status==true)
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	return Result;
}
@Step
public String Navigate_Preauth_Widget_to_detailed_preauth_view(String Preauth_text,String Device) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.pre_authorization_widget()));
		if(dasboardpageObjects.pre_authorization_widget().getText().equals(Preauth_text))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Navigate_Pre_auth_view()));
			dasboardpageObjects.Navigate_Pre_auth_view().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
			if(dasboardpageObjects.preauthorization_text().getText().equals(Preauth_text))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.pre_authorization_widget()));
		if(dasboardpageObjects.pre_authorization_widget().getText().equals(Preauth_text))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Navigate_Pre_auth_view()));
			dasboardpageObjects.Navigate_Pre_auth_view().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
			if(dasboardpageObjects.preauthorization_text().getText().equals(Preauth_text))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		for(int i=0;i<dasboardpageObjects.swipe_option.size();i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			executor.executeScript("arguments[0].click()", dasboardpageObjects.swipe_option.get(i));
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			System.out.println(dasboardpageObjects.pre_authorization_widget.isCurrentlyVisible());
			if(dasboardpageObjects.pre_authorization_widget.isCurrentlyVisible())
			{
				if(dasboardpageObjects.pre_authorization_widget().getText().equals(Preauth_text))
				{
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Navigate_Pre_auth_view()));
					executor.executeScript("arguments[0].click()", dasboardpageObjects.Navigate_Pre_auth_view());
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
					if(dasboardpageObjects.preauthorization_text().getText().equals(Preauth_text))
					{
						Result="Passed";
					}
					else
					{
						Result="Failed";
					}
				}
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			}
		}
	}
	return Result;
	
}
@Step
public String Navigate_Funding_Widget_to_detailed_funding_view(String funding_text,String Device) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.view_details_funding()));
		dasboardpageObjects.view_details_funding().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
		if(dasboardpageObjects.funding_text().getText().equals(funding_text))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.view_details_funding()));
		dasboardpageObjects.view_details_funding().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
		if(dasboardpageObjects.funding_text().getText().equals(funding_text))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		for(int i=0;i<dasboardpageObjects.swipe_option.size();i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			executor.executeScript("arguments[0].click()", dasboardpageObjects.swipe_option.get(i));
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			System.out.println(dasboardpageObjects.view_details_funding.isCurrentlyVisible());
			if(dasboardpageObjects.view_details_funding.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.view_details_funding()));
				dasboardpageObjects.view_details_funding().click();
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
				if(dasboardpageObjects.funding_text().getText().equals(funding_text))
				{
					Result="Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			}
		}
	}
	return Result;
	
}
@Step
public String Navigate_sales_to_transaction(String Device) throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver,50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Sales_dashboard_link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.Sales_dashboard_link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Couldnot_find_result_text()));
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		if(dasboardpageObjects.Couldnot_find_result_text.isDisplayed())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.date_dropdown()));
			dasboardpageObjects.date_dropdown().click();
			dasboardpageObjects.Last_7_days_link().click();
			dasboardpageObjects.Apply_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.posting_date()));
			Result="Passed";	
		}
		else {
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Sales_dashboard_link()));
		executor.executeScript("arguments[0].click()", dasboardpageObjects.Sales_dashboard_link());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Couldnot_find_result_text()));
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		if(dasboardpageObjects.Couldnot_find_result_text.isDisplayed())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.date_dropdown()));
			dasboardpageObjects.date_dropdown().click();
			dasboardpageObjects.Last_7_days_link().click();
			dasboardpageObjects.Apply_button().click();
			Result="Passed";	
		}
		else {
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		for(int i=0;i<dasboardpageObjects.swipe_option.size();i++)
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			executor.executeScript("arguments[0].click()", dasboardpageObjects.swipe_option.get(i));
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			if(dasboardpageObjects.Sales_dashboard_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Sales_dashboard_link()));
				executor.executeScript("arguments[0].click()", dasboardpageObjects.Sales_dashboard_link());
				
				for(int i1=0;i1<=150;i1++)
				{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_text()));}
				
				//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				if(dasboardpageObjects.Couldnot_find_result_text.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.date_dropdown()));
					executor.executeScript("arguments[0].click()",dasboardpageObjects.date_dropdown());
					executor.executeScript("arguments[0].click()",dasboardpageObjects.Last_7_days_link());
					executor.executeScript("arguments[0].click()",dasboardpageObjects.Apply_button());
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_text()));
					Result="Passed";	
				}
				else {
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.posting_date()));
					Result="Passed "+"Transactions are available for the particular date ";
				}
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
			}
		}
	}

	return Result;	
}
@Step
public String Change_currency_code(String Currency_code) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.currency_drop_down));
	dasboardpageObjects.currency_drop_down.click();
	if(Currency_code.equals("EUR"))
	{
		dasboardpageObjects.EUR_currency().click();
		if((dasboardpageObjects.payment_currency_Text_Validation()).getText().contains("�"))
		{
			Result="Passed : "+ dasboardpageObjects.payment_currency_Text_Validation().getText();
		}
	}
	else if(Currency_code.equals("USD"))
	{
		dasboardpageObjects.USD_currency().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.payment_currency_Text_Validation()));
		if((dasboardpageObjects.payment_currency_Text_Validation()).getText().contains("$"))
		{
			Result="Passed : "+ dasboardpageObjects.payment_currency_Text_Validation().getText();
		}
	}
	else
	{
		Result="Failed";
	}
	
	return Result;
}

@Step
public String Change_Language_code(String Language_change,String Pre_authorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Device) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		dasboardpageObjects.more_option().click();
		for(int i=0;i<=50;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));}
		dasboardpageObjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
		executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
		if(Language_change.equals("Dutch") || Language_change.equals("Nederlands") || Language_change.equals("N�erlandais") || Language_change.equals("Niederl�ndisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());	
		}
		else if(Language_change.equals("English") || Language_change.equals("Engels") || Language_change.equals("Englisch") || Language_change.equals("Anglais"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
		}
		else if(Language_change.equals("French") || Language_change.equals("Frans") || Language_change.equals("Fran�ais") || Language_change.equals("Franz�sisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
		}
		else if(Language_change.equals("German") || Language_change.equals("Duits") || Language_change.equals("Allemand") || Language_change.equals("Deutsch")  )
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
		}
		executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
		if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
		{
			if(dasboardpageObjects.pre_authorization_widget.getText().contains(Pre_authorizations_Text) && 
					dasboardpageObjects.sales_dashboard_text.getText().contains(Transactions_Text) && 
					dasboardpageObjects.payment_dashboard_text.getText().contains(Authorizations_Text) &&
					dasboardpageObjects.funding_Dashboard_Text.getText().contains(Funding_Text))
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.payment_dashboard_text()));
			Result="Passed "+": "+ Language_change +"_"+ dasboardpageObjects.payment_dashboard_text().getText()+" "+
			dasboardpageObjects.sales_dashboard_text.getText()+" "+ dasboardpageObjects.payment_dashboard_text +" "+
			dasboardpageObjects.funding_Dashboard_Text;
			}
		}
		else
		{
			Result="Failed "+"The langauge has not been changed ";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		dasboardpageObjects.more_option().click();
		for(int i=0;i<=50;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));}
		dasboardpageObjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
		executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
		if(Language_change.equals("Dutch") || Language_change.equals("Nederlands") || Language_change.equals("N�erlandais") || Language_change.equals("Niederl�ndisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());	
		}
		else if(Language_change.equals("English") || Language_change.equals("Engels") || Language_change.equals("Englisch") || Language_change.equals("Anglais"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
		}
		else if(Language_change.equals("French") || Language_change.equals("Frans") || Language_change.equals("Fran�ais") || Language_change.equals("Franz�sisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
		}
		else if(Language_change.equals("German") || Language_change.equals("Duits") || Language_change.equals("Allemand") || Language_change.equals("Deutsch")  )
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
		}
		executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
		if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
		{
			if(dasboardpageObjects.pre_authorization_widget.getText().contains(Pre_authorizations_Text) && 
					dasboardpageObjects.sales_dashboard_text.getText().contains(Transactions_Text) && 
					dasboardpageObjects.payment_dashboard_text.getText().contains(Authorizations_Text) &&
					dasboardpageObjects.funding_Dashboard_Text.getText().contains(Funding_Text))
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.payment_dashboard_text()));
			Result="Passed "+": "+ Language_change +"_"+ dasboardpageObjects.payment_dashboard_text().getText()+" "+
			dasboardpageObjects.sales_dashboard_text.getText()+" "+ dasboardpageObjects.payment_dashboard_text +" "+
			dasboardpageObjects.funding_Dashboard_Text;
			}
		}
		else
		{
			Result="Failed "+"The langauge has not been changed ";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option));
		dasboardpageObjects.more_option().click();
		for(int i=0;i<=50;i++)
		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));}
		dasboardpageObjects.settings().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
		executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
		if(Language_change.equals("Dutch") || Language_change.equals("Nederlands") || Language_change.equals("N�erlandais") || Language_change.equals("Niederl�ndisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());	
		}
		else if(Language_change.equals("English") || Language_change.equals("Engels") || Language_change.equals("Englisch") || Language_change.equals("Anglais"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
		}
		else if(Language_change.equals("French") || Language_change.equals("Frans") || Language_change.equals("Fran�ais") || Language_change.equals("Franz�sisch"))
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
		}
		else if(Language_change.equals("German") || Language_change.equals("Duits") || Language_change.equals("Allemand") || Language_change.equals("Deutsch")  )
		{
			executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
		}
		executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
		{
			if(dasboardpageObjects.payment_dashboard_text.getText().contains(Authorizations_Text))
			{
				String payment_Text=dasboardpageObjects.payment_dashboard_text.getText();
				for(int i=0;i<dasboardpageObjects.swipe_option.size()-1;i++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
					executor.executeScript("arguments[0].click()",dasboardpageObjects.swipe_option.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
				}
				Result="Passed "+": "+ Language_change +"_"+payment_Text;

			}
			else
			{
				Result="Failed "+" : "+Language_change+" The Language has not been changed ";
			}
		}
	}
	return Result;
}
@Step
public String Navigate_to_message_view_from_notification()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;

		if(dasboardpageObjects.Message_Title_Notification.isCurrentlyVisible())	
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Message_Title_Notification()));
		String message_title=dasboardpageObjects.Message_Title_Notification().getText();
		String Message_subTitle=dasboardpageObjects.Message_subtitle_notification().getText();
		dasboardpageObjects.Read_more_message_notofication().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
		if(messagepageObjects.Message_Title().getText().equals(message_title) && messagepageObjects.message_subTitle().getText().equals(Message_subTitle))
		{
			Result="Passed" +" "+message_title;
		}
		else{
			Result= "Failed";
			
		}
		}
		else
		{
			Result="Failed";
		}
	
	return Result;

}
@Step
public String Confirm_unread_alert_after_login()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 100);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	//wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.unread_alerts()));
	if(dasboardpageObjects.unread_alerts.isCurrentlyVisible())
	{
		
		String alert_title=dasboardpageObjects.unread_alerts_title().getText();
		executor.executeScript("arguments[0].click()",dasboardpageObjects.unread_alerts());
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Result="Passed "+alert_title;
		
	}
	else
	{
		Result="Failed";
	}
	
	return Result;	
}
@Step
public String Close_message_notification()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	//wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_notofication_cross_symbol()));
	if(dasboardpageObjects.message_notofication_cross_symbol.isCurrentlyVisible())
	{
		String message_title=dasboardpageObjects.Message_Title_Notification().getText();
		String Message_subTitle=dasboardpageObjects.Message_subtitle_notification().getText();
		executor.executeScript("arguments[0].click()",dasboardpageObjects.message_notofication_cross_symbol());
		if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			if(!dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
			{
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			if(!dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
			{
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
			
	}
	else
	{
		Result="Failed";
	}
		
	return Result;
}
@Step
public String Navigate_unread_message_detail_view(String Device)  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	
	if(Device.equalsIgnoreCase("desktop"))
	{
		if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
			Result="Passed";
		}
		else if(!dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
			Result="Passed";
		}
		else if(!dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}

	else if(Device.equalsIgnoreCase("mobile"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
		
		if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
			dasboardpageObjects.message_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
			Result="Passed";
		}
		else if(!dasboardpageObjects.message_indicator_count.isCurrentlyVisible() && dasboardpageObjects.document_indicator_count.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
			dasboardpageObjects.document_indicator_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_unread_count()));
			dasboardpageObjects.document_unread_count().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.all_document()));
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	return Result;
}
@Step
public String Validate_Disclaimer_widget()  throws InterruptedException{
	driver = this.getDriver();	
	String Result1=null,Result2=null,Result3=null,Result4=null;
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_payment_icon()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_payment_icon());
	if(dasboardpageObjects.Payment_Disclaimer_text.isCurrentlyVisible())
	{
		Result1="Passed "+dasboardpageObjects.Payment_Disclaimer_text().getText();
	}
	else
	{
		Result1="Failed "+"No Disclaimer is available";
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_sales_icon()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_sales_icon());
	if(dasboardpageObjects.sales_Disclaimer_text.isCurrentlyVisible())
	{
		Result2="Passed "+dasboardpageObjects.sales_Disclaimer_text().getText();
	}
	else
	{
		Result2="Failed "+"No Disclaimer is available";
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_preauth_icon()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_preauth_icon());
	if(dasboardpageObjects.preauth_Disclaimer_text.isCurrentlyVisible())
	{
		Result3="Passed "+dasboardpageObjects.preauth_Disclaimer_text().getText();
	}
	else
	{
		Result3="Failed "+"No Disclaimer is available";
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.TextDisclaimer_transafer_icon()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.TextDisclaimer_transafer_icon());
	if(dasboardpageObjects.transafer_Disclaimer_text.isCurrentlyVisible())
	{
		Result4="Passed "+dasboardpageObjects.transafer_Disclaimer_text().getText();
	}
	else
	{
		Result4="Failed "+"No Disclaimer is available";
	}
	Result=Result1+Result2+Result3+Result4;
	return Result;
}



@Step
public String user_should_be_able_to_view_revenue_for_each_payment_type()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
	wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
	wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
	//View Transaction for the Day
	if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
		if(dasboardpageObjects.Payment_Type_Value.isCurrentlyVisible())
		{
		Result="Passed"+"::"+"Transaction for Period -> "+dasboardpageObjects.Date.getText()+";"+dasboardpageObjects.Payment_Type_Value.getText();
		}				
	}
	//View Transaction for the Week
	else
	{
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
		dasboardpageObjects.Week.click();
		wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
		//View Transaction for the current Week
		if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			if(dasboardpageObjects.Payment_Type_Value.isCurrentlyVisible())
			{
			Result="Passed"+"::"+"Transaction for Period -> "+dasboardpageObjects.Date.getText()+";"+dasboardpageObjects.Payment_Type_Value.getText();
			}
		}
		//View Transaction for the Previous Week
		else
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
			wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			//View Transaction for Previous Week if enabled
			if(dasboardpageObjects.Previous_Week.isEnabled())
			{
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
				wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
				dasboardpageObjects.Previous_Week.click();
				wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
				if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
					wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
					if(dasboardpageObjects.Payment_Type_Value.isCurrentlyVisible())
					{
					Result="Passed"+"::"+"Transaction for Period -> "+dasboardpageObjects.Date.getText()+";"+dasboardpageObjects.Payment_Type_Value.getText();
					}
				}
				//No Transaction until Previous Week
				else
				{
					Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
				}
			}
			//Display result of current Week
			else
			{
				Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
			}
		}
	}
	return Result;
}

@Step
public String user_should_be_able_to_view_payment_details()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
	//View Transaction for the Day
	if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
		dasboardpageObjects.view_details_link.click();
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.View_Details_resultpg_Search_button()));
		if(!dasboardpageObjects.View_Details_NoResult_text.isCurrentlyVisible()||dasboardpageObjects.View_Details_Result_Expand.isCurrentlyVisible())
		{
			Result="Passed"+"::"+"Transactions combined in summary view is displayed";
		}
		else
		{
			Result="Failed"+"::"+dasboardpageObjects.View_Details_Date.getText()+"=>"+dasboardpageObjects.View_Details_NoResult_text.getText();
		}
				
	}
	//View Transaction for the Week
	else
	{
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
		dasboardpageObjects.Week.click();
		wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
		//View Transaction for the current Week
		if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			dasboardpageObjects.view_details_link.click();
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.View_Details_resultpg_Search_button()));
			if(!dasboardpageObjects.View_Details_NoResult_text.isCurrentlyVisible())
			{
				Result="Passed"+"::"+"Transactions combined in summary view is displayed";
			}
			else
			{
				Result="Failed"+"::"+dasboardpageObjects.View_Details_Date.getText()+"=>"+dasboardpageObjects.View_Details_NoResult_text.getText();
			}
		}
		//View Transaction for the Previous Week
		else
		{
			wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
			//View Transaction for Previous Week if enabled
			if(dasboardpageObjects.Previous_Week.isEnabled())
			{
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
				dasboardpageObjects.Previous_Week.click();
				wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
				if(!dasboardpageObjects.No_Transactions.isCurrentlyVisible())
				{
					wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
					dasboardpageObjects.view_details_link.click();
					wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.View_Details_resultpg_Search_button()));
					if(!dasboardpageObjects.View_Details_NoResult_text.isCurrentlyVisible())
					{
						Result="Passed"+"::"+"Transactions combined in summary view is displayed";
					}
					else
					{
						Result="Failed"+"::"+dasboardpageObjects.View_Details_Date.getText()+"=>"+dasboardpageObjects.View_Details_NoResult_text.getText();
					}
				}
				//No Transaction until Previous Week
				else
				{
					Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
				}
			}
			//Display result of current Week
			else
			{
				Result="Failed"+"::"+"No Transactions until "+dasboardpageObjects.Date.getText()+"=>"+dasboardpageObjects.No_Transactions.getText();
			}
		}
		
	}
	return Result;
}

@Step
public String user_should_be_able_to_view_Approval_widget_for_the_day()  throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOf(usermanagementpageobjects.page_load_text()));
	wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Week()));
	wait.until(ExpectedConditions.visibilityOf(dasboardpageObjects.Page_load_image()));
	//View Transaction for the Day
	if(dasboardpageObjects.Dashboard_Successful.isCurrentlyVisible())
	{
		Result="Passed"+"::"+dasboardpageObjects.Dashboard_Successful.getText()+" -> "+dasboardpageObjects.Dashboard_Successful_percent.getText()+" ; "+dasboardpageObjects.Dashboard_Declined.getText()+" -> "+dasboardpageObjects.Dashboard_Declined_percent.getText();		
	}
	else
	{
		Result="Failed"+"::"+dasboardpageObjects.No_Transactions.getText();		
	}
	return Result;
}
public void clickJS(WebElementFacade pageObject){
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].click()", pageObject);
}
}
