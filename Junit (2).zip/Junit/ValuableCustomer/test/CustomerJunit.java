import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class CustomerJunit {
	private CustomerBO customerBo;
	
	@Test
	public void testValuableCustomer(){
		assertEquals("Valuable customer",customerBo.findValuableCustomerOrNot(321));
		assertEquals("Valuable customer",customerBo.findValuableCustomerOrNot(30));
	}
	
	@Test
	public void testNonValuableCustomer(){
		assertEquals("Not a valuable customer",customerBo.findValuableCustomerOrNot(1));
		assertEquals("Not a valuable customer",customerBo.findValuableCustomerOrNot(15));
		assertEquals("Not a valuable customer",customerBo.findValuableCustomerOrNot(20));
	}
	
	@Test
	public void testInvalidShipment(){
		assertEquals("Invalid Input",customerBo.findValuableCustomerOrNot(-1));
		assertEquals("Invalid Input",customerBo.findValuableCustomerOrNot(-1));
	}
	
	@Before
	public void createObjectForCustomerBO (){
		customerBo = new CustomerBO();
	}
	
}
