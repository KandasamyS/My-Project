import java.text.SimpleDateFormat;
import java.util.Date;

public class Shipment {

	private String name;
	private Date arrivaDate;
	private Date departureDate;
	private ShipmentStatus shipmentStatus;
	SimpleDateFormat formatter = new SimpleDateFormat("dd-mm-yyyy");

	Shipment() {
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setArrivalDate(Date arrivaDate) {
		this.arrivaDate = arrivaDate;
	}

	public Date getArrivalDate() {
		return arrivaDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setShipmentStatus(ShipmentStatus shipmentStatus) {
		this.shipmentStatus = shipmentStatus;
	}

	public ShipmentStatus getShipmentStatus() {
		return shipmentStatus;
	}

	@Override
	public String toString() {
		return String.format("%-15s %-15s %-15s %-15s", name,
				formatter.format(arrivaDate), formatter.format(departureDate),
				shipmentStatus);
	}
}