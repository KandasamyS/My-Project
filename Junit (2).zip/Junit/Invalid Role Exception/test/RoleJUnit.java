import static org.junit.Assert.assertEquals;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;

import org.hamcrest.beans.HasProperty;
import org.junit.Before;
import org.junit.Test;

public class RoleJUnit {
	RoleBO roleBO;
	@Before
	public void createObjectForRoleBO() {
		roleBO = new RoleBO();
	}
	@Test
	public void testIsRolePresent() throws InvalidRoleException {
		assertThat(roleBO.isRolePresent(1, "name1", 10),hasProperty("id",is(1)));
	}
	@Test(expected=InvalidRoleException.class)
	public void testIsRolePresent_Exception() throws InvalidRoleException {
		assertThat(roleBO.isRolePresent(1, "name1", 100),hasProperty("id",is(1)));
	}
}