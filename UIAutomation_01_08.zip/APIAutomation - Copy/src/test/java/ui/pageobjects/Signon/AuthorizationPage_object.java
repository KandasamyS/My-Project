package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
public class AuthorizationPage_object extends PageObject{
	
@FindBy(css=".btn.flat-button")
public WebElementFacade date_dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade LastsevenDays_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(3)")
public WebElementFacade this_week_filter;

@FindBy(css=".extended-interface > button:nth-child(4)")
public WebElementFacade Last_month_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade apply_button;

@FindBy(css="authorization-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade search_error_message;

@FindBy(css="authorization-search > form > div.export > button > span.text.ng-scope")
public WebElementFacade export_button;
//authorization-search > form > div.export > button > span.text.ng-scope
@FindBy(css="div.modal-body.ng-scope > div:nth-child(2) > p > span:nth-child(3)")
public WebElementFacade csv_button;

@FindBy(css="div.modal-footer.ng-scope > button.default-button.x-small.blue.ng-scope")
public WebElementFacade cancel_button;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(3) > p > span:nth-child(3)")
public WebElementFacade xml_button;

@FindBy(css="div.modal-footer.ng-scope > button:nth-child(1)")
public WebElementFacade download_button;

@FindBy(css="div.modal-body-norecords.ng-scope")
public WebElementFacade noRecords_after_export;

@FindBy(css="div.modal-footer-norecords.ng-scope > button")
public WebElementFacade close_button;

@FindBy(css="#search-container > ul > li:nth-child(3) > a > span:nth-child(3)")
public WebElementFacade search_orderId;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade Authorization_date;

@FindBy(css="div.col-lg-12.tab-inside.ng-scope > div > authorization-search > save-search > div > p")
public WebElementFacade search_success_message;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade searchFieldText;

@FindBy(css="div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade search_button;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(5) > span.date > input")
public WebElementFacade from_date;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(6) > span.date > input")
public WebElementFacade to_date;

@FindBy(css="#search-container > ul > li:nth-child(1) > a > span:nth-child(3)")
public WebElementFacade _search_merchantId;

@FindBy(css="authorization-search > save-search > div > button > span.text.ng-binding")
public WebElementFacade save_search_button;

@FindBy(css="authorization-search > save-search > div > p")
public WebElementFacade save_search_text;

@FindBy(css="authorization-search > form > div.saved-searches.ng-scope > a")
public WebElementFacade save_search_link;

@FindBy(css="#saved-popup > p")
public WebElementFacade save_popup_text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > page-scroll > div > span")
public WebElementFacade Top_buttom_view_button;

@FindBy(css="div.tg-column.ng-scope.more-icon-column.no-overflow.sticky > span")
public List<WebElement> plus_icon;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-5> span > span.header-label.ng-binding.ng-scope")
public WebElementFacade orderID_text;

@FindBy(css="div.tg-column.ng-scope.tg-col-id-5 > span")
public List<WebElement> orderID_value;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-3> span > span.header-label.ng-binding.ng-scope")
public WebElementFacade merchant_id_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-2 > span > span.header-label.header-label-html.ng-binding.ng-scope")
public WebElementFacade ecom_pos_image;

@FindBy(css=" div.tg-column.tg-header.ng-scope.tg-col-id-4 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade store_id_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-6 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade Brand_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-7 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade auth_type_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-8 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade status_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-9 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade auth_code_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-10 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade amount_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-13 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade dcc_transaction;

@FindBy(css=" div.tg-column.tg-header.ng-scope.tg-col-id-14> span > span.header-label.ng-binding.ng-scope")
public WebElementFacade card_number_text;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-15 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade currency_text;

@FindBy(css="authorisation-details > div > div:nth-child(1) > p:nth-child(4) > span.detail-column.ng-binding.ng-scope.full-width")
public List<WebElement> auth_code;

@FindBy(css="authorisation-details > div > div:nth-child(2) > p:nth-child(2) > span.detail-column.ng-binding.ng-scope.full-width.big")
public List<WebElement> card_number;

@FindBy(css="p.detail-row.clearfix.ng-scope.image-paragraph > span.detail-column.ng-binding.ng-scope.image-label")
public List<WebElement> card_type;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.authorisations > a > span > span")
public WebElementFacade Authorizations_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade auth_homepage_text;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade Search_Textbox;

@FindBy(css="#search-container > ul > li:nth-child(3) > a")
public WebElementFacade auth_Search_autofill_OrderID;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade auth_Search_button;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade Auth_NoResult;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-5.tg-fixed-w-5.tg-col-id-0.more-icon-column.no-overflow.sticky > span")
public WebElementFacade Auth_Search_Expand;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-1.tg-w-9.tg-fixed-w-9 > span > span.date-desktop")
public WebElementFacade auth_Date;

@FindBy(css="ng-transclude > authorisation-details > div > div:nth-child(2) > p:nth-child(2) > span.detail-column.ng-binding.ng-scope.full-width.big")
public WebElementFacade auth_Cardno;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-10.no-overflow.scaleable.align-right.tg-w-6.tg-fixed-w-6 > span > auth-amount-cell > div > span")
public WebElementFacade auth_amount;

@FindBy(css="div.tg-row-outer.tg-row-header-outer > div.tg-row.tg-row-header.sticky > column-picker > div.column-picker-content > div > p:nth-child(18) > button")
public WebElementFacade Auth_Apply_Button;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-8.tg-w-6.tg-fixed-w-6 > span > div > span:nth-child(2)")
public WebElementFacade auth_status;

@FindBy(css="ng-transclude > authorisation-details > div > div:nth-child(1) > div > voiding > button")
public WebElementFacade Void_button;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > ng-include > div > div.bottom-navigation > button")
public WebElementFacade auth_void_authorization;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > ng-include > div > div.bottom-navigation > a > span")
public WebElementFacade auth_void_S1_Cancel;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-header.text-center > h2 > span")
public WebElementFacade auth_vc_header;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div:nth-child(1) > strong")
public WebElementFacade auth_vc_heading_Cardno;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div.ng-binding")
public WebElementFacade auth_vc_Cardno;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div:nth-child(4) > strong")
public WebElementFacade auth_vc_Date;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > div > div:nth-child(5) > span")
public WebElementFacade auth_vc_Amount;

@FindBy(css="#merchant-portal > div.modal.ng-isolate-scope.voiding-modal-window.in > div > div > div > div.modal-container > div.modal-body > ng-include > form > div.bottom-navigation > a > span")
public WebElementFacade auth_vc_Back;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.date-picker > div > span.input-group-btn > button > i")
public WebElementFacade Filter_Date_Dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade Last7days_Dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade Filter_Date_Apply;

@FindBy(css="#search-container > ul > li:nth-child(1) > a")
public WebElementFacade auth_Search_autofill_MerchantID;

@FindBy(css="#search-container > ul > li:nth-child(2) > a")
public WebElementFacade auth_Search_autofill_StoreID;

@FindBy(css="#search-container > ul > li:nth-child(4) > a")
public WebElementFacade auth_Search_autofill_Authcode;

@FindBy(css="#search-container > ul > li:nth-child(5) > a")
public WebElementFacade auth_Search_autofill_CardNumber;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.more-filters > a")
public WebElementFacade More_Filter;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.dropdown-container > div:nth-child(1) > div > button.btn.dropdown-toggle > span.fa.fa-caret-down.fa-lg")
public WebElementFacade ChannelType_dropdown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.dropdown-container > div:nth-child(1) > div > ul > li:nth-child(2) > p")
public WebElementFacade ChannelType_Ecommerce;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.dropdown-container > div:nth-child(1) > div > ul > li:nth-child(3) > p")
public WebElementFacade ChannelType_pos;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.dropdown-container > div:nth-child(2) > div > button.btn.dropdown-toggle > span.fa.fa-caret-down.fa-lg")
public WebElementFacade AuthType_dropdown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(2) > p")
public WebElementFacade AuthType_Purchase;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(3) > p")
public WebElementFacade AuthType_Payment;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.dropdown-container > div:nth-child(2) > div > ul > li:nth-child(4) > p")
public WebElementFacade AuthType_Refund;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > amounts-search > div:nth-child(2) > fieldset > input")
public WebElementFacade AmtFrom;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > amounts-search > div:nth-child(4) > fieldset > input")
public WebElementFacade AmtTo;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > reset-filters > a")
public WebElementFacade ResetFilter_button;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-5.tg-w-16.tg-fixed-w-16 > span")
public List<WebElementFacade> SearchResult_OrderID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-3.tg-w-7.tg-fixed-w-7 > span")
public List<WebElementFacade> SearchResult_MerchantID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-4.tg-w-6.tg-fixed-w-6 > span")
public List<WebElementFacade> SearchResult_StoreID;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-9.tg-w-10.tg-fixed-w-10 > span")
public List<WebElementFacade> SearchResult_Authcode;

@FindBy(css="ng-transclude > authorisation-details > div > div:nth-child(2) > p:nth-child(2) > span.detail-column.ng-binding.ng-scope.full-width.big")
public WebElementFacade SearchResult_CardNumber;

@FindBy(css="i[class='card-3']")
public WebElementFacade SearchResult_ChannelType_Ecomm;

@FindBy(css="i[class='card-2']")
public WebElementFacade SearchResult_ChannelType_Pos;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-7.tg-w-7.tg-fixed-w-7 > span")
public List<WebElementFacade> SearchResult_AuthType;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-10.no-overflow.scaleable.align-right.tg-w-6.tg-fixed-w-6 > span > auth-amount-cell > div > span")
public List<WebElementFacade> SearchResult_Amt;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > form-search-input > div > button.default-button.x-small.gray > i")
public WebElementFacade Search_Textbox_Close_icon;

public  WebElement Authorizations_Link(){
    return Authorizations_Link;
}

public  WebElement auth_homepage_text(){
    return auth_homepage_text;
}

public  WebElement Search_Textbox(){
    return Search_Textbox;
}

public  WebElement auth_Search_autofill_OrderID(){
    return auth_Search_autofill_OrderID;
}

public  WebElement auth_Search_button(){
    return auth_Search_button;
}

public  WebElement Auth_NoResult(){
    return Auth_NoResult;
}

public  WebElement Auth_Search_Expand(){
    return Auth_Search_Expand;
}

public  WebElement auth_Date(){
    return auth_Date;
}

public  WebElement auth_Cardno(){
    return auth_Cardno;
}

public  WebElement auth_amount(){
    return auth_amount;
}

public  WebElement Auth_Apply_Button(){
    return Auth_Apply_Button;
}

public WebElement auth_status(){
	return auth_status;
}

public WebElement Void_button(){
	return Void_button;
}

public WebElement auth_void_authorization(){
	return auth_void_authorization;
}

public WebElement auth_void_S1_Cancel(){
	return auth_void_S1_Cancel;
}

public WebElement auth_vc_header(){
	return auth_vc_header;
}

public WebElement auth_vc_heading_Cardno(){
	return auth_vc_heading_Cardno;
}

public WebElement auth_vc_Cardno(){
	return auth_vc_Cardno;
}

public WebElement auth_vc_Date(){
	return auth_vc_Date;
}

public WebElement auth_vc_Amount(){
	return auth_vc_Amount;
}

public WebElement auth_vc_Back(){
	return auth_vc_Back;
}

public WebElement Filter_Date_Dropdown(){
	return Filter_Date_Dropdown;
}

public WebElement Last7days_Dropdown(){
	return Last7days_Dropdown;
}

public WebElement Filter_Date_Apply(){
	return Filter_Date_Apply;
}

public WebElement auth_Search_autofill_MerchantID(){
	return auth_Search_autofill_MerchantID;
}

public WebElement auth_Search_autofill_StoreID(){
	return auth_Search_autofill_StoreID;
}

public WebElement auth_Search_autofill_Authcode(){
	return auth_Search_autofill_Authcode;
}

public WebElement auth_Search_autofill_CardNumber(){
	return auth_Search_autofill_CardNumber;
}

public WebElement More_Filter(){
	return More_Filter;
}

public WebElement ChannelType_dropdown(){
	return ChannelType_dropdown;
}

public WebElement ChannelType_Ecommerce(){
	return ChannelType_Ecommerce;
}

public WebElement ChannelType_pos(){
	return ChannelType_pos;
}

public WebElement AuthType_dropdown(){
	return AuthType_dropdown;
}

public WebElement AuthType_Purchase(){
	return AuthType_Purchase;
}

public WebElement AuthType_Payment(){
	return AuthType_Payment;
}

public WebElement AuthType_Refund(){
	return AuthType_Refund;
}

public WebElement AmtFrom(){
	return AmtFrom;
}

public WebElement AmtTo(){
	return AmtTo;
}

public WebElement ResetFilter_button(){
	return ResetFilter_button;
}

public List<WebElementFacade> SearchResult_OrderID(){
	return SearchResult_OrderID;
}

public List<WebElementFacade> SearchResult_MerchantID(){
	return SearchResult_MerchantID;
}

public List<WebElementFacade> SearchResult_StoreID(){
	return SearchResult_StoreID;
}

public List<WebElementFacade> SearchResult_Authcode(){
	return SearchResult_Authcode;
}

public WebElement SearchResult_CardNumber(){
	return SearchResult_CardNumber;
}

public WebElement SearchResult_ChannelType_Ecomm(){
	return SearchResult_ChannelType_Ecomm;
}

public WebElement SearchResult_ChannelType_Pos(){
	return SearchResult_ChannelType_Pos;
}

public List<WebElementFacade> SearchResult_AuthType(){
	return SearchResult_AuthType;
}

public List<WebElementFacade> SearchResult_Amt(){
	return SearchResult_Amt;
}

public WebElement Search_Textbox_Close_icon(){
	return Search_Textbox_Close_icon;
}

/*public WebElement auth_code(){
	return auth_code;
}
public WebElement card_number(){
	return card_number;
}
public WebElement card_type(){
	return card_type;
}*/
public WebElement store_id_text(){
	return store_id_text;
}
public WebElement auth_code_text(){
	return auth_code_text;
}
public WebElement amount_text(){
	return amount_text;
}
public WebElement status_text(){
	return status_text;
}
public WebElement auth_type_text(){
	return auth_type_text;
}
public WebElement card_number_text(){
	return card_number_text;
}
public WebElement currency_text(){
	return currency_text;
}
public WebElement dcc_transaction(){
	return dcc_transaction;
}
public WebElement merchant_id_text(){
	return merchant_id_text;
}
public WebElement ecom_pos_image(){
	return ecom_pos_image;
}
public WebElement orderID_text(){
	return orderID_text;
}
public WebElement Top_buttom_view_button(){
	return Top_buttom_view_button;
}
public WebElement save_popup_text(){
	return save_popup_text;
}
public WebElement save_search_link(){
	return save_search_link;
}
public WebElement save_search_text(){
	return save_search_text;
}
public WebElement save_search_button(){
	return save_search_button;
}
public WebElement _search_merchantId(){
	return _search_merchantId;
}
public WebElement from_date(){
	return from_date;
}
public WebElement to_date(){
	return to_date;
}
public WebElement searchFieldText(){
	return searchFieldText;
}
public WebElement search_button(){
	return search_button;
}
public WebElement search_success_message(){
	return search_success_message;
}
public WebElement Authorization_date(){
	return Authorization_date;
}
public WebElement search_orderId(){
	return search_orderId;
}
public WebElement cancel_button(){
	return cancel_button;
}
public WebElement close_button(){
	return close_button;
}
public WebElement date_dropdown(){
	return date_dropdown;
}
public  WebElement LastsevenDays_filter(){
    return LastsevenDays_filter;
}
public  WebElement this_week_filter(){
    return this_week_filter;
}
public  WebElement Last_month_filter(){
    return Last_month_filter;
}
public  WebElement apply_button(){
    return apply_button;
}
public WebElement search_error_message(){
	return search_error_message;
}
public WebElement export_button(){
	return export_button;
}
public WebElement csv_button(){
	return csv_button;
}
public WebElement xml_button(){
	return xml_button;
}
public WebElement download_button(){
	return download_button;
}
public WebElement noRecords_after_export(){
	return noRecords_after_export;
}
}
