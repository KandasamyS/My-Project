package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SettingsuserPage_object extends PageObject{

	
@FindBy(css="div.account-settings-details-container.personal > div.btn-group.dropdown > button.btn.dropdown-toggle > span")
public WebElementFacade Language_dropDown;

@FindBy(css="div.btn-group.dropdown.open > ul > li:nth-child(1) > a")
public WebElementFacade English_Language;

@FindBy(css=" div.btn-group.dropdown.open > ul > li:nth-child(2) > a")
public WebElementFacade Dutch_Language;

@FindBy(css=" div.btn-group.dropdown.open > ul > li:nth-child(3) > a")
public WebElementFacade French_Language;

@FindBy(css="div.btn-group.dropdown.open > ul > li:nth-child(4) > a")
public WebElementFacade German_Language;

@FindBy(css="div:nth-child(2) > div > div > button")
public WebElementFacade Save_language_button;

@FindBy(css="div.account-settings-details-container.personal > h4:nth-child(3) > span")
public WebElementFacade email_addres;

@FindBy(css=" div.account-settings-details-container.personal > div.phones > h4:nth-child(1) > span")
public WebElementFacade mobile_number;

@FindBy(css="div.account-settings-details-container.login > h4 > span")
public WebElementFacade userName;

@FindBy(css="div.account-settings-details-container.personal > p.name > span")
public WebElementFacade First_LastName;

@FindBy(css="div.account-settings-details-container.login > a")
public WebElementFacade changePassword_link;

@FindBy(css="#oldPassword")
public WebElementFacade oldPassword;

@FindBy(css="#newPassword")
public WebElementFacade newPassword;

@FindBy(css="#newPasswordConfirm")
public WebElementFacade confirmPassword;

@FindBy(css="form > div:nth-child(3) > div > div > button")
public WebElementFacade continue_button;

@FindBy(css="form > div:nth-child(1) > div > div > p.ng-binding.ng-scope")
public WebElementFacade passwordErromessage;

@FindBy(css="form > div:nth-child(1) > div > div > p:nth-child(2)")
public WebElementFacade passwordsetmessage;

@FindBy(css="li.ng-scope.settings > a > span > span")
public WebElementFacade Settings_Link;

@FindBy(css="div.account-settings-details-container.personal > h4:nth-child(3) > span")
public WebElementFacade Email_address;

@FindBy(css="div.account-settings-details-container.login > h4 > span")
public WebElementFacade User_name;

public  WebElement Settings_Link(){
    return Settings_Link;
}

public  WebElement Email_address(){
    return Email_address;
}

public  WebElement User_name(){
    return User_name;
}

public WebElement Language_dropDown(){
	return Language_dropDown;
}
public WebElement English_Language(){
    return English_Language;
  }
public WebElement Dutch_Language(){
    return Dutch_Language;
  }
public WebElement French_Language(){
    return French_Language;
  }
public WebElement German_Language(){
    return German_Language;
  }
public WebElement Save_language_button(){
    return Save_language_button;
  }
public WebElement email_addres(){
    return email_addres;
  }
public WebElement mobile_number(){
	return mobile_number;
}
public WebElement userName(){
	return userName;
}
public WebElement First_LastName(){
	return First_LastName;
}
public WebElementFacade changePassword_link(){
	return changePassword_link;
}
public WebElementFacade oldPassword(){
	return oldPassword;
}
public WebElementFacade newPassword(){
	return newPassword;
}
public WebElementFacade confirmPassword(){
	return confirmPassword;
}
public WebElementFacade continue_button(){
	return continue_button;
}
public WebElementFacade passwordErromessage(){
	return passwordErromessage;
}
public WebElementFacade passwordsetmessage(){
	return passwordsetmessage;
}
}
