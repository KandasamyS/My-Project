package ui.pageobjects.Signon;
import org.openqa.selenium.WebElement;

import common.WrappedWebDriver;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SignonPage_objects extends PageObject{

//EMS
@FindBy(css="#username")
public WebElementFacade UserName;

@FindBy(css="#password")
public WebElementFacade Password;

@FindBy(css="label.ng-scope")
public WebElementFacade RememberMe;

@FindBy(css="#submit")
public WebElementFacade Submit;

@FindBy(css="div.fade-animation.validate-container.validation-error > div > p.ng-binding.ng-scope")
public WebElementFacade error_message_invalidLogin;

@FindBy(css="div.fade-animation.validate-container > div > p.ng-binding.ng-scope")
public WebElementFacade accountActiveStatus;
//LBC
@FindBy(css="div.inputs > div:nth-child(2) > input")
public WebElementFacade userId_LBC;

@FindBy(css="div.inputs > div:nth-child(3) > input")
public WebElementFacade password_LBC;

@FindBy(css="form > div.inputs > button")
public WebElementFacade submit_lbc;

@FindBy(css="div.modal-footer.ng-scope > a")
public WebElementFacade download_TermsConditions;

@FindBy(css="div.modal-footer.ng-scope > button")
public WebElementFacade Accept_TermsAndCondition;

@FindBy(css="div:nth-child(1) > div > div:nth-child(2) > section > div > form > div > div > div.row > div > button")
public WebElementFacade Lets_go_link_in_registration;

//Admin
@FindBy(css="[name*=allianceLogin]")
public WebElement alliance;

@FindBy(css="#login")
public WebElement login_admin;

@FindBy(css="span[class*='feedbackPanelERROR']")
public WebElementFacade error_login_admin_console;

@FindBy(css="#panel-user-label")
public WebElement Welcome_text_admin;

@FindBy(css="div[class^='inside-table'] ")
public WebElement Login_error;

public WebElement error_login_admin_console(){
    return error_login_admin_console;
}
public WebElement Login_error(){
    return Login_error;
}
public  WebElement userId_LBC(){
    return userId_LBC;
}
public  WebElement accountActiveStatus(){
    return accountActiveStatus;
}
public  WebElement password_LBC(){
    return password_LBC;
}
public  WebElement submit_lbc(){
    return submit_lbc;
}
public  WebElement UserName(){
    return UserName;
}
public WebElement Password(){
    return Password;
}
public WebElement Submit(){
    return Submit;
}
public WebElement error_message_invalidLogin(){
	return error_message_invalidLogin;
}
public WebElement RememberMe() {
	return RememberMe;
}
public WebElement alliance(){
    return alliance;
}
public WebElement login_admin(){
    return login_admin;
}
public WebElement Welcome_text_admin(){
    return Welcome_text_admin;
}
public WebElement download_TermsConditions(){
	return download_TermsConditions;
}
public WebElement Accept_TermsAndCondition(){
	return Accept_TermsAndCondition;
}
public WebElement Lets_go_link_in_registration(){
	return Lets_go_link_in_registration;
}
}

