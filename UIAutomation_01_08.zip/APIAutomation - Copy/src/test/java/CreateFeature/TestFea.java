package CreateFeature;

/*import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;*/
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import util.ExcelUtil;

public class TestFea {
	
	public static void CreateFeatureFile() throws Exception {
		// TODO Auto-generated method stub
		 // The name of the file to open.
		/*String readFileName = "C:/Users/fayz3p2/Desktop/Automation/Automation/src/test/resources/Templates/Test.feature";
		String writeFilename = "C:/Users/fayz3p2/Desktop/Automation/Automation/src/test/resources/features/UIupdate_next.feature";
        String Path="C:/Users/fayz3p2/Desktop/Automation/Automation/UI_RunManager.xlsx";*/
		String readFileName =System.getProperty("user.dir") + "/src/test/resources/Templates/Test.feature";
		String writeFilename = System.getProperty("user.dir") + "/src/test/resources/features/Testupdate.feature";
        String Path= System.getProperty("user.dir") + "/UI_RunManager.xlsx";
        int i = 0;
        String combined=null;
        try
        {
	        String varStringline = null,tagName=null;
	        BufferedWriter bw = null;
	        FileWriter fw = null;
	        String Exectag = null;	    
	        File file = new File(readFileName);
	        System.out.println(System.getProperty("user.dir"));
	        FileReader fileReader = new FileReader(file);
	        boolean bval1= file.exists();
	        boolean bval = file.setReadable(true);
	        BufferedReader bufferedReader = new BufferedReader(fileReader);
	        fw = new FileWriter(writeFilename);
	        bw = new BufferedWriter(fw);
	        while ((varStringline = bufferedReader.readLine()) != null) 
	        { 
	        	ExcelUtil.setExcelFile(Path, "Sheet1");
	        	for(i=1;i<ExcelUtil.getPhysicalNumberOfRows();++i)
	        	{
	        		ExcelUtil.setExcelFile(Path, "Sheet1");  
	        		Exectag=ExcelUtil.getCellData(i, 0);

	        		if(varStringline.equalsIgnoreCase(Exectag))
	        		{
	        			tagName=varStringline;
	        		}
	        		if(varStringline.equalsIgnoreCase("#----") && tagName.equalsIgnoreCase(Exectag)){
	        			String Reports=ExcelUtil.getCellData(i,Findpointer(0,"Reports"));
	        			String appurl=ExcelUtil.getCellData(i,Findpointer(0,"appurl"));
	        			String username=ExcelUtil.getCellData(i,Findpointer(0,"username"));
	        			String password=ExcelUtil.getCellData(i, Findpointer(0,"password"));
	        			String Alliance_code=ExcelUtil.getCellData(i, Findpointer(0,"Alliance_code"));
	        			String Welcome_Text=ExcelUtil.getCellData(i, Findpointer(0, "Welcome_Text"));
	        			String Pre_authorizations_Text=ExcelUtil.getCellData(i, Findpointer(0, "Pre_authorizations_Text"));
	        			String Authorizations_Text=ExcelUtil.getCellData(i, Findpointer(0, "Authorizations_Text"));
	        			String Transactions_Text=ExcelUtil.getCellData(i, Findpointer(0, "Transactions_Text"));
	        			String Funding_Text=ExcelUtil.getCellData(i, Findpointer(0, "Funding_Text"));
	        			String Messages_Text=ExcelUtil.getCellData(i, Findpointer(0, "Messages_Text"));
	        			String Documents_Text=ExcelUtil.getCellData(i, Findpointer(0, "Documents_Text"));
	        			String Help_Text=ExcelUtil.getCellData(i, Findpointer(0, "Help_Text"));
	        			String Currency_change=ExcelUtil.getCellData(i, Findpointer(0, "Currency_change"));
	        			String Language_Change=ExcelUtil.getCellData(i, Findpointer(0, "Language_Change"));
	        			String Alliance_Name=ExcelUtil.getCellData(i, Findpointer(0, "Alliance_Name"));
	        			String Language=ExcelUtil.getCellData(i, Findpointer(0, "Language"));
	        			String Type=ExcelUtil.getCellData(i, Findpointer(0, "Type"));
	        			String Message_title=ExcelUtil.getCellData(i, Findpointer(0, "Message_title"));
	        			String Sub_title=ExcelUtil.getCellData(i, Findpointer(0, "Sub_title"));
	        			String Date_received=ExcelUtil.getCellData(i, Findpointer(0, "Date_received"));
	        			String Validity_type=ExcelUtil.getCellData(i, Findpointer(0, "Validity_type"));
	        			String In_days_Validity_days=ExcelUtil.getCellData(i, Findpointer(0, "In_days_Validity_days"));
	        			String message_body=ExcelUtil.getCellData(i, Findpointer(0, "message_body"));
	        			String userId_LBC=ExcelUtil.getCellData(i, Findpointer(0, "userId_LBC"));
	        			String password_LBC=ExcelUtil.getCellData(i, Findpointer(0, "password_LBC"));
	        			String User_Type=ExcelUtil.getCellData(i, Findpointer(0, "User_Type"));
	        			String Alliance_name=ExcelUtil.getCellData(i, Findpointer(0, "Alliance_name"));
	        			String Profile_type=ExcelUtil.getCellData(i, Findpointer(0, "Profile_type"));
	        			String First_Name=ExcelUtil.getCellData(i, Findpointer(0, "First_Name"));
	        			String last_name=ExcelUtil.getCellData(i, Findpointer(0, "last_name"));
	        			String email_id=ExcelUtil.getCellData(i, Findpointer(0, "email_id"));
	        			String UserName_new_alliance=ExcelUtil.getCellData(i, Findpointer(0, "UserName_new_alliance"));
	        			String mobile_number=ExcelUtil.getCellData(i, Findpointer(0, "mobile_number"));
	        			String New_password=ExcelUtil.getCellData(i, Findpointer(0, "New_password"));
	        			String downloaded_Path=ExcelUtil.getCellData(i, Findpointer(0, "downloaded_Path"));
	        			String Merchant_ID=ExcelUtil.getCellData(i, Findpointer(0, "Merchant_ID"));
	        			String Upload_file=ExcelUtil.getCellData(i, Findpointer(0, "Upload_file"));
	        			String Funding_Reference_number=ExcelUtil.getCellData(i, Findpointer(0, "Funding_Reference_number"));
	        			String From_date=ExcelUtil.getCellData(i, Findpointer(0, "From_date"));
	        			String To_date=ExcelUtil.getCellData(i, Findpointer(0, "To_date"));
	        			String Document_Name=ExcelUtil.getCellData(i, Findpointer(0, "Document_Name"));
	        			String attachmentPath=ExcelUtil.getCellData(i, Findpointer(0, "attachmentPath"));
	        			String Description_DocumentText=ExcelUtil.getCellData(i, Findpointer(0, "Description_DocumentText"));
	        			String Rename_document=ExcelUtil.getCellData(i, Findpointer(0, "Rename_document"));
	        			String Order_ID=ExcelUtil.getCellData(i, Findpointer(0, "Order_ID"));
	        			
	        			
	        			
	        			/*String CountryCode=ExcelUtil.getCellData(i, Findpointer(0,"ErrorCode"));*/
	        			combined="|"+Reports+"|"+appurl+"|"+username+"|"+password+"|"+Alliance_code+"|"+Welcome_Text+"|"+Pre_authorizations_Text+"|"+Authorizations_Text+
	        					"|"+Transactions_Text+"|"+Funding_Text+"|"+Messages_Text+"|"+Documents_Text+"|"+Help_Text+"|"+Currency_change+"|"+Language_Change+"|"+Alliance_Name+"|"+Language+"|"+Type+"|"+Message_title+
	        					"|"+Sub_title+"|"+Date_received+"|"+Validity_type+"|"+In_days_Validity_days+"|"+message_body+"|"+
	        					userId_LBC+"|"+password_LBC+"|"+User_Type+"|"+Alliance_name+"|"+Profile_type+"|"+First_Name+"|"
	        					+last_name+"|"+email_id+"|"+UserName_new_alliance+"|"+mobile_number+"|"+New_password+"|"+
	        					downloaded_Path+"|"+Merchant_ID+"|"+Upload_file+"|"+Funding_Reference_number+"|"+From_date+"|"+
	        					To_date+"|"+Document_Name+"|"+attachmentPath+"|"+Description_DocumentText+"|"+Rename_document+"|"+Order_ID+"|";
	        			bw.write(combined);
	        			bw.newLine();
	        		} 

	        	}

	        	bw.write(varStringline);
	        	bw.newLine();

	        }    
        
	        bufferedReader.close();fileReader.close();/*if (bw != null)*/bw.close();/*if (fw != null)*/fw.close();
     }     
        
        catch(FileNotFoundException ex) {
        System.out.println("Unable to open file '" + readFileName + "'");                
        }
        catch(IOException ex) {System.out.println("Error reading file '" + readFileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
    }
  }
	private static int Findpointer(int i,String findstring) throws Exception
	{
		int Excel_col=ExcelUtil.getPhysicalNumberofcolumn(i);
		int column_number=0,column_number_final=0;
		for(int col=0;col<=Excel_col;col++)
		{
			if(ExcelUtil.getCellData(i, col).equalsIgnoreCase(findstring))
			{
				column_number=col;
			}
		}
		column_number_final=column_number;
		return column_number_final;	
	}
}
    




