package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;


@RunWith(CucumberWithSerenity.class)
@CucumberOptions(monochrome=true,
features="src/test/resources/features",
glue="stepdefinitions",
strict=true,
tags="@MEPOE-5358_User_Management,@MEPOE-5391_User_Management")
public class TestRunner {
	//@MEPOE-5358_User_Management,,@MEPOE-5391_User_Management,@MEPOE-5653_Financial_Activity,@MEPOE-5826_User_Management
}