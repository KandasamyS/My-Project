package stepdefinitions;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import CreateFeature.TestFea;
import Reports.TestResult;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Steps;
import ui.Signon.Document_Management;
import ui.Signon.Financial_Activity;
import ui.Signon.Impersonation;
import ui.Signon.MessagePage;
import ui.Signon.Online_Authorization;
import ui.Signon.Terms_Conditions;
import ui.Signon.User_management;
import ui.Signon.Dashboard_Customization;
import ui.Signon.Dashboard_Navigation;
import net.thucydides.core.webdriver.SerenityWebdriverManager;

public class UIDefinitions extends PageObject {
TestResult lib=new TestResult();
@Steps
User_management userManagementPage;
Dashboard_Navigation dashboardpage;
MessagePage messages;
Terms_Conditions termsandConditions;
Document_Management documentManagement;
Financial_Activity financialactivity;
Online_Authorization onlineauthorization;
Dashboard_Customization dashboardcustomization;
Impersonation imporsonation;
String Result1;
public static WebDriver driver = null;
public static String driverType ="";
public static Dimension desktop = new Dimension(2000,2000);
public static Dimension mobile = new Dimension(375,667);
public static Dimension tablet = new Dimension(1024,1366);

	@Before
	public void bfre() throws Exception{

	}
	@After
	public void aftr()
	{
		lib.closeTestReport();
		lib.endTestReport();
		lib.SummarizeTestReport();
	}
	
	@Given("^the Feature file path creattion$")
	public void the_Feature_file_path_creattion() throws Throwable {
		TestFea.CreateFeatureFile();
	}
	@Given("^the EMS portal and configure \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void the_EMS_portal(String report,String dimension,String executionMode) throws Throwable {
		//driverType=driver;
		//System.out.println("The driver type is:"+driverType);
		userManagementPage.loadbrowser();
		driver=this.getDriver();
		if(!executionMode.contains("SaucelabsWeb_")&& !executionMode.contains("SaucelabsMobile_"))
		switch(dimension)
		{
		case "mobile": driver.manage().window().setSize(mobile); break;
		case "desktop": driver.manage().window().setSize(desktop); break;
		case "tablet": driver.manage().window().setSize(tablet); break;
		}
		lib.initializeTest("RequestForApplicationUIInfo"+" "+report);
		lib.WriteReportStep("1", "Loading the browser", "", "", "");
	}
	@And("^user Navigate to URL \"([^\"]*)\"$")
	public void user_Navigate_to_URL(String appurl) throws Throwable {
		lib.WriteReportStep("1", "Get url", "", "", "");
		String Result = userManagementPage.navigate(appurl);
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the URL", "Verify the URL",  "WebPage successfully loaded "+Result, "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the URL", "Verify the URL", "Failed to load the webPage "+Result, "Failed");
		 }
	}

	
/*	------------------------------------------------------------------------------------------------
		UI Description: User Management - Login to Merchant Portal
		UI Feature name: MEPOE-5325_User_Management
	------------------------------------------------------------------------------------------------*/

	@When("^user enter \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_enter_as(String FieldName, String FieldValue) throws Throwable {
		lib.WriteReportStep("1", "Get username", "", "", "");
		String Result = userManagementPage.userInput(FieldName,FieldValue);
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+"UserId Entered correctly", "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+"Failed to enter the userID", "Failed");
		 }
		
	}
	@And("^user entertext \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_entertext_as(String FieldName, String FieldValue) throws Throwable {
		lib.WriteReportStep("1", "Get Password", "", "", "");
	    String Result= userManagementPage.userInput(FieldName,FieldValue);
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+"Password entered correctly", "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+"Failed to enter the password", "Failed");
		 }
	}
	@Then("^user click Submit login and verify \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_click_Submit_login_and_verify(String Welcome_text,String Device) throws Throwable {
		 lib.WriteReportStep("1", "Login to the application", "", "", "");
		 String Result= userManagementPage.Submitlogin(Welcome_text,Device);
		 Result1=Result;
		 System.out.println(Result);
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Successfully login to application "+Result,"Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Failed to login to application"+Result,"Failed");
		 }
		 
	}
	
/*	------------------------------------------------------------------------------------------------
		UI Description: User Management - Remember my Merchant Portal login
		UI Feature name: MEPOE-5326_User_Management
	------------------------------------------------------------------------------------------------*/
	@And("^user click on RememberMe$")
	public void user_click_on_RememberMe() throws Throwable {
		userManagementPage.RememberMe();
	}
	
/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation - Inform visitors about the Merchant Portal cookie use
		UI Feature name: MEPOE-5372_Dashboard_navigation
	------------------------------------------------------------------------------------------------*/		
	
	@Then("^user Verify Dashboard cookie information link \"([^\"]*)\"$")
	public void user_Verify_Dashboard_cookie_information_link(String Device) throws Throwable {
		 
		if(Result1.contains("Passed"))
		{ 
			 lib.WriteReportStep("1", "Verify Cookie information", "", "", "");
			 String Result=dashboardpage.Dashboard_cookie_information_link(Device);
			 if(Result.contains("Passed"))
			 {
				 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is present"+Result,"Passed");
			 }
			 else
			 {
				 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is not there"+Result,"Failed");
			 }
		}
		 
	}
	
/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation  - Show message indicator
		UI Feature name: MEPOE-5373_Dashboard_navigation 
	------------------------------------------------------------------------------------------------*/	
	
	@Then("^user Verify Unread message count \"([^\"]*)\"$")
	public void user_Verify_Unread_message_count(String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		 lib.WriteReportStep("1", "Verify Unread message count", "", "", "");
		 String Result=dashboardpage.Unread_message_count(Device);
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "Unread message count is : "+ Result,"Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "No unread message are there : "+ Result,"Failed");
		 }
		}
	}

/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation  - Show document indicators
		UI Feature name: MEPOE-5374_Dashboard_navigation 
	------------------------------------------------------------------------------------------------*/	
	
	@Then("^user Verify Unread document count \"([^\"]*)\"$")
	public void user_Verify_Unread_document_count(String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify unread document count", "", "", "");
		String Result=dashboardpage.Unread_Document_count(Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "Unread Document count is : "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "No unread Document are there : "+ Result,"Failed");
		}
		}
	}

/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation  - Portal navigation
		UI Feature name: MEPOE-5377_Dashboard_navigation
	------------------------------------------------------------------------------------------------*/	

	@Then("^user Verify all the dashboard Panel element and check \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_Verify_all_the_dashboard_Panel_element_and_check(String Preauthorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Messages_Text, String Documents_Text, String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify all the dashboard element", "", "", "");
		String Result=dashboardpage.Verify_dashboard_panel_Navigation(Preauthorizations_Text,Authorizations_Text,Transactions_Text,Funding_Text,Messages_Text,Documents_Text,Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Successfully navigated to each widget","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Failed to navigate to each widget","Failed");
		}
		}
	}
	
/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation  - Move from Pre-authorisation Widget to detailed pre-authorisations view
		UI Feature name: MEPOE-6292_Dashboard_navigation
	------------------------------------------------------------------------------------------------*/
	
	@Then("^user should navigate from Pre_authorisation Widget to detailed pre_authorisations view and check \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_navigate_from_Pre_authorisation_Widget_to_detailed_pre_authorisations_view_and_check(String PreAuth_Text,String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
			System.out.println(PreAuth_Text);
		lib.WriteReportStep("1", "Verify Navigation from preAuth_widget", "", "", "");
		String Result=dashboardpage.Navigate_Preauth_Widget_to_detailed_preauth_view(PreAuth_Text,Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Successfully navigated to Preauth_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
		}
		}
	}
	
/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation  - Portal navigation
		UI Feature name: MEPOE-5377_Dashboard_navigation
	------------------------------------------------------------------------------------------------*/
	
	@Then("^user should navigate from Funding Widget to funding_summary view and check \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_navigate_from_Funding_Widget_to_funding_summary_view_and_check(String funding_text,String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Navigation from funding_widget", "", "", "");
		String Result=dashboardpage.Navigate_Funding_Widget_to_detailed_funding_view(funding_text,Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from Funding Widget","Verify Navigation from Funding Widget", "Successfully navigated to Funding_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
		}
		}
	}
	
/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation  - Portal navigation
		UI Feature name: MEPOE-5377_Dashboard_navigation
	------------------------------------------------------------------------------------------------*/
	
	@Then("^user should navigate from Sales Widget to Transaction summary view and check the detailed Transaction view \"([^\"]*)\"$")
	public void user_should_navigate_from_Sales_Widget_to_Transaction_summary_view_and_check_the_detailed_Transaction_view(String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Navigation from sales_widget", "", "", "");
		String Result=dashboardpage.Navigate_sales_to_transaction(Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from sales Widget","Verify Navigation from sales Widget", "Successfully navigated to Transaction_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from sales_widget","Verify Navigation from sales_widget", "Failed to navigate to Transaction_view","Failed");
		}
		}
	}
	
/*	------------------------------------------------------------------------------------------------
		UI Description: Dashboard navigation  - Portal navigation
		UI Feature name: MEPOE-5377_Dashboard_navigation
	------------------------------------------------------------------------------------------------*/
	
	@Then("^user should change the currency code to \"([^\"]*)\" and validate the dashboard$")
	public void user_should_change_the_currency_code_to_and_validate_the_dashboard(String arg1) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify currency_code change", "", "", "");
		String Result=dashboardpage.Change_currency_code(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Successfully Changed to currency_code "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Failed to change the currency code","Failed");
		}
		}
	}
	@Then("^user should change the Language code to \"([^\"]*)\" and validate the dashboard by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_change_the_Language_code_to_and_validate_the_dashboard(String Language_Change, String Pre_authorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Language_code change", "", "", "");
		String Result=dashboardpage.Change_Language_code(Language_Change,Pre_authorizations_Text,Authorizations_Text,Transactions_Text,Funding_Text,Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Successfully Changed to Language_code "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Failed to Change the language","Failed");
		}
		}
	}
	@Then("^User should be able to verify print option is working in messages as \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_print_option_is_working_in_messages_as(String arg1) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Print_option in Message change", "", "", "");
		String Result=messages.Print_option_Message(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Successfully Printed the message  ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Failed to Print the message ","Failed");
		}
		}
	}
	@When("^user enterAlliance \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_enterAlliance_as(String Alliance, String Alliance_code) throws Throwable { 
		lib.WriteReportStep("1", "Verify Alliance_code", "", "", "");
		String Result=userManagementPage.userInput(Alliance, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Successfully Entered alliancecode ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Failed to Enter Alliance_code","Failed");
		}	  
	}
	@When("^user click login button and enter to the admin console$")
	public void user_click_login_button_and_enter_to_the_admin_console() throws Throwable {
		lib.WriteReportStep("1", "Verify Login to Adminconsole", "", "", "");
		String Result=userManagementPage.login_admin_console();
		Result1=Result;
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Successfully Entered to adminconsole ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Failed to Enter into adminconsole","Failed");
		}
	}
	@Then("^user should be able to create the new message and give the input as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_the_new_message_and_give_the_input_as(String Alliance_Name, String Language, String Type, String Title, String Sub_title, String Date_received, String Validity_type,String In_days_Validity_days, String message_body) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify create message", "", "", "");
		String Result=messages.Create_message(Alliance_Name,Language,Type,Title,Sub_title,Date_received,Validity_type,In_days_Validity_days,message_body);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify create message","Verify create message", "Successfully created message "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify create message","Verify create message", "Failed to create message","Failed");
		}
		}
		
	}
	@Then("^User should be able to Navigate from message notification to the message detail$")
	public void User_should_be_able_to_Navigate_from_message_notification_to_the_message_detail(String Device) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be navigate from message notification to message detail", "", "", "");
		String Result=dashboardpage.Navigate_to_message_view_from_notification();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be navigate from message notification to message detail","Verify User should be navigate from messqage notification to message detail", "Successfully navigate to message detail ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be navigate from message notification to message detail","Verify User should be navigate from messqage notification to message detail", "No unread message are there come back later","Failed");
		}
		}
	}
	@When("^user click Submit login for alert$")
	public void user_click_Submit_login() throws Throwable{
		lib.WriteReportStep("1", "Verify submit button for alert testcase", "", "", "");
		String Result=userManagementPage.Submitlogin_for_alert_testcase();
		Result1=Result;
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Successfully navigate to Home Page ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Failed to navigate to home page","Failed");
		}
	}
	@Then("^User should be able to view unread alerts it will appear directly after logging in$")
	public void User_should_be_able_to_view_unread_alerts_it_will_appear_directly_after_logging_in() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to view unread allert", "", "", "");
		String Result=dashboardpage.Confirm_unread_alert_after_login();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "Successfully confirming unread alert ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "No unread alerts are there come back later","Failed");
		}
		}
	}
	@Then("^User should be able to close the message notification and check the message will be in read status$")
	public void User_should_be_able_to_close_the_message_notification_and_check_the_message_will_be_in_read_status() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to close the notification", "", "", "");
		String Result=dashboardpage.Close_message_notification();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to close the notification","Verify User should be able to close the notification", "Successfully closed the notification ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to close the notification","Verify User should be able to close the notification", "No unread Messages are there for now come back later","Failed");
		}
		}
	}
	@Then("^User should be able click the unread message/Document count and go to the detailed view \"([^\"]*)\"$")
	public void user_should_be_able_click_the_unread_message_Document_count_and_go_to_the_detailed_view(String Device) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able see the unread message and document", "", "", "");
		String Result=dashboardpage.Navigate_unread_message_detail_view(Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able see the unread message and document","Verify User should be able see the unread message and document", "Successfully Navigate to detailed message and document ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able see the unread message and document","Verify User should be able see the unread message and document", "Failed to navigate the document and message","Failed");
		}
		}
	}
	@Then("^User should be able to download the attachment of the specific message as \"([^\"]*)\"$")
	public void user_should_be_able_to_download_the_attachment_of_the_specific_message_as(String message_Title) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to download the attachment from the message", "", "", "");
		String Result=messages.Download_attachment_from_message(message_Title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "Successfully Downloaded the attachment ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "No Attachment files are there in the particular message","Failed");
		}
		}
	}
	@Then("^User should be able to validate all the property of the specific message title as \"([^\"]*)\"$")
	public void User_should_be_able_to_validate_all_the_property_of_the_specific_message_title_as(String message_Title) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to validate all the property of the specific message title", "", "", "");
		String Result=messages.validation_of_message_template(message_Title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to validate all the property of the specific message title","Verify User should be able to validate all the property of the specific message title", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to validate all the property of the specific message title","Verify User should be able to validate all the property of the specific message title",Result ,"Failed");
		}
		}
	}
	@Then("^User should be able to get the permanent link from the message and login through the portal as \"([^\"]*)\" and \"([^\"]*)\" and validate the message title as \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_permanent_link_from_the_message_and_login_through_the_portal_as_and_and_validate_the_message_title_as(String userID_LBC, String password_LBC, String message_Title) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to get the permanent link from the message", "", "", "");
		String Result=messages.permanent_link_Retrive(userID_LBC,password_LBC,message_Title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to get the permanent link from the message","Verify User should be able to get the permanent link from the message", "Successfully get the permanent link"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to get the permanent link from the message","Verify User should be able to get the permanent link from the message", "No permanent Link Found","Failed");
		}
		}
	}
	@Then("^User should be able to Navigate through the message by pagination$")
	public void User_should_be_able_to_Navigate_through_the_message_by_pagination() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to navigate through the message pages", "", "", "");
		String Result=messages.pagination_of_message();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to navigate through the message pages","Verify User should be able to navigate through the message pages", "Successfully pagination done"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to navigate through the message pages","Verify User should be able to navigate through the message pages", "Failed to do the pagination"+Result,"Failed");
		}
		}
	}
	@Then("^User should be able to see messages by default displayed in descending order by Date and Time of the message$")
	public void User_should_be_able_to_see_messages_by_default_displayed_in_descending_order_by_Date_and_Time_of_the_message() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "", "", "");
		String Result=messages.display_message_in_descending_order();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message","Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "Successfully displayed the message by descending order"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message","Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "Failed to display the message by descending order"+Result,"Failed");
		}
		}
	}
	@Then("^User should be able to see last login date and time displayed on the home page$")
	public void User_should_be_able_to_see_last_login_date_and_time_displayed_on_the_home_page() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to see last login date and time displayed on the home page", "", "", "");
		String Result=userManagementPage.last_login_date_time_in_home_page();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to see last login date and time displayed on the home page","Verify User should be able to see last login date and time displayed on the home page", "Successfully displayed the last login date and time in the home page"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to see last login date and time displayed on the home page","Verify User should be able to see last login date and time displayed on the home page", "Failed to display the Last login date and time in the homwe page"+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to create a new alliance user by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_a_new_alliance_user_by_giving(String Language,String User_Type, String Alliance_name, String Profile_type, String First_Name, String last_name, String email_id, String UserName_new_alliance, String mobile_number) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Admin should be able to Create new Allianz", "", "", "");
		String Result=userManagementPage.create_new_allianz_user(User_Type, Alliance_name, Profile_type, First_Name, last_name, email_id, UserName_new_alliance, mobile_number, Language);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to Create new Allianz","Verify Admin should be able to Create new Allianz", "Successfully Created the allianz"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to Create new Allianz","Verify Admin should be able to Create new Allianz", "Failed to create the allianz"+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to create a new merchant user by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_a_new_merchant_user_by_giving(String User_Type,String Merchant_ID,String Profile_type,String First_Name,String last_name,String UserName_new_alliance,String email_id,String mobile_number,String Language) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Admin should be able to create a merchant", "", "", "");
		String Result=userManagementPage.Create_new_merchant(User_Type,Merchant_ID,Profile_type,First_Name, last_name, UserName_new_alliance, email_id, mobile_number, Language);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Successfully Created the Merchant"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Failed to create the Merchant"+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to validate the profile information of the account$")
	public void user_should_be_able_to_validate_the_profile_information_of_the_account() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to validate profile information", "", "", "");
		String Result=userManagementPage.Validate_profile_information();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate profile information","Verify BO should be able to validate profile information", "Successfully verified the profile information"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate profile information","Verify BO should be able to validate profile information", "Failed to verify the profile information"+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to change the password to a new one as \"([^\"]*)\" ,\"([^\"]*)\"$")
	public void user_should_be_able_to_change_the_password_to_a_new_one_as(String New_password, String password) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to change the password", "", "", "");
		String Result=userManagementPage.Change_Password_of_BO(New_password,password);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to change the password","Verify BO should be able to change the password", "Successfully Changed the password "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to change the password","Verify BO should be able to change the password", "Failed to Change the password "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to download the terms and conditions in the given path \"([^\"]*)\"$")
	public void user_should_be_able_to_download_the_terms_and_conditions_in_the_given_path(String downloaded_Path) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to download the terms and conditions", "", "", "");
		String Result=termsandConditions.download_terms_and_condition(downloaded_Path);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions","Verify BO should be able to download the terms and conditions", "Successfully Downloaded the terms and conditions "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions","Verify BO should be able to download the terms and conditions", "Failed to Downloaded the terms and conditions "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to accept the terms and conditions$")
	public void user_should_be_able_to_accept_the_terms_and_conditions() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to Accept the terms and conditions", "", "", "");
		String Result=termsandConditions.Accept_terms_and_conditions();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to accept the terms and conditions","Verify BO should be able to accept the terms and conditions", "Successfully accepted the terms and conditions "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to accept the terms and conditions","Verify BO should be able to accept the terms and conditions", "Failed to accept the terms and conditions "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to see the password expiry message and change the password like \"([^\"]*)\" ,\"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_password_expiry_message_and_change_the_password_like(String New_password, String password) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to see the expired message and able to change the password", "", "", "");
		String Result=userManagementPage.Password_expire_message(New_password,password);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the expired message and able to change the password","Verify BO should be able to see the expired message and able to change the password", "Successfully Changed the password "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the expired message and able to change the password","Verify BO should be able to see the expired message and able to change the password", "Failed to Change the password "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to download multiple_documents from document library by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_download_multiple_documents_from_document_library_by_providing(String Alliance_code,String downloaded_Path) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to download multiple documents", "", "", "");
		String Result=documentManagement.Download_document_from_document_library(Alliance_code, downloaded_Path);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download multiple documents","Verify BO should be able to download multiple documents", "Successfully downloaded the documents "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download multiple documents","Verify BO should be able to download multiple documents", "Failed to download the documents "+Result,"Failed");
		}
		}
	}
	@Then("^Then user should be able to navigate to the preAuthorization page and select any time period filter$")
	public void user_should_be_able_to_navigate_to_the_preAuthorization_page_and_select_any_time_period_filter() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "", "", "");
		String Result=financialactivity.Verify_Time_Period_filter_For_Preauthorization();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter","Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "Successfully selected and verified every time period filter "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter","Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "Failed to Verify the time period filter "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to get the xml report downloaded for transaction page and \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_xml_report_downloaded_for_transaction_page_and(String downloaded_Path, String Alliance_code) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in xml format", "", "", "");
		String Result=financialactivity.Verify_transaction_xml_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xml format","Verify BO should be able to export the transaction details in xml format", "Successfully exported the transaction detail "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xml format","Verify BO should be able to export the transaction details in xml format", "Failed to export the transaction detail "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to modify the message content by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_modify_the_message_content_by_giving(String Message_title, String Sub_title, String message_body, String Upload_file) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify CM should be able to modify the message content", "", "", "");
		String Result=messages.modify_the_Message(Message_title, Sub_title, message_body, Upload_file);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to modify the message content","Verify CM should be able to modify the message content", "Successfully modified a message "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to modify the message content","Verify CM should be able to modify the message content", "Failed to modify a message "+Result,"Failed");
		}  
		}
	}
	@Then("^user should be able to delete the message by giving \"([^\"]*)\"$")
	public void user_should_be_able_to_delete_the_message_by_giving(String Message_title) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify CM should be able to delete a message", "", "", "");
		String Result=messages.delete_the_Message(Message_title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to delete a message","Verify CM should be able to delete a message", "Successfully deleted the message from the system "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to delete a message","Verify CM should be able to delete a message", "Failed to delete the message "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to search the user list by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_search_the_user_list_by_providing(String First_Name, String last_name, String UserName_new_alliance) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Admin will be able to search the user by their name and user name", "", "", "");
		String Result=userManagementPage.Search_User_in_Admin_console(First_Name, last_name, UserName_new_alliance);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin will be able to search the user by their name and user name","Verify Admin will be able to search the user by their name and user name", "Successfully got the user from the system "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin will be able to search the user by their name and user name","Verify CM Admin will be able to search the user by their name and user name", "Failed to get the user "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to get the xls report downloaded for transaction page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_xls_report_downloaded_for_transaction_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in xls format", "", "", "");
		String Result=financialactivity.Verify_transaction_xls_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xls format","Verify BO should be able to export the transaction details in xls format", "Successfully downloaded the transaction file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xls format","Verify BO should be able to export the transaction details in xls format", "Failed to download the file "+Result,"Failed");
		}
		}
	}
	@When("^user should be able to get the csv report downloaded from transaction page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_csv_report_downloaded_from_transaction_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in csv format", "", "", "");
		String Result=financialactivity.Verify_transaction_csv_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in csv format","Verify BO should be able to export the transaction details in csv format", "Successfully downloaded the transaction file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in csv format","Verify BO should be able to export the transaction details in csv format", "Failed to download the file "+Result,"Failed");
		}
		}
	}

	@When("^user should be able to export csv report from funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_csv_report_from_funding_page_by_providing(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to export the Funding batch details in csv format", "", "", "");
		String Result=financialactivity.Verify_funding_csv_file_download(downloaded_Path, Alliance_code, Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Successfully downloaded the Funding file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Failed to download the file "+Result,"Failed");
		}
		}
	}

	@Then("^user should be able to export csv report from Authorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_csv_report_from_Authorization_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to export the Authorization details in csv format", "", "", "");
		String Result=financialactivity.Verify_Authorization_csv_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in csv format","Verify BO should be able to export the Authorization details in csv format", "Successfully downloaded the Authorization file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in csv format","Verify BO should be able to export the Authorization details in csv format", "Failed to download the file "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to provide the \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_provide_the(String From_date, String To_date) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to provide the date", "", "", "");
		String Result=financialactivity.Verify_Time_picker_in_transaction_view(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the date","Verify BO should be able to provide the date", "Successfully provided the dates "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the date","Verify BO should be able to provide the date", "Failed to provide the date "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to navigate to the Transaction page and select any time period filter$")
	public void user_should_be_able_to_navigate_to_the_Transaction_page_and_select_any_time_period_filter() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to navigate to the Transaction page and select any time period filter", "", "", "");
		String Result=financialactivity.Verify_Time_Period_filter_For_Transaction();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the Transaction page and select any time period filter","Verify BO should be able to navigate to the Transaction page and select any time period filter", "Successfully selected and verified every time period filter "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the Transaction page and select any time period filter","Verify BO should be able to navigate to the Transaction page and select any time period filter", "Failed to Verify the time period filter "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to verify the \"([^\"]*)\" should be before \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_should_be_before(String From_date, String To_date) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able verify from date is before to date", "", "", "");
		String Result=financialactivity.Verify_From_date_should_be_before_to_date(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Successfully verified from date before todate "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Failed to verify "+Result,"Failed");
		}
		}
	}
	@When("^user should be able to export xml report from funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_xml_report_from_funding_page_by_providing(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in csv format", "", "", "");
		String Result=financialactivity.Verify_funding_xml_file_download(downloaded_Path, Alliance_code, Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Successfully downloaded the Funding file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Failed to download the file "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to provide the \"([^\"]*)\", \"([^\"]*)\" and verify the transaction$")
	public void user_should_be_able_to_provide_the_and_verify_the_transaction(String From_date, String To_date) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to provide the dates and verify the transaction detail", "", "", "");
		String Result=financialactivity.Verify_the_transaction_details_after_giving_dates(From_date,To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the dates and verify the transaction detail","Verify BO should be able to provide the dates and verify the transaction detail", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the dates and verify the transaction detail","Verify BO should be able to provide the dates and verify the transaction detail", "Failed to download the file "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to retrieve a permanent document link by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_retrieve_a_permanent_document_link_by_providing(String userID_LBC, String password_LBC, String downloaded_Path) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify CM should be able to retrieve a permanent link for document", "", "", "");
		String Result=documentManagement.permanent_link_Retrive(userID_LBC, password_LBC, downloaded_Path);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to retrieve a permanent link for document","Verify CM should be able to retrieve a permanent link for document", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to retrieve a permanent link for document","Verify CM should be able to retrieve a permanent link for document", "Failed"+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to add by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_add_by_providing(String document_Name, String Alliance_name, String Language, String Upload_file, String attachmentPath, String Description_DocumentText) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify CM should be able to add a new document", "", "", "");
		String Result=documentManagement.Add_a_new_document(document_Name, Alliance_name, Language, Upload_file, attachmentPath, Description_DocumentText);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to add a new document","Verify CM should be able to add a new document", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to add a new document","Verify CM should be able to add a new document", "Failed"+Result,"Failed");
		}
		}
	}

	@Then("^user should be able to rename a document by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_rename_a_document_by_providing(String Rename_document,String Upload_file) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify CM should be able to rename a document", "", "", "");
		String Result=documentManagement.Rename_a_document(Rename_document, Upload_file);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to rename a document","Verify CM should be able to rename a document", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to rename a document","Verify CM should be able to rename a document", "Failed"+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to remove a document by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_remove_a_document_by_providing(String Upload_file) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify CM should be able to remove a document", "", "", "");
		String Result=documentManagement.Remove_a_document(Upload_file);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to remove a document","Verify CM should be able to remove a document", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to remove a document","Verify CM should be able to remove a document", "Failed"+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to export xml report from Authorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_xml_report_from_Authorization_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to export the Authorization details in xml format", "", "", "");
		String Result=financialactivity.Verify_Authorization_xml_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in xml format","Verify BO should be able to export the Authorization details in xml format", "Successfully downloaded the Authorization file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in xml format","Verify BO should be able to export the Authorization details in xml format", "Failed to download the file "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to navigate to the document and validate the document unread status$")
	public void user_should_be_able_to_navigate_to_the_document_and_validate_the_document_unread_status() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to validate the document unread status", "", "", "");
		String Result=documentManagement.marked_unread_document();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate the document unread status","Verify BO should be able to validate the document unread status", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate the document unread status","Verify BO should be able to validate the document unread status", "Failed to load the document page "+Result,"Failed");
		}
		}
	}
	@Then("^user should be able to export the list of alliance users by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_the_list_of_alliance_users_by_providing(String Alliance_name, String downloaded_Path) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify User should be able to export the list of alliance user list", "", "", "");
		String Result=userManagementPage.Export_the_alliance_user_list(Alliance_name, downloaded_Path);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to export the list of alliance user list","Verify User should be able to export the list of alliance user list", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to export the list of alliance user list","Verify User should be able to export the list of alliance user list", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to search the authorization detail by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_search_the_authorization_detail_by_providing(String Order_ID,String From_date, String To_date) throws Throwable
	{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to search the authorization detail by providing order_id", "", "", "");
		String Result=financialactivity.verify_the_authorization_detail(Order_ID,From_date,To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to search the authorization detail by providing order_id","Verify User should be able to search the authorization detail by providing order_id", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to search the authorization detail by providing order_id","Verify User should be able to search the authorization detail by providing order_id", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to search the transaction detail by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_search_the_transaction_detail_by_providing(String Merchant_ID_Transaction) throws Throwable
	{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to search the transaction detail by providing merchant_id", "", "", "");
		String Result=financialactivity.Search_the_transaction_detail_by_giving_single_search_criteria(Merchant_ID_Transaction);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to search the transaction detail by providing merchant_id","Verify User should be able to search the transaction detail by providing merchant_id", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to search the transaction detail by providing merchant_id","Verify User should be able to search the transaction detail by providing merchant_id", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to validate the text disclaimer for each widget$")
	public void user_should_be_able_to_validate_the_text_disclaimer_for_each_widget() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to verify the text disclaimer for each widget", "", "", "");
		String Result=dashboardpage.Validate_Disclaimer_widget();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the text disclaimer for each widget","Verify User should be able to verify the text disclaimer for each widget", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to verify the text disclaimer for each widget","Verify User should be able to verify the text disclaimer for each widget", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to verify the details in funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_details_in_funding_page_by_providing(String From_date,String To_date,String Funding_Reference_number) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to verify the funding page and the store details", "", "", "");
		String Result=financialactivity.verify_the_funding_Activities_view_for_store_details(From_date,To_date,Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the store details","Verify user should be able to verify the funding page and the store details", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the store details","Verify user should be able to verify the funding page and the store details", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to verify the details in funding page and in the fees and vat details by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_details_in_funding_page_and_in_the_fees_and_vat_details_by_providing(String Funding_Reference_number) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to verify the funding page and the fees and vat details", "", "", "");
		String Result=financialactivity.verify_the_funding_Activities_view_for_feesAndVat_details(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to export report from PreAuthorization page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_report_from_PreAuthorization_page_by_providing(String downloaded_Path,String Alliance_code,String File_type_Format) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to export the preauthorization list in "+File_type_Format, "", "", "");
		String Result=financialactivity.Export_PreAuthorization_details(downloaded_Path, Alliance_code, File_type_Format);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in "+File_type_Format,"Verify user should be able to export the preauthorization list in "+File_type_Format, Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in "+File_type_Format,"Verify user should be able to export the preauthorization list in "+File_type_Format, Result,"Failed");
		}
		}
	}

	@Then("^user should be able to export XML report from PreAuthorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_XML_report_from_PreAuthorization_page_by_providing(String downloaded_Path,String Alliance_code) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to export the preauthorization list in XML format", "", "", "");
		String Result=financialactivity.Export_XML_PreAuthorization_details(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in XML format","Verify user should be able to export the preauthorization list in XML format", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in XML format","Verify user should be able to export the preauthorization list in XML format", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to verify the batch details in funding page by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_batch_details_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view the batch details in funding page", "", "", "");
		String Result=financialactivity.verify_the_funding_Activities_view_for_Batch_details(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the batch details in funding page","Verify user should be able to view the batch details in funding page", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the batch details in funding page","Verify user should be able to view the batch details in funding page", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to verify the payment type details in funding page by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_payment_type_details_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view the batch details in funding page", "", "", "");
		String Result=financialactivity.verify_the_funding_Activities_view_for_payment_method(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the payment type details in funding page","Verify user should be able to view the payment type details in funding page", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the payment type details in funding page","Verify user should be able to view the payment type details in funding page", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to verify the \"([^\"]*)\" should be before \"([^\"]*)\" in the pre auth view$")
	public void user_should_be_able_to_verify_the_should_be_before_in_the_pre_auth_view(String From_date, String To_date) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able verify from date is before to date", "", "", "");
		String Result=financialactivity.Verify_From_date_should_be_before_to_date_in_preAuth_view(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Successfully verified from date before todate "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Failed to verify "+Result,"Failed");
		}
		}
	}
	
	@Then("^user should be able to search and save the search by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_search_in_each_view(String Merchant_ID) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to search and save the search by providing", "", "", "");
		String Result=financialactivity.set_and_save_search_criteria_for_each_view(Merchant_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to navigate from top to buttom without scrolling a lot$")
	public void user_should_be_able_to_navigate_from_top_to_buttom_without_scrolling_a_lot() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to navigate from top to buttom view", "", "", "");
		String Result=financialactivity.Navigate_to_top_and_buttom_view();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate from top to buttom view","Verify BO should be able to navigate from top to buttom view", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate from top to buttom view","Verify BO should be able to navigate from top to buttom view", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify the webShop details in funding page by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_webShop_details_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to verify webshop details in the funding page", "", "", "");
		String Result=financialactivity.verify_the_funding_Activities_view_for_Webshop_details(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to verify webshop details in the funding page","Verify BO should be able to verify webshop details in the funding page", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to verify webshop details in the funding page","Verify BO should be able to verify webshop details in the funding page", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify the summary of fees by card type in funding page by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_summary_of_fees_by_card_type_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to verify summary of fees by each card type in the funding page", "", "", "");
		String Result=financialactivity.summary_of_fees_by_card_type(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to verify summary of fees by each card type in the funding page","Verify BO should be able to verify summary of fees by each card type in the funding page", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to verify summary of fees by each card type in the funding page","Verify BO should be able to verify summary of fees by each card type in the funding page", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify the funding summary page in the funding view$")
	public void user_should_be_able_to_verify_the_funding_summary_page_in_the_funding_view() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to verify funding summary view in the funding page", "", "", "");
		String Result=financialactivity.verify_the_funding_summary_view_in_funding_view();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to verify funding summary view in the funding page","Verify BO should be able to verify funding summary view in the funding page", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to verify funding summary view in the funding page","Verify BO should be able to verify funding summary view in the funding page", Result,"Failed");
		}}
	}
	@Then("^Admin should be able to see the communication summary and the registraion link by providing \"([^\"]*)\"$")
	public void Admin_should_be_able_to_see_the_communication_summary_and_the_registraion_link_by_providing(String UserName_new_alliance) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Admin should able to see the communication summary and the registraion link by providing", "", "", "");
		String Result=userManagementPage.Check_communication_summary_for_registraion_link(UserName_new_alliance);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to able to see the communication summary and the registraion link by providing","Verify Admin should be able to able to see the communication summary and the registraion link by providing", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to see the communication summary and the registraion link by providing","Verify Admin should be able to see the communication summary and the registraion link by providing", Result,"Failed");
		}}
	}
	@Then("^user should be able to view the detailed list of all fees applied to account in the funding view by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_view_the_detailed_list_of_all_fees_applied_to_account_in_the_funding_view_by_providing(String Funding_Reference_number) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify business owner should be able to see detailed list of all the fees applied to account ", "", "", "");
		String Result=financialactivity.detailed_list_of_all_fees_applied_to_account(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to see detailed list of all the fees applied to account","Verify business owner should be able to see detailed list of all the fees applied to account", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to see detailed list of all the fees applied to account","Verify business owner should be able to see detailed list of all the fees applied to account", Result,"Failed");
		}}
	}
	@Then("^user should be able to filter transactions in Funding Summary view by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_filter_transactions_in_Funding_Summary_view_by_providing(String From_date,String To_date,String Funding_Reference_number) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify business owner should be able to filter transactions in Funding Summary view by providing ", "", "", "");
		String Result=financialactivity.filter_transactions_in_Funding_Summary_view(From_date, To_date, Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to filter transactions in Funding Summary view by providing","Verify business owner should be able to filter transactions in Funding Summary view by providing", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to filter transactions in Funding Summary view by providing","Verify business owner should be able to filter transactions in Funding Summary view by providing", Result,"Failed");
		}}
	}
	@Then("^user should be able to see the order id in the authorization page$")
	public void user_should_be_able_to_see_the_order_id_in_the_authorization_page() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify business owner should be able to see the order id in the authorization page ", "", "", "");
		String Result=financialactivity.Display_Order_ID_in_Authorization_view();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to see the order id in the authorization page","Verify business owner should be able to see the order id in the authorization page", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to see the order id in the authorization page","Verify business owner should be able to see the order id in the authorization page", Result,"Failed");
		}}
	}
	@Then("^user should be able to set a filter and view individual stores via searching on \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_set_a_filter_and_view_individual_stores_via_searching_on(String Merchant_ID,String Store_ID) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify business owner should be able to filter the search by MID or TID ", "", "", "");
		String Result=financialactivity.filter_and_view_individual_stores_via_searching_on_MID_or_TID_level(Merchant_ID, Store_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to filter the search by MID or TID ","Verify business owner should be able to filter the search by MID or TID ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to filter the search by MID or TID ","Verify business owner should be able to filter the search by MID or TID ", Result,"Failed");
		}}
	}
	@Then("^user should be able to receive a Registration E-Mail and can landed upon the registration page by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_receive_a_Registration_Email_and_can_landed_upon_the_registration_page_by_providing(String UserName_new_alliance) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify new merchant should get the resgistraion link ", "", "", "");
		String Result=userManagementPage.Send_Registration_Email_available_in_communication_summary(UserName_new_alliance);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify new merchant should get the resgistraion link ","Verify new merchant should get the resgistraion link ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify new merchant should get the resgistraion link ","Verify new merchant should get the resgistraion link ", Result,"Failed");
		}}
	}
	@Then("^user should be able to search the preauth data by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_search_the_preauth_data_by_providing(String Merchant_ID) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify business owner should be able to search the preauth data ", "", "", "");
		String Result=financialactivity.search_through_preauth_data_by_entering_single_criteria_into_a_search_field(Merchant_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to search the preauth data ","Verify business owner should be able to search the preauth data ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify business owner should be able to search the preauth data ","Verify business owner should be able to search the preauth data ", Result,"Failed");
		}} 
	}
	@Then("^user should be able to search and save the search in the preauth view by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_search_and_save_the_search_in_the_preauth_view(String Merchant_ID) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to search and save the search by providing", "", "", "");
		String Result=financialactivity.set_and_save_search_criteria_for_preAuth_view(Merchant_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Failed");
		}}
	}
	@Then("^check next time when you login you can see the saved search by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void check_next_time_when_you_login_you_can_see_the_saved_search_by_providing(String appurl,String username,String password) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to see the saved search in preauth view", "", "", "");
		String Result=financialactivity.check_next_time_in_preAuth_view_for_same_search(appurl, username, password);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the saved search in preauth view","Verify BO should be able to see the saved search in preauth view", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the saved search in preauth view","Verify BO should be able to see the saved search in preauth view", Result,"Failed");
		}}
	}
	@Then("^user should be able to see the prompt while changing the password to a new one as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_change_the_password_to_a_new_one_as(String password, String New_password, String Retype_New_password) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to see the error message prompt ", "", "", "");
		String Result=userManagementPage.Change_Password_error_prompt(password, New_password, Retype_New_password);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the error message prompt ","Verify BO should be able to see the error message prompt ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the error message prompt ","Verify BO should be able to see the error message prompt ", Result,"Failed");
		}}
	}
	@Then("^user should be able to define and modify email templates by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_define_and_modify_email_templates_by_providing(String email_Type, String Language, String Description_email,String email_subject) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Admin should be able to modify the email template ", "", "", "");
		String Result=userManagementPage.Define_Modify_email_template(email_Type, Language, Description_email, email_subject);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to modify the email template ","Verify Admin should be able to modify the email template ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to modify the email template ","Verify Admin should be able to modify the email template ", Result,"Failed");
		}}
	}
	@Then("^user should be able to define and modify sms templates by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_define_and_modify_sms_templates_by_providing(String sms_Type, String Language, String Description_sms,String sms_subject) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify Admin should be able to modify the sms template ", "", "", "");
		String Result=userManagementPage.Define_Modify_sms_template(sms_Type, Language, Description_sms, sms_subject);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to modify the sms template ","Verify Admin should be able to modify the sms template ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to modify the sms template ","Verify Admin should be able to modify the sms template ", Result,"Failed");
		}}
	}
	@Then("^user should be able to see all the static and dynamic contents in the prefered \"([^\"]*)\" by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_all_the_static_and_dynamic_contents_in_the_prefered_by_providing(String Language_Change, String Welcome_Text, String Authorizations_Text, String Pre_authorizations_Text, String Transactions_Text, String Funding_Text) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify BO should be able to see the static contents in prefered laguage ", "", "", "");
		String Result=dashboardcustomization.Display_static_manage_content_in_preferred_language(Language_Change,Welcome_Text, Authorizations_Text, Pre_authorizations_Text, Transactions_Text, Funding_Text);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the static contents in prefered laguage ","Verify BO should be able to see the static contents in prefered laguage ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the static contents in prefered laguage ","Verify BO should be able to see the static contents in prefered laguage ", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify the batch details for general view in funding page by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_batch_details_for_general_view_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view the batch details in funding page", "", "", "");
		String Result=onlineauthorization.verify_the_funding_Activities_view_for_Batch_details_for_online_authorization(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the batch details for general view in funding page","Verify user should be able to view the batch details in funding page", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the batch details for general view in funding page","Verify user should be able to view the batch details in funding page", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify the fees and vat details for general view in funding page by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_fees_and_vat_details_for_general_view_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to verify the funding page and the fees and vat details", "", "", "");
		String Result=onlineauthorization.verify_the_funding_Activities_view_for_feesAndVat_details_for_online_authorization(Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the funding page in the general view and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the funding page in the general view and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify the transaction details and the EMS and funding fees for general view in transaction page$")
	public void user_should_be_able_to_verify_the_transaction_details_and_the_EMS_and_funding_fees_for_general_view_in_transaction_page() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to verify the transaction page and the funding and ems fees", "", "", "");
		String Result=onlineauthorization.verify_the_transaction_Activities_view_for_online_authorization();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the transaction page in the general view and the funding and the EMS fees ","Verify user should be able to verify the transaction page and the funding and EMS fees ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the transaction page in the general view and the funding and the EMS fees ","Verify user should be able to verify the transaction page and the funding and the EMS fees ", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify the authorization details for general view in Authorization page$")
	public void user_should_be_able_to_verify_the_authorization_details_for_general_view_in_Authorization_page() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to verify the Authorization page", "", "", "");
		String Result=onlineauthorization.verify_the_Authorization_Activities_view_for_online_authorization();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the Authorization page in the general view ","Verify user should be able to verify the authorization page ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the authorization page in the general view ","Verify user should be able to verify the authorization page ", Result,"Failed");
		}}
	}
	@Then("^user should be able to verify role based access restriction for each user in pre_authorization view$")
	public void user_should_be_able_to_verify_role_based_access_restriction_for_each_user_in_pre_authorization_view() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to verify the Authorization page", "", "", "");
		String Result=userManagementPage.Role_based_access_restriction_for_BO_and_BA();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify role based access restriction for each user in pre_authorization view ","Verify user should be able to verify role based access restriction for each user in pre_authorization view ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify role based access restriction for each user in pre_authorization view ","Verify user should be able to verify role based access restriction for each user in pre_authorization view ", Result,"Failed");
		}}
	}
	@Then("^user should be able to create a sub account by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_a_sub_account_by_providing(String First_Name, String last_name, String UserName_new_alliance, String email_id, String mobile_number, String Profile_type) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to create a sub account in the merchant portal", "", "", "");
		String Result=userManagementPage.Create_sub_account_in_merchant_portal(First_Name, last_name, UserName_new_alliance, email_id, mobile_number, Profile_type);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to create a sub account in the merchant portal ","Verify user should be able to create a sub account in the merchant portal ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to create a sub account in the merchant portal ","Verify user should be able to create a sub account in the merchant portal ", Result,"Failed");
		}}
	}
	@Then("^user should be able to search a sub account user by giving \"([^\"]*)\"$")
	public void user_should_be_able_to_search_a_sub_account_user_by_giving(String UserName_new_alliance) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to search a sub account in the admin portal", "", "", "");
		String Result=userManagementPage.Modify_sub_account_in_Admin_portal(UserName_new_alliance);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to search a sub account in the admin portal ","Verify user should be able to search a sub account in the admin portal ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to search a sub account in the admin portal ","Verify user should be able to search a sub account in the admin portal ", Result,"Failed");
		}}
	}
	@Then("^user should be able to see no transactions for provided search criteria by providing the \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_no_transactions_for_provided_search_criteria_by_providing_the(String From_date, String To_date) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to see an error message while searching in transaction data", "", "", "");
		String Result=financialactivity.no_transactions_for_search_criteria(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in transaction data ","Verify user should be able to see an error message while searching in transaction data ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in transaction data ","Verify user should be able to see an error message while searching in transaction data ", Result,"Failed");
		}}
	}
	@Then("^user should be able to see no preauth data for provided search criteria by providing the \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_no_preauth_data_for_provided_search_criteria_by_providing_the(String From_date, String To_date) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to see an error message while searching in preauth view", "", "", "");
		String Result=financialactivity.no_preAuth_data_for_search_criteria(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in preauth view ","Verify user should be able to see an error message while searching in preauth view ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in preauth view ","Verify user should be able to see an error message while searching in preauth view ", Result,"Failed");
		}}
	}
	@Then("^user should be able to see data in descending order by Data/Time by default in the pre_authorisation view$")
	public void user_should_be_able_to_see_data_in_descending_order_by_Data_Time_by_default_in_the_pre_authorisation_view() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to see data in descending order in the preauth view", "", "", "");
		String Result=financialactivity.Default_Descending_order_data_in_PreAuth_view();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to see data in descending order in the preauth view ","Verify user should be able to see data in descending order in the preauth view ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to see data in descending order in the preauth view ","Verify user should be able to see data in descending order in the preauth view ", Result,"Failed");
		}}
	}
	@Then("^user should be able to view and scroll through a detailed list of all authorization data by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_view_and_scroll_through_a_detailed_list_of_all_authorization_data_by_providing(String From_date,String To_date) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view and scroll through a detailed list of all authorization data", "", "", "");
		String Result=financialactivity.verify_the_Authorization_data_and_Activities_in_authorization_view(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all authorization data ","Verify user should be able to view and scroll through a detailed list of all authorization data ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all authorization data ","Verify user should be able to view and scroll through a detailed list of all authorization data ", Result,"Failed");
		}}
	}
	@Then("^user should be able to view and scroll through a detailed list of all transaction data$")
	public void user_should_be_able_to_view_and_scroll_through_a_detailed_list_of_all_transaction_data() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view and scroll through a detailed list of all transaction data", "", "", "");
		String Result=financialactivity.verify_the_transaction_details_and_Activities_in_Transaction_view();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all transaction data ","Verify user should be able to view and scroll through a detailed list of all transaction data ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all transaction data ","Verify user should be able to view and scroll through a detailed list of all transaction data ", Result,"Failed");
		}}
	}
	@Then("^user should be able to sort preAuth data into ascending and descending order \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_sort_preAuth_data_into_ascending_and_descending_order(String From_date,String To_date) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to sort preAuth data into ascending and descending order", "", "", "");
		String Result=financialactivity.sort_preauth_data_into_ascending_and_descending_order(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to sort preAuth data into ascending and descending order ","Verify user should be able to sort preAuth data into ascending and descending order ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to sort preAuth data into ascending and descending order ","Verify user should be able to sort preAuth data into ascending and descending order ", Result,"Failed");
		}}
	}
	@Then("^user should be able to sort transaction data into ascending and descending order$")
	public void user_should_be_able_to_sort_transaction_data_into_ascending_and_descending_order() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to sort transaction data into ascending and descending order", "", "", "");
		String Result=financialactivity.sort_transaction_data_into_ascending_and_descending_order();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to sort transaction data into ascending and descending order ","Verify user should be able to sort transaction data into ascending and descending order ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to sort transaction data into ascending and descending order ","Verify user should be able to sort transaction data into ascending and descending order ", Result,"Failed");
		}}
	}
	@Then("^user should be able to see data in descending order by Data/Time by default in the transaction view$")
	public void user_should_be_able_to_see_data_in_descending_order_by_Data_Time_by_default_in_the_transaction_view() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to see default transaction data in descending order", "", "", "");
		String Result=financialactivity.Default_view_is_descending_order_in_transaction_view();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to see default transaction data in descending order ","Verify user should be able to see default transaction data in descending order ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to see default transaction data in descending order ","Verify user should be able to see default transaction data in descending order ", Result,"Failed");
		}}
	}
	@Then("^user should be able to see fee information in the Transaction detail$")
	public void user_should_be_able_to_see_fee_information_in_the_Transaction_detail() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to see fee information in the Transaction detail ", "", "", "");
		String Result=financialactivity.Fee_information_in_the_transaction_detail_of_each_transaction();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Failed");
		}}
	}
	@Then("^user should verify the date and time in the dashboard page by providing \"([^\"]*)\"$")
	public void user_should_verify_the_date_and_time_in_the_dashboard_page_by_providing(String Welcome_Text) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to see fee information in the Transaction detail ", "", "", "");
		String Result=dashboardcustomization.portal_appears_in_my_preferred_locale(Welcome_Text);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Failed");
		}}
	}
	@Then("^user should be able to validate refunding amount not greater than remaining refund amount by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_validate_refunding_amount_not_greater_than_remaining_refund_amount_by_providing(String Transaction_ID,String Refund_amount) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to validate refunding amount not greater than remaining refund amount ", "", "", "");
		String Result=financialactivity.Validate_refunding_amount_not_greater_than_remaining_refund_amount(Transaction_ID, Refund_amount);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate refunding amount not greater than remaining refund amount ","Verify user should be able to validate refunding amount not greater than remaining refund amount ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate refunding amount not greater than remaining refund amount ","Verify user should be able to validate refunding amount not greater than remaining refund amount ", Result,"Failed");
		}}
	}
	@Then("^user should be able to see view records of all the multiple refunds initiated$")
	public void user_should_be_able_to_see_view_records_of_all_the_multiple_refunds_initiated() throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to see view records of all the multiple refunds initiated ", "", "", "");
		String Result=financialactivity.View_records_of_all_the_multiple_refunds_initiated();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to see view records of all the multiple refunds initiated ","Verify user should be able to see view records of all the multiple refunds initiated ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to see view records of all the multiple refunds initiated ","Verify user should be able to see view records of all the multiple refunds initiated ", Result,"Failed");
		}}
	}
	@Then("^user should be able to manage Portal content in multiple languages and verify it in message page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_manage_Portal_content_in_multiple_languages_and_verify_it_in_message_page_by_providing(String Language_Change,String Message_title) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to manage Portal content in multiple languages and verify it in message page ", "", "", "");
		String Result=dashboardcustomization.Manage_the_message_in_portal_specific_Language(Language_Change, Message_title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to manage Portal content in multiple languages and verify it in message page ","Verify user should be able to manage Portal content in multiple languages and verify it in message page ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to manage Portal content in multiple languages and verify it in message page ","Verify user should be able to manage Portal content in multiple languages and verify it in message page ", Result,"Failed");
		}}
	}
	@Then("^user should be able to enter correct amount for refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_enter_correct_amount_for_refund_by_providing(String From_date,String To_date,String Transaction_ID,String Refund_amount ) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to enter correct amount for refund ", "", "", "");
		String Result=financialactivity.Validate_Enter_correct_amount_for_refund(From_date,To_date,Transaction_ID, Refund_amount);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to enter correct amount for refund ","Verify user should be able to enter correct amount for refund ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to enter correct amount for refund ","Verify user should be able to enter correct amount for refund ", Result,"Failed");
		}}
	}
	@Then("^user should be able to provide separate user right for accessing refund functionality$")
	public void user_should_be_able_to_provide_separate_user_right_for_accessing_refund_functionality() throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to provide separate user rights for accessing refund functionality ", "", "", "");
		String Result=financialactivity.user_access_right_for_refund_functionality();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to provide separate user rights for accessing refund functionality ","Verify user should be able to provide separate user rights for accessing refund functionality ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to provide separate user rights for accessing refund functionality ","Verify user should be able to provide separate user rights for accessing refund functionality ", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to validate preauth validity duration from the date of the preauth transaction by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_validate_preauth_validity_duration_from_the_date_of_the_preauth_transaction_by_providing(String Order_ID) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to validate preauth validity duration from the date of the preauth transaction ", "", "", "");
		String Result=financialactivity.Pre_auth_validity_duration_from_the_date_of_the_pre_auth_transaction(Order_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate preauth validity duration from the date of the preauth transaction ","Verify user should be able to validate preauth validity duration from the date of the preauth transaction ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate preauth validity duration from the date of the preauth transaction ","Verify user should be able to validate preauth validity duration from the date of the preauth transaction ", Result,"Failed");
		}
		}
	}	
	@Then("^user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion \"([^\"]*)\"$")
	public void user_should_be_able_to_validate_pre_authorisation_transaction_to_be_eligible_for_pre_auth_completion(String Order_ID) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ", "", "", "");
		String Result=financialactivity.Rules_for_pre_auth_completion(Order_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ","Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ","Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ", Result,"Failed");
		}}
	}
	@Then("^user should be able to validate pre-auth completion to be in the same currency as the preauth amount \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_validate_pre_auth_completion_to_be_in_the_same_currency_as_the_preauth_amount(String Order_ID, String sqlQuery) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", " Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ", "", "", "");
		String Result=financialactivity.preauth_completion_to_be_in_the_same_currency_as_the_preauth(Order_ID, sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ","Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ","Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to validate confirmation page of pre-auth completion \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_validate_confirmation_page_of_preauth_completion(String Order_ID, String sqlQuery) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to validate confirmation page of pre-auth completion ", "", "", "");
		String Result=financialactivity.preauth_completion_to_be_in_the_same_currency_as_the_preauth(Order_ID, sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate confirmation page of pre-auth completion ","Verify user should be able to validate confirmation page of pre-auth completion ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate confirmation page of pre-auth completion ","Verify user should be able to validate confirmation page of pre-auth completion ", Result,"Failed");
		}}
	}
	@Then("^user should be able to return to the pre-auth view from the auth completion confirmation screen \"([^\"]*)\"$")
	public void user_should_be_able_to_return_to_the_preauth_view_from_the_auth_completion_confirmation_screen(String Order_ID) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ", "", "", "");
		String Result=financialactivity.return_to_the_preauth_view_from_the_auth_completion_confirmation_screen(Order_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ","Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ","Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ", Result,"Failed");
		}}
	}
	@Then("^user should be able to request resending of the passcode \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_request_resending_of_the_passcode(String Order_ID, String sqlQuery) throws Throwable {
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to request resending of the passcode ", "", "", "");
		String Result=financialactivity.request_resending_of_the_passcode_in_pre_auth_completion(Order_ID,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to request resending of the passcode ","Verify user should be able to request resending of the passcode ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to request resending of the passcode ","Verify user should be able to request resending of the passcode ", Result,"Failed");
		}}
	}
	@Then("^user should be able to preauth completion cannot be initiated once the preauth validity duration has expired by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_preauth_completion_cannot_be_initiated_once_the_preauth_validity_duration_has_expired_by_providing(String From_date,String To_date,String Order_ID )throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ", "", "", "");
		String Result=financialactivity.Initiating_preauth_completion_after_the_validity_has_expired(From_date,To_date,Order_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ","Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ","Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ", Result,"Failed");
		}}
	}
	@Then("^user should be able to view the available preauth completion amount when an auth completion is initiated by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_view_the_available_preauth_completion_amount_when_an_auth_completion_is_initiated_by_providing(String Order_ID,String sqlQuery)throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view the available preauth completion amount when an auth completion is initiated ", "", "", "");
		String Result=financialactivity.view_the_available_preauth_completion_amount_when_an_auth_completion_is_initiated(Order_ID,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the available preauth completion amount when an auth completion is initiated ","Verify user should be able to view the available preauth completion amount when an auth completion is initiated ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view the available preauth completion amount when an auth completion is initiated ","Verify user should be able to view the available preauth completion amount when an auth completion is initiated ", Result,"Failed");
		}}
	}
	@Then("^user should be able to do full preauth completion on preauthorisation by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_do_full_preauth_completion_on_preauthorisation_by_providing(String Order_ID,String sqlQuery)throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to do full preauth completion on preauthorisation ", "", "", "");
		String Result=financialactivity.Full_preauth_completion_on_preauthorisation(Order_ID,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to do full preauth completion on preauthorisation ","Verify user should be able to do full preauth completion on preauthorisation ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to do full preauth completion on preauthorisation ","Verify user should be able to do full preauth completion on preauthorisation ", Result,"Failed");
		}}
	}
	@Then("^user should be able to identify refundable transactions and made available for refund$")
	public void user_should_be_able_to_identify_refundable_transactions_and_made_available_for_refund()throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to identify refundable transactions and made available for refund ", "", "", "");
		String Result=financialactivity.Identifying_refundable_transaction();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to identify refundable transactions and made available for refund ","Verify user should be able to identify refundable transactions and made available for refundn ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to identify refundable transactions and made available for refund ","Verify user should be able to identify refundable transactions and made available for refund ", Result,"Failed");
		}}
	}
	@Then("^user should be able to view remaining refund amount by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_view_remaining_refund_amount_by_providing(String From_date,String To_date,String Order_ID) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view remaining refund amount ", "", "", "");
		String Result=financialactivity.Remaining_refund_amount_for_every_refundable_transaction(From_date,To_date,Order_ID);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view remaining refund amount ","Verify user should be able to view remaining refund amount ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view remaining refund amount ","Verify user should be able to view remaining refund amount ", Result,"Failed");
		}}
	}
	@Then("^user should be able to add unsuccessful refund amount to the remaining refund amount by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_add_unsuccessful_refund_amount_to_the_remaining_refund_amount_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", "", "", "");
		String Result=financialactivity.Adjusting_unsuccessful_refund_amount_back_to_remaining_refund_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ","Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ","Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", Result,"Failed");
		}}
	}
	@Then("^user should be able to view successful refunded amount by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_view_successful_refunded_amount_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", "", "", "");
		String Result=financialactivity.View_successful_refunded_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view successful refunded amount ","Verify user should be able to view successful refunded amount ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view successful refunded amount ","Verify user should be able to view successful refunded amount ", Result,"Failed");
		}}
	}
	@Then("^user should be able to view status of refund transaction initiated by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_view_status_of_refund_transaction_initiated_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view status of refund transaction initiated ", "", "", "");
		String Result=financialactivity.View_successful_refunded_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view status of refund transaction initiated ","Verify user should be able to view status of refund transaction initiated ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view status of refund transaction initiated ","Verify user should be able to view status of refund transaction initiated ", Result,"Failed");
		}}
	}
	@Then("^user should be able to validate user mobile number perfoming preauth completion by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_validate_user_mobile_number_perfoming_preauth_completion_by_providing(String Order_ID,String sqlQuery) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to validate user mobile number perfoming preauth completion ", "", "", "");
		String Result=financialactivity.validation_of_user_mobile_number_perfoming_preauth_completion(Order_ID,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate user mobile number perfoming preauth completion ","Verify user should be able to validate user mobile number perfoming preauth completion ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to validate user mobile number perfoming preauth completion ","Verify user should be able to validate user mobile number perfoming preauth completion", Result,"Failed");
		}}
	}
	@Then("^user should be able to send passcode to user mobile number for performing refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_send_passcode_to_user_mobile_number_for_performing_refund_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to send passcode to user mobile number for performing refund ", "", "", "");
		String Result=financialactivity.validation_of_user_mobile_number_perfoming_refund(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to send passcode to user mobile number for performing refund ","Verify user should be able to send passcode to user mobile number for performing refund ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to send passcode to user mobile number for performing refund ","Verify user should be able to send passcode to user mobile number for performing refund ", Result,"Failed");
		}}
	}
	
	@Then("^user should be able to have an option to enter passcode received for performing refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_have_an_option_to_enter_passcode_received_for_performing_refund_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to have an option to enter passcode received for performing refund ", "", "", "");
		String Result=financialactivity.Option_to_enter_passcode_received_for_performing_refund(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to have an option to enter passcode received for performing refund ","Verify user should be able to have an option to enter passcode received for performing refund ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to have an option to enter passcode received for performing refund ","Verify user should be able to have an option to enter passcode received for performing refund ", Result,"Failed");
		}}
	}
	@Then("^user should be able to review and rectify the refund transaction before confirming the refund processing by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_review_and_rectify_the_refund_transaction_before_confirming_the_refund_processing_by_providing(String From_date,String To_date,String Transaction_ID,String Refund_amount ) throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to review and rectify the refund transaction before confirming the refund ", "", "", "");
		String Result=financialactivity.Validate_Enter_correct_amount_for_refund(From_date,To_date,Transaction_ID, Refund_amount);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to review and rectify the refund transaction before confirming the refund ","Verify user should be able to review and rectify the refund transaction before confirming the refund ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to review and rectify the refund transaction before confirming the refund ","Verify user should be able to review and rectify the refund transaction before confirming the refund ", Result,"Failed");
		}}
	}
	@Then("^user should be able to modify the original transaction to refund to either do full or partial refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_modify_the_original_transaction_to_refund_to_either_do_full_or_partial_refund_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to modify the original transaction to refund to either do full or partial refund ", "", "", "");
		String Result=financialactivity.View_successful_refunded_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to modify the original transaction to refund to either do full or partial refund ","Verify user should be able to modify the original transaction to refund to either do full or partial refund ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to modify the original transaction to refund to either do full or partial refund ","Verify user should be able to modify the original transaction to refund to either do full or partial refund ", Result,"Failed");
		}}
	}
	@Then("^user should be able to request resending of passcode by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_request_resending_of_passcode_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to request resending of passcode ", "", "", "");
		String Result=financialactivity.Request_resending_of_passcode_for_performing_refund(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to request resending of passcode ","Verify user should be able to request resending of passcode ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to request resending of passcode ","Verify user should be able to request resending of passcode ", Result,"Failed");
		}}
	}
	@Then("^user should be able to completely void preauthorisation transactions in the preAuth view by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_completely_void_preauthorisation_transactions_in_the_preAuth_view_by_providing(String Order_ID,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to completely void preauthorisation transactions in the preAuth view ", "", "", "");
		String Result=financialactivity.Void_preauthorisation_Transactions(Order_ID,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to completely void preauthorisation transactions in the preAuth view ","Verify user should be able to completely void preauthorisation transactions in the preAuth view ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to completely void preauthorisation transactions in the preAuth view ","Verify user should be able to completely void preauthorisation transactions in the preAuth view ", Result,"Failed");
		}}
	}
	@Then("^user should be able to view status of the preauth completion transaction in preauth view by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_view_status_of_the_preauth_completion_transaction_in_preauth_view_by_providing(String Order_ID,String sqlQuery)  throws Throwable{
		if(Result1.contains("Passed"))
		{ 
		lib.WriteReportStep("1", "Verify user should be able to view status of the preauth completion transaction in preauth view ", "", "", "");
		String Result=financialactivity.View_status_of_the_preauth_completion_transaction_in_the_preauth(Order_ID,sqlQuery);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to view status of the preauth completion transaction in preauth view ","Verify user should be able to view status of the preauth completion transaction in preauth view ", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify user should be able to view status of the preauth completion transaction in preauth view ","Verify user should be able to view status of the preauth completion transaction in preauth view ", Result,"Failed");
		}
		}
	}
	@Then("^user should be able to view the PreAuthorization details in the dashboard along with the expiring preauthorizations$")
	public void user_should_be_able_to_view_the_PreAuthorization_details_in_the_dashboard_along_with_the_expiring_preauthorizations() throws Throwable{
		if(Result1.contains("Passed"))
		{    
		lib.WriteReportStep("1", "View PreAuthorization Details", "", "", "");
           try
           {
                  String Result=financialactivity.validatePreAuthorizationsDetails();
                  if(Result.equalsIgnoreCase("PreAuthorization details are displayed"))
                  {
                        lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Passed");
                  }
                  else if(Result.contains("the next 3 days"))
                  {
                        lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Passed");
                  }
                  else
                  {
                        lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Failed");
                  }

           }
           catch(Exception e)
           {
                  lib.WriteReportStep("2", "View PreAuthorization Details", "PreAuthorizations details should be available", e.getMessage(),"Failed");
                  e.printStackTrace();
           }
		}
    }
	
	
////////////////////////////////////////////////////////////////////////Janani////////////////////////////////////////////////////////////////////////////////	
	
	
	@And("^user Navigate to UserLists$")
	public void user_Navigate_to_UserLists() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation to UsersList", "", "", "");
		//userManagementPage.navigate_to_UserLists();
		String Result=userManagementPage.navigate_to_UserLists();
		if(Result1.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click UsersList", "User should be successfuly navigated to UsersList", "Successfuly navigated to UsersList", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click UsersList", "User should be successfuly navigated to UsersList", "Unable to navigate to UsersList", "Failed");
		}
	}
	
	@When("^user clicks search icon using searchtext as \"([^\"]*)\"$")
	public void user_clicks_search_icon_using_searchtext_as(String User_Name) throws Throwable {
	    lib.WriteReportStep("1", "Enter username & click Search", "", "", "");
	    String Result = userManagementPage.Search_Userdetails(User_Name);
	    Result1=Result;
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Enter User Name & click Search Icon", "User should be able to view search result for User Name: "+User_Name, "Search Result: "+Result, "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Enter User Name & click Search Icon", "User should be able to view search result for User Name: "+User_Name, "Search Result: "+Result, "Failed");
		 }
		
	}
	
	@Then("^user should be able to modify user details for the desired user for fields \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_modify_user_details_for_the_desired_user_for_fields(String First_Name, String Last_Name, String Email, String Mobile_Phone, String Phone_Number) throws Throwable {
		lib.WriteReportStep("1", "Modify User details", "", "", "");
		if (Result1.contains("Passed"))
		{
			String Result = userManagementPage.Modify_Userdetails(First_Name, Last_Name, Email, Mobile_Phone, Phone_Number);
			if(Result.contains("Passed"))
			 {
				lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "User details modified successfully:" + Result, "Passed");
			 }
			 else
			 {
				 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details", "Failed");
			 }
		}
		else
		 {
			 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
		 }
	}
		
	@And("^Navigates to User Management$")
	public void Navigates_to_User_Management() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation to User Management", "", "", "");
		String Result=userManagementPage.navigate_to_User_Management();
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click User Management", "User should be successfuly navigated to User Management", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click User Management", "User should be successfuly navigated to User Management", Result, "Failed");
		}
	}
	
	@And("^Navigates to Manage user access for the user \"([^\"]*)\"$")
	public void navigates_to_Manage_user_access_for_the_user(String User_Name) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Verify Navigation to Manage user access", "", "", "");
			String Result=userManagementPage.navigate_to_Manage_user_access(User_Name);
			Result1=Result;
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Search for User Name and navigate to Manage user access", "User should be successfuly navigated to Manage user access", "Successfuly navigated to Manage user access", "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Search for User Name and navigate to Manage user access", "User should be successfuly navigated to Manage user access", "Unable to navigate to Manage user access; "+Result, "Failed");
			}
		}
	}
	
	@Then("^user should be able to provide reason \"([^\"]*)\" for blocking sub-account$")
	public void user_should_be_able_to_provide_reason_for_blocking_sub_account(String reason) throws Throwable {
		lib.WriteReportStep("1", "Block the user with approriate reason", "", "", "");
		if (Result1.contains("Passed"))
		{
		String Result=userManagementPage.user_should_be_able_to_provide_reason_for_blocking_sub_account(reason);
		
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Update Profile access and Reason for change in access", "User should successfuly be able to Update Profile access and Reason for change in access", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Update Profile access and Reason for change in access", "User should successfuly be able to Update Profile access and Reason for change in access", Result, "Failed");
			}
		}
		else
		 {
			 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
		 }
	
	}
	
	@Then("^user should be able to view revenue for each payment type$")
	public void user_should_be_able_to_view_revenue_for_each_payment_type() throws Throwable {
		lib.WriteReportStep("1", "View revenue for each payment type", "", "", "");
		String Result=dashboardpage.user_should_be_able_to_view_revenue_for_each_payment_type();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "View revenue for each payment type", "User should successfuly be able to view revenue for each payment type", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "View revenue for each payment type", "User should successfuly be able to view revenue for each payment type", Result, "Failed");
		}
	}
	
	@Then("^user should be able to view payment details$")
	public void user_should_be_able_to_view_payment_details() throws Throwable {
		lib.WriteReportStep("1", "View payment details", "", "", "");
		String Result=dashboardpage.user_should_be_able_to_view_payment_details();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click View details link", "User should successfuly be able to view payment details", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click View details link", "User should successfuly be able to view payment details", Result, "Failed");
		}
	}
	
	@Then("^user should not be able to view Mark for Expiry$")
	public void user_should_not_be_able_to_view_Mark_for_Expiry() throws Throwable {
		lib.WriteReportStep("1", "Verify if user is not be able to view Mark for Expiry", "", "", "");
		if (Result1.contains("Passed"))
		{
		String Result=userManagementPage.user_should_not_be_able_to_view_Mark_for_Expiry();
		
			if(Result.equals("Passed"))
			{
			lib.WriteReportStep("2", "Verify if user is not be able to view Mark for Expiry", "User should not be able to view Mark for Expiry", "User is not able to view Mark for Expiry", "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Verify if user is not be able to view Mark for Expiry", "User should not be able to view Mark for Expiry", "User is able to view Mark for Expiry", "Failed");
			}
		}
		else
		 {
			 lib.WriteReportStep("2", "Verify if user is not be able to view Mark for Expiry", "User should not be able to view Mark for Expiry", "Unable to verify, No Result Found", "Failed");
		 }
	}
	
	@Then("^user should not be able to view option to terminate all additional users$")
	public void user_should_not_be_able_to_view_option_to_terminate_all_additional_users() throws Throwable {
		if (Result1.contains("Passed"))
		{
		lib.WriteReportStep("1", "View Checkbox to select all users", "", "", "");
		String Result=userManagementPage.user_should_not_be_able_to_view_option_to_terminate_all_additional_users();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if Checkbox exist in the page", "Checkbox should not be available in the page and hence user should have no option to terminate all additional users", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if Checkbox exist in the page", "Checkbox should not be available in the page and hence user should have no option to terminate all additional users", Result, "Failed");
		}
		}
	}
	
	@Then("^access should be restricted for additional BO user to modify \"([^\"]*)\"$")
	public void access_should_be_restricted_for_additional_BO_user_to_modify(String original_BO_accounts) throws Throwable {
		if (Result1.contains("Passed"))
		{
		lib.WriteReportStep("1", "Search for Original BO Accounts", "", "", "");
		String Result=userManagementPage.access_should_be_restricted_for_additional_BO_user_to_modify(original_BO_accounts);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Search for Original BO Accounts", "User should not find Original BO Accounts in search result", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Search for Original BO Accounts", "User should not find Original BO Accounts in search result", Result, "Failed");
		}
		}
	}
	 
	@Then("^user clicks submit and should be logged in as call center agent$")
	public void user_clicks_submit_and_should_be_logged_in_as_call_center_agent() throws Throwable {
		 lib.WriteReportStep("1", "Login to the application", "", "", "");
		 String Result= imporsonation.user_clicks_submit_and_should_be_logged_in_as_call_center_agent();
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify Login","User should be logged in Call center agent", Result,"Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify Login","User should be logged in Call center agent", Result,"Failed");
		 }
		 
	}
	
	@And("^Navigates to Settings$")
	public void Navigates_to_Settings() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation to Settings", "", "", "");
		String Result=userManagementPage.Navigates_to_Settings();
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click Settings", "User should be successfuly navigated to Settings", "Successfuly navigated to Settings", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click Settings", "User should be successfuly navigated to Settings", "Unable to navigate to Settings", "Failed");
		}
	}
	@Then("^username should be same as email address$")
	public void username_should_be_same_as_email_address() throws Throwable {
		lib.WriteReportStep("1", "Verify if username is same as email address", "", "", "");
		String Result=userManagementPage.username_should_be_same_as_email_address();
		if(Result1.contains("Passed"))
		{
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Verify if username is same as Email address", "Username should be same as Email address", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Verify if username is same as Email address", "Username should be same as Email address", Result, "Failed");
			}
		}
	}
	@And("^user Navigate to Communication summary$")
	public void user_Navigate_to_Communication_summary() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation to Communication Summary", "", "", "");
		String Result=userManagementPage.user_Navigate_to_Communication_summary();
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click Communication Summary", "User should be successfuly navigated to Communication Summary", "Successfuly navigated to Communication Summary", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click Communication Summary", "User should be successfuly navigated to Communication Summary", "Unable to navigate to Communication Summary", "Failed");
		}
	}
	@Then("^user should be able to view communication history for Email and SMS$")
	public void user_should_be_able_to_view_communication_history_for_Email_and_SMS() throws Throwable {
		lib.WriteReportStep("1", "View Communication History for Email and SMS", "", "", "");
		String Result=userManagementPage.user_should_be_able_to_view_communication_history_for_Email_and_SMS();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if user is able to view communication History for Email and SMS", "User should be able to view communication History for Email and SMS", "User is able to view communication History for Email and SMS", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if user is able to view communication History for Email and SMS", "User should be able to view communication History for Email and SMS", "User is not able to view communication History for Email and SMS", "Failed");
		}
	}
	@Then("^user should be able to Resend previous communications via email$")
	public void user_should_be_able_to_Resend_previous_communications_via_email() throws Throwable {
		if(Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Resend previous communications via e-mail", "", "", "");
			String Result=userManagementPage.user_should_be_able_to_Resend_previous_communications_via_email();
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Verify if user is able to Resend previous communications via e-mail", "User should be able to Resend previous communications via e-mail", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Verify if user is able to Resend previous communications via e-mail", "User should be able to Resend previous communications via e-mail", "User is not able to Resend previous communications via e-mail", "Failed");
			}
		}
	}
	@When("^agent enter merchant user name \"([^\"]*)\"$")
	public void agent_enter_merchant_user_name(String BOusername) throws Throwable {
		lib.WriteReportStep("1", "Impersonate as Merchant", "", "", "");
		String Result=financialactivity.agent_enter_merchant_user_name(BOusername);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Impersonate as Merchant", "Agent should successfully be able to impersonate as merchant", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Impersonate as Merchant", "Agent should successfully be able to impersonate as merchant", Result, "Failed");
		}
	}
	@And("^Navigate to Preauthorization$")
	public void Navigate_to_Preauthorization() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation to Pre-authorization", "", "", "");
		String Result=financialactivity.Navigate_to_Preauthorization();
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click Pre-authorization", "User should be successfuly navigated to Pre-authorization", "Successfuly navigated to Pre-authorization", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click Pre-authorization", "User should be successfuly navigated to Pre-authorization", "Unable to navigate to Pre-authorization", "Failed");
		}
	}
	@Then("^user should not be able to view Complete preauthorization and Void button$")
	public void user_should_not_be_able_to_view_Complete_preauthorization_and_Void_button() throws Throwable {
		lib.WriteReportStep("1", "Verify if Call center agent access the portal in read only mode ", "", "", "");
		String Result=financialactivity.user_should_not_be_able_to_view_Complete_preauthorization_and_Void_button();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if Complete preauthorization and Void buttons are not present", "Complete preauthorization and Void buttons should not be present", "Complete preauthorization and Void buttons is not present", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if Complete preauthorization and Void buttons are not present", "Complete preauthorization and Void buttons should not be present", Result, "Failed");
		}
	}
	@Then("^user should be able to view Approval widget for the day$")
	public void user_should_be_able_to_view_Approval_widget_for_the_day() throws Throwable {
		lib.WriteReportStep("1", "View Approval widget for the day", "", "", "");
		String Result=dashboardpage.user_should_be_able_to_view_Approval_widget_for_the_day();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "View Approval widget for the day", "User should successfuly be able to view Approval widget for the day", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "View Approval widget for the day", "User should successfuly be able to view Approval widget for the day", Result, "Failed");
		}
	}
	@And("^Navigates to Edit user details for the user \"([^\"]*)\"$")
	public void navigates_to_Edit_user_details_for_the_user(String User_Name) throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation to Edit user details", "", "", "");
		String Result=userManagementPage.navigate_to_Edit_user_details(User_Name);
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Search for User Name and navigate to Edit user details", "User should be successfuly navigated to Edit user details", "Successfuly navigated to Edit user details", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Search for User Name and navigate to Edit user details", "User should be successfuly navigated to Edit user details", "Unable to navigate to Edit user details; "+Result, "Failed");
		}
	}
	
	@Then("^user should be able to edit \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_edit(String Firstname, String Lastname, String Email, String mobileno, String telphoneno, String Profile) throws Throwable {
		if (Result1.contains("Passed"))
		{
		lib.WriteReportStep("1", "Edit User Details", "", "", "");
		String Result=userManagementPage.user_should_be_able_to_edit(Firstname, Lastname, Email, mobileno, telphoneno, Profile);
		
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Edit User details", "User should successfuly be able to edit user details", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Edit User details", "User should successfuly be able to edit user details", Result, "Failed");
			}
		}
		else
		 {
			 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
		 }
	
	}
	
	@And("^Click Create User$")
	public void Click_Create_User() throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Verify Navigation to Create User", "", "", "");
			String Result=userManagementPage.Click_Create_User();
			Result1=Result;
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Click Create User", "User should be successfuly navigated to Create new user page", "Successfuly navigated to Create new user page", "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Click Create User", "User should be successfuly navigated to Create new user page", "Unable to navigate to Create new user page", "Failed");
			}
		}
	}
	
	@Then("^user should be able to provide BO Profile to additional users \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_provide_BO_Profile_to_additional_users(String Firstname, String Lastname, String User_name, String Email, String mobileno, String telphoneno) throws Throwable {
		if (Result1.contains("Passed"))
		{
		lib.WriteReportStep("1", "Create additional user and provide BO Profile", "", "", "");
		String Result=userManagementPage.user_should_be_able_to_provide_BO_Profile_to_additional_users(Firstname, Lastname, User_name, Email, mobileno, telphoneno);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Create additional user and provide BO Profile", "User should successfuly be able to Create additional user and provide BO Profile", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Create additional user and provide BO Profile", "User should successfuly be able to Create additional user and provide BO Profile", Result, "Failed");
			}
		}
	}
	
	@And("^Navigate to Transactions$")
	public void Navigate_to_Transactions() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation to Transactions", "", "", "");
		String Result=financialactivity.Navigate_to_Transactions();
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click Transactions", "User should be successfuly navigated to Transactions", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click Transactions", "User should be successfuly navigated to Transactions", Result, "Failed");
		}
	}
	
	@Then("^user should be able to navigate to top and bottom of transaction list$")
	public void user_should_be_able_to_navigate_to_top_and_bottom_of_transaction_list() throws Throwable {
		if(Result1.contains("Passed"))
		{
		lib.WriteReportStep("1", "Verify Navigation to top and bottom of transaction list", "", "", "");
		String Result=financialactivity.user_should_be_able_to_navigate_to_top_and_bottom_of_transaction_list();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Navigate to Top and bottom of transaction list", "User should be successfuly navigated to Top & bottom of transaction list", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Navigate to Top and bottom of transaction list", "User should be successfuly navigated to Top & bottom of transaction list", Result, "Failed");
		}
		}
	}
	
	@And("^save column preference in Transactions$")
	public void save_column_preference() throws Throwable {
		lib.WriteReportStep("1", "Save column preference in Transactions", "", "", "");
		String Result=financialactivity.save_column_preference_in_Transactions();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Save column preference in Transactions", "User should successfuly be able to Save column preference", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Save column preference in Transactions", "User should successfuly be able to Save column preference", Result, "Failed");
		}
	}
	
	@And("^Navigate to Authorization$")
	public void Navigate_to_Authorization() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigate to Authorization", "", "", "");
		String Result=financialactivity.Navigate_to_Authorization();
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click Authorization", "User should be successfuly navigated to Authorization", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click Authorization", "User should be successfuly navigated to Authorization", Result, "Failed");
		}
	}
	@And("^save column preference in Authorization$")
	public void save_column_preference_in_Authorization() throws Throwable {
		lib.WriteReportStep("1", "Save column preference in Authorization", "", "", "");
		String Result=financialactivity.save_column_preference_in_Authorization();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Save column preference in Authorization", "User should successfuly be able to Save column preference", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Save column preference in Authorization", "User should successfuly be able to Save column preference", Result, "Failed");
		}
	}
	
	@Then("^user should able to view Choosen column in Authorization$")
	public void user_should_able_to_view_Choosen_column_in_Authorization() throws Throwable {
		lib.WriteReportStep("1", "Verify if saved column preference is displayed in future login", "", "", "");
		String Result=financialactivity.user_should_able_to_view_Choosen_column_in_Authorization();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Failed");
		}
	}
	@Then("^user should able to view Choosen column in Transactions$")
	public void user_should_able_to_view_Choosen_column_in_Transactions() throws Throwable {
		lib.WriteReportStep("1", "Verify if saved column preference is displayed in future login", "", "", "");
		String Result=financialactivity.user_should_able_to_view_Choosen_column_in_Transactions();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Failed");
		}
	}
	@Then("^user should be able to Create new user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_Create_new_user(String Firstname, String Lastname, String User_name, String Email, String mobileno, String telphoneno, String Profile) throws Throwable {
		if (Result1.contains("Passed"))
		{
		lib.WriteReportStep("1", "Create New User", "", "", "");
		String Result=userManagementPage.user_should_be_able_to_Create_new_user(Firstname, Lastname, User_name, Email, mobileno, telphoneno, Profile);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Create New User", "User should successfuly be able to Create new user", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Create new User", "User should successfuly be able to Create new user", Result, "Failed");
			}
		}
	}
	
	@Then("^should be able to view User \"([^\"]*)\" created by the BO$")
	public void should_be_able_to_view_User_created_by_the_BO(String AdditionalUser) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "View the user", "", "", "");
			String Result=userManagementPage.should_be_able_to_view_User_created_by_the_BO(AdditionalUser);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Search for User Name and view user", "User should successfuly be able to view user", "Successfuly viewed user", "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Search for User Name and view user", "User should successfuly be able to view user", "Unable to view user; "+Result, "Failed");
			}
		}
	}
	
	@Then("^user should be able to unblock sub-account$")
	public void user_should_be_able_to_unblock_sub_account() throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Unblock the user", "", "", "");
			String Result=userManagementPage.user_should_be_able_to_unblock_sub_account();
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Unblock the user", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Unblock the user", Result, "Failed");
			}
		}
		else
		 {
			 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
		 }
	}
	
	@Then("^user should be able to Terminate sub-account$")
	public void user_should_be_able_to_Terminate_sub_account() throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Terminate the user", "", "", "");
			String Result=userManagementPage.user_should_be_able_to_Terminate_sub_account();
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Terminate the user", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Terminate the user", Result, "Failed");
			}
		}
		else
		 {
			 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
		 }
	}
	@Then("^validate Preauth confirmation screen for OrderID \"([^\"]*)\"$")
	public void validate_Preauth_confirmation_screen_for_OrderID(String Order_ID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Validate Preauth confirmation screen", "", "", "");
			String Result=financialactivity.validate_Preauth_confirmation_screen_for_OrderID(Order_ID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Validate Preauth confirmation screen", "User should successfuly be able to validate Preauth confirmation screen", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Validate Preauth confirmation screen", "User should successfuly be able to validate Preauth confirmation screen", Result, "Failed");
			}
		}
	}
	@Then("^validate auth confirmation screen for OrderID \"([^\"]*)\"$")
	public void validate_auth_confirmation_screen_for_OrderID(String OrderID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Validate Auth confirmation screen", "", "", "");
			String Result=financialactivity.validate_auth_confirmation_screen_for_OrderID(OrderID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Validate Auth confirmation screen", "User should successfuly be able to validate Auth confirmation screen", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Validate Auth confirmation screen", "User should successfuly be able to validate Auth confirmation screen", Result, "Failed");
			}
		}
	}
	@Then("^Return from void confirmation back to preauth view for OrderID \"([^\"]*)\"$")
	public void Return_from_void_confirmation_back_to_preauth_view_for_OrderID(String Order_ID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Validate Return from void confirmation back to preauth view", "", "", "");
			String Result=financialactivity.Return_from_void_confirmation_back_to_preauth_view_for_OrderID(Order_ID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Validate Return from void confirmation back to preauth view", "User should successfuly be able to Return from void confirmation back to preauth view", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Validate Return from void confirmation back to preauth view", "User should successfuly be able to Return from void confirmation back to preauth view", Result, "Failed");
			}
		}
	}
	@Then("^Return from void confirmation back to authorization view for OrderID \"([^\"]*)\"$")
	public void Return_from_void_confirmation_back_to_authorization_view_for_OrderID (String OrderID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Validate Return from void confirmation back to authorization view", "", "", "");
			String Result=financialactivity.Return_from_void_confirmation_back_to_authorization_view_for_OrderID(OrderID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Validate Return from void confirmation back to authorization view", "User should successfuly be able to Return from void confirmation back to authorization view", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Validate Return from void confirmation back to authorization view", "User should successfuly be able to Return from void confirmation back to authorization view", Result, "Failed");
			}
		}
	}
	
	@Then("^verify void on transaction past today in authorization view for OrderID \"([^\"]*)\"$")
	public void verify_void_on_transaction_past_today_in_authorization_view_for_OrderID (String OrderID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "verify void on transaction past today in authorization view", "", "", "");
			String Result=financialactivity.verify_void_on_transaction_past_today_in_authorization_view_for_OrderID(OrderID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "verify void on transaction past today in authorization view", "Void should not be available for transaction past today in authorization view", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "verify void on transaction past today in authorization view", "Void should not be available for transaction past today in authorization view", Result, "Failed");
			}
		}
	}
	
	@Then("^user should be able to filter transaction in transaction view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_filter_transaction_in_transaction_view (String OrderID, String MerchantID, String StoreID, String Authcode, String txnID, String CardNumber, String ChannelType, String Txntype, String AmtFrom, String AmtTo) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "verify filter of transaction in transaction view", "", "", "");
			String Result=financialactivity.user_should_be_able_to_filter_transaction_in_transaction_view(OrderID, MerchantID, StoreID, Authcode, txnID, CardNumber, ChannelType, Txntype, AmtFrom, AmtTo);
			if(Result.contains("Failed"))
			{
			lib.WriteReportStep("2", "verify if user is able to filter transaction in transaction view", "User should be able to filter transaction in transaction view", Result, "Failed");
			}
			else
			{
			lib.WriteReportStep("2", "verify if user is able to filter transaction in transaction view", "User should be able to filter transaction in transaction view", Result, "Passed");
			}
		}
	}
	
	@Then("^user should be able to view refund button in transaction view \"([^\"]*)\"$")
	public void user_should_be_able_to_view_refund_button_in_transaction_view (String txnID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "verify Refund button transaction view", "", "", "");
			String Result=financialactivity.user_should_be_able_to_view_refund_button_in_transaction_view(txnID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "verify if user is able to view Refund button in transaction view", "User should be able to view Refund button in transaction view", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "verify if user is able to view Refund button in transaction view", "User should be able to view Refund button in transaction view", Result, "Failed");
			}
		}
	}
	
	@Then("^validate presence of void button in Preauth view for OrderID \"([^\"]*)\"$")
	public void validate_presence_of_void_button_in_Preauth_view_for_OrderID(String Order_ID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Validate presence of void button in Preauth view", "", "", "");
			String Result=financialactivity.validate_presence_of_void_button_in_Preauth_view_for_OrderID(Order_ID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Validate presence of void button in Preauth view", "User should successfuly be able to validate presence of void button in Preauth view", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Validate presence of void button in Preauth view", "User should successfuly be able to validate presence of void button in Preauth view", Result, "Failed");
			}
		}
	}
	
	@Then("^validate presence of void button in auth view for OrderID \"([^\"]*)\"$")
	public void validate_presence_of_void_button_in_auth_view_for_OrderID(String OrderID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Validate presence of void button in Authorization view", "", "", "");
			String Result=financialactivity.validate_presence_of_void_button_in_auth_view_for_OrderID(OrderID);
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Validate presence of void button in Authorization view", "User should successfuly be able to validate presence of void button in Authorization view", Result, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Validate presence of void button in Authorization view", "User should successfuly be able to validate presence of void button in Authorization view", Result, "Failed");
			}
		}
	}
	
	@Then("^user should be able to filter transaction in Authorisation view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_filter_transaction_in_Authorisation_view (String OrderID, String MerchantID, String StoreID, String Authcode, String CardNumber, String ChannelType, String Authtype, String AmtFrom, String AmtTo) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "verify filter of transaction in Authorisation view", "", "", "");
			String Result=financialactivity.user_should_be_able_to_filter_transaction_in_Authorisation_view(OrderID, MerchantID, StoreID, Authcode, CardNumber, ChannelType, Authtype, AmtFrom, AmtTo);
			if(Result.contains("Failed"))
			{
			lib.WriteReportStep("2", "verify if user is able to filter transaction in Authorisation view", "User should be able to filter transaction in Authorisation view", Result, "Failed");
			}
			else
			{
			lib.WriteReportStep("2", "verify if user is able to filter transaction in Authorisation view", "User should be able to filter transaction in Authorisation view", Result, "Passed");
			}
		}
	}
	
	@Then("^user should be able to filter transaction in Preauthorisation view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_filter_transaction_in_Preauthorisation_view (String OrderID, String MerchantID, String StoreID, String Preauthcode, String Reservationno, String CardNumber, String ChannelType, String Txntype, String AmtFrom, String AmtTo) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "verify filter of transaction in Preauthorisation view", "", "", "");
			String Result=financialactivity.user_should_be_able_to_filter_transaction_in_Preauthorisation_view(OrderID, MerchantID, StoreID, Preauthcode, Reservationno, CardNumber, ChannelType, Txntype, AmtFrom, AmtTo);
			if(Result.contains("Failed"))
			{
			lib.WriteReportStep("2", "verify if user is able to filter transaction in Preauthorisation view", "User should be able to filter transaction in Authorisation view", Result, "Failed");
			}
			else
			{
			lib.WriteReportStep("2", "verify if user is able to filter transaction in Preauthorisation view", "User should be able to filter transaction in Authorisation view", Result, "Passed");
			}
		}
	}
	
	@Then("^user should see Portal transaction data in corresponding language \"([^\"]*)\"$")
	public void user_should_see_Portal_transaction_data_in_corresponding_language (String PortalLanguage) throws Throwable {
		lib.WriteReportStep("1", "Verify display of transaction data in corresponding language", "", "", "");
		String Result=financialactivity.user_should_see_Portal_transaction_data_in_corresponding_language(PortalLanguage);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify display of transaction data in corresponding language", "User should be able to view transaction data in corresponding language", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify display of transaction data in corresponding language", "User should be able to view transaction data in corresponding language", Result, "Failed");
		}
	}
	
	@Then("^view Fees displayed in 3 decimal format in Transaction view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void view_Fees_displayed_in_3_decimal_format_in_Transaction_view (String FromDate, String ToDate, String TxnID) throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "verify if Fees is displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", "", "", "");
			String Result=financialactivity.view_Fees_displayed_in_3_decimal_format_in_Transaction_view(FromDate, ToDate, TxnID);
			if(Result.contains("Failed"))
			{
			lib.WriteReportStep("2", "verify if Fees is displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", "User should be able to view Fees displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", Result, "Failed");
			}
			else
			{
			lib.WriteReportStep("2", "verify if Fees is displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", "User should be able to view Fees displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", Result, "Passed");
			}
		}
	}

	@Then("^user should be able to view Preauthorisations in Preauth view$")
	public void user_should_be_able_to_view_Preauthorisations_in_Preauth_view() throws Throwable {
		if (Result1.contains("Passed"))
		{
			lib.WriteReportStep("1", "Verify if user is be able to view Preauthorisations in Preauth view", "", "", "");
			String Result=financialactivity.user_should_be_able_to_view_Preauthorisations_in_Preauth_view();
			if(Result.contains("Passed"))
			{
			lib.WriteReportStep("2", "Verify if user is be able to view Preauthorisations in Preauth view", "User should be able to view Preauthorisations in Preauth view","The PreAuth Details are:"+financialactivity.TempResult, "Passed");
			}
			else
			{
			lib.WriteReportStep("2", "Verify if user is be able to view Preauthorisations in Preauth view", "User should be able to view Preauthorisations in Preauth view", Result, "Failed");
			}
		}
	}
	@Then("^Logout from the application by providing \"([^\"]*)\"$")
	public void Logout_from_the_application(String Device) throws Throwable{
		if (Result1.contains("Passed"))
		{
		
		lib.WriteReportStep("1", "Verify BO should be able to Logout from the system", "", "", "");
		String Result=userManagementPage.logout(Device);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to Logout from the system","Verify BO should be able to Logout from the system", "Successfully Logout from the system "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to Logout from the system","Verify BO should be able to Logout from the system", "Failed to logout "+Result,"Failed");
		}
		}
	}
	
}
